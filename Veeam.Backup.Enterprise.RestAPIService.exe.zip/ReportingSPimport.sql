-----------------------------------------------------
--[dbo].[usp_Import_Folder_Host_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Folder_Host_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Folder_Host_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Folder_Host_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [host_id] uniqueidentifier,
       [folder_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [host_id], [folder_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [host_id] uniqueidentifier 'host_id',
       [folder_id] uniqueidentifier 'folder_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Folder_Host]
    SET
        [C.Folder_Host].[host_id] = src.[host_id],
        [C.Folder_Host].[folder_id] = src.[folder_id]
    FROM [C.Folder_Host] INNER JOIN @imported_changes src
    ON [C.Folder_Host].id = src.id    AND [C.Folder_Host].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Folder_Host]([id], [host_id], [folder_id], db_instance_id)
    SELECT
        src.[id],
        src.[host_id],
        src.[folder_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Folder_Host] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Folder_Host_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Folder_Host_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Folder_Host_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Folder_Host_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Folder_Host]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Folder_Host].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_ObjectsInJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_ObjectsInJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_ObjectsInJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_ObjectsInJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [type] int,
       [location] nvarchar(1024),
       [approx_size] bigint,
       [folder_id] uniqueidentifier,
       [id] uniqueidentifier,
       [job_id] uniqueidentifier,
       [object_id] uniqueidentifier,
       [vss_options] xml,
       [order_no] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([type], [location], [approx_size], [folder_id], [id], [job_id], [object_id], [vss_options], [order_no])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [type] int 'type',
       [location] nvarchar(1024) 'location',
       [approx_size] bigint 'approx_size',
       [folder_id] uniqueidentifier 'folder_id',
       [id] uniqueidentifier 'id',
       [job_id] uniqueidentifier 'job_id',
       [object_id] uniqueidentifier 'object_id',
       [vss_options] xml 'vss_options/*',
       [order_no] int 'order_no'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.ObjectsInJobs]
    SET
        [C.ObjectsInJobs].[type] = src.[type],
        [C.ObjectsInJobs].[location] = src.[location],
        [C.ObjectsInJobs].[approx_size] = src.[approx_size],
        [C.ObjectsInJobs].[folder_id] = src.[folder_id],
        [C.ObjectsInJobs].[job_id] = src.[job_id],
        [C.ObjectsInJobs].[object_id] = src.[object_id],
        [C.ObjectsInJobs].[vss_options] = src.[vss_options],
        [C.ObjectsInJobs].[order_no] = src.[order_no]
    FROM [C.ObjectsInJobs] INNER JOIN @imported_changes src
    ON [C.ObjectsInJobs].id = src.id    AND [C.ObjectsInJobs].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.ObjectsInJobs]([type], [location], [approx_size], [folder_id], [id], [job_id], [object_id], [vss_options], [order_no], db_instance_id)
    SELECT
        src.[type],
        src.[location],
        src.[approx_size],
        src.[folder_id],
        src.[id],
        src.[job_id],
        src.[object_id],
        src.[vss_options],
        src.[order_no],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.ObjectsInJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_ObjectsInJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_ObjectsInJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_ObjectsInJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_ObjectsInJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.ObjectsInJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.ObjectsInJobs].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Soap_creds_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Soap_creds_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Soap_creds_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Soap_creds_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [port] int,
       [enabled] bit,
       [useproxy] bit,
       [savepassword] bit,
       [proxyip] nvarchar(1024),
       [host_id] uniqueidentifier,
       [proxyport] int,
       [id] uniqueidentifier,
       [creds] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([port], [enabled], [useproxy], [savepassword], [proxyip], [host_id], [proxyport], [id], [creds])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [port] int 'port',
       [enabled] bit 'enabled',
       [useproxy] bit 'useproxy',
       [savepassword] bit 'savepassword',
       [proxyip] nvarchar(1024) 'proxyip',
       [host_id] uniqueidentifier 'host_id',
       [proxyport] int 'proxyport',
       [id] uniqueidentifier 'id',
       [creds] uniqueidentifier 'creds'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Soap_creds]
    SET
        [C.Soap_creds].[port] = src.[port],
        [C.Soap_creds].[enabled] = src.[enabled],
        [C.Soap_creds].[useproxy] = src.[useproxy],
        [C.Soap_creds].[savepassword] = src.[savepassword],
        [C.Soap_creds].[proxyip] = src.[proxyip],
        [C.Soap_creds].[host_id] = src.[host_id],
        [C.Soap_creds].[proxyport] = src.[proxyport],
        [C.Soap_creds].[creds] = src.[creds]
    FROM [C.Soap_creds] INNER JOIN @imported_changes src
    ON [C.Soap_creds].id = src.id    AND [C.Soap_creds].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Soap_creds]([port], [enabled], [useproxy], [savepassword], [proxyip], [host_id], [proxyport], [id], [creds], db_instance_id)
    SELECT
        src.[port],
        src.[enabled],
        src.[useproxy],
        src.[savepassword],
        src.[proxyip],
        src.[host_id],
        src.[proxyport],
        src.[id],
        src.[creds],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Soap_creds] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Soap_creds_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Soap_creds_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Soap_creds_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Soap_creds_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Soap_creds]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Soap_creds].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_BJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_BJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_BJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [latest_result] int,
       [target_type] int,
       [id] uniqueidentifier,
       [is_deleted] bit,
       [options] xml,
       [platform] int,
       [target_host_id] uniqueidentifier,
       [schedule] xml,
       [vss_options] xml,
       [target_file] nvarchar(2000),
       [vcb_host_id] uniqueidentifier,
       [description] nvarchar(1024),
       [name] nvarchar(255),
       [schedule_enabled] bit,
       [type] int,
       [target_dir] nvarchar(2000),
       [parent_schedule_id] uniqueidentifier,
       [repository_id] uniqueidentifier,
	   [pwd_key_id] uniqueidentifier,
       [next_run_time] datetime,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([latest_result], [target_type], [id], [is_deleted], [options], [platform], [target_host_id], [schedule], [vss_options], [target_file], [vcb_host_id], [description], [name], [schedule_enabled], [type], [target_dir], [parent_schedule_id], [repository_id], [pwd_key_id], [next_run_time])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [latest_result] int 'latest_result',
       [target_type] int 'target_type',
       [id] uniqueidentifier 'id',
       [is_deleted] bit 'is_deleted',
       [options] xml 'options/*',
       [platform] int 'platform',
       [target_host_id] uniqueidentifier 'target_host_id',
       [schedule] xml 'schedule/*',
       [vss_options] xml 'vss_options/*',
       [target_file] nvarchar(2000) 'target_file',
       [vcb_host_id] uniqueidentifier 'vcb_host_id',
       [description] nvarchar(1024) 'description',
       [name] nvarchar(255) 'name',
       [schedule_enabled] bit 'schedule_enabled',
       [type] int 'type',
       [target_dir] nvarchar(2000) 'target_dir',
       [parent_schedule_id] uniqueidentifier 'parent_schedule_id',
       [repository_id] uniqueidentifier 'repository_id',
	   [pwd_key_id] uniqueidentifier 'pwd_key_id',
       [next_run_time] datetime 'next_run_time'
    ) WHERE [type] < 100 OR [type] = 202; /* Do not import util jobs */
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET [next_run_time] = DATEADD( minute, -@TimeZoneShift, [next_run_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.BJobs]
    SET
        [C.BJobs].[latest_result] = src.[latest_result],
        [C.BJobs].[target_type] = src.[target_type],
        [C.BJobs].[is_deleted] = src.[is_deleted],
        [C.BJobs].[options] = src.[options],
        [C.BJobs].[platform] = src.[platform],
        [C.BJobs].[target_host_id] = src.[target_host_id],
        [C.BJobs].[schedule] = src.[schedule],
        [C.BJobs].[vss_options] = src.[vss_options],
        [C.BJobs].[target_file] = src.[target_file],
        [C.BJobs].[vcb_host_id] = src.[vcb_host_id],
        [C.BJobs].[description] = src.[description],
        [C.BJobs].[name] = src.[name],
        [C.BJobs].[schedule_enabled] = src.[schedule_enabled],
        [C.BJobs].[type] = src.[type],
        [C.BJobs].[target_dir] = src.[target_dir],
        [C.BJobs].[parent_schedule_id] = src.[parent_schedule_id],
        [C.BJobs].[repository_id] = src.[repository_id],
		[C.BJobs].[pwd_key_id] = src.[pwd_key_id],
        [C.BJobs].[next_run_time] = src.[next_run_time]
    FROM [C.BJobs] INNER JOIN @imported_changes src
    ON [C.BJobs].id = src.id    AND [C.BJobs].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.BJobs]([latest_result], [target_type], [id], [is_deleted], [options], [platform], [target_host_id], [schedule], [vss_options], [target_file], [vcb_host_id], [description], [name], [schedule_enabled], [type], [target_dir], [parent_schedule_id], [repository_id], [pwd_key_id], [next_run_time], db_instance_id)
    SELECT
        src.[latest_result],
        src.[target_type],
        src.[id],
        src.[is_deleted],
        src.[options],
        src.[platform],
        src.[target_host_id],
        src.[schedule],
        src.[vss_options],
        src.[target_file],
        src.[vcb_host_id],
        src.[description],
        src.[name],
        src.[schedule_enabled],
        src.[type],
        src.[target_dir],
        src.[parent_schedule_id],
        src.[repository_id],
		src.[pwd_key_id],
        src.[next_run_time],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.BJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_BJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_BJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_BJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.BJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.BJobs].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_BObjects_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BObjects_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_BObjects_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_BObjects_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [object_name] nvarchar(2000),
       [guest_os] xml,
       [host_id] uniqueidentifier,
       [object_id] nvarchar(434),
       [viobject_type] nvarchar(50),
       [type] int,
       [unique_key_hash] varbinary(max),
       [display_name] nvarchar(256),
       [platform] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [object_name], [guest_os], [host_id], [object_id], [viobject_type], [type], [unique_key_hash], [display_name], [platform])
    SELECT   
		T.id,
		T.object_name,
		T.guest_os,
		T.host_id,
		T.object_id,
		T.viobject_type,
		T.type,
		T.unique_key_hash.value('.', 'varbinary(max)'),
		T.display_name,
		T.platform
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [object_name] nvarchar(2000) 'object_name',
       [guest_os] xml 'guest_os/*',
       [host_id] uniqueidentifier 'host_id',
       [object_id] nvarchar(434) 'object_id',
       [viobject_type] nvarchar(50) 'viobject_type',
       [type] int 'type',
       [unique_key_hash] xml 'unique_key_hash',
       [display_name] nvarchar(256) 'display_name',
       [platform] int 'platform'
    )  as T
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId


	/* Update empty xml values */
	UPDATE @imported_changes 
	SET [guest_os] = '<GuestInfo />'
    WHERE [guest_os] IS NULL;

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.BObjects]
    SET
        [C.BObjects].[object_name] = src.[object_name],
        [C.BObjects].[guest_os] = src.[guest_os],
        [C.BObjects].[host_id] = src.[host_id],
        [C.BObjects].[object_id] = src.[object_id],
        [C.BObjects].[viobject_type] = src.[viobject_type],
        [C.BObjects].[type] = src.[type],
        [C.BObjects].[unique_key_hash] = src.[unique_key_hash],
        [C.BObjects].[display_name] = src.[display_name],
        [C.BObjects].[platform] = src.[platform]
    FROM [C.BObjects] INNER JOIN @imported_changes src
    ON [C.BObjects].id = src.id    AND [C.BObjects].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.BObjects]([id], [object_name], [guest_os], [host_id], [object_id], [viobject_type], [type], [unique_key_hash], [display_name], [platform], db_instance_id)
    SELECT
        src.[id],
        src.[object_name],
        src.[guest_os],
        src.[host_id],
        src.[object_id],
        src.[viobject_type],
        src.[type],
        src.[unique_key_hash],
        src.[display_name],
        src.[platform],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.BObjects] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_BObjects_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BObjects_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_BObjects_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_BObjects_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.BObjects]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.BObjects].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_Backups_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_Backups_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_Backups_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_Backups_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [job_source_type] int,
       [id] uniqueidentifier,
       [job_name] nvarchar(255),
       [job_target_host_protocol] int,
       [job_target_host_id] uniqueidentifier,
       [job_target_type] int,
       [job_id] uniqueidentifier,
       [repository_id] uniqueidentifier,
       [platform] int,
       [target_type] int,
       [dir_path] nvarchar(max),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([job_source_type], [id], [job_name], [job_target_host_protocol], [job_target_host_id], [job_target_type], [job_id], [repository_id], [platform], [target_type], [dir_path])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [job_source_type] int 'job_source_type',
       [id] uniqueidentifier 'id',
       [job_name] nvarchar(255) 'job_name',
       [job_target_host_protocol] int 'job_target_host_protocol',
       [job_target_host_id] uniqueidentifier 'job_target_host_id',
       [job_target_type] int 'job_target_type',
       [job_id] uniqueidentifier 'job_id',
       [repository_id] uniqueidentifier 'repository_id',
       [platform] int 'platform',
       [target_type] int 'target_type',
       [dir_path] nvarchar(max) 'dir_path'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.Backups]
    SET
        [C.Backup.Model.Backups].[job_source_type] = src.[job_source_type],
        [C.Backup.Model.Backups].[job_name] = src.[job_name],
        [C.Backup.Model.Backups].[job_target_host_protocol] = src.[job_target_host_protocol],
        [C.Backup.Model.Backups].[job_target_host_id] = src.[job_target_host_id],
        [C.Backup.Model.Backups].[job_target_type] = src.[job_target_type],
        [C.Backup.Model.Backups].[job_id] = src.[job_id],
        [C.Backup.Model.Backups].[repository_id] = src.[repository_id],
        [C.Backup.Model.Backups].[platform] = src.[platform],
        [C.Backup.Model.Backups].[target_type] = src.[target_type],
        [C.Backup.Model.Backups].[dir_path] = src.[dir_path]
    FROM [C.Backup.Model.Backups] INNER JOIN @imported_changes src
    ON [C.Backup.Model.Backups].id = src.id    AND [C.Backup.Model.Backups].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.Backups]([job_source_type], [id], [job_name], [job_target_host_protocol], [job_target_host_id], [job_target_type], [job_id], [repository_id], [platform], [target_type], [dir_path], db_instance_id)
    SELECT
        src.[job_source_type],
        src.[id],
        src.[job_name],
        src.[job_target_host_protocol],
        src.[job_target_host_id],
        src.[job_target_type],
        src.[job_id],
        src.[repository_id],
        src.[platform],
        src.[target_type],
        src.[dir_path],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.Backups] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_Backups_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_Backups_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_Backups_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_Backups_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.Backups]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.Backups].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_Storages_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_Storages_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_Storages_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_Storages_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [block_size] int,
       [backup_id] uniqueidentifier,
       [stats] xml,
       [modification_time] datetime,
       [version] int,
       [id] uniqueidentifier,
       [file_path] nvarchar(1000),
       [creation_time] datetime,
       [host_id] uniqueidentifier,
       [full_size] bigint,
	   [availability] smallint,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([block_size], [backup_id], [stats], [modification_time], [version], [id], [file_path], [creation_time], [host_id], [full_size], [availability])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [block_size] int 'block_size',
       [backup_id] uniqueidentifier 'backup_id',
       [stats] xml 'stats/*',
       [modification_time] datetime 'modification_time',
       [version] int 'version',
       [id] uniqueidentifier 'id',
       [file_path] nvarchar(1000) 'file_path',
       [creation_time] datetime 'creation_time',
       [host_id] uniqueidentifier 'host_id',
       [full_size] bigint 'full_size',
	   [availability] smallint 'availability'
    )
    EXEC sp_xml_removedocument @idoc

        DECLARE @cur_backup_id uniqueidentifier
        SET @cur_backup_id = (SELECT TOP(1) id FROM @imported_changes WHERE full_size IS NULL)
        WHILE @cur_backup_id IS NOT NULL
        BEGIN
		    DECLARE @xml XML
		    SET @xml = (SELECT TOP(1) stats FROM @imported_changes WHERE id = @cur_backup_id)

		    IF @xml IS NULL
			    UPDATE @imported_changes
			    SET full_size = 0
			    WHERE id = @cur_backup_id
		    ELSE
			    BEGIN
				    EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

				    UPDATE @imported_changes
				    SET full_size = 
					    (SELECT
						    CASE
							    WHEN size IS NULL THEN 0
							    ELSE size
						    END
					    FROM OPENXML( @idoc, 'stats/CBackupStats/BackupSize', 3)
					    WITH (size bigint 'text()'))
				    WHERE id = @cur_backup_id
				
				    UPDATE @imported_changes
				    SET full_size = 0
				    WHERE id = @cur_backup_id AND full_size IS NULL

				    EXEC sp_xml_removedocument @idoc
			    END
		
		    SET @cur_backup_id = (SELECT TOP(1) id FROM @imported_changes WHERE full_size IS NULL)
        END


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET
        [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time]),
        [modification_time] = DATEADD( minute, -@TimeZoneShift, [modification_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.Storages]
    SET
        [C.Backup.Model.Storages].[block_size] = src.[block_size],
        [C.Backup.Model.Storages].[backup_id] = src.[backup_id],
        [C.Backup.Model.Storages].[stats] = src.[stats],
        [C.Backup.Model.Storages].[modification_time] = src.[modification_time],
        [C.Backup.Model.Storages].[version] = src.[version],
        [C.Backup.Model.Storages].[file_path] = src.[file_path],
        [C.Backup.Model.Storages].[creation_time] = src.[creation_time],
        [C.Backup.Model.Storages].[host_id] = src.[host_id],
        [C.Backup.Model.Storages].[full_size] = src.[full_size],
        [C.Backup.Model.Storages].[availability] = src.[availability]
		
    FROM [C.Backup.Model.Storages] INNER JOIN @imported_changes src
    ON [C.Backup.Model.Storages].id = src.id    AND [C.Backup.Model.Storages].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.Storages]([block_size], [backup_id], [stats], [modification_time], [version], [id], [file_path], [creation_time], [host_id], [full_size], [availability], db_instance_id)
    SELECT
        src.[block_size],
        src.[backup_id],
        src.[stats],
        src.[modification_time],
        src.[version],
        src.[id],
        src.[file_path],
        src.[creation_time],
        src.[host_id],
        src.[full_size],
		src.[availability],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.Storages] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_Storages_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_Storages_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_Storages_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_Storages_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.Storages]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.Storages].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_HostsByJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_HostsByJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_HostsByJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_HostsByJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [job_id] uniqueidentifier,
       [host_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([job_id], [host_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [job_id] uniqueidentifier 'job_id',
       [host_id] uniqueidentifier 'host_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.HostsByJobs]
    SET
        [C.HostsByJobs].[job_id] = src.[job_id],
        [C.HostsByJobs].[host_id] = src.[host_id]
    FROM [C.HostsByJobs] INNER JOIN @imported_changes src
    ON [C.HostsByJobs].id = src.id    AND [C.HostsByJobs].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.HostsByJobs]([job_id], [host_id], [id], db_instance_id)
    SELECT
        src.[job_id],
        src.[host_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.HostsByJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_HostsByJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_HostsByJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_HostsByJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_HostsByJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.HostsByJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.HostsByJobs].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_Points_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_Points_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_Points_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_Points_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [link_id] uniqueidentifier,
       [num] numeric,
       [id] uniqueidentifier,
       [alg] int,
       [backup_id] uniqueidentifier,
       [group_id] uniqueidentifier,
       [type] int,
       [creation_time] datetime,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([link_id], [num], [id], [alg], [backup_id], [group_id], [type], [creation_time])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [link_id] uniqueidentifier 'link_id',
       [num] numeric 'num',
       [id] uniqueidentifier 'id',
       [alg] int 'alg',
       [backup_id] uniqueidentifier 'backup_id',
       [group_id] uniqueidentifier 'group_id',
       [type] int 'type',
       [creation_time] datetime 'creation_time'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET[creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.Points]
    SET
        [C.Backup.Model.Points].[link_id] = src.[link_id],
        [C.Backup.Model.Points].[num] = src.[num],
        [C.Backup.Model.Points].[alg] = src.[alg],
        [C.Backup.Model.Points].[backup_id] = src.[backup_id],
        [C.Backup.Model.Points].[group_id] = src.[group_id],
        [C.Backup.Model.Points].[type] = src.[type],
        [C.Backup.Model.Points].[creation_time] = src.[creation_time]
    FROM [C.Backup.Model.Points] INNER JOIN @imported_changes src
    ON [C.Backup.Model.Points].id = src.id    AND [C.Backup.Model.Points].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.Points]([link_id], [num], [id], [alg], [backup_id], [group_id], [type], [creation_time], db_instance_id)
    SELECT
        src.[link_id],
        src.[num],
        src.[id],
        src.[alg],
        src.[backup_id],
        src.[group_id],
        src.[type],
        src.[creation_time],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.Points] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_Points_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_Points_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_Points_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_Points_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.Points]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.Points].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Ssh_creds_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Ssh_creds_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Ssh_creds_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Ssh_creds_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [adjust_firewall] bit,
       [isftserver] bit,
       [endftport] int,
       [auto_sudo] bit,
       [port] int,
       [enabled] bit,
       [startftport] int,
       [timeout] int,
       [elevatetoroot] bit,
       [buffersize] int,
       [id] uniqueidentifier,
       [creds] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([adjust_firewall], [isftserver], [endftport], [auto_sudo], [port], [enabled], [startftport], [timeout], [elevatetoroot], [buffersize], [id], [creds])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [adjust_firewall] bit 'adjust_firewall',
       [isftserver] bit 'isftserver',
       [endftport] int 'endftport',
       [auto_sudo] bit 'auto_sudo',
       [port] int 'port',
       [enabled] bit 'enabled',
       [startftport] int 'startftport',
       [timeout] int 'timeout',
       [elevatetoroot] bit 'elevatetoroot',
       [buffersize] int 'buffersize',
       [id] uniqueidentifier 'id',
       [creds] uniqueidentifier 'creds'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Ssh_creds]
    SET
        [C.Ssh_creds].[adjust_firewall] = src.[adjust_firewall],
        [C.Ssh_creds].[isftserver] = src.[isftserver],
        [C.Ssh_creds].[endftport] = src.[endftport],
        [C.Ssh_creds].[auto_sudo] = src.[auto_sudo],
        [C.Ssh_creds].[port] = src.[port],
        [C.Ssh_creds].[enabled] = src.[enabled],
        [C.Ssh_creds].[startftport] = src.[startftport],
        [C.Ssh_creds].[timeout] = src.[timeout],
        [C.Ssh_creds].[elevatetoroot] = src.[elevatetoroot],
        [C.Ssh_creds].[buffersize] = src.[buffersize],
        [C.Ssh_creds].[creds] = src.[creds]
    FROM [C.Ssh_creds] INNER JOIN @imported_changes src
    ON [C.Ssh_creds].id = src.id    AND [C.Ssh_creds].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Ssh_creds]([adjust_firewall], [isftserver], [endftport], [auto_sudo], [port], [enabled], [startftport], [timeout], [elevatetoroot], [buffersize], [id], [creds], db_instance_id)
    SELECT
        src.[adjust_firewall],
        src.[isftserver],
        src.[endftport],
        src.[auto_sudo],
        src.[port],
        src.[enabled],
        src.[startftport],
        src.[timeout],
        src.[elevatetoroot],
        src.[buffersize],
        src.[id],
        src.[creds],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Ssh_creds] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Ssh_creds_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Ssh_creds_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Ssh_creds_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Ssh_creds_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Ssh_creds]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Ssh_creds].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_OIBs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_OIBs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_OIBs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_OIBs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [has_index] bit,
       [has_exchange] bit,
       [type] int,
       [is_corrupted] bit,
       [alg] int,
       [creation_time] datetime,
       [is_consistent] bit,
       [storage_id] uniqueidentifier,
       [inside_dir] nvarchar(400),
       [state] int,
       [id] uniqueidentifier,
       [guest_os_info] xml,
       [memory] bigint,
       [point_id] uniqueidentifier,
       [link_id] uniqueidentifier,
       [approx_size] bigint,
       [vmname] nvarchar(1000),
       [process_id] int,
       [object_id] uniqueidentifier,
       [aux_data] xml,
       [display_name] nvarchar(256),
       [original_oib_id] uniqueidentifier,
	   [fqdn] nvarchar(255),
	   [has_sql] bit,
	   [parent_id] uniqueidentifier,
	   [is_recheck_corrupted] bit,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([has_index], [has_exchange], [type], [is_corrupted], [alg], [creation_time], [is_consistent], [storage_id], [inside_dir], [state], [id], [guest_os_info], [memory], [point_id], [link_id], [approx_size], [vmname], [process_id], [object_id], [aux_data], [display_name], [original_oib_id],[fqdn], [has_sql], [parent_id], [is_recheck_corrupted])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [has_index] bit 'has_index',
       [has_exchange] bit 'has_exchange',
       [type] int 'type',
       [is_corrupted] bit 'is_corrupted',
       [alg] int 'alg',
       [creation_time] datetime 'creation_time',
       [is_consistent] bit 'is_consistent',
       [storage_id] uniqueidentifier 'storage_id',
       [inside_dir] nvarchar(400) 'inside_dir',
       [state] int 'state',
       [id] uniqueidentifier 'id',
       [guest_os_info] xml 'guest_os_info/*',
       [memory] bigint 'memory',
       [point_id] uniqueidentifier 'point_id',
       [link_id] uniqueidentifier 'link_id',
       [approx_size] bigint 'approx_size',
       [vmname] nvarchar(1000) 'vmname',
       [process_id] int 'process_id',
       [object_id] uniqueidentifier 'object_id',
       [aux_data] xml 'aux_data/*',
       [display_name] nvarchar(256) 'display_name',
       [original_oib_id] uniqueidentifier 'original_oib_id',
	   [fqdn] nvarchar(255) 'fqdn',
	   [has_sql] bit 'has_sql',
	   [parent_id] uniqueidentifier 'parent_id',
	   [is_recheck_corrupted] bit 'is_recheck_corrupted'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.OIBs]
    SET
        [C.Backup.Model.OIBs].[has_index] = src.[has_index],
        [C.Backup.Model.OIBs].[has_exchange] = src.[has_exchange],
        [C.Backup.Model.OIBs].[type] = src.[type],
        [C.Backup.Model.OIBs].[is_corrupted] = src.[is_corrupted],
        [C.Backup.Model.OIBs].[alg] = src.[alg],
        [C.Backup.Model.OIBs].[creation_time] = src.[creation_time],
        [C.Backup.Model.OIBs].[is_consistent] = src.[is_consistent],
        [C.Backup.Model.OIBs].[storage_id] = src.[storage_id],
        [C.Backup.Model.OIBs].[inside_dir] = src.[inside_dir],
        [C.Backup.Model.OIBs].[state] = src.[state],
        [C.Backup.Model.OIBs].[guest_os_info] = src.[guest_os_info],
        [C.Backup.Model.OIBs].[memory] = src.[memory],
        [C.Backup.Model.OIBs].[point_id] = src.[point_id],
        [C.Backup.Model.OIBs].[link_id] = src.[link_id],
        [C.Backup.Model.OIBs].[approx_size] = src.[approx_size],
        [C.Backup.Model.OIBs].[vmname] = src.[vmname],
        [C.Backup.Model.OIBs].[process_id] = src.[process_id],
        [C.Backup.Model.OIBs].[object_id] = src.[object_id],
        [C.Backup.Model.OIBs].[aux_data] = src.[aux_data],
        [C.Backup.Model.OIBs].[display_name] = src.[display_name],
        [C.Backup.Model.OIBs].[original_oib_id] = src.[original_oib_id],
		[C.Backup.Model.OIBs].[fqdn]  = src.[fqdn],
		[C.Backup.Model.OIBs].[has_sql] = src.[has_sql],
		[C.Backup.Model.OIBs].[parent_id] = src.[parent_id],
		[C.Backup.Model.OIBS].[is_recheck_corrupted] = src.[is_recheck_corrupted]
    FROM [C.Backup.Model.OIBs] INNER JOIN @imported_changes src
    ON [C.Backup.Model.OIBs].id = src.id    AND [C.Backup.Model.OIBs].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.OIBs]([has_index], [has_exchange], [type], [is_corrupted], [alg], [creation_time], [is_consistent], [storage_id], [inside_dir], [state], [id], [guest_os_info], [memory], [point_id], [link_id], [approx_size], [vmname], [process_id], [object_id], [aux_data], [display_name], [original_oib_id], [fqdn], [has_sql], [parent_id], [is_recheck_corrupted], db_instance_id)
    SELECT
        src.[has_index],
        src.[has_exchange],
        src.[type],
        src.[is_corrupted],
        src.[alg],
        src.[creation_time],
        src.[is_consistent],
        src.[storage_id],
        src.[inside_dir],
        src.[state],
        src.[id],
        src.[guest_os_info],
        src.[memory],
        src.[point_id],
        src.[link_id],
        src.[approx_size],
        src.[vmname],
        src.[process_id],
        src.[object_id],
        src.[aux_data],
        src.[display_name],
        src.[original_oib_id],
		src.[fqdn],
		src.[has_sql],
		src.[parent_id],
		src.[is_recheck_corrupted],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.OIBs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_OIBs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_OIBs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_OIBs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_OIBs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.OIBs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_LicensedHosts_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_LicensedHosts_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_LicensedHosts_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_LicensedHosts_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [lic_edition] int,
       [is_licensed] bit,
       [type] int,
       [id] uniqueidentifier,
       [physical_host_id] uniqueidentifier,
       [lic_tier] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([lic_edition], [is_licensed], [type], [id], [physical_host_id], [lic_tier])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [lic_edition] int 'lic_edition',
       [is_licensed] bit 'is_licensed',
       [type] int 'type',
       [id] uniqueidentifier 'id',
       [physical_host_id] uniqueidentifier 'physical_host_id',
       [lic_tier] int 'lic_tier'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.LicensedHosts]
    SET
        [C.LicensedHosts].[lic_edition] = src.[lic_edition],
        [C.LicensedHosts].[is_licensed] = src.[is_licensed],
        [C.LicensedHosts].[type] = src.[type],
        [C.LicensedHosts].[physical_host_id] = src.[physical_host_id],
        [C.LicensedHosts].[lic_tier] = src.[lic_tier]
    FROM [C.LicensedHosts] INNER JOIN @imported_changes src
    ON [C.LicensedHosts].id = src.id    AND [C.LicensedHosts].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.LicensedHosts]([lic_edition], [is_licensed], [type], [id], [physical_host_id], [lic_tier], db_instance_id)
    SELECT
        src.[lic_edition],
        src.[is_licensed],
        src.[type],
        src.[id],
        src.[physical_host_id],
        src.[lic_tier],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.LicensedHosts] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_LicensedHosts_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_LicensedHosts_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_LicensedHosts_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_LicensedHosts_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.LicensedHosts]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.LicensedHosts].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Hosts_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Hosts_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Hosts_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Hosts_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [description] nvarchar(1024),
       [protocol] int,
       [info] nvarchar(255),
       [ip] nvarchar(50),
       [parent_id] uniqueidentifier,
       [api_version] int,
       [type] int,
       [win_creds] xml,
       [id] uniqueidentifier,
       [name] nvarchar(255),
       [reference] nvarchar(1024),
       [host_instance_id] varchar(255),
       [physical_host_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([description], [protocol], [info], [ip], [parent_id], [api_version], [type], [win_creds], [id], [name], [reference], [host_instance_id], [physical_host_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [description] nvarchar(1024) 'description',
       [protocol] int 'protocol',
       [info] nvarchar(255) 'info',
       [ip] nvarchar(50) 'ip',
       [parent_id] uniqueidentifier 'parent_id',
       [api_version] int 'api_version',
       [type] int 'type',
       [win_creds] xml 'win_creds',
       [id] uniqueidentifier 'id',
       [name] nvarchar(255) 'name',
       [reference] nvarchar(1024) 'reference',
       [host_instance_id] varchar(255) 'host_instance_id',
       [physical_host_id] uniqueidentifier 'physical_host_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */

	/*  UPDATE HOST INSTANCE IF CHANGED */

	declare @changed_host_instance_id_rows table ( old_id varchar(255), new_id varchar(255));
	
	INSERT INTO @changed_host_instance_id_rows (old_id, new_id)
	SELECT  [C.Hosts].[host_instance_id], src.[host_instance_id]
	FROM  [C.Hosts] INNER JOIN @imported_changes src ON [C.Hosts].id = src.id
	WHERE [C.Hosts].[host_instance_id] != src.[host_instance_id]
	GROUP BY [C.Hosts].[host_instance_id], src.[host_instance_id]

	
	/*             UPDATE EXISTING ROWS     */
    UPDATE [C.Hosts]
    SET
        [C.Hosts].[description] = src.[description],
        [C.Hosts].[protocol] = src.[protocol],
        [C.Hosts].[info] = src.[info],
        [C.Hosts].[ip] = src.[ip],
        [C.Hosts].[parent_id] = src.[parent_id],
        [C.Hosts].[api_version] = src.[api_version],
        [C.Hosts].[type] = src.[type],
        [C.Hosts].[win_creds] = src.[win_creds],
        [C.Hosts].[name] = src.[name],
        [C.Hosts].[reference] = src.[reference],
        [C.Hosts].[host_instance_id] = src.[host_instance_id],
        [C.Hosts].[physical_host_id] = src.[physical_host_id]
    FROM [C.Hosts] INNER JOIN @imported_changes src
    ON [C.Hosts].id = src.id    AND [C.Hosts].db_instance_id = @dbInstanceId

       /* UPDATE hierarchy scope */

     UPDATE [dbo].[Security.HierarchyScopes]
     SET [hierarchy_root_instance_id] = changed.new_id,
     [hierarchy_object_keyhash] = [dbo].[fn.Backup.MakeObjectHash]([hierarchy_object_ref], changed.new_id),
     [scope_state] = 0
     FROM   [dbo].[Security.HierarchyScopes]  INNER JOIN @changed_host_instance_id_rows changed 
     ON ([dbo].[Security.HierarchyScopes].hierarchy_root_instance_id = changed.old_id)

  /*      INSERT NEW ROWS       */
    INSERT INTO [C.Hosts]([description], [protocol], [info], [ip], [parent_id], [api_version], [type], [win_creds], [id], [name], [reference], [host_instance_id], [physical_host_id], db_instance_id)
    SELECT
        src.[description],
        src.[protocol],
        src.[info],
        src.[ip],
        src.[parent_id],
        src.[api_version],
        src.[type],
        src.[win_creds],
        src.[id],
        src.[name],
        src.[reference],
        src.[host_instance_id],
        src.[physical_host_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Hosts] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Hosts_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Hosts_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Hosts_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Hosts_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Hosts]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
	AND [dbo].[C.Hosts].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Folders_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Folders_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Folders_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Folders_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [name] nvarchar(255),
       [parent_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([name], [parent_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [name] nvarchar(255) 'name',
       [parent_id] uniqueidentifier 'parent_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Folders]
    SET
        [C.Folders].[name] = src.[name],
        [C.Folders].[parent_id] = src.[parent_id]
    FROM [C.Folders] INNER JOIN @imported_changes src
    ON [C.Folders].id = src.id    AND [C.Folders].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Folders]([name], [parent_id], [id], db_instance_id)
    SELECT
        src.[name],
        src.[parent_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Folders] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Folders_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Folders_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Folders_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Folders_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Folders]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Folders].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_VirtualLabs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_VirtualLabs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_VirtualLabs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_VirtualLabs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [host_id] uniqueidentifier,
       [vm_ref] nvarchar(1024),
       [description] nvarchar(255),
       [name] nvarchar(255),
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([host_id], [vm_ref], [description], [name], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [host_id] uniqueidentifier 'host_id',
       [vm_ref] nvarchar(1024) 'vm_ref',
       [description] nvarchar(255) 'description',
       [name] nvarchar(255) 'name',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.VirtualLabs]
    SET
        [C.VirtualLabs].[host_id] = src.[host_id],
        [C.VirtualLabs].[vm_ref] = src.[vm_ref],
        [C.VirtualLabs].[description] = src.[description],
        [C.VirtualLabs].[name] = src.[name]
    FROM [C.VirtualLabs] INNER JOIN @imported_changes src
    ON [C.VirtualLabs].id = src.id    AND [C.VirtualLabs].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.VirtualLabs]([host_id], [vm_ref], [description], [name], [id], db_instance_id)
    SELECT
        src.[host_id],
        src.[vm_ref],
        src.[description],
        src.[name],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.VirtualLabs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_VirtualLabs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_VirtualLabs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_VirtualLabs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_VirtualLabs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.VirtualLabs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.VirtualLabs].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_ObjectsInApplicationGroups_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_ObjectsInApplicationGroups_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_ObjectsInApplicationGroups_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_ObjectsInApplicationGroups_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [effective_memory] bigint,
       [guest_os_info] xml,
       [options] xml,
       [id] uniqueidentifier,
       [order] int,
       [object_id] uniqueidentifier,
       [folder_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([effective_memory], [guest_os_info], [options], [id], [order], [object_id], [folder_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [effective_memory] bigint 'effective_memory',
       [guest_os_info] xml 'guest_os_info',
       [options] xml 'options/*',
       [id] uniqueidentifier 'id',
       [order] int 'order',
       [object_id] uniqueidentifier 'object_id',
       [folder_id] uniqueidentifier 'folder_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.ObjectsInApplicationGroups]
    SET
        [C.ObjectsInApplicationGroups].[effective_memory] = src.[effective_memory],
        [C.ObjectsInApplicationGroups].[guest_os_info] = src.[guest_os_info],
        [C.ObjectsInApplicationGroups].[options] = src.[options],
        [C.ObjectsInApplicationGroups].[order] = src.[order],
        [C.ObjectsInApplicationGroups].[object_id] = src.[object_id],
        [C.ObjectsInApplicationGroups].[folder_id] = src.[folder_id]
    FROM [C.ObjectsInApplicationGroups] INNER JOIN @imported_changes src
    ON [C.ObjectsInApplicationGroups].id = src.id    AND [C.ObjectsInApplicationGroups].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.ObjectsInApplicationGroups]([effective_memory], [guest_os_info], [options], [id], [order], [object_id], [folder_id], db_instance_id)
    SELECT
        src.[effective_memory],
        src.[guest_os_info],
        src.[options],
        src.[id],
        src.[order],
        src.[object_id],
        src.[folder_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.ObjectsInApplicationGroups] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_ObjectsInApplicationGroups_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_ObjectsInApplicationGroups_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_ObjectsInApplicationGroups_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_ObjectsInApplicationGroups_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.ObjectsInApplicationGroups]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.ObjectsInApplicationGroups].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_DRRoles_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_DRRoles_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_DRRoles_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_DRRoles_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [effective_memory] bigint,
       [id] uniqueidentifier,
       [boot_delay] int,
       [test_script_file_full_name] nvarchar(max),
       [name] nvarchar(max),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([effective_memory], [id], [boot_delay], [test_script_file_full_name], [name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [effective_memory] bigint 'effective_memory',
       [id] uniqueidentifier 'id',
       [boot_delay] int 'boot_delay',
       [test_script_file_full_name] nvarchar(max) 'test_script_file_full_name',
       [name] nvarchar(max) 'name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.DRRoles]
    SET
        [C.DRRoles].[effective_memory] = src.[effective_memory],
        [C.DRRoles].[boot_delay] = src.[boot_delay],
        [C.DRRoles].[test_script_file_full_name] = src.[test_script_file_full_name],
        [C.DRRoles].[name] = src.[name]
    FROM [C.DRRoles] INNER JOIN @imported_changes src
    ON [C.DRRoles].id = src.id    AND [C.DRRoles].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.DRRoles]([effective_memory], [id], [boot_delay], [test_script_file_full_name], [name], db_instance_id)
    SELECT
        src.[effective_memory],
        src.[id],
        src.[boot_delay],
        src.[test_script_file_full_name],
        src.[name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.DRRoles] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_DRRoles_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_DRRoles_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_DRRoles_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_DRRoles_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.DRRoles]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.DRRoles].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_JobSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_JobSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_JobSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_JobSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [log_xml] xml,
       [progress] int,
       [job_name] nvarchar(255),
       [result] int,
       [job_id] uniqueidentifier,
       [state] int,
       [job_type] int,
       [creation_time] datetime,
       [id] uniqueidentifier,
       [end_time] datetime,
       [operation] nvarchar(400),
       [control] int,
       [description] text,
       [log_text] ntext,
	   [usn] bigint,
	   [initiator_sid] nvarchar(255),
	   [initiator_name] nvarchar(255),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([log_xml], [progress], [job_name], [result], [job_id], [state], [job_type], [creation_time], [id], [end_time], [operation], [control], [description], [log_text], [usn], [initiator_sid], [initiator_name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [log_xml] xml 'log_xml/*',
       [progress] int 'progress',
       [job_name] nvarchar(255) 'job_name',
       [result] int 'result',
       [job_id] uniqueidentifier 'job_id',
       [state] int 'state',
       [job_type] int 'job_type',
       [creation_time] datetime 'creation_time',
       [id] uniqueidentifier 'id',
       [end_time] datetime 'end_time',
       [operation] nvarchar(400) 'operation',
       [control] int 'control',
       [description] text 'description',
       [log_text] ntext 'log_text',
	   [usn] bigint 'usn',
	   [initiator_sid] nvarchar(255) 'initiator_sid',
	   [initiator_name] nvarchar(255) 'initiator_name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET        
        [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time]),
        [end_time] = DATEADD( minute, -@TimeZoneShift, [end_time])


    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.JobSessions]
    SET
        [C.Backup.Model.JobSessions].[log_xml] = src.[log_xml],
        [C.Backup.Model.JobSessions].[progress] = src.[progress],
        [C.Backup.Model.JobSessions].[job_name] = src.[job_name],
        [C.Backup.Model.JobSessions].[result] = src.[result],
        [C.Backup.Model.JobSessions].[job_id] = src.[job_id],
        [C.Backup.Model.JobSessions].[state] = src.[state],
        [C.Backup.Model.JobSessions].[job_type] = src.[job_type],
        [C.Backup.Model.JobSessions].[creation_time] = src.[creation_time],
        [C.Backup.Model.JobSessions].[end_time] = src.[end_time],
        [C.Backup.Model.JobSessions].[operation] = src.[operation],
        [C.Backup.Model.JobSessions].[control] = src.[control],
        [C.Backup.Model.JobSessions].[description] = src.[description],
        [C.Backup.Model.JobSessions].[log_text] = src.[log_text],
		[C.Backup.Model.JobSessions].[usn] = src.[usn],
		[C.Backup.Model.JobSessions].[initiator_sid] = src.[initiator_sid],
		[C.Backup.Model.JobSessions].[initiator_name] = src.[initiator_name]
    FROM [C.Backup.Model.JobSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.JobSessions].id = src.id    AND [C.Backup.Model.JobSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.JobSessions]([log_xml], [progress], [job_name], [result], [job_id], [state], [job_type], [creation_time], [id], [end_time], [operation], [control], [description], [log_text], [usn], [initiator_sid], [initiator_name], db_instance_id)
    SELECT
        src.[log_xml],
        src.[progress],
        src.[job_name],
        src.[result],
        src.[job_id],
        src.[state],
        src.[job_type],
        src.[creation_time],
        src.[id],
        src.[end_time],
        src.[operation],
        src.[control],
        src.[description],
        src.[log_text],
		src.[usn],
		src.[initiator_sid],
		src.[initiator_name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.JobSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_JobSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_JobSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_JobSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_JobSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.JobSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.JobSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_SbTaskSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_SbTaskSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_SbTaskSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_SbTaskSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [order_num] int,
       [object_id] uniqueidentifier,
       [description] nvarchar(max),
       [powerOn_status] int,
       [restore_counter] int,
       [ping_status] int,
       [appliance_ip] nvarchar(80),
       [subnet_ip] nvarchar(80),
       [subnet_mask] nvarchar(80),
       [vm_ref] nvarchar(max),
       [state] int,
       [start_time] datetime,
       [drsession_id] uniqueidentifier,
       [total_steps] int,
       [percent] int,
       [finish_time] datetime,
       [object_name] nvarchar(max),
       [id] uniqueidentifier,
       [oib_id] uniqueidentifier,
       [heartbeat_status] int,
       [overall_status] int,
       [control] int,
       [type] int,
       [test_script_error_code] int,
       [powerOff_status] int,
       [vm_external_ip] nvarchar(80),
       [test_script_status] int,
       [test_scripts_results] xml,
       [oiag_id] uniqueidentifier,
       [processed_steps] int,
       [leave_powered_on] bit,
       [validation_status] int,
       [log_xml] xml,
       [db_instance_id] uniqueidentifier,
	   [usn] bigint
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([order_num], [object_id], [description], [powerOn_status], [restore_counter], [ping_status], [appliance_ip], [subnet_ip], [subnet_mask], [vm_ref], [state], [start_time], [drsession_id], [total_steps], [percent], [finish_time], [object_name], [id], [oib_id], [heartbeat_status], [overall_status], [control], [type], [test_script_error_code], [powerOff_status], [vm_external_ip], [test_script_status], [test_scripts_results], [oiag_id], [processed_steps], [leave_powered_on], [validation_status], [log_xml], [usn])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [order_num] int 'order_num',
       [object_id] uniqueidentifier 'object_id',
       [description] nvarchar(max) 'description',
       [powerOn_status] int 'powerOn_status',
       [restore_counter] int 'restore_counter',
       [ping_status] int 'ping_status',
       [appliance_ip] nvarchar(80) 'appliance_ip',
       [subnet_ip] nvarchar(80) 'subnet_ip',
       [subnet_mask] nvarchar(80) 'subnet_mask',
       [vm_ref] nvarchar(max) 'vm_ref',
       [state] int 'state',
       [start_time] datetime 'start_time',
       [drsession_id] uniqueidentifier 'drsession_id',
       [total_steps] int 'total_steps',
       [percent] int 'percent',
       [finish_time] datetime 'finish_time',
       [object_name] nvarchar(max) 'object_name',
       [id] uniqueidentifier 'id',
       [oib_id] uniqueidentifier 'oib_id',
       [heartbeat_status] int 'heartbeat_status',
       [overall_status] int 'overall_status',
       [control] int 'control',
       [type] int 'type',
       [test_script_error_code] int 'test_script_error_code',
       [powerOff_status] int 'powerOff_status',
       [vm_external_ip] nvarchar(80) 'vm_external_ip',
       [test_script_status] int 'test_script_status',
       [test_scripts_results] xml 'test_scripts_results/*',
       [oiag_id] uniqueidentifier 'oiag_id',
       [processed_steps] int 'processed_steps',
       [leave_powered_on] bit 'leave_powered_on',
       [validation_status] int 'validation_status',
       [log_xml] xml 'log_xml/*',
	   [usn] bigint 'usn'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET
        [start_time] = DATEADD( minute, -@TimeZoneShift, [start_time]),
        [finish_time] = DATEADD( minute, -@TimeZoneShift, [finish_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.SbTaskSessions]
    SET
        [C.Backup.Model.SbTaskSessions].[order_num] = src.[order_num],
        [C.Backup.Model.SbTaskSessions].[object_id] = src.[object_id],
        [C.Backup.Model.SbTaskSessions].[description] = src.[description],
        [C.Backup.Model.SbTaskSessions].[powerOn_status] = src.[powerOn_status],
        [C.Backup.Model.SbTaskSessions].[restore_counter] = src.[restore_counter],
        [C.Backup.Model.SbTaskSessions].[ping_status] = src.[ping_status],
        [C.Backup.Model.SbTaskSessions].[appliance_ip] = src.[appliance_ip],
        [C.Backup.Model.SbTaskSessions].[subnet_ip] = src.[subnet_ip],
        [C.Backup.Model.SbTaskSessions].[subnet_mask] = src.[subnet_mask],
        [C.Backup.Model.SbTaskSessions].[vm_ref] = src.[vm_ref],
        [C.Backup.Model.SbTaskSessions].[state] = src.[state],
        [C.Backup.Model.SbTaskSessions].[start_time] = src.[start_time],
        [C.Backup.Model.SbTaskSessions].[drsession_id] = src.[drsession_id],
        [C.Backup.Model.SbTaskSessions].[total_steps] = src.[total_steps],
        [C.Backup.Model.SbTaskSessions].[percent] = src.[percent],
        [C.Backup.Model.SbTaskSessions].[finish_time] = src.[finish_time],
        [C.Backup.Model.SbTaskSessions].[object_name] = src.[object_name],
        [C.Backup.Model.SbTaskSessions].[oib_id] = src.[oib_id],
        [C.Backup.Model.SbTaskSessions].[heartbeat_status] = src.[heartbeat_status],
        [C.Backup.Model.SbTaskSessions].[overall_status] = src.[overall_status],
        [C.Backup.Model.SbTaskSessions].[control] = src.[control],
        [C.Backup.Model.SbTaskSessions].[type] = src.[type],
        [C.Backup.Model.SbTaskSessions].[test_script_error_code] = src.[test_script_error_code],
        [C.Backup.Model.SbTaskSessions].[powerOff_status] = src.[powerOff_status],
        [C.Backup.Model.SbTaskSessions].[vm_external_ip] = src.[vm_external_ip],
        [C.Backup.Model.SbTaskSessions].[test_script_status] = src.[test_script_status],
        [C.Backup.Model.SbTaskSessions].[test_scripts_results] = src.[test_scripts_results],
        [C.Backup.Model.SbTaskSessions].[oiag_id] = src.[oiag_id],
        [C.Backup.Model.SbTaskSessions].[processed_steps] = src.[processed_steps],
        [C.Backup.Model.SbTaskSessions].[leave_powered_on] = src.[leave_powered_on],
        [C.Backup.Model.SbTaskSessions].[validation_status] = src.[validation_status],
        [C.Backup.Model.SbTaskSessions].[log_xml] = src.[log_xml],
		[C.Backup.Model.SbTaskSessions].[usn] = src.[usn]
    FROM [C.Backup.Model.SbTaskSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.SbTaskSessions].id = src.id    AND [C.Backup.Model.SbTaskSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.SbTaskSessions]([order_num], [object_id], [description], [powerOn_status], [restore_counter], [ping_status], [appliance_ip], [subnet_ip], [subnet_mask], [vm_ref], [state], [start_time], [drsession_id], [total_steps], [percent], [finish_time], [object_name], [id], [oib_id], [heartbeat_status], [overall_status], [control], [type], [test_script_error_code], [powerOff_status], [vm_external_ip], [test_script_status], [test_scripts_results], [oiag_id], [processed_steps], [leave_powered_on], [validation_status], [log_xml], db_instance_id, [usn])
    SELECT
        src.[order_num],
        src.[object_id],
        src.[description],
        src.[powerOn_status],
        src.[restore_counter],
        src.[ping_status],
        src.[appliance_ip],
        src.[subnet_ip],
        src.[subnet_mask],
        src.[vm_ref],
        src.[state],
        src.[start_time],
        src.[drsession_id],
        src.[total_steps],
        src.[percent],
        src.[finish_time],
        src.[object_name],
        src.[id],
        src.[oib_id],
        src.[heartbeat_status],
        src.[overall_status],
        src.[control],
        src.[type],
        src.[test_script_error_code],
        src.[powerOff_status],
        src.[vm_external_ip],
        src.[test_script_status],
        src.[test_scripts_results],
        src.[oiag_id],
        src.[processed_steps],
        src.[leave_powered_on],
        src.[validation_status],
        src.[log_xml],
        src.db_instance_id,
		src.[usn]
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.SbTaskSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_SbTaskSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_SbTaskSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_SbTaskSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_SbTaskSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.SbTaskSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.SbTaskSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_SbSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_SbSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_SbSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_SbSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [preferred_date] datetime,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([preferred_date], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [preferred_date] datetime 'preferred_date',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET [preferred_date] = DATEADD( minute, -@TimeZoneShift, [preferred_date])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.SbSessions]
    SET
        [C.Backup.Model.SbSessions].[preferred_date] = src.[preferred_date]
    FROM [C.Backup.Model.SbSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.SbSessions].id = src.id    AND [C.Backup.Model.SbSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.SbSessions]([preferred_date], [id], db_instance_id)
    SELECT
        src.[preferred_date],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.SbSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_SbSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_SbSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_SbSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_SbSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.SbSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.SbSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_BackupJobSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_BackupJobSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_BackupJobSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_BackupJobSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [is_full] bit,
       [total_size] bigint,
       [processed_objects] int,
       [is_retry] bit,
       [total_objects] int,
       [processed_size] bigint,
       [avg_speed] bigint,
       [job_source_type] int,
       [id] uniqueidentifier,
       [stored_size] bigint,
       [is_active_full] bit,
       [cur_point_id] uniqueidentifier,
	   [usn] bigint,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([is_full], [total_size], [processed_objects], [is_retry], [total_objects], [processed_size], [avg_speed], [job_source_type], [id], [stored_size], [is_active_full], [cur_point_id], [usn])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [is_full] bit 'is_full',
       [total_size] bigint 'total_size',
       [processed_objects] int 'processed_objects',
       [is_retry] bit 'is_retry',
       [total_objects] int 'total_objects',
       [processed_size] bigint 'processed_size',
       [avg_speed] bigint 'avg_speed',
       [job_source_type] int 'job_source_type',
       [id] uniqueidentifier 'id',
       [stored_size] bigint 'stored_size',
       [is_active_full] bit 'is_active_full',
       [cur_point_id] uniqueidentifier 'cur_point_id',
	   [usn] bigint 'usn'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.BackupJobSessions]
    SET
        [C.Backup.Model.BackupJobSessions].[is_full] = src.[is_full],
        [C.Backup.Model.BackupJobSessions].[total_size] = src.[total_size],
        [C.Backup.Model.BackupJobSessions].[processed_objects] = src.[processed_objects],
        [C.Backup.Model.BackupJobSessions].[is_retry] = src.[is_retry],
        [C.Backup.Model.BackupJobSessions].[total_objects] = src.[total_objects],
        [C.Backup.Model.BackupJobSessions].[processed_size] = src.[processed_size],
        [C.Backup.Model.BackupJobSessions].[avg_speed] = src.[avg_speed],
        [C.Backup.Model.BackupJobSessions].[job_source_type] = src.[job_source_type],
        [C.Backup.Model.BackupJobSessions].[stored_size] = src.[stored_size],
        [C.Backup.Model.BackupJobSessions].[is_active_full] = src.[is_active_full],
        [C.Backup.Model.BackupJobSessions].[cur_point_id] = src.[cur_point_id],
		[C.Backup.Model.BackupJobSessions].[usn] = src.[usn]		
    FROM [C.Backup.Model.BackupJobSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.BackupJobSessions].id = src.id    AND [C.Backup.Model.BackupJobSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.BackupJobSessions]([is_full], [total_size], [processed_objects], [is_retry], [total_objects], [processed_size], [avg_speed], [job_source_type], [id], [stored_size], [is_active_full], [cur_point_id], [usn], db_instance_id)
    SELECT
        src.[is_full],
        src.[total_size],
        src.[processed_objects],
        src.[is_retry],
        src.[total_objects],
        src.[processed_size],
        src.[avg_speed],
        src.[job_source_type],
        src.[id],
        src.[stored_size],
        src.[is_active_full],
        src.[cur_point_id],
		src.[usn],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.BackupJobSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_BackupJobSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_BackupJobSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_BackupJobSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_BackupJobSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.BackupJobSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.BackupJobSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_BackupTaskSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_BackupTaskSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_BackupTaskSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_BackupTaskSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [processed_size] bigint,
       [operation] nvarchar(400),
       [end_time] datetime,
       [object_name] nvarchar(2000),
       [log_xml] xml,
       [read_size] bigint,
       [stored_size] bigint,
       [object_id] uniqueidentifier,
       [processed_objects] int,
       [session_id] uniqueidentifier,
       [creation_time] datetime,
       [mode] int,
       [total_objects] int,
       [total_size] bigint,
       [reason] ntext,
       [change_tracking] bit,
       [status] int,
       [avg_speed] bigint,
	   [usn] bigint,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [processed_size], [operation], [end_time], [object_name], [log_xml], [read_size], [stored_size], [object_id], [processed_objects], [session_id], [creation_time], [mode], [total_objects], [total_size], [reason], [change_tracking], [status], [avg_speed], [usn])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [processed_size] bigint 'processed_size',
       [operation] nvarchar(400) 'operation',
       [end_time] datetime 'end_time',
       [object_name] nvarchar(2000) 'object_name',
       [log_xml] xml 'log_xml/*',
       [read_size] bigint 'read_size',
       [stored_size] bigint 'stored_size',
       [object_id] uniqueidentifier 'object_id',
       [processed_objects] int 'processed_objects',
       [session_id] uniqueidentifier 'session_id',
       [creation_time] datetime 'creation_time',
       [mode] int 'mode',
       [total_objects] int 'total_objects',
       [total_size] bigint 'total_size',
       [reason] ntext 'reason',
       [change_tracking] bit 'change_tracking',
       [status] int 'status',
       [avg_speed] bigint 'avg_speed',
	   [usn] bigint 'usn'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET
        [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time]),
        [end_time] = DATEADD( minute, -@TimeZoneShift, [end_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.BackupTaskSessions]
    SET
        [C.Backup.Model.BackupTaskSessions].[processed_size] = src.[processed_size],
        [C.Backup.Model.BackupTaskSessions].[operation] = src.[operation],
        [C.Backup.Model.BackupTaskSessions].[end_time] = src.[end_time],
        [C.Backup.Model.BackupTaskSessions].[object_name] = src.[object_name],
        [C.Backup.Model.BackupTaskSessions].[log_xml] = src.[log_xml],
        [C.Backup.Model.BackupTaskSessions].[read_size] = src.[read_size],
        [C.Backup.Model.BackupTaskSessions].[stored_size] = src.[stored_size],
        [C.Backup.Model.BackupTaskSessions].[object_id] = src.[object_id],
        [C.Backup.Model.BackupTaskSessions].[processed_objects] = src.[processed_objects],
        [C.Backup.Model.BackupTaskSessions].[session_id] = src.[session_id],
        [C.Backup.Model.BackupTaskSessions].[creation_time] = src.[creation_time],
        [C.Backup.Model.BackupTaskSessions].[mode] = src.[mode],
        [C.Backup.Model.BackupTaskSessions].[total_objects] = src.[total_objects],
        [C.Backup.Model.BackupTaskSessions].[total_size] = src.[total_size],
        [C.Backup.Model.BackupTaskSessions].[reason] = src.[reason],
        [C.Backup.Model.BackupTaskSessions].[change_tracking] = src.[change_tracking],
        [C.Backup.Model.BackupTaskSessions].[status] = src.[status],
        [C.Backup.Model.BackupTaskSessions].[avg_speed] = src.[avg_speed],
		[C.Backup.Model.BackupTaskSessions].[usn] = src.[usn]		
    FROM [C.Backup.Model.BackupTaskSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.BackupTaskSessions].id = src.id    AND [C.Backup.Model.BackupTaskSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.BackupTaskSessions]([id], [processed_size], [operation], [end_time], [object_name], [log_xml], [read_size], [stored_size], [object_id], [processed_objects], [session_id], [creation_time], [mode], [total_objects], [total_size], [reason], [change_tracking], [status], [avg_speed], [usn], db_instance_id)
    SELECT
        src.[id],
        src.[processed_size],
        src.[operation],
        src.[end_time],
        src.[object_name],
        src.[log_xml],
        src.[read_size],
        src.[stored_size],
        src.[object_id],
        src.[processed_objects],
        src.[session_id],
        src.[creation_time],
        src.[mode],
        src.[total_objects],
        src.[total_size],
        src.[reason],
        src.[change_tracking],
        src.[status],
        src.[avg_speed],
		src.[usn],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.BackupTaskSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_BackupTaskSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_BackupTaskSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_BackupTaskSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_BackupTaskSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.BackupTaskSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.BackupTaskSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_LinkedJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_LinkedJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_LinkedJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_LinkedJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [linked_job_id] uniqueidentifier,
       [id] uniqueidentifier,
       [job_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([linked_job_id], [id], [job_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [linked_job_id] uniqueidentifier 'linked_job_id',
       [id] uniqueidentifier 'id',
       [job_id] uniqueidentifier 'job_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.LinkedJobs]
    SET
        [C.LinkedJobs].[linked_job_id] = src.[linked_job_id],
        [C.LinkedJobs].[job_id] = src.[job_id]
    FROM [C.LinkedJobs] INNER JOIN @imported_changes src
    ON [C.LinkedJobs].id = src.id    AND [C.LinkedJobs].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.LinkedJobs]([linked_job_id], [id], [job_id], db_instance_id)
    SELECT
        src.[linked_job_id],
        src.[id],
        src.[job_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.LinkedJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_LinkedJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_LinkedJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_LinkedJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_LinkedJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.LinkedJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.LinkedJobs].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_SbVerificationRules_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_SbVerificationRules_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_SbVerificationRules_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_SbVerificationRules_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [options] xml,
       [job_id] uniqueidentifier,
       [object_type] int,
       [object_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [options], [job_id], [object_type], [object_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [options] xml 'options/*',
       [job_id] uniqueidentifier 'job_id',
       [object_type] int 'object_type',
       [object_id] uniqueidentifier 'object_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.SbVerificationRules]
    SET
        [C.SbVerificationRules].[options] = src.[options],
        [C.SbVerificationRules].[job_id] = src.[job_id],
        [C.SbVerificationRules].[object_type] = src.[object_type],
        [C.SbVerificationRules].[object_id] = src.[object_id]
    FROM [C.SbVerificationRules] INNER JOIN @imported_changes src
    ON [C.SbVerificationRules].id = src.id    AND [C.SbVerificationRules].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.SbVerificationRules]([id], [options], [job_id], [object_type], [object_id], db_instance_id)
    SELECT
        src.[id],
        src.[options],
        src.[job_id],
        src.[object_type],
        src.[object_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.SbVerificationRules] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_SbVerificationRules_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_SbVerificationRules_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_SbVerificationRules_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_SbVerificationRules_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.SbVerificationRules]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.SbVerificationRules].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_BackupProxies_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BackupProxies_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_BackupProxies_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_BackupProxies_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [name] nvarchar(max),
       [description] nvarchar(max),
       [type] int,
       [options] xml,
       [disabled] bit,
       [is_busy] bit,
       [is_unavailable] bit,
       [unique_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [description], [type], [options], [disabled], [is_busy], [is_unavailable], [unique_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [name] nvarchar(max) 'name',
       [description] nvarchar(max) 'description',
       [type] int 'type',
       [options] xml 'options/*',
       [disabled] bit 'disabled',
       [is_busy] bit 'is_busy',
       [is_unavailable] bit 'is_unavailable',
       [unique_id] uniqueidentifier 'unique_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.BackupProxies]
    SET
        [C.BackupProxies].[name] = src.[name],
        [C.BackupProxies].[description] = src.[description],
        [C.BackupProxies].[type] = src.[type],
        [C.BackupProxies].[options] = src.[options],
        [C.BackupProxies].[disabled] = src.[disabled],
        [C.BackupProxies].[is_busy] = src.[is_busy],
        [C.BackupProxies].[is_unavailable] = src.[is_unavailable],
        [C.BackupProxies].[unique_id] = src.[unique_id]
    FROM [C.BackupProxies] INNER JOIN @imported_changes src
    ON [C.BackupProxies].id = src.id    AND [C.BackupProxies].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.BackupProxies]([id], [name], [description], [type], [options], [disabled], [is_busy], [is_unavailable], [unique_id], db_instance_id)
    SELECT
        src.[id],
        src.[name],
        src.[description],
        src.[type],
        src.[options],
        src.[disabled],
        src.[is_busy],
        src.[is_unavailable],
        src.[unique_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.BackupProxies] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_BackupProxies_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BackupProxies_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_BackupProxies_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_BackupProxies_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.BackupProxies]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.BackupProxies].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_BackupRepositories_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BackupRepositories_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_BackupRepositories_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_BackupRepositories_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [name] nvarchar(max),
       [description] nvarchar(max),
       [type] int,
       [host_id] uniqueidentifier,
       [mount_host_id] uniqueidentifier,
       [path] nvarchar(max),
       [options] xml,
       [is_busy] bit,
       [is_unavailable] bit,
       [is_full] bit,
       [total_space] bigint,
       [free_space] bigint,
       [unique_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [description], [type], [host_id], [mount_host_id], [path], [options], [is_busy], [is_unavailable], [is_full], [total_space], [free_space], [unique_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [name] nvarchar(max) 'name',
       [description] nvarchar(max) 'description',
       [type] int 'type',
       [host_id] uniqueidentifier 'host_id',
       [mount_host_id] uniqueidentifier 'mount_host_id',
       [path] nvarchar(max) 'path',
       [options] xml 'options/*',
       [is_busy] bit 'is_busy',
       [is_unavailable] bit 'is_unavailable',
       [is_full] bit 'is_full',
       [total_space] bigint 'total_space',
       [free_space] bigint 'free_space',
       [unique_id] uniqueidentifier 'unique_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.BackupRepositories]
    SET
        [C.BackupRepositories].[name] = src.[name],
        [C.BackupRepositories].[description] = src.[description],
        [C.BackupRepositories].[type] = src.[type],
        [C.BackupRepositories].[host_id] = src.[host_id],
        [C.BackupRepositories].[mount_host_id] = src.[mount_host_id],
        [C.BackupRepositories].[path] = src.[path],
        [C.BackupRepositories].[options] = src.[options],
        [C.BackupRepositories].[is_busy] = src.[is_busy],
        [C.BackupRepositories].[is_unavailable] = src.[is_unavailable],
        [C.BackupRepositories].[is_full] = src.[is_full],
        [C.BackupRepositories].[total_space] = src.[total_space],
        [C.BackupRepositories].[free_space] = src.[free_space],
        [C.BackupRepositories].[unique_id] = src.[unique_id]
    FROM [C.BackupRepositories] INNER JOIN @imported_changes src
    ON [C.BackupRepositories].id = src.id    AND [C.BackupRepositories].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.BackupRepositories]([id], [name], [description], [type], [host_id], [mount_host_id], [path], [options], [is_busy], [is_unavailable], [is_full], [total_space], [free_space], [unique_id], db_instance_id)
    SELECT
        src.[id],
        src.[name],
        src.[description],
        src.[type],
        src.[host_id],
        src.[mount_host_id],
        src.[path],
        src.[options],
        src.[is_busy],
        src.[is_unavailable],
        src.[is_full],
        src.[total_space],
        src.[free_space],
        src.[unique_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.BackupRepositories] trg
    ON src.[unique_id] = trg.[unique_id]
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_BackupRepositories_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_BackupRepositories_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_BackupRepositories_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_BackupRepositories_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.BackupRepositories]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.BackupRepositories].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Credentials_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Credentials_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Credentials_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Credentials_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [user_name] nvarchar(255),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [user_name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [user_name] nvarchar(255) 'user_name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Credentials]
    SET
        [C.Credentials].[user_name] = src.[user_name]
    FROM [C.Credentials] INNER JOIN @imported_changes src
    ON [C.Credentials].id = src.id    AND [C.Credentials].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Credentials]([id], [user_name], db_instance_id)
    SELECT
        src.[id],
        src.[user_name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Credentials] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Credentials_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Credentials_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Credentials_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Credentials_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Credentials]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Credentials].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_RestoreJobSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_RestoreJobSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_RestoreJobSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_RestoreJobSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [action] int,
       [usn] bigint,
       [options] xml,
       [reason] nvarchar(max),
       [files_log_xml] xml,
       [platform] int,
       [multi_restore_id] uniqueidentifier,
       [restore_type] int,
       [oib_id] uniqueidentifier,
       [is_internal] bit,
       [oib_display_name] nvarchar(256),
       [oib_creation_time] datetime,
       [sub_type] int,
       [restored_obj_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [action], [usn], [options], [reason], [files_log_xml], [platform], [multi_restore_id], [restore_type], [oib_id], [is_internal], [oib_display_name], [oib_creation_time], [sub_type], [restored_obj_id])
    SELECT 
       [id],
       [action],
       [usn],
       ISNULL([options], ''),
       [reason],
       ISNULL([files_log_xml], '<Root TotalUsn="0" TotalId="0" />'),
       [platform],
       [multi_restore_id],
       [restore_type],
       [oib_id],
       [is_internal],
       [oib_display_name],
       [oib_creation_time],
       [sub_type],
       [restored_obj_id]
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [action] int 'action',
       [usn] bigint 'usn',
       [options] xml 'options/*',
       [initiator_sid] nvarchar(255) 'initiator_sid',
       [initiator_name] nvarchar(255) 'initiator_name',
       [reason] nvarchar(max) 'reason',
       [files_log_xml] xml 'files_log_xml/*',
       [platform] int 'platform',
       [multi_restore_id] uniqueidentifier 'multi_restore_id',
       [restore_type] int 'restore_type',
       [oib_id] uniqueidentifier 'oib_id',
       [is_internal] bit 'is_internal',
       [oib_display_name] nvarchar(256) 'oib_display_name',
       [oib_creation_time] datetime 'oib_creation_time',
       [sub_type] int 'sub_type',
	   [restored_obj_id] uniqueidentifier 'restored_obj_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

	UPDATE @imported_changes 
	SET [files_log_xml] = '<Root TotalUsn="0" TotalId="0" />'
    WHERE [files_log_xml] IS NULL;

    UPDATE @imported_changes 
    SET [options] = ''
    WHERE [options] IS NULL;


    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.RestoreJobSessions]
    SET
        [C.Backup.Model.RestoreJobSessions].[action] = src.[action],
        [C.Backup.Model.RestoreJobSessions].[usn] = src.[usn],
        [C.Backup.Model.RestoreJobSessions].[options] = ISNULL(src.[options], N''),
        [C.Backup.Model.RestoreJobSessions].[reason] = src.[reason],
        [C.Backup.Model.RestoreJobSessions].[files_log_xml] = src.[files_log_xml],
        [C.Backup.Model.RestoreJobSessions].[platform] = src.[platform],
        [C.Backup.Model.RestoreJobSessions].[multi_restore_id] = src.[multi_restore_id],
        [C.Backup.Model.RestoreJobSessions].[restore_type] = src.[restore_type],
        [C.Backup.Model.RestoreJobSessions].[oib_id] = src.[oib_id],
        [C.Backup.Model.RestoreJobSessions].[is_internal] = src.[is_internal],
        [C.Backup.Model.RestoreJobSessions].[oib_display_name] = src.[oib_display_name],
        [C.Backup.Model.RestoreJobSessions].[oib_creation_time] = src.[oib_creation_time],
        [C.Backup.Model.RestoreJobSessions].[sub_type] = src.[sub_type],
        [C.Backup.Model.RestoreJobSessions].[restored_obj_id] = src.[restored_obj_id]
    FROM [C.Backup.Model.RestoreJobSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.RestoreJobSessions].id = src.id    AND [C.Backup.Model.RestoreJobSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.RestoreJobSessions]([id], [action], [usn], [options], [reason], [files_log_xml], [platform], [multi_restore_id], [restore_type], [oib_id], [is_internal], [oib_display_name], [oib_creation_time], [sub_type], [restored_obj_id], db_instance_id)
    SELECT
        src.[id],
        src.[action],
        src.[usn],
		ISNULL(src.[options], N''),
        src.[reason],
        src.[files_log_xml],
        src.[platform],
        src.[multi_restore_id],
        src.[restore_type],
        src.[oib_id],
        src.[is_internal],
        src.[oib_display_name],
        src.[oib_creation_time],
        src.[sub_type],
        src.[restored_obj_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.RestoreJobSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_RestoreJobSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_RestoreJobSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_RestoreJobSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_RestoreJobSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.RestoreJobSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.RestoreJobSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_JobVssCredentials_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_JobVssCredentials_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_JobVssCredentials_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_JobVssCredentials_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [job_id] uniqueidentifier,
       [oij_id] uniqueidentifier,
       [win_creds_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [job_id], [oij_id], [win_creds_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [job_id] uniqueidentifier 'job_id',
       [oij_id] uniqueidentifier 'oij_id',
       [win_creds_id] uniqueidentifier 'win_creds_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.JobVssCredentials]
    SET
        [C.JobVssCredentials].[job_id] = src.[job_id],
        [C.JobVssCredentials].[oij_id] = src.[oij_id],
        [C.JobVssCredentials].[win_creds_id] = src.[win_creds_id]
    FROM [C.JobVssCredentials] INNER JOIN @imported_changes src
    ON [C.JobVssCredentials].id = src.id    AND [C.JobVssCredentials].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.JobVssCredentials]([id], [job_id], [oij_id], [win_creds_id], db_instance_id)
    SELECT
        src.[id],
        src.[job_id],
        src.[oij_id],
        src.[win_creds_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.JobVssCredentials] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_JobVssCredentials_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_JobVssCredentials_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_JobVssCredentials_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_JobVssCredentials_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.JobVssCredentials]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.JobVssCredentials].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_PhysicalHosts_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_PhysicalHosts_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_PhysicalHosts_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_PhysicalHosts_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [name] nvarchar(max),
       [bios_uuid] nvarchar(255),
	   [chassis_type] [int] NOT NULL,
	   [hardware_info] [xml] NOT NULL,
	   [net_info] [xml] NOT NULL,
	   [os_type] [int] NOT NULL,
	   [os_platform] [int] NOT NULL,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [bios_uuid], [chassis_type],[hardware_info],[net_info],[os_type],[os_platform])
    SELECT 
		[id], 
		[name],
		[bios_uuid],
		[chassis_type],
		ISNULL([hardware_info], '<HardwareInfo />'),
		ISNULL([net_info], '<NetInfo />'),
		[os_type],
		[os_platform]
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [name] nvarchar(max) 'name',
       [bios_uuid] nvarchar(255) 'bios_uuid',
	   [chassis_type] int 'chassis_type',
	   [hardware_info] xml 'hardware_info/*',
	   [net_info] xml 'net_info/*',
	   [os_type] int 'os_type',
	   [os_platform] int 'os_platform'
	   
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.PhysicalHosts]
    SET
        [C.PhysicalHosts].[name] = src.[name],
        [C.PhysicalHosts].[bios_uuid] = src.[bios_uuid],
		[C.PhysicalHosts].[chassis_type] = src.[chassis_type],
		[C.PhysicalHosts].[hardware_info] = src.[hardware_info],
		[C.PhysicalHosts].[net_info] = src.[net_info],
		[C.PhysicalHosts].[os_type] = src.[os_type],
		[C.PhysicalHosts].[os_platform]  = src.[os_platform]
    FROM [C.PhysicalHosts] INNER JOIN @imported_changes src
    ON [C.PhysicalHosts].id = src.id AND [C.PhysicalHosts].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.PhysicalHosts]([id], [name], [bios_uuid], [chassis_type],[hardware_info],[net_info],[os_type],[os_platform], db_instance_id)
    SELECT
        src.[id],
        src.[name],
        src.[bios_uuid],
		src.[chassis_type],
		src.[hardware_info],
		src.[net_info],
		src.[os_type],
		src.[os_platform],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.PhysicalHosts] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_PhysicalHosts_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_PhysicalHosts_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_PhysicalHosts_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_PhysicalHosts_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.PhysicalHosts]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
	 AND [dbo].[C.PhysicalHosts].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_OibAdminAccounts_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_OibAdminAccounts_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_OibAdminAccounts_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_OibAdminAccounts_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [sid] nvarchar(184),
       [oib_id] uniqueidentifier,
       [account_type] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [sid], [oib_id], [account_type])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [sid] nvarchar(184) 'sid',
       [oib_id] uniqueidentifier 'oib_id',
       [account_type] int 'account_type'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.OibAdminAccounts]
    SET
        [C.OibAdminAccounts].[sid] = src.[sid],
        [C.OibAdminAccounts].[oib_id] = src.[oib_id],
        [C.OibAdminAccounts].[account_type] = src.[account_type]
    FROM [C.OibAdminAccounts] INNER JOIN @imported_changes src
    ON [C.OibAdminAccounts].id = src.id    AND [C.OibAdminAccounts].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.OibAdminAccounts]([id], [sid], [oib_id], [account_type], db_instance_id)
    SELECT
        src.[id],
        src.[sid],
        src.[oib_id],
        src.[account_type],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.OibAdminAccounts] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_OibAdminAccounts_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_OibAdminAccounts_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_OibAdminAccounts_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_OibAdminAccounts_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.OibAdminAccounts]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.OibAdminAccounts].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

--[dbo].[usp_Import_Backup_Model_GuestDatabase_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_GuestDatabase_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_GuestDatabase_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_GuestDatabase_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [obj_id] uniqueidentifier,
       [server_name] nvarchar(1000),
       [db_instance] nvarchar(max),
       [db_name] nvarchar(max),
       [creation_time] datetime,
       [is_system] bit,
	   [db_id] int,
	   [compatibility] int,
	   [family_guid] uniqueidentifier,
       [db_instance_id] uniqueidentifier,
	   [local_creation_time] datetime,
	   [local_creation_time_str] varchar(max)

    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [obj_id], [server_name], [db_instance], [db_name], [creation_time], [is_system], [db_id], [compatibility],[family_guid],[local_creation_time], [local_creation_time_str])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [obj_id] uniqueidentifier 'obj_id',
       [server_namee] nvarchar(1000) 'server_name',
       [db_instance] nvarchar(max) 'db_instance',
       [db_name] nvarchar(max) 'db_name',
       [creation_time] datetime 'creation_time',
       [is_system] bit 'is_system',
	   [db_id] int 'db_id',
	   [compatibility] int 'compatibility',
	   [family_guid] uniqueidentifier 'family_guid',	   
	   [local_creation_time] datetime 'local_creation_time',
	   [local_creation_time_str] varchar(max) 'local_creation_time_str'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */

	UPDATE @imported_changes
    SET
        [local_creation_time] = DATEADD( minute, -@TimeZoneShift, [local_creation_time])



    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.GuestDatabase]
    SET
        [C.Backup.Model.GuestDatabase].[obj_id] = src.[obj_id],
        [C.Backup.Model.GuestDatabase].[server_name] = src.[server_name],
        [C.Backup.Model.GuestDatabase].[db_instance] = src.[db_instance],
        [C.Backup.Model.GuestDatabase].[db_name] = src.[db_name],
        [C.Backup.Model.GuestDatabase].[creation_time] = src.[creation_time],
        [C.Backup.Model.GuestDatabase].[is_system] = src.[is_system],
		[C.Backup.Model.GuestDatabase].[db_id] = src.[db_id],
		[C.Backup.Model.GuestDatabase].[compatibility] = src.[compatibility],
		[C.Backup.Model.GuestDatabase].[family_guid] = src.[family_guid],
		[C.Backup.Model.GuestDatabase].[local_creation_time] = src.[local_creation_time],
		[C.Backup.Model.GuestDatabase].[local_creation_time_str] = src.[local_creation_time_str]
    FROM [C.Backup.Model.GuestDatabase] INNER JOIN @imported_changes src
    ON [C.Backup.Model.GuestDatabase].id = src.id    AND [C.Backup.Model.GuestDatabase].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.GuestDatabase]([id], [obj_id], [server_name], [db_instance], [db_name], [creation_time], [is_system], [db_id], [compatibility], [family_guid], db_instance_id, [local_creation_time], [local_creation_time_str])
    SELECT
        src.[id],
        src.[obj_id],
        src.[server_name],
        src.[db_instance],
        src.[db_name],
        src.[creation_time],
        src.[is_system],
		src.[db_id],
		src.[compatibility],
		src.[family_guid],
        src.db_instance_id,
		src.[local_creation_time],
		src.[local_creation_time_str]
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.GuestDatabase] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
-----------------------------------------------------
--[dbo].[usp_Import_C_Backup_Model_GuestDatabase_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_C_Backup_Model_GuestDatabase_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_C_Backup_Model_GuestDatabase_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_C_Backup_Model_GuestDatabase_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.GuestDatabase]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.GuestDatabase].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

-----------------------------------------------------
--[dbo].[usp_Import_WanAccelerators_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_WanAccelerators_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_WanAccelerators_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_WanAccelerators_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
		[id] [uniqueidentifier],
		[host_id] [uniqueidentifier],
		[name] [nvarchar](max),
		[description] [nvarchar](max) NULL,
		[is_unavailable] [bit],
		[db_instance_id] [uniqueidentifier]
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [host_id],  [name], [description], [is_unavailable])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
		[id] [uniqueidentifier] 'id',
		[host_id] [uniqueidentifier] 'host_id',
		[name] [nvarchar](max) 'name',
		[description] [nvarchar](max) 'description',
		[is_unavailable] [bit] 'is_unavailable'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.WanAccelerators]
    SET
        [C.WanAccelerators].[name] = src.[name],
        [C.WanAccelerators].[description] = src.[description],
        [C.WanAccelerators].[host_id] = src.[host_id],
        [C.WanAccelerators].[is_unavailable] = src.[is_unavailable]
    FROM [C.WanAccelerators] INNER JOIN @imported_changes src
    ON [C.WanAccelerators].id = src.id    AND [C.WanAccelerators].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.WanAccelerators]([id], [host_id], [name], [description], [is_unavailable], db_instance_id)
    SELECT
        src.[id],
        src.[host_id],
        src.[name],
        src.[description],
        src.[is_unavailable],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.WanAccelerators] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
-----------------------------------------------------
--[dbo].[usp_Import_WanAccelerators_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_WanAccelerators_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_WanAccelerators_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_WanAccelerators_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.WanAccelerators]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.WanAccelerators].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_HostComponents_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_HostComponents_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_HostComponents_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_HostComponents_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
		[id] [uniqueidentifier],
		[physical_host_id] [uniqueidentifier],
		[type] [int],
		[version] [nvarchar](255),
		[options] [xml],
		[is_up_to_date] [bit],
		[db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [physical_host_id], [type], [version], [options], [is_up_to_date])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [physical_host_id] uniqueidentifier 'physical_host_id',
       [type] int 'type',
       [version] nvarchar(255) 'version',
       [options] xml 'options/*',
       [is_up_to_date] bit 'is_up_to_date'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.HostComponents]
    SET
        [C.HostComponents].[id] = src.[id],
        [C.HostComponents].[physical_host_id] = src.[physical_host_id],
        [C.HostComponents].[type] = src.[type],
        [C.HostComponents].[is_up_to_date] = src.[is_up_to_date],
        [C.HostComponents].[options] = src.[options],
        [C.HostComponents].[version] = src.[version]
    FROM [C.HostComponents] INNER JOIN @imported_changes src
    ON [C.HostComponents].id = src.id    AND [C.HostComponents].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.HostComponents]([id], [physical_host_id], [type], [is_up_to_date], [options], [version], db_instance_id)
    SELECT
        src.[id],
        src.[physical_host_id],
        src.[type],
		src.[is_up_to_date],
        src.[options],  
        src.[version],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.HostComponents] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
-----------------------------------------------------
--[dbo].[usp_Import_HostComponents_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_HostComponents_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_HostComponents_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_HostComponents_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.HostComponents]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.HostComponents].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudGates_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudGates_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudGates_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudGates_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
		[id] [uniqueidentifier],
		[name] [nvarchar](max),
		[description] [nvarchar](max),
		[creds_id] [uniqueidentifier],
		[options] [xml],
		[host_id] [uniqueidentifier],
		[disabled] [bit],
		[is_available] [bit],
		[db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [description], [creds_id], [options], [host_id], [disabled], [is_available])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
		[id] [uniqueidentifier] 'id',
		[name] [nvarchar](max) 'name',
		[description] [nvarchar](max) 'description',
		[creds_id] [uniqueidentifier] 'creds_id',
		[options] [xml] 'options',
		[host_id] [uniqueidentifier] 'host_id',
		[disabled] [bit] 'disabled',
		[is_available] [bit] 'is_available'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudGates]
    SET
		[C.Backup.Model.CloudGates].[id] = src.[id],
		[C.Backup.Model.CloudGates].[name] = src.[name], 
		[C.Backup.Model.CloudGates].[description] = src.[description], 
		[C.Backup.Model.CloudGates].[creds_id] = src.[creds_id], 
		[C.Backup.Model.CloudGates].[options] = src.[options], 
		[C.Backup.Model.CloudGates].[host_id] = src.[host_id], 
		[C.Backup.Model.CloudGates].[disabled] = src.[disabled], 
		[C.Backup.Model.CloudGates].[is_available] = src.[is_available]
    FROM [C.Backup.Model.CloudGates] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudGates].id = src.id    AND [C.Backup.Model.CloudGates].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudGates]([id], [name], [description], [creds_id], [options], [host_id], [disabled], [is_available], db_instance_id)
    SELECT
        src.[id], 
		src.[name], 
		src.[description], 
		src.[creds_id], 
		src.[options], 
		src.[host_id], 
		src.[disabled], 
		src.[is_available],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudGates] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudGates_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudGates_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudGates_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudGates_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudGates]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudGates].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

-----------------------------------------------------
--[dbo].[usp_Import_Tenants_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Tenants_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Tenants_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Tenants_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [name] nvarchar(max),
       [description] nvarchar(max),
       [expire_time] datetime,
       [disabled] bit,
       [password] nvarchar(max),
       [options] xml,
       [throttling_speed_limit] int,
       [throttling_speed_unit] int,
       [max_concurent_tasks] int,
	   [is_throttling_enabled] bit,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [description], [expire_time], [disabled], [password], [options], [throttling_speed_limit], [throttling_speed_unit], [max_concurent_tasks], [is_throttling_enabled])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [name] nvarchar(max) 'name',
       [description] nvarchar(max) 'description',
       [expire_time] datetime 'expire_time',
       [disabled] bit 'disabled',
       [password] nvarchar(max) 'password',
       [options] xml 'options/*',
       [throttling_speed_limit] int 'throttling_speed_limit',
       [throttling_speed_unit] int 'throttling_speed_unit',
       [max_concurent_tasks] int 'max_concurent_tasks',
       [is_throttling_enabled] bit 'is_throttling_enabled'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Tenants]
    SET
        [C.Tenants].[name] = src.[name],
        [C.Tenants].[description] = src.[description],
        [C.Tenants].[expire_time] = src.[expire_time],
        [C.Tenants].[disabled] = src.[disabled],
        [C.Tenants].[password] = src.[password],
        [C.Tenants].[options] = src.[options],
        [C.Tenants].[throttling_speed_limit] = src.[throttling_speed_limit],
        [C.Tenants].[throttling_speed_unit] = src.[throttling_speed_unit],
        [C.Tenants].[max_concurent_tasks] = src.[max_concurent_tasks],
        [C.Tenants].[is_throttling_enabled] = src.[is_throttling_enabled]
    FROM [C.Tenants] INNER JOIN @imported_changes src
    ON [C.Tenants].id = src.id    AND [C.Tenants].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Tenants]([id], [name], [description], [expire_time], [disabled], [password], [options], [throttling_speed_limit], [throttling_speed_unit], [max_concurent_tasks], [is_throttling_enabled], db_instance_id)
    SELECT
        src.[id],
        src.[name],
        src.[description],
        src.[expire_time],
        src.[disabled],
        src.[password],
        src.[options],
        src.[throttling_speed_limit],
        src.[throttling_speed_unit],
        src.[max_concurent_tasks],
        src.[is_throttling_enabled],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Tenants] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Tenants_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Tenants_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Tenants_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Tenants_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Tenants]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Tenants].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_TenantsResourcesQuota_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_TenantsResourcesQuota_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_TenantsResourcesQuota_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_TenantsResourcesQuota_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
		[id] [uniqueidentifier] NOT NULL,
		[tenant_id] [uniqueidentifier] NOT NULL,
		[repository_id] [uniqueidentifier] NOT NULL,
		[folder] [nvarchar](max) NULL,
		[wan_id] [uniqueidentifier] NULL,
		[quota_mb] [int] NULL,
		[used_quota_mb] [int] NOT NULL,
		[friendly_name] [nvarchar](max) NOT NULL,
		[db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [tenant_id], [repository_id], [folder], [wan_id], [quota_mb], [used_quota_mb], [friendly_name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
		[id] [uniqueidentifier] 'id',
		[tenant_id] [uniqueidentifier] 'tenant_id',
		[repository_id] [uniqueidentifier] 'repository_id',
		[folder] [nvarchar](max) 'folder',
		[wan_id] [uniqueidentifier] 'wan_id',
		[quota_mb] [int] 'quota_mb',
		[used_quota_mb] [int] 'used_quota_mb',
		[friendly_name] [nvarchar](max) 'friendly_name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.TenantsResourcesQuota]
    SET
        [C.TenantsResourcesQuota].[id] = src.[id],
        [C.TenantsResourcesQuota].[tenant_id] = src.[tenant_id],
        [C.TenantsResourcesQuota].[repository_id] = src.[repository_id],
        [C.TenantsResourcesQuota].[folder] = src.[folder],
        [C.TenantsResourcesQuota].[wan_id] = src.[wan_id],
        [C.TenantsResourcesQuota].[quota_mb] = src.[quota_mb],
        [C.TenantsResourcesQuota].[used_quota_mb] = src.[used_quota_mb],
        [C.TenantsResourcesQuota].[friendly_name] = src.[friendly_name]
    FROM [C.TenantsResourcesQuota] INNER JOIN @imported_changes src
    ON [C.TenantsResourcesQuota].id = src.id    AND [C.TenantsResourcesQuota].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.TenantsResourcesQuota]([id], [tenant_id], [repository_id], [folder], [wan_id], [quota_mb], [used_quota_mb], [friendly_name], db_instance_id)
    SELECT
        src.[id],
        src.[tenant_id],
        src.[repository_id],
		src.[folder],
        src.[wan_id],  
        src.[quota_mb],
        src.[used_quota_mb],
        src.[friendly_name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.TenantsResourcesQuota] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
-----------------------------------------------------
--[dbo].[usp_Import_TenantsResourcesQuota_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_TenantsResourcesQuota_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_TenantsResourcesQuota_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_TenantsResourcesQuota_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.TenantsResourcesQuota]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.TenantsResourcesQuota].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [data_sent_to_client] bigint,
       [data_received_from_client] bigint,
       [session_type] int,
       [tenant_name] nvarchar(max),
       [tenant_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [data_sent_to_client], [data_received_from_client], [session_type], [tenant_name], [tenant_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [data_sent_to_client] bigint 'data_sent_to_client',
       [data_received_from_client] bigint 'data_received_from_client',
       [session_type] int 'session_type',
       [tenant_name] nvarchar(max) 'tenant_name',
       [tenant_id] uniqueidentifier 'tenant_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudSessions]
    SET
        [C.Backup.Model.CloudSessions].[data_sent_to_client] = src.[data_sent_to_client],
        [C.Backup.Model.CloudSessions].[data_received_from_client] = src.[data_received_from_client],
        [C.Backup.Model.CloudSessions].[session_type] = src.[session_type],
        [C.Backup.Model.CloudSessions].[tenant_name] = src.[tenant_name],
        [C.Backup.Model.CloudSessions].[tenant_id] = src.[tenant_id]
    FROM [C.Backup.Model.CloudSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudSessions].id = src.id    AND [C.Backup.Model.CloudSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudSessions]([id], [data_sent_to_client], [data_received_from_client], [session_type], [tenant_name], [tenant_id], db_instance_id)
    SELECT
        src.[id],
        src.[data_sent_to_client],
        src.[data_received_from_client],
        src.[session_type],
        src.[tenant_name],
        src.[tenant_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [session_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([session_id], [quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [session_id] uniqueidentifier 'session_id',
       [quota_id] uniqueidentifier 'quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudSessionsOnQuotas]
    SET
        [C.Backup.Model.CloudSessionsOnQuotas].[session_id] = src.[session_id],
        [C.Backup.Model.CloudSessionsOnQuotas].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.CloudSessionsOnQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudSessionsOnQuotas].id = src.id    AND [C.Backup.Model.CloudSessionsOnQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudSessionsOnQuotas]([session_id], [quota_id], [id], db_instance_id)
    SELECT
        src.[session_id],
        src.[quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudSessionsOnQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudSessionsOnQuotas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudSessionsOnQuotas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVms_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVms_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] bigint,
       [vm_uuid] nvarchar(256),
       [unique_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [vm_uuid], [unique_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] bigint 'id',
       [vm_uuid] nvarchar(256) 'vm_uuid',
       [unique_id] uniqueidentifier 'unique_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudVms]
    SET
        [C.Backup.Model.CloudVms].[vm_uuid] = src.[vm_uuid],
        [C.Backup.Model.CloudVms].[unique_id] = src.[unique_id]
    FROM [C.Backup.Model.CloudVms] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudVms].id = src.id    AND [C.Backup.Model.CloudVms].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudVms]([id], [vm_uuid], [unique_id], db_instance_id)
    SELECT
        src.[id],
        src.[vm_uuid],
        src.[unique_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudVms] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVms_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVms_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  bigint
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id bigint '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudVms]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudVms].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [vm_id] bigint,
       [resource_quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([vm_id], [resource_quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [vm_id] bigint 'vm_id',
       [resource_quota_id] uniqueidentifier 'resource_quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudVmsOnQuotas]
    SET
        [C.Backup.Model.CloudVmsOnQuotas].[vm_id] = src.[vm_id],
        [C.Backup.Model.CloudVmsOnQuotas].[resource_quota_id] = src.[resource_quota_id]
    FROM [C.Backup.Model.CloudVmsOnQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudVmsOnQuotas].id = src.id    AND [C.Backup.Model.CloudVmsOnQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudVmsOnQuotas]([vm_id], [resource_quota_id], [id], db_instance_id)
    SELECT
        src.[vm_id],
        src.[resource_quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudVmsOnQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.TenantsResourcesQuota]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [data_sent_to_client] bigint,
       [data_received_from_client] bigint,
       [session_type] int,
       [tenant_name] nvarchar(max),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [data_sent_to_client], [data_received_from_client], [session_type], [tenant_name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [data_sent_to_client] bigint 'data_sent_to_client',
       [data_received_from_client] bigint 'data_received_from_client',
       [session_type] int 'session_type',
       [tenant_name] nvarchar(max) 'tenant_name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudSessions]
    SET
        [C.Backup.Model.CloudSessions].[data_sent_to_client] = src.[data_sent_to_client],
        [C.Backup.Model.CloudSessions].[data_received_from_client] = src.[data_received_from_client],
        [C.Backup.Model.CloudSessions].[session_type] = src.[session_type],
        [C.Backup.Model.CloudSessions].[tenant_name] = src.[tenant_name]
    FROM [C.Backup.Model.CloudSessions] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudSessions].id = src.id    AND [C.Backup.Model.CloudSessions].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudSessions]([id], [data_sent_to_client], [data_received_from_client], [session_type], [tenant_name], db_instance_id)
    SELECT
        src.[id],
        src.[data_sent_to_client],
        src.[data_received_from_client],
        src.[session_type],
        src.[tenant_name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudSessions].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [session_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([session_id], [quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [session_id] uniqueidentifier 'session_id',
       [quota_id] uniqueidentifier 'quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudSessionsOnQuotas]
    SET
        [C.Backup.Model.CloudSessionsOnQuotas].[session_id] = src.[session_id],
        [C.Backup.Model.CloudSessionsOnQuotas].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.CloudSessionsOnQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudSessionsOnQuotas].id = src.id    AND [C.Backup.Model.CloudSessionsOnQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudSessionsOnQuotas]([session_id], [quota_id], [id], db_instance_id)
    SELECT
        src.[session_id],
        src.[quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudSessionsOnQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudSessionsOnQuotas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudSessionsOnQuotas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVms_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVms_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] bigint,
       [vm_uuid] nvarchar(256),
       [unique_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [vm_uuid], [unique_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] bigint 'id',
       [vm_uuid] nvarchar(256) 'vm_uuid',
       [unique_id] uniqueidentifier 'unique_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudVms]
    SET
        [C.Backup.Model.CloudVms].[vm_uuid] = src.[vm_uuid],
        [C.Backup.Model.CloudVms].[unique_id] = src.[unique_id]
    FROM [C.Backup.Model.CloudVms] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudVms].id = src.id    AND [C.Backup.Model.CloudVms].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudVms]([id], [vm_uuid], [unique_id], db_instance_id)
    SELECT
        src.[id],
        src.[vm_uuid],
        src.[unique_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudVms] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVms_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVms_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVms_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@unique_id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudVms]
    WHERE unique_id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudVms].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [vm_id] bigint,
       [resource_quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([vm_id], [resource_quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [vm_id] bigint 'vm_id',
       [resource_quota_id] uniqueidentifier 'resource_quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudVmsOnQuotas]
    SET
        [C.Backup.Model.CloudVmsOnQuotas].[vm_id] = src.[vm_id],
        [C.Backup.Model.CloudVmsOnQuotas].[resource_quota_id] = src.[resource_quota_id]
    FROM [C.Backup.Model.CloudVmsOnQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudVmsOnQuotas].id = src.id    AND [C.Backup.Model.CloudVmsOnQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudVmsOnQuotas]([vm_id], [resource_quota_id], [id], db_instance_id)
    SELECT
        src.[vm_id],
        src.[resource_quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudVmsOnQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudVmsOnQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudVmsOnQuotas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudVmsOnQuotas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [job_id] uniqueidentifier,
       [tenant_id] uniqueidentifier,
       [options] xml,
       [test_mode_job_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [job_id], [tenant_id], [options], [test_mode_job_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [job_id] uniqueidentifier 'job_id',
       [tenant_id] uniqueidentifier 'tenant_id',
       [options] xml 'options/*',
       [test_mode_job_id] uniqueidentifier 'test_mode_job_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudFailoverPlan]
    SET
        [C.Backup.Model.CloudFailoverPlan].[job_id] = src.[job_id],
        [C.Backup.Model.CloudFailoverPlan].[tenant_id] = src.[tenant_id],
        [C.Backup.Model.CloudFailoverPlan].[options] = src.[options],
        [C.Backup.Model.CloudFailoverPlan].[test_mode_job_id] = src.[test_mode_job_id]
    FROM [C.Backup.Model.CloudFailoverPlan] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudFailoverPlan].id = src.id    AND [C.Backup.Model.CloudFailoverPlan].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudFailoverPlan]([id], [job_id], [tenant_id], [options], [test_mode_job_id], db_instance_id)
    SELECT
        src.[id],
        src.[job_id],
        src.[tenant_id],
        src.[options],
        src.[test_mode_job_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudFailoverPlan] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudFailoverPlan_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudFailoverPlan]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudFailoverPlan].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [backup_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [backup_id], [quota_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [backup_id] uniqueidentifier 'backup_id',
       [quota_id] uniqueidentifier 'quota_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViCloudTenantBackups]
    SET
        [C.Backup.Model.ViCloudTenantBackups].[backup_id] = src.[backup_id],
        [C.Backup.Model.ViCloudTenantBackups].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.ViCloudTenantBackups] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViCloudTenantBackups].id = src.id    AND [C.Backup.Model.ViCloudTenantBackups].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViCloudTenantBackups]([id], [backup_id], [quota_id], db_instance_id)
    SELECT
        src.[id],
        src.[backup_id],
        src.[quota_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViCloudTenantBackups] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudTenantBackups_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViCloudTenantBackups]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViCloudTenantBackups].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [backup_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [backup_id], [quota_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [backup_id] uniqueidentifier 'backup_id',
       [quota_id] uniqueidentifier 'quota_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvCloudTenantBackups]
    SET
        [C.Backup.Model.HvCloudTenantBackups].[backup_id] = src.[backup_id],
        [C.Backup.Model.HvCloudTenantBackups].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.HvCloudTenantBackups] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvCloudTenantBackups].id = src.id    AND [C.Backup.Model.HvCloudTenantBackups].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvCloudTenantBackups]([id], [backup_id], [quota_id], db_instance_id)
    SELECT
        src.[id],
        src.[backup_id],
        src.[quota_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvCloudTenantBackups] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudTenantBackups_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvCloudTenantBackups]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvCloudTenantBackups].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [tenantId] uniqueidentifier,
       [hardwarePlanId] uniqueidentifier,
       [expireDate] datetime,
       [folderReference] nvarchar(max),
       [resourcePoolReference] nvarchar(max),
       [isCorrespondsToPlan] bit,
       [wan_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [tenantId], [hardwarePlanId], [expireDate], [folderReference], [resourcePoolReference], [isCorrespondsToPlan], [wan_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [tenantId] uniqueidentifier 'tenantId',
       [hardwarePlanId] uniqueidentifier 'hardwarePlanId',
       [expireDate] datetime 'expireDate',
       [folderReference] nvarchar(max) 'folderReference',
       [resourcePoolReference] nvarchar(max) 'resourcePoolReference',
       [isCorrespondsToPlan] bit 'isCorrespondsToPlan',
       [wan_id] uniqueidentifier 'wan_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViHardwareQuotas]
    SET
        [C.Backup.Model.ViHardwareQuotas].[tenantId] = src.[tenantId],
        [C.Backup.Model.ViHardwareQuotas].[hardwarePlanId] = src.[hardwarePlanId],
        [C.Backup.Model.ViHardwareQuotas].[expireDate] = src.[expireDate],
        [C.Backup.Model.ViHardwareQuotas].[folderReference] = src.[folderReference],
        [C.Backup.Model.ViHardwareQuotas].[resourcePoolReference] = src.[resourcePoolReference],
        [C.Backup.Model.ViHardwareQuotas].[isCorrespondsToPlan] = src.[isCorrespondsToPlan],
        [C.Backup.Model.ViHardwareQuotas].[wan_id] = src.[wan_id]
    FROM [C.Backup.Model.ViHardwareQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViHardwareQuotas].id = src.id    AND [C.Backup.Model.ViHardwareQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViHardwareQuotas]([id], [tenantId], [hardwarePlanId], [expireDate], [folderReference], [resourcePoolReference], [isCorrespondsToPlan], [wan_id], db_instance_id)
    SELECT
        src.[id],
        src.[tenantId],
        src.[hardwarePlanId],
        src.[expireDate],
        src.[folderReference],
        src.[resourcePoolReference],
        src.[isCorrespondsToPlan],
        src.[wan_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViHardwareQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViHardwareQuotas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViHardwareQuotas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------



-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [tenantId] uniqueidentifier,
       [hardwarePlanId] uniqueidentifier,
       [expireDate] datetime,
       [isCorrespondsToPlan] bit,
       [wan_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [tenantId], [hardwarePlanId], [expireDate], [isCorrespondsToPlan], [wan_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [tenantId] uniqueidentifier 'tenantId',
       [hardwarePlanId] uniqueidentifier 'hardwarePlanId',
       [expireDate] datetime 'expireDate',
       [isCorrespondsToPlan] bit 'isCorrespondsToPlan',
       [wan_id] uniqueidentifier 'wan_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvHardwareQuotas]
    SET
        [C.Backup.Model.HvHardwareQuotas].[tenantId] = src.[tenantId],
        [C.Backup.Model.HvHardwareQuotas].[hardwarePlanId] = src.[hardwarePlanId],
        [C.Backup.Model.HvHardwareQuotas].[expireDate] = src.[expireDate],
        [C.Backup.Model.HvHardwareQuotas].[isCorrespondsToPlan] = src.[isCorrespondsToPlan],
        [C.Backup.Model.HvHardwareQuotas].[wan_id] = src.[wan_id]
    FROM [C.Backup.Model.HvHardwareQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvHardwareQuotas].id = src.id    AND [C.Backup.Model.HvHardwareQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvHardwareQuotas]([id], [tenantId], [hardwarePlanId], [expireDate], [isCorrespondsToPlan], [wan_id], db_instance_id)
    SELECT
        src.[id],
        src.[tenantId],
        src.[hardwarePlanId],
        src.[expireDate],
        src.[isCorrespondsToPlan],
        src.[wan_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvHardwareQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvHardwareQuotas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvHardwareQuotas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwarePlans_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwarePlans_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlans_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlans_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [friendlyName] nvarchar(max),
	   [description] nvarchar(max),
       [hypervisorHostId] uniqueidentifier,
       [parentType] int,
       [parentName] nvarchar(max),
       [parentReference] nvarchar(max),       
       [processorUsageLimitMhz] int,
       [memoryUsageLimitMb] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [friendlyName],[description], [hypervisorHostId], [parentType], [parentName], [parentReference], [processorUsageLimitMhz], [memoryUsageLimitMb])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [friendlyName] nvarchar(max) 'friendlyName',
	   [description] nvarchar(max) 'description',
       [hypervisorHostId] uniqueidentifier 'hypervisorHostId',
       [parentType] int 'parentType',
       [parentName] nvarchar(max) 'parentName',
       [parentReference] nvarchar(max) 'parentReference',       
       [processorUsageLimitMhz] int 'processorUsageLimitMhz',
       [memoryUsageLimitMb] int 'memoryUsageLimitMb'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViHardwarePlans]
    SET
        [C.Backup.Model.ViHardwarePlans].[friendlyName] = src.[friendlyName],
        [C.Backup.Model.ViHardwarePlans].[description] = src.[description],
        [C.Backup.Model.ViHardwarePlans].[hypervisorHostId] = src.[hypervisorHostId],
        [C.Backup.Model.ViHardwarePlans].[parentType] = src.[parentType],
        [C.Backup.Model.ViHardwarePlans].[parentName] = src.[parentName],
        [C.Backup.Model.ViHardwarePlans].[parentReference] = src.[parentReference],      
        [C.Backup.Model.ViHardwarePlans].[processorUsageLimitMhz] = src.[processorUsageLimitMhz],
        [C.Backup.Model.ViHardwarePlans].[memoryUsageLimitMb] = src.[memoryUsageLimitMb]
    FROM [C.Backup.Model.ViHardwarePlans] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViHardwarePlans].id = src.id    AND [C.Backup.Model.ViHardwarePlans].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViHardwarePlans]([id], [friendlyName],[description], [hypervisorHostId], [parentType], [parentName], [parentReference], [processorUsageLimitMhz], [memoryUsageLimitMb], db_instance_id)
    SELECT
        src.[id],
        src.[friendlyName],
		src.[description],
        src.[hypervisorHostId],
        src.[parentType],
        src.[parentName],
        src.[parentReference],        
        src.[processorUsageLimitMhz],
        src.[memoryUsageLimitMb],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViHardwarePlans] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwarePlans_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwarePlans_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlans_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlans_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViHardwarePlans]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViHardwarePlans].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwarePlans_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwarePlans_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlans_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlans_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [friendlyName] nvarchar(max),
       [description] nvarchar(max),
       [hypervisorHostId] uniqueidentifier,
       [processorUsageLimitCores] int,
       [memoryUsageLimitMb] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [friendlyName], [description], [hypervisorHostId], [processorUsageLimitCores], [memoryUsageLimitMb])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [friendlyName] nvarchar(max) 'friendlyName',
       [description] nvarchar(max) 'description',
       [hypervisorHostId] uniqueidentifier 'hypervisorHostId',
       [processorUsageLimitCores] int 'processorUsageLimitCores',
       [memoryUsageLimitMb] int 'memoryUsageLimitMb'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvHardwarePlans]
    SET
        [C.Backup.Model.HvHardwarePlans].[friendlyName] = src.[friendlyName],
        [C.Backup.Model.HvHardwarePlans].[description] = src.[description],
        [C.Backup.Model.HvHardwarePlans].[hypervisorHostId] = src.[hypervisorHostId],
        [C.Backup.Model.HvHardwarePlans].[processorUsageLimitCores] = src.[processorUsageLimitCores],
        [C.Backup.Model.HvHardwarePlans].[memoryUsageLimitMb] = src.[memoryUsageLimitMb]
    FROM [C.Backup.Model.HvHardwarePlans] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvHardwarePlans].id = src.id    AND [C.Backup.Model.HvHardwarePlans].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvHardwarePlans]([id], [friendlyName], [description], [hypervisorHostId], [processorUsageLimitCores], [memoryUsageLimitMb], db_instance_id)
    SELECT
        src.[id],
        src.[friendlyName],
        src.[description],
        src.[hypervisorHostId],
        src.[processorUsageLimitCores],
        src.[memoryUsageLimitMb],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvHardwarePlans] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwarePlans_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwarePlans_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlans_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlans_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvHardwarePlans]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvHardwarePlans].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

----------------------------------------------------
--[dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [meta_repo_id] uniqueidentifier,
       [dependant_repo_id] uniqueidentifier,
       [options] xml,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [meta_repo_id], [dependant_repo_id], [options])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [meta_repo_id] uniqueidentifier 'meta_repo_id',
       [dependant_repo_id] uniqueidentifier 'dependant_repo_id',
       [options] xml 'options/*'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.ExtRepo.ExtRepos]
    SET
        [C.Backup.ExtRepo.ExtRepos].[meta_repo_id] = src.[meta_repo_id],
        [C.Backup.ExtRepo.ExtRepos].[dependant_repo_id] = src.[dependant_repo_id],
        [C.Backup.ExtRepo.ExtRepos].[options] =   ISNULL(src.[options], '<DependantRepositoryOptions />')
    FROM [C.Backup.ExtRepo.ExtRepos] INNER JOIN @imported_changes src
    ON [C.Backup.ExtRepo.ExtRepos].id = src.id    AND [C.Backup.ExtRepo.ExtRepos].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.ExtRepo.ExtRepos]([id], [meta_repo_id], [dependant_repo_id], [options], db_instance_id)
    SELECT
        src.[id],
        src.[meta_repo_id],
        src.[dependant_repo_id],
        ISNULL(src.[options], '<DependantRepositoryOptions />'),
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.ExtRepo.ExtRepos] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
--[dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_ExtRepo_ExtRepos_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.ExtRepo.ExtRepos]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.ExtRepo.ExtRepos].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanId] uniqueidentifier,
       [friendlyName] nvarchar(max),
       [reference] nvarchar(max),
       [rootPath] nvarchar(max),
       [quotaGb] int,
       [viType] nvarchar(max),
       [pbmProfileId] nvarchar(max),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanId], [friendlyName], [reference], [rootPath], [quotaGb], [viType], [pbmProfileId])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanId] uniqueidentifier 'hardwarePlanId',
       [friendlyName] nvarchar(max) 'friendlyName',
       [reference] nvarchar(max) 'reference',
       [rootPath] nvarchar(max) 'rootPath',
       [quotaGb] int 'quotaGb',
       [viType] nvarchar(max) 'viType',
       [pbmProfileId] nvarchar(max) 'pbmProfileId'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViHardwarePlanDatastores]
    SET
        [C.Backup.Model.ViHardwarePlanDatastores].[hardwarePlanId] = src.[hardwarePlanId],
        [C.Backup.Model.ViHardwarePlanDatastores].[friendlyName] = src.[friendlyName],
        [C.Backup.Model.ViHardwarePlanDatastores].[reference] = src.[reference],
        [C.Backup.Model.ViHardwarePlanDatastores].[rootPath] = src.[rootPath],
        [C.Backup.Model.ViHardwarePlanDatastores].[quotaGb] = src.[quotaGb],
        [C.Backup.Model.ViHardwarePlanDatastores].[viType] = src.[viType],
        [C.Backup.Model.ViHardwarePlanDatastores].[pbmProfileId] = src.[pbmProfileId]
    FROM [C.Backup.Model.ViHardwarePlanDatastores] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViHardwarePlanDatastores].id = src.id    AND [C.Backup.Model.ViHardwarePlanDatastores].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViHardwarePlanDatastores]([id], [hardwarePlanId], [friendlyName], [reference], [rootPath], [quotaGb], [viType], [pbmProfileId], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanId],
        src.[friendlyName],
        src.[reference],
        src.[rootPath],
        src.[quotaGb],
        src.[viType],
        src.[pbmProfileId],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViHardwarePlanDatastores] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanDatastores_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViHardwarePlanDatastores]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViHardwarePlanDatastores].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanId] uniqueidentifier,
       [countWithInternent] int,
       [countWithoutInternent] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanId], [countWithInternent], [countWithoutInternent])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanId] uniqueidentifier 'hardwarePlanId',
       [countWithInternent] int 'countWithInternent',
       [countWithoutInternent] int 'countWithoutInternent'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViHardwarePlanNetworks]
    SET
        [C.Backup.Model.ViHardwarePlanNetworks].[hardwarePlanId] = src.[hardwarePlanId],
        [C.Backup.Model.ViHardwarePlanNetworks].[countWithInternet] = src.[countWithInternent],
        [C.Backup.Model.ViHardwarePlanNetworks].[countWithoutInternet] = src.[countWithoutInternent]
    FROM [C.Backup.Model.ViHardwarePlanNetworks] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViHardwarePlanNetworks].id = src.id    AND [C.Backup.Model.ViHardwarePlanNetworks].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViHardwarePlanNetworks]([id], [hardwarePlanId], [countWithInternet], [countWithoutInternet], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanId],
        src.[countWithInternent],
        src.[countWithoutInternent],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViHardwarePlanNetworks] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwarePlanNetworks_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViHardwarePlanNetworks]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViHardwarePlanNetworks].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanNetworkId] uniqueidentifier,
       [hardwareQuotaId] uniqueidentifier,
       [name] nvarchar(max),
       [vlanId] int,
       [ifaceNum] int,
       [tenantInfo] xml,
       [hasInternet] bit,
       [hostNetworks] xml,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanNetworkId], [hardwareQuotaId], [name], [vlanId], [ifaceNum], [tenantInfo], [hasInternet], [hostNetworks])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanNetworkId] uniqueidentifier 'hardwarePlanNetworkId',
       [hardwareQuotaId] uniqueidentifier 'hardwareQuotaId',
       [name] nvarchar(max) 'name',
       [vlanId] int 'vlanId',
       [ifaceNum] int 'ifaceNum',
       [tenantInfo] xml 'tenantInfo/*',
       [hasInternet] bit 'hasInternet',
       [hostNetworks] xml 'hostNetworks/*'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViHardwareQuotaNetworks]
    SET
        [C.Backup.Model.ViHardwareQuotaNetworks].[hardwarePlanNetworkId] = src.[hardwarePlanNetworkId],
        [C.Backup.Model.ViHardwareQuotaNetworks].[hardwareQuotaId] = src.[hardwareQuotaId],
        [C.Backup.Model.ViHardwareQuotaNetworks].[name] = src.[name],
        [C.Backup.Model.ViHardwareQuotaNetworks].[vlanId] = src.[vlanId],
        [C.Backup.Model.ViHardwareQuotaNetworks].[ifaceNum] = src.[ifaceNum],
        [C.Backup.Model.ViHardwareQuotaNetworks].[tenantInfo] = src.[tenantInfo],
        [C.Backup.Model.ViHardwareQuotaNetworks].[hasInternet] = src.[hasInternet],
        [C.Backup.Model.ViHardwareQuotaNetworks].[hostNetworks] = src.[hostNetworks]
    FROM [C.Backup.Model.ViHardwareQuotaNetworks] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViHardwareQuotaNetworks].id = src.id    AND [C.Backup.Model.ViHardwareQuotaNetworks].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViHardwareQuotaNetworks]([id], [hardwarePlanNetworkId], [hardwareQuotaId], [name], [vlanId], [ifaceNum], [tenantInfo], [hasInternet], [hostNetworks], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanNetworkId],
        src.[hardwareQuotaId],
        src.[name],
        src.[vlanId],
        src.[ifaceNum],
        src.[tenantInfo],
        src.[hasInternet],
        src.[hostNetworks],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViHardwareQuotaNetworks] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaNetworks_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViHardwareQuotaNetworks]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViHardwareQuotaNetworks].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanId] uniqueidentifier,
       [friendlyName] nvarchar(max),
       [volumePath] nvarchar(max),
       [quotaGb] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanId], [friendlyName], [volumePath], [quotaGb])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanId] uniqueidentifier 'hardwarePlanId',
       [friendlyName] nvarchar(max) 'friendlyName',
       [volumePath] nvarchar(max) 'volumePath',
       [quotaGb] int 'quotaGb'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvHardwarePlanVolumes]
    SET
        [C.Backup.Model.HvHardwarePlanVolumes].[hardwarePlanId] = src.[hardwarePlanId],
        [C.Backup.Model.HvHardwarePlanVolumes].[friendlyName] = src.[friendlyName],
        [C.Backup.Model.HvHardwarePlanVolumes].[volumePath] = src.[volumePath],
        [C.Backup.Model.HvHardwarePlanVolumes].[quotaGb] = src.[quotaGb]
    FROM [C.Backup.Model.HvHardwarePlanVolumes] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvHardwarePlanVolumes].id = src.id    AND [C.Backup.Model.HvHardwarePlanVolumes].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvHardwarePlanVolumes]([id], [hardwarePlanId], [friendlyName], [volumePath], [quotaGb], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanId],
        src.[friendlyName],
        src.[volumePath],
        src.[quotaGb],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvHardwarePlanVolumes] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanVolumes_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvHardwarePlanVolumes]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvHardwarePlanVolumes].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanId] uniqueidentifier,
       [countWithInternent] int,
       [countWithoutInternent] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanId], [countWithInternent], [countWithoutInternent])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanId] uniqueidentifier 'hardwarePlanId',
       [countWithInternent] int 'countWithInternent',
       [countWithoutInternent] int 'countWithoutInternent'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvHardwarePlanNetworks]
    SET
        [C.Backup.Model.HvHardwarePlanNetworks].[hardwarePlanId] = src.[hardwarePlanId],
        [C.Backup.Model.HvHardwarePlanNetworks].[countWithInternet] = src.[countWithInternent],
        [C.Backup.Model.HvHardwarePlanNetworks].[countWithoutInternet] = src.[countWithoutInternent]
    FROM [C.Backup.Model.HvHardwarePlanNetworks] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvHardwarePlanNetworks].id = src.id    AND [C.Backup.Model.HvHardwarePlanNetworks].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvHardwarePlanNetworks]([id], [hardwarePlanId], [countWithInternet], [countWithoutInternet], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanId],
        src.[countWithInternent],
        src.[countWithoutInternent],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvHardwarePlanNetworks] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwarePlanNetworks_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvHardwarePlanNetworks]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvHardwarePlanNetworks].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotaNetworks_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaNetworks_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaNetworks_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanNetworkId] uniqueidentifier,
       [hardwareQuotaId] uniqueidentifier,
       [name] nvarchar(max),
       [vlanId] int,
       [ifaceNum] int,
       [tenantInfo] xml,
       [hasInternet] bit,
       [switchName] nvarchar(max),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanNetworkId], [hardwareQuotaId], [name], [vlanId], [ifaceNum], [tenantInfo], [hasInternet], [switchName])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanNetworkId] uniqueidentifier 'hardwarePlanNetworkId',
       [hardwareQuotaId] uniqueidentifier 'hardwareQuotaId',
       [name] nvarchar(max) 'name',
       [vlanId] int 'vlanId',
       [ifaceNum] int 'ifaceNum',
       [tenantInfo] xml 'tenantInfo/*',
       [hasInternet] bit 'hasInternet',
       [switchName] nvarchar(max) 'switchName'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvHardwareQuotaNetworks]
    SET
        [C.Backup.Model.HvHardwareQuotaNetworks].[hardwarePlanNetworkId] = src.[hardwarePlanNetworkId],
        [C.Backup.Model.HvHardwareQuotaNetworks].[hardwareQuotaId] = src.[hardwareQuotaId],
        [C.Backup.Model.HvHardwareQuotaNetworks].[name] = src.[name],
        [C.Backup.Model.HvHardwareQuotaNetworks].[vlanId] = src.[vlanId],
        [C.Backup.Model.HvHardwareQuotaNetworks].[ifaceNum] = src.[ifaceNum],
        [C.Backup.Model.HvHardwareQuotaNetworks].[tenantInfo] = src.[tenantInfo],
        [C.Backup.Model.HvHardwareQuotaNetworks].[hasInternet] = src.[hasInternet],
        [C.Backup.Model.HvHardwareQuotaNetworks].[switchName] = src.[switchName]
    FROM [C.Backup.Model.HvHardwareQuotaNetworks] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvHardwareQuotaNetworks].id = src.id    AND [C.Backup.Model.HvHardwareQuotaNetworks].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvHardwareQuotaNetworks]([id], [hardwarePlanNetworkId], [hardwareQuotaId], [name], [vlanId], [ifaceNum], [tenantInfo], [hasInternet], [switchName], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanNetworkId],
        src.[hardwareQuotaId],
        src.[name],
        src.[vlanId],
        src.[ifaceNum],
        src.[tenantInfo],
        src.[hasInternet],
        src.[switchName],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvHardwareQuotaNetworks] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwareQuotaNetworks_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotaNetworks_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaNetworks_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaNetworks_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvHardwareQuotaNetworks]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvHardwareQuotaNetworks].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudPublicIp_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudPublicIp_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudPublicIp_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudPublicIp_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [ip_address] nvarchar(15),
       [tenant_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [ip_address], [tenant_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [ip_address] nvarchar(15) 'ip_address',
       [tenant_id] uniqueidentifier 'tenant_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudPublicIp]
    SET
        [C.Backup.Model.CloudPublicIp].[ip_address] = src.[ip_address],
        [C.Backup.Model.CloudPublicIp].[tenant_id] = src.[tenant_id]
    FROM [C.Backup.Model.CloudPublicIp] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudPublicIp].id = src.id    AND [C.Backup.Model.CloudPublicIp].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudPublicIp]([id], [ip_address], [tenant_id], db_instance_id)
    SELECT
        src.[id],
        src.[ip_address],
        src.[tenant_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudPublicIp] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudPublicIp_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudPublicIp_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudPublicIp_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudPublicIp_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudPublicIp]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudPublicIp].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_TenantPublicIp_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_TenantPublicIp_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_TenantPublicIp_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_TenantPublicIp_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [cloud_public_ip_id] uniqueidentifier,
       [id] uniqueidentifier,
       [target_port] int,
       [source_ip_address] nvarchar(15),
       [source_port] int,
       [object_id] uniqueidentifier,
       [failoverplan_id] uniqueidentifier,
       [description] nvarchar(max),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([cloud_public_ip_id], [id], [target_port], [source_ip_address], [source_port], [object_id], [failoverplan_id], [description])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [cloud_public_ip_id] uniqueidentifier 'cloud_public_ip_id',
       [id] uniqueidentifier 'id',
       [target_port] int 'target_port',
       [source_ip_address] nvarchar(15) 'source_ip_address',
       [source_port] int 'source_port',
       [object_id] uniqueidentifier 'object_id',
       [failoverplan_id] uniqueidentifier 'failoverplan_id',
       [description] nvarchar(max) 'description'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.TenantPublicIp]
    SET
        [C.Backup.Model.TenantPublicIp].[cloud_public_ip_id] = src.[cloud_public_ip_id],
        [C.Backup.Model.TenantPublicIp].[target_port] = src.[target_port],
        [C.Backup.Model.TenantPublicIp].[source_ip_address] = src.[source_ip_address],
        [C.Backup.Model.TenantPublicIp].[source_port] = src.[source_port],
        [C.Backup.Model.TenantPublicIp].[object_id] = src.[object_id],
        [C.Backup.Model.TenantPublicIp].[failoverplan_id] = src.[failoverplan_id],
        [C.Backup.Model.TenantPublicIp].[description] = src.[description]
    FROM [C.Backup.Model.TenantPublicIp] INNER JOIN @imported_changes src
    ON [C.Backup.Model.TenantPublicIp].id = src.id    AND [C.Backup.Model.TenantPublicIp].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.TenantPublicIp]([cloud_public_ip_id], [id], [target_port], [source_ip_address], [source_port], [object_id], [failoverplan_id], [description], db_instance_id)
    SELECT
        src.[cloud_public_ip_id],
        src.[id],
        src.[target_port],
        src.[source_ip_address],
        src.[source_port],
        src.[object_id],
        src.[failoverplan_id],
        src.[description],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.TenantPublicIp] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_TenantPublicIp_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_TenantPublicIp_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_TenantPublicIp_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_TenantPublicIp_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.TenantPublicIp]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.TenantPublicIp].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_HostNetwork_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_HostNetwork_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_HostNetwork_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_HostNetwork_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [host_id] uniqueidentifier,
       [inet_vlans_left_bound] int,
       [inet_vlans_right_bound] int,
       [non_inet_vlans_left_bound] int,
       [non_inet_vlans_right_bound] int,
       [vi_cluster_ref] nvarchar(2000),
       [vi_cluster_name] nvarchar(2000),
       [vswitch_name] nvarchar(2000),
       [vswitch_type] int,
       [vswitch_id] nvarchar(2000),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [host_id], [inet_vlans_left_bound], [inet_vlans_right_bound], [non_inet_vlans_left_bound], [non_inet_vlans_right_bound], [vi_cluster_ref], [vi_cluster_name], [vswitch_name], [vswitch_type], [vswitch_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [host_id] uniqueidentifier 'host_id',
       [inet_vlans_left_bound] int 'inet_vlans_left_bound',
       [inet_vlans_right_bound] int 'inet_vlans_right_bound',
       [non_inet_vlans_left_bound] int 'non_inet_vlans_left_bound',
       [non_inet_vlans_right_bound] int 'non_inet_vlans_right_bound',
       [vi_cluster_ref] nvarchar(2000) 'vi_cluster_ref',
       [vi_cluster_name] nvarchar(2000) 'vi_cluster_name',
       [vswitch_name] nvarchar(2000) 'vswitch_name',
       [vswitch_type] int 'vswitch_type',
       [vswitch_id] nvarchar(2000) 'vswitch_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.HostNetwork]
    SET
        [C.HostNetwork].[host_id] = src.[host_id],
        [C.HostNetwork].[inet_vlans_left_bound] = src.[inet_vlans_left_bound],
        [C.HostNetwork].[inet_vlans_right_bound] = src.[inet_vlans_right_bound],
        [C.HostNetwork].[non_inet_vlans_left_bound] = src.[non_inet_vlans_left_bound],
        [C.HostNetwork].[non_inet_vlans_right_bound] = src.[non_inet_vlans_right_bound],
        [C.HostNetwork].[vi_cluster_ref] = src.[vi_cluster_ref],
        [C.HostNetwork].[vi_cluster_name] = src.[vi_cluster_name],
        [C.HostNetwork].[vswitch_name] = src.[vswitch_name],
        [C.HostNetwork].[vswitch_type] = src.[vswitch_type],
        [C.HostNetwork].[vswitch_id] = src.[vswitch_id]
    FROM [C.HostNetwork] INNER JOIN @imported_changes src
    ON [C.HostNetwork].id = src.id    AND [C.HostNetwork].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.HostNetwork]([id], [host_id], [inet_vlans_left_bound], [inet_vlans_right_bound], [non_inet_vlans_left_bound], [non_inet_vlans_right_bound], [vi_cluster_ref], [vi_cluster_name], [vswitch_name], [vswitch_type], [vswitch_id], db_instance_id)
    SELECT
        src.[id],
        src.[host_id],
        src.[inet_vlans_left_bound],
        src.[inet_vlans_right_bound],
        src.[non_inet_vlans_left_bound],
        src.[non_inet_vlans_right_bound],
        src.[vi_cluster_ref],
        src.[vi_cluster_name],
        src.[vswitch_name],
        src.[vswitch_type],
        src.[vswitch_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.HostNetwork] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_HostNetwork_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_HostNetwork_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_HostNetwork_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_HostNetwork_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.HostNetwork]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.HostNetwork].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudAppliances_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudAppliances_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudAppliances_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudAppliances_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [tenant_id] uniqueidentifier,
       [connhost_id] uniqueidentifier,
       [pod_id] nvarchar(max),
       [network_spec] xml,
       [live_info] xml,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [tenant_id], [connhost_id], [pod_id], [network_spec], [live_info])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [tenant_id] uniqueidentifier 'tenant_id',
       [connhost_id] uniqueidentifier 'connhost_id',
       [pod_id] nvarchar(max) 'pod_id',
       [network_spec] xml 'network_spec/*',
       [live_info] xml 'live_info/*'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudAppliances]
    SET
        [C.Backup.Model.CloudAppliances].[tenant_id] = src.[tenant_id],
        [C.Backup.Model.CloudAppliances].[connhost_id] = src.[connhost_id],
        [C.Backup.Model.CloudAppliances].[pod_id] = src.[pod_id],
        [C.Backup.Model.CloudAppliances].[network_spec] = src.[network_spec],
        [C.Backup.Model.CloudAppliances].[live_info] = src.[live_info]
    FROM [C.Backup.Model.CloudAppliances] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudAppliances].id = src.id    AND [C.Backup.Model.CloudAppliances].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudAppliances]([id], [tenant_id], [connhost_id], [pod_id], [network_spec], [live_info], db_instance_id)
    SELECT
        src.[id],
        src.[tenant_id],
        src.[connhost_id],
        src.[pod_id],
        src.[network_spec],
        src.[live_info],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudAppliances] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudAppliances_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudAppliances_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudAppliances_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudAppliances_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudAppliances]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudAppliances].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_LicensedVms_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_LicensedVms_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_LicensedVms_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_LicensedVms_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [object_id] uniqueidentifier,
       [first_start_time] datetime,
       [last_start_time] datetime,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [object_id], [first_start_time], [last_start_time])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [object_id] uniqueidentifier 'object_id',
       [first_start_time] datetime 'first_start_time',
       [last_start_time] datetime 'last_start_time'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.LicensedVms]
    SET
        [C.Backup.Model.LicensedVms].[object_id] = src.[object_id],
        [C.Backup.Model.LicensedVms].[first_start_time] = src.[first_start_time],
        [C.Backup.Model.LicensedVms].[last_start_time] = src.[last_start_time]
    FROM [C.Backup.Model.LicensedVms] INNER JOIN @imported_changes src
    ON [C.Backup.Model.LicensedVms].id = src.id    AND [C.Backup.Model.LicensedVms].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.LicensedVms]([id], [object_id], [first_start_time], [last_start_time], db_instance_id)
    SELECT
        src.[id],
        src.[object_id],
        src.[first_start_time],
        src.[last_start_time],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.LicensedVms] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_LicensedVms_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_LicensedVms_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_LicensedVms_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_LicensedVms_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.LicensedVms]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.LicensedVms].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Replicas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Replicas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Replicas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Replicas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [backup_id] uniqueidentifier,
       [object_id] uniqueidentifier,
       [vm_name] nvarchar(1000),
       [source_location] nvarchar(512),
       [target_location] nvarchar(512),
       [target_vm_ref] nvarchar(2000),
       [state] int,
       [target_vm_name] nvarchar(1000),
       [vpn_state] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [backup_id], [object_id], [vm_name], [source_location], [target_location], [target_vm_ref], [state], [target_vm_name], [vpn_state])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [backup_id] uniqueidentifier 'backup_id',
       [object_id] uniqueidentifier 'object_id',
       [vm_name] nvarchar(1000) 'vm_name',
       [source_location] nvarchar(512) 'source_location',
       [target_location] nvarchar(512) 'target_location',
       [target_vm_ref] nvarchar(2000) 'target_vm_ref',
       [state] int 'state',
       [target_vm_name] nvarchar(1000) 'target_vm_name',
       [vpn_state] int 'vpn_state'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Replicas]
    SET
        [C.Replicas].[backup_id] = src.[backup_id],
        [C.Replicas].[object_id] = src.[object_id],
        [C.Replicas].[vm_name] = src.[vm_name],
        [C.Replicas].[source_location] = src.[source_location],
        [C.Replicas].[target_location] = src.[target_location],
        [C.Replicas].[target_vm_ref] = src.[target_vm_ref],
        [C.Replicas].[state] = src.[state],
        [C.Replicas].[target_vm_name] = src.[target_vm_name],
        [C.Replicas].[vpn_state] = src.[vpn_state]
    FROM [C.Replicas] INNER JOIN @imported_changes src
    ON [C.Replicas].id = src.id    AND [C.Replicas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Replicas]([id], [backup_id], [object_id], [vm_name], [source_location], [target_location], [target_vm_ref], [state], [target_vm_name], [vpn_state], db_instance_id)
    SELECT
        src.[id],
        src.[backup_id],
        src.[object_id],
        src.[vm_name],
        src.[source_location],
        src.[target_location],
        src.[target_vm_ref],
        src.[state],
        src.[target_vm_name],
        src.[vpn_state],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Replicas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Replicas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Replicas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Replicas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Replicas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Replicas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Replicas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

-----------------------------------------------------
--[dbo].[usp_Import_ReplicaConfigurations_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_ReplicaConfigurations_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_ReplicaConfigurations_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_ReplicaConfigurations_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [cpuCount] int,
       [memoryMb] int,
       [specific] xml,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [cpuCount], [memoryMb], [specific])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [cpuCount] int 'cpuCount',
       [memoryMb] int 'memoryMb',
       [specific] xml 'specific/*'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.ReplicaConfigurations]
    SET
        [C.ReplicaConfigurations].[cpuCount] = src.[cpuCount],
        [C.ReplicaConfigurations].[memoryMb] = src.[memoryMb],
        [C.ReplicaConfigurations].[specific] = src.[specific]
    FROM [C.ReplicaConfigurations] INNER JOIN @imported_changes src
    ON [C.ReplicaConfigurations].id = src.id    AND [C.ReplicaConfigurations].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.ReplicaConfigurations]([id], [cpuCount], [memoryMb], [specific], db_instance_id)
    SELECT
        src.[id],
        src.[cpuCount],
        src.[memoryMb],
        src.[specific],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.ReplicaConfigurations] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_ReplicaConfigurations_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_ReplicaConfigurations_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_ReplicaConfigurations_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_ReplicaConfigurations_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.ReplicaConfigurations]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.ReplicaConfigurations].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [hardwareDatastoreQuotaId] uniqueidentifier,
       [replicaId] uniqueidentifier,
       [usageBytes] bigint,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([hardwareDatastoreQuotaId], [replicaId], [usageBytes], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [hardwareDatastoreQuotaId] uniqueidentifier 'hardwareDatastoreQuotaId',
       [replicaId] uniqueidentifier 'replicaId',
       [usageBytes] bigint 'usageBytes',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViHardwareQuotaDatastoreUsages]
    SET
        [C.Backup.Model.ViHardwareQuotaDatastoreUsages].[hardwareDatastoreQuotaId] = src.[hardwareDatastoreQuotaId],
        [C.Backup.Model.ViHardwareQuotaDatastoreUsages].[replicaId] = src.[replicaId],
        [C.Backup.Model.ViHardwareQuotaDatastoreUsages].[usageBytes] = src.[usageBytes]
    FROM [C.Backup.Model.ViHardwareQuotaDatastoreUsages] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViHardwareQuotaDatastoreUsages].id = src.id    AND [C.Backup.Model.ViHardwareQuotaDatastoreUsages].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViHardwareQuotaDatastoreUsages]([hardwareDatastoreQuotaId], [replicaId], [usageBytes], [id], db_instance_id)
    SELECT
        src.[hardwareDatastoreQuotaId],
        src.[replicaId],
        src.[usageBytes],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViHardwareQuotaDatastoreUsages] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViHardwareQuotaDatastoreUsages]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViHardwareQuotaDatastoreUsages].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [hardwareVolumeQuotaId] uniqueidentifier,
       [replicaId] uniqueidentifier,
       [usageBytes] bigint,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([hardwareVolumeQuotaId], [replicaId], [usageBytes], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [hardwareVolumeQuotaId] uniqueidentifier 'hardwareVolumeQuotaId',
       [replicaId] uniqueidentifier 'replicaId',
       [usageBytes] bigint 'usageBytes',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvHardwareQuotaVolumeUsages]
    SET
        [C.Backup.Model.HvHardwareQuotaVolumeUsages].[hardwareVolumeQuotaId] = src.[hardwareVolumeQuotaId],
        [C.Backup.Model.HvHardwareQuotaVolumeUsages].[replicaId] = src.[replicaId],
        [C.Backup.Model.HvHardwareQuotaVolumeUsages].[usageBytes] = src.[usageBytes]
    FROM [C.Backup.Model.HvHardwareQuotaVolumeUsages] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvHardwareQuotaVolumeUsages].id = src.id    AND [C.Backup.Model.HvHardwareQuotaVolumeUsages].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvHardwareQuotaVolumeUsages]([hardwareVolumeQuotaId], [replicaId], [usageBytes], [id], db_instance_id)
    SELECT
        src.[hardwareVolumeQuotaId],
        src.[replicaId],
        src.[usageBytes],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvHardwareQuotaVolumeUsages] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvHardwareQuotaVolumeUsages]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvHardwareQuotaVolumeUsages].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------

-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanDatastoreId] uniqueidentifier,
       [hardwareQuotaId] uniqueidentifier,
       [relativePath] nvarchar(MAX),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanDatastoreId], [hardwareQuotaId], [relativePath])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanDatastoreId] uniqueidentifier 'hardwarePlanDatastoreId',
       [hardwareQuotaId] uniqueidentifier 'hardwareQuotaId',
       [relativePath] nvarchar(MAX) 'relativePath'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViHardwareQuotaDatastores]
    SET
        [C.Backup.Model.ViHardwareQuotaDatastores].[hardwarePlanDatastoreId] = src.[hardwarePlanDatastoreId],
        [C.Backup.Model.ViHardwareQuotaDatastores].[hardwareQuotaId] = src.[hardwareQuotaId],
        [C.Backup.Model.ViHardwareQuotaDatastores].[relativePath] = src.[relativePath]
    FROM [C.Backup.Model.ViHardwareQuotaDatastores] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViHardwareQuotaDatastores].id = src.id    AND [C.Backup.Model.ViHardwareQuotaDatastores].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViHardwareQuotaDatastores]([id], [hardwarePlanDatastoreId], [hardwareQuotaId], [relativePath], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanDatastoreId],
        src.[hardwareQuotaId],
        src.[relativePath],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViHardwareQuotaDatastores] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViHardwareQuotaDatastores_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViHardwareQuotaDatastores]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViHardwareQuotaDatastores].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [hardwarePlanVolumeId] uniqueidentifier,
       [hardwareQuotaId] uniqueidentifier,
       [relativePath] nvarchar(MAX),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [hardwarePlanVolumeId], [hardwareQuotaId], [relativePath])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [hardwarePlanVolumeId] uniqueidentifier 'hardwarePlanVolumeId',
       [hardwareQuotaId] uniqueidentifier 'hardwareQuotaId',
       [relativePath] nvarchar(MAX) 'relativePath'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvHardwareQuotaVolumes]
    SET
        [C.Backup.Model.HvHardwareQuotaVolumes].[hardwarePlanVolumeId] = src.[hardwarePlanVolumeId],
        [C.Backup.Model.HvHardwareQuotaVolumes].[hardwareQuotaId] = src.[hardwareQuotaId],
        [C.Backup.Model.HvHardwareQuotaVolumes].[relativePath] = src.[relativePath]
    FROM [C.Backup.Model.HvHardwareQuotaVolumes] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvHardwareQuotaVolumes].id = src.id    AND [C.Backup.Model.HvHardwareQuotaVolumes].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvHardwareQuotaVolumes]([id], [hardwarePlanVolumeId], [hardwareQuotaId], [relativePath], db_instance_id)
    SELECT
        src.[id],
        src.[hardwarePlanVolumeId],
        src.[hardwareQuotaId],
        src.[relativePath],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvHardwareQuotaVolumes] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvHardwareQuotaVolumes_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvHardwareQuotaVolumes]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvHardwareQuotaVolumes].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------
-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [object_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([object_id], [quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [object_id] uniqueidentifier 'object_id',
       [quota_id] uniqueidentifier 'quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.ViCloudQuotaObjects]
    SET
        [C.Backup.Model.ViCloudQuotaObjects].[object_id] = src.[object_id],
        [C.Backup.Model.ViCloudQuotaObjects].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.ViCloudQuotaObjects] INNER JOIN @imported_changes src
    ON [C.Backup.Model.ViCloudQuotaObjects].id = src.id    AND [C.Backup.Model.ViCloudQuotaObjects].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.ViCloudQuotaObjects]([object_id], [quota_id], [id], db_instance_id)
    SELECT
        src.[object_id],
        src.[quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.ViCloudQuotaObjects] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_ViCloudQuotaObjects_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.ViCloudQuotaObjects]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.ViCloudQuotaObjects].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [object_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([object_id], [quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [object_id] uniqueidentifier 'object_id',
       [quota_id] uniqueidentifier 'quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.HvCloudQuotaObjects]
    SET
        [C.Backup.Model.HvCloudQuotaObjects].[object_id] = src.[object_id],
        [C.Backup.Model.HvCloudQuotaObjects].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.HvCloudQuotaObjects] INNER JOIN @imported_changes src
    ON [C.Backup.Model.HvCloudQuotaObjects].id = src.id    AND [C.Backup.Model.HvCloudQuotaObjects].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.HvCloudQuotaObjects]([object_id], [quota_id], [id], db_instance_id)
    SELECT
        src.[object_id],
        src.[quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.HvCloudQuotaObjects] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_HvCloudQuotaObjects_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.HvCloudQuotaObjects]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.HvCloudQuotaObjects].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [object_id] uniqueidentifier,
       [number] bigint,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([object_id], [number], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [object_id] uniqueidentifier 'object_id',
       [number] bigint 'number',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudLicensedObjects]
    SET
        [C.Backup.Model.CloudLicensedObjects].[object_id] = src.[object_id],
        [C.Backup.Model.CloudLicensedObjects].[number] = src.[number]
    FROM [C.Backup.Model.CloudLicensedObjects] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudLicensedObjects].id = src.id    AND [C.Backup.Model.CloudLicensedObjects].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudLicensedObjects]([object_id], [number], [id], db_instance_id)
    SELECT
        src.[object_id],
        src.[number],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudLicensedObjects] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudLicensedObjects_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudLicensedObjects]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudLicensedObjects].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [session_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([session_id], [quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [session_id] uniqueidentifier 'session_id',
       [quota_id] uniqueidentifier 'quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudSessionsOnViHardwareQuotas]
    SET
        [C.Backup.Model.CloudSessionsOnViHardwareQuotas].[session_id] = src.[session_id],
        [C.Backup.Model.CloudSessionsOnViHardwareQuotas].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.CloudSessionsOnViHardwareQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudSessionsOnViHardwareQuotas].id = src.id    AND [C.Backup.Model.CloudSessionsOnViHardwareQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudSessionsOnViHardwareQuotas]([session_id], [quota_id], [id], db_instance_id)
    SELECT
        src.[session_id],
        src.[quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudSessionsOnViHardwareQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudSessionsOnViHardwareQuotas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudSessionsOnViHardwareQuotas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [session_id] uniqueidentifier,
       [quota_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([session_id], [quota_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [session_id] uniqueidentifier 'session_id',
       [quota_id] uniqueidentifier 'quota_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [C.Backup.Model.CloudSessionsOnHvHardwareQuotas]
    SET
        [C.Backup.Model.CloudSessionsOnHvHardwareQuotas].[session_id] = src.[session_id],
        [C.Backup.Model.CloudSessionsOnHvHardwareQuotas].[quota_id] = src.[quota_id]
    FROM [C.Backup.Model.CloudSessionsOnHvHardwareQuotas] INNER JOIN @imported_changes src
    ON [C.Backup.Model.CloudSessionsOnHvHardwareQuotas].id = src.id    AND [C.Backup.Model.CloudSessionsOnHvHardwareQuotas].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [C.Backup.Model.CloudSessionsOnHvHardwareQuotas]([session_id], [quota_id], [id], db_instance_id)
    SELECT
        src.[session_id],
        src.[quota_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [C.Backup.Model.CloudSessionsOnHvHardwareQuotas] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[C.Backup.Model.CloudSessionsOnHvHardwareQuotas]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
    AND [dbo].[C.Backup.Model.CloudSessionsOnHvHardwareQuotas].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


