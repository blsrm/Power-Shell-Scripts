﻿-----------------------------------------------------
--[dbo].[usp_Import_70_Folder_Host_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Folder_Host_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Folder_Host_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Folder_Host_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [host_id] uniqueidentifier,
       [folder_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [host_id], [folder_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [host_id] uniqueidentifier 'host_id',
       [folder_id] uniqueidentifier 'folder_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Folder_Host]
    SET
        [70.Folder_Host].[host_id] = src.[host_id],
        [70.Folder_Host].[folder_id] = src.[folder_id]
    FROM [70.Folder_Host] INNER JOIN @imported_changes src
    ON [70.Folder_Host].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Folder_Host]([id], [host_id], [folder_id], db_instance_id)
    SELECT
        src.[id],
        src.[host_id],
        src.[folder_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Folder_Host] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Folder_Host_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Folder_Host_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Folder_Host_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Folder_Host_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Folder_Host]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_ObjectsInJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_ObjectsInJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_ObjectsInJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_ObjectsInJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [type] int,
       [location] nvarchar(1024),
       [approx_size] bigint,
       [folder_id] uniqueidentifier,
       [id] uniqueidentifier,
       [job_id] uniqueidentifier,
       [object_id] uniqueidentifier,
       [vss_options] xml,
       [order_no] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([type], [location], [approx_size], [folder_id], [id], [job_id], [object_id], [vss_options], [order_no])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [type] int 'type',
       [location] nvarchar(1024) 'location',
       [approx_size] bigint 'approx_size',
       [folder_id] uniqueidentifier 'folder_id',
       [id] uniqueidentifier 'id',
       [job_id] uniqueidentifier 'job_id',
       [object_id] uniqueidentifier 'object_id',
       [vss_options] xml 'vss_options/*',
       [order_no] int 'order_no'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.ObjectsInJobs]
    SET
        [70.ObjectsInJobs].[type] = src.[type],
        [70.ObjectsInJobs].[location] = src.[location],
        [70.ObjectsInJobs].[approx_size] = src.[approx_size],
        [70.ObjectsInJobs].[folder_id] = src.[folder_id],
        [70.ObjectsInJobs].[job_id] = src.[job_id],
        [70.ObjectsInJobs].[object_id] = src.[object_id],
        [70.ObjectsInJobs].[vss_options] = src.[vss_options],
        [70.ObjectsInJobs].[order_no] = src.[order_no]
    FROM [70.ObjectsInJobs] INNER JOIN @imported_changes src
    ON [70.ObjectsInJobs].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.ObjectsInJobs]([type], [location], [approx_size], [folder_id], [id], [job_id], [object_id], [vss_options], [order_no], db_instance_id)
    SELECT
        src.[type],
        src.[location],
        src.[approx_size],
        src.[folder_id],
        src.[id],
        src.[job_id],
        src.[object_id],
        src.[vss_options],
        src.[order_no],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.ObjectsInJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_ObjectsInJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_ObjectsInJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_ObjectsInJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_ObjectsInJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.ObjectsInJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Soap_creds_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Soap_creds_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Soap_creds_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Soap_creds_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [port] int,
       [enabled] bit,
       [useproxy] bit,
       [savepassword] bit,
       [proxyip] nvarchar(1024),
       [host_id] uniqueidentifier,
       [proxyport] int,
       [id] uniqueidentifier,
       [creds] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([port], [enabled], [useproxy], [savepassword], [proxyip], [host_id], [proxyport], [id], [creds])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [port] int 'port',
       [enabled] bit 'enabled',
       [useproxy] bit 'useproxy',
       [savepassword] bit 'savepassword',
       [proxyip] nvarchar(1024) 'proxyip',
       [host_id] uniqueidentifier 'host_id',
       [proxyport] int 'proxyport',
       [id] uniqueidentifier 'id',
       [creds] uniqueidentifier 'creds'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Soap_creds]
    SET
        [70.Soap_creds].[port] = src.[port],
        [70.Soap_creds].[enabled] = src.[enabled],
        [70.Soap_creds].[useproxy] = src.[useproxy],
        [70.Soap_creds].[savepassword] = src.[savepassword],
        [70.Soap_creds].[proxyip] = src.[proxyip],
        [70.Soap_creds].[host_id] = src.[host_id],
        [70.Soap_creds].[proxyport] = src.[proxyport],
        [70.Soap_creds].[creds] = src.[creds]
    FROM [70.Soap_creds] INNER JOIN @imported_changes src
    ON [70.Soap_creds].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Soap_creds]([port], [enabled], [useproxy], [savepassword], [proxyip], [host_id], [proxyport], [id], [creds], db_instance_id)
    SELECT
        src.[port],
        src.[enabled],
        src.[useproxy],
        src.[savepassword],
        src.[proxyip],
        src.[host_id],
        src.[proxyport],
        src.[id],
        src.[creds],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Soap_creds] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Soap_creds_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Soap_creds_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Soap_creds_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Soap_creds_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Soap_creds]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_BJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_BJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [latest_result] int,
       [target_type] int,
       [id] uniqueidentifier,
       [is_deleted] bit,
       [options] xml,
       [platform] int,
       [target_host_id] uniqueidentifier,
       [schedule] xml,
       [vss_options] xml,
       [target_file] nvarchar(2000),
       [vcb_host_id] uniqueidentifier,
       [description] nvarchar(1024),
       [name] nvarchar(255),
       [schedule_enabled] bit,
       [type] int,
       [target_dir] nvarchar(2000),
       [parent_schedule_id] uniqueidentifier,
       [repository_id] uniqueidentifier,
       [next_run_time] datetime,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([latest_result], [target_type], [id], [is_deleted], [options], [platform], [target_host_id], [schedule], [vss_options], [target_file], [vcb_host_id], [description], [name], [schedule_enabled], [type], [target_dir], [parent_schedule_id], [repository_id], [next_run_time])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [latest_result] int 'latest_result',
       [target_type] int 'target_type',
       [id] uniqueidentifier 'id',
       [is_deleted] bit 'is_deleted',
       [options] xml 'options/*',
       [platform] int 'platform',
       [target_host_id] uniqueidentifier 'target_host_id',
       [schedule] xml 'schedule/*',
       [vss_options] xml 'vss_options/*',
       [target_file] nvarchar(2000) 'target_file',
       [vcb_host_id] uniqueidentifier 'vcb_host_id',
       [description] nvarchar(1024) 'description',
       [name] nvarchar(255) 'name',
       [schedule_enabled] bit 'schedule_enabled',
       [type] int 'type',
       [target_dir] nvarchar(2000) 'target_dir',
       [parent_schedule_id] uniqueidentifier 'parent_schedule_id',
       [repository_id] uniqueidentifier 'repository_id',
       [next_run_time] datetime 'next_run_time'
    ) as x WHERE x.type < 100; /* Do not import util jobs */
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET [next_run_time] = DATEADD( minute, -@TimeZoneShift, [next_run_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.BJobs]
    SET
        [70.BJobs].[latest_result] = src.[latest_result],
        [70.BJobs].[target_type] = src.[target_type],
        [70.BJobs].[is_deleted] = src.[is_deleted],
        [70.BJobs].[options] = src.[options],
        [70.BJobs].[platform] = src.[platform],
        [70.BJobs].[target_host_id] = src.[target_host_id],
        [70.BJobs].[schedule] = src.[schedule],
        [70.BJobs].[vss_options] = src.[vss_options],
        [70.BJobs].[target_file] = src.[target_file],
        [70.BJobs].[vcb_host_id] = src.[vcb_host_id],
        [70.BJobs].[description] = src.[description],
        [70.BJobs].[name] = src.[name],
        [70.BJobs].[schedule_enabled] = src.[schedule_enabled],
        [70.BJobs].[type] = src.[type],
        [70.BJobs].[target_dir] = src.[target_dir],
        [70.BJobs].[parent_schedule_id] = src.[parent_schedule_id],
        [70.BJobs].[repository_id] = src.[repository_id],
        [70.BJobs].[next_run_time] = src.[next_run_time]
    FROM [70.BJobs] INNER JOIN @imported_changes src
    ON [70.BJobs].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.BJobs]([latest_result], [target_type], [id], [is_deleted], [options], [platform], [target_host_id], [schedule], [vss_options], [target_file], [vcb_host_id], [description], [name], [schedule_enabled], [type], [target_dir], [parent_schedule_id], [repository_id], [next_run_time], db_instance_id)
    SELECT
        src.[latest_result],
        src.[target_type],
        src.[id],
        src.[is_deleted],
        src.[options],
        src.[platform],
        src.[target_host_id],
        src.[schedule],
        src.[vss_options],
        src.[target_file],
        src.[vcb_host_id],
        src.[description],
        src.[name],
        src.[schedule_enabled],
        src.[type],
        src.[target_dir],
        src.[parent_schedule_id],
        src.[repository_id],
        src.[next_run_time],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.BJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_BJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_BJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.BJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_BObjects_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BObjects_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_BObjects_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BObjects_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [object_name] nvarchar(2000),
       [guest_os] xml,
       [host_id] uniqueidentifier,
       [object_id] nvarchar(434),
       [viobject_type] nvarchar(50),
       [type] int,
       [unique_key_hash] varbinary(max),
       [display_name] nvarchar(256),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [object_name], [guest_os], [host_id], [object_id], [viobject_type], [type], [unique_key_hash], [display_name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [object_name] nvarchar(2000) 'object_name',
       [guest_os] xml 'guest_os/*',
       [host_id] uniqueidentifier 'host_id',
       [object_id] nvarchar(434) 'object_id',
       [viobject_type] nvarchar(50) 'viobject_type',
       [type] int 'type',
       [unique_key_hash] varbinary(max) 'unique_key_hash',
       [display_name] nvarchar(256) 'display_name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

	/* Update empty xml values */
	UPDATE @imported_changes 
	SET [guest_os] = '<GuestInfo />'
    WHERE [guest_os] IS NULL;


    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.BObjects]
    SET
        [70.BObjects].[object_name] = src.[object_name],
        [70.BObjects].[guest_os] = src.[guest_os],
        [70.BObjects].[host_id] = src.[host_id],
        [70.BObjects].[object_id] = src.[object_id],
        [70.BObjects].[viobject_type] = src.[viobject_type],
        [70.BObjects].[type] = src.[type],
        [70.BObjects].[unique_key_hash] = src.[unique_key_hash],
        [70.BObjects].[display_name] = src.[display_name]
    FROM [70.BObjects] INNER JOIN @imported_changes src
    ON [70.BObjects].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.BObjects]([id], [object_name], [guest_os], [host_id], [object_id], [viobject_type], [type], [unique_key_hash], [display_name], db_instance_id)
    SELECT
        src.[id],
        src.[object_name],
        src.[guest_os],
        src.[host_id],
        src.[object_id],
        src.[viobject_type],
        src.[type],
        src.[unique_key_hash],
        src.[display_name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.BObjects] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_BObjects_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BObjects_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_BObjects_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BObjects_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.BObjects]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_Backups_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_Backups_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_Backups_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_Backups_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [job_source_type] int,
       [id] uniqueidentifier,
       [job_name] nvarchar(255),
       [job_target_host_protocol] int,
       [job_target_host_id] uniqueidentifier,
       [job_target_type] int,
       [job_id] uniqueidentifier,
       [repository_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([job_source_type], [id], [job_name], [job_target_host_protocol], [job_target_host_id], [job_target_type], [job_id], [repository_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [job_source_type] int 'job_source_type',
       [id] uniqueidentifier 'id',
       [job_name] nvarchar(255) 'job_name',
       [job_target_host_protocol] int 'job_target_host_protocol',
       [job_target_host_id] uniqueidentifier 'job_target_host_id',
       [job_target_type] int 'job_target_type',
       [job_id] uniqueidentifier 'job_id',
       [repository_id] uniqueidentifier 'repository_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.Backups]
    SET
        [70.Backup.Model.Backups].[job_source_type] = src.[job_source_type],
        [70.Backup.Model.Backups].[job_name] = src.[job_name],
        [70.Backup.Model.Backups].[job_target_host_protocol] = src.[job_target_host_protocol],
        [70.Backup.Model.Backups].[job_target_host_id] = src.[job_target_host_id],
        [70.Backup.Model.Backups].[job_target_type] = src.[job_target_type],
        [70.Backup.Model.Backups].[job_id] = src.[job_id],
        [70.Backup.Model.Backups].[repository_id] = src.[repository_id]
    FROM [70.Backup.Model.Backups] INNER JOIN @imported_changes src
    ON [70.Backup.Model.Backups].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.Backups]([job_source_type], [id], [job_name], [job_target_host_protocol], [job_target_host_id], [job_target_type], [job_id], [repository_id], db_instance_id)
    SELECT
        src.[job_source_type],
        src.[id],
        src.[job_name],
        src.[job_target_host_protocol],
        src.[job_target_host_id],
        src.[job_target_type],
        src.[job_id],
        src.[repository_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.Backups] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_Backups_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_Backups_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_Backups_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_Backups_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.Backups]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_Storages_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_Storages_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_Storages_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_Storages_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [block_size] int,
       [backup_id] uniqueidentifier,
       [stats] xml,
       [modification_time] datetime,
       [version] int,
       [id] uniqueidentifier,
       [file_path] nvarchar(1000),
       [creation_time] datetime,
       [host_id] uniqueidentifier,
       [full_size] bigint,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([block_size], [backup_id], [stats], [modification_time], [version], [id], [file_path], [creation_time], [host_id], [full_size])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [block_size] int 'block_size',
       [backup_id] uniqueidentifier 'backup_id',
       [stats] xml 'stats/*',
       [modification_time] datetime 'modification_time',
       [version] int 'version',
       [id] uniqueidentifier 'id',
       [file_path] nvarchar(1000) 'file_path',
       [creation_time] datetime 'creation_time',
       [host_id] uniqueidentifier 'host_id',
       [full_size] bigint 'full_size'
    )
    EXEC sp_xml_removedocument @idoc

        DECLARE @cur_backup_id uniqueidentifier
        SET @cur_backup_id = (SELECT TOP(1) id FROM @imported_changes WHERE full_size IS NULL)
        WHILE @cur_backup_id IS NOT NULL
        BEGIN
		    DECLARE @xml XML
		    SET @xml = (SELECT TOP(1) stats FROM @imported_changes WHERE id = @cur_backup_id)

		    IF @xml IS NULL
			    UPDATE @imported_changes
			    SET full_size = 0
			    WHERE id = @cur_backup_id
		    ELSE
			    BEGIN
				    EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

				    UPDATE @imported_changes
				    SET full_size = 
					    (SELECT
						    CASE
							    WHEN size IS NULL THEN 0
							    ELSE size
						    END
					    FROM OPENXML( @idoc, 'stats/CBackupStats/BackupSize', 3)
					    WITH (size bigint 'text()'))
				    WHERE id = @cur_backup_id
				
				    UPDATE @imported_changes
				    SET full_size = 0
				    WHERE id = @cur_backup_id AND full_size IS NULL

				    EXEC sp_xml_removedocument @idoc
			    END
		
		    SET @cur_backup_id = (SELECT TOP(1) id FROM @imported_changes WHERE full_size IS NULL)
        END


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET
        [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time]),
        [modification_time] = DATEADD( minute, -@TimeZoneShift, [modification_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.Storages]
    SET
        [70.Backup.Model.Storages].[block_size] = src.[block_size],
        [70.Backup.Model.Storages].[backup_id] = src.[backup_id],
        [70.Backup.Model.Storages].[stats] = src.[stats],
        [70.Backup.Model.Storages].[modification_time] = src.[modification_time],
        [70.Backup.Model.Storages].[version] = src.[version],
        [70.Backup.Model.Storages].[file_path] = src.[file_path],
        [70.Backup.Model.Storages].[creation_time] = src.[creation_time],
        [70.Backup.Model.Storages].[host_id] = src.[host_id],
        [70.Backup.Model.Storages].[full_size] = src.[full_size]
    FROM [70.Backup.Model.Storages] INNER JOIN @imported_changes src
    ON [70.Backup.Model.Storages].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.Storages]([block_size], [backup_id], [stats], [modification_time], [version], [id], [file_path], [creation_time], [host_id], [full_size], db_instance_id)
    SELECT
        src.[block_size],
        src.[backup_id],
        src.[stats],
        src.[modification_time],
        src.[version],
        src.[id],
        src.[file_path],
        src.[creation_time],
        src.[host_id],
        src.[full_size],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.Storages] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_Storages_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_Storages_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_Storages_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_Storages_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.Storages]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_HostsByJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_HostsByJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_HostsByJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_HostsByJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [job_id] uniqueidentifier,
       [host_id] uniqueidentifier,
       [id] uniqueidentifier,
       [uuid] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([job_id], [host_id], [id], [uuid])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [job_id] uniqueidentifier 'job_id',
       [host_id] uniqueidentifier 'host_id',
       [id] uniqueidentifier 'id',
       [uuid] uniqueidentifier 'uuid'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.HostsByJobs]
    SET
        [70.HostsByJobs].[job_id] = src.[job_id],
        [70.HostsByJobs].[host_id] = src.[host_id],
        [70.HostsByJobs].[uuid] = src.[uuid]
    FROM [70.HostsByJobs] INNER JOIN @imported_changes src
    ON [70.HostsByJobs].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.HostsByJobs]([job_id], [host_id], [id], [uuid], db_instance_id)
    SELECT
        src.[job_id],
        src.[host_id],
        src.[id],
        src.[uuid],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.HostsByJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_HostsByJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_HostsByJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_HostsByJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_HostsByJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.HostsByJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_Points_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_Points_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_Points_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_Points_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [link_id] uniqueidentifier,
       [num] numeric,
       [id] uniqueidentifier,
       [alg] int,
       [backup_id] uniqueidentifier,
       [group_id] uniqueidentifier,
       [type] int,
       [creation_time] datetime,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([link_id], [num], [id], [alg], [backup_id], [group_id], [type], [creation_time])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [link_id] uniqueidentifier 'link_id',
       [num] numeric 'num',
       [id] uniqueidentifier 'id',
       [alg] int 'alg',
       [backup_id] uniqueidentifier 'backup_id',
       [group_id] uniqueidentifier 'group_id',
       [type] int 'type',
       [creation_time] datetime 'creation_time'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET[creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.Points]
    SET
        [70.Backup.Model.Points].[link_id] = src.[link_id],
        [70.Backup.Model.Points].[num] = src.[num],
        [70.Backup.Model.Points].[alg] = src.[alg],
        [70.Backup.Model.Points].[backup_id] = src.[backup_id],
        [70.Backup.Model.Points].[group_id] = src.[group_id],
        [70.Backup.Model.Points].[type] = src.[type],
        [70.Backup.Model.Points].[creation_time] = src.[creation_time]
    FROM [70.Backup.Model.Points] INNER JOIN @imported_changes src
    ON [70.Backup.Model.Points].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.Points]([link_id], [num], [id], [alg], [backup_id], [group_id], [type], [creation_time], db_instance_id)
    SELECT
        src.[link_id],
        src.[num],
        src.[id],
        src.[alg],
        src.[backup_id],
        src.[group_id],
        src.[type],
        src.[creation_time],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.Points] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_Points_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_Points_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_Points_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_Points_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.Points]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Ssh_creds_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Ssh_creds_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Ssh_creds_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Ssh_creds_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [savepassword] bit,
       [adjust_firewall] bit,
       [isftserver] bit,
       [endftport] int,
       [auto_sudo] bit,
       [port] int,
       [enabled] bit,
       [host_id] uniqueidentifier,
       [startftport] int,
       [timeout] int,
       [elevatetoroot] bit,
       [buffersize] int,
       [id] uniqueidentifier,
       [creds] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([savepassword], [adjust_firewall], [isftserver], [endftport], [auto_sudo], [port], [enabled], [host_id], [startftport], [timeout], [elevatetoroot], [buffersize], [id], [creds])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [savepassword] bit 'savepassword',
       [adjust_firewall] bit 'adjust_firewall',
       [isftserver] bit 'isftserver',
       [endftport] int 'endftport',
       [auto_sudo] bit 'auto_sudo',
       [port] int 'port',
       [enabled] bit 'enabled',
       [host_id] uniqueidentifier 'host_id',
       [startftport] int 'startftport',
       [timeout] int 'timeout',
       [elevatetoroot] bit 'elevatetoroot',
       [buffersize] int 'buffersize',
       [id] uniqueidentifier 'id',
       [creds] uniqueidentifier 'creds'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Ssh_creds]
    SET
        [70.Ssh_creds].[savepassword] = src.[savepassword],
        [70.Ssh_creds].[adjust_firewall] = src.[adjust_firewall],
        [70.Ssh_creds].[isftserver] = src.[isftserver],
        [70.Ssh_creds].[endftport] = src.[endftport],
        [70.Ssh_creds].[auto_sudo] = src.[auto_sudo],
        [70.Ssh_creds].[port] = src.[port],
        [70.Ssh_creds].[enabled] = src.[enabled],
        [70.Ssh_creds].[host_id] = src.[host_id],
        [70.Ssh_creds].[startftport] = src.[startftport],
        [70.Ssh_creds].[timeout] = src.[timeout],
        [70.Ssh_creds].[elevatetoroot] = src.[elevatetoroot],
        [70.Ssh_creds].[buffersize] = src.[buffersize],
        [70.Ssh_creds].[creds] = src.[creds]
    FROM [70.Ssh_creds] INNER JOIN @imported_changes src
    ON [70.Ssh_creds].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Ssh_creds]([savepassword], [adjust_firewall], [isftserver], [endftport], [auto_sudo], [port], [enabled], [host_id], [startftport], [timeout], [elevatetoroot], [buffersize], [id], [creds], db_instance_id)
    SELECT
        src.[savepassword],
        src.[adjust_firewall],
        src.[isftserver],
        src.[endftport],
        src.[auto_sudo],
        src.[port],
        src.[enabled],
        src.[host_id],
        src.[startftport],
        src.[timeout],
        src.[elevatetoroot],
        src.[buffersize],
        src.[id],
        src.[creds],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Ssh_creds] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Ssh_creds_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Ssh_creds_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Ssh_creds_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Ssh_creds_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Ssh_creds]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_OIBs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_OIBs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_OIBs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_OIBs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [has_index] bit,
       [has_exchange] bit,
       [type] int,
       [is_corrupted] bit,
       [alg] int,
       [creation_time] datetime,
       [is_consistent] bit,
       [storage_id] uniqueidentifier,
       [inside_dir] nvarchar(400),
       [state] int,
       [id] uniqueidentifier,
       [guest_os_info] xml,
       [memory] bigint,
       [point_id] uniqueidentifier,
       [link_id] uniqueidentifier,
       [approx_size] bigint,
       [vmname] nvarchar(1000),
       [process_id] int,
       [object_id] uniqueidentifier,
	   [parent_id] uniqueidentifier,
       [aux_data] xml,
       [display_name] nvarchar(256),
       [original_oib_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([has_index], [has_exchange], [type], [is_corrupted], [alg], [creation_time], [is_consistent], [storage_id], [inside_dir], [state], [id], [guest_os_info], [memory], [point_id], [link_id], [approx_size], [vmname], [process_id], [object_id],  [parent_id],[aux_data], [display_name], [original_oib_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [has_index] bit 'has_index',
       [has_exchange] bit 'has_exchange',
       [type] int 'type',
       [is_corrupted] bit 'is_corrupted',
       [alg] int 'alg',
       [creation_time] datetime 'creation_time',
       [is_consistent] bit 'is_consistent',
       [storage_id] uniqueidentifier 'storage_id',
       [inside_dir] nvarchar(400) 'inside_dir',
       [state] int 'state',
       [id] uniqueidentifier 'id',
       [guest_os_info] xml 'guest_os_info',
       [memory] bigint 'memory',
       [point_id] uniqueidentifier 'point_id',
       [link_id] uniqueidentifier 'link_id',
       [approx_size] bigint 'approx_size',
       [vmname] nvarchar(1000) 'vmname',
       [process_id] int 'process_id',
       [object_id] uniqueidentifier 'object_id',
	   [parent_id] uniqueidentifier 'parent_id',
       [aux_data] xml 'aux_data/*',
       [display_name] nvarchar(256) 'display_name',
       [original_oib_id] uniqueidentifier 'original_oib_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.OIBs]
    SET
        [70.Backup.Model.OIBs].[has_index] = src.[has_index],
        [70.Backup.Model.OIBs].[has_exchange] = src.[has_exchange],
        [70.Backup.Model.OIBs].[type] = src.[type],
        [70.Backup.Model.OIBs].[is_corrupted] = src.[is_corrupted],
        [70.Backup.Model.OIBs].[alg] = src.[alg],
        [70.Backup.Model.OIBs].[creation_time] = src.[creation_time],
        [70.Backup.Model.OIBs].[is_consistent] = src.[is_consistent],
        [70.Backup.Model.OIBs].[storage_id] = src.[storage_id],
        [70.Backup.Model.OIBs].[inside_dir] = src.[inside_dir],
        [70.Backup.Model.OIBs].[state] = src.[state],
        [70.Backup.Model.OIBs].[guest_os_info] = src.[guest_os_info],
        [70.Backup.Model.OIBs].[memory] = src.[memory],
        [70.Backup.Model.OIBs].[point_id] = src.[point_id],
        [70.Backup.Model.OIBs].[link_id] = src.[link_id],
        [70.Backup.Model.OIBs].[approx_size] = src.[approx_size],
        [70.Backup.Model.OIBs].[vmname] = src.[vmname],
        [70.Backup.Model.OIBs].[process_id] = src.[process_id],
        [70.Backup.Model.OIBs].[object_id] = src.[object_id],
        [70.Backup.Model.OIBs].[parent_id] = src.[parent_id],
        [70.Backup.Model.OIBs].[aux_data] = src.[aux_data],
        [70.Backup.Model.OIBs].[display_name] = src.[display_name],
        [70.Backup.Model.OIBs].[original_oib_id] = src.[original_oib_id]
    FROM [70.Backup.Model.OIBs] INNER JOIN @imported_changes src
    ON [70.Backup.Model.OIBs].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.OIBs]([has_index], [has_exchange], [type], [is_corrupted], [alg], [creation_time], [is_consistent], [storage_id], [inside_dir], [state], [id], [guest_os_info], [memory], [point_id], [link_id], [approx_size], [vmname], [process_id], [object_id], [parent_id],[aux_data], [display_name], [original_oib_id], db_instance_id)
    SELECT
        src.[has_index],
        src.[has_exchange],
        src.[type],
        src.[is_corrupted],
        src.[alg],
        src.[creation_time],
        src.[is_consistent],
        src.[storage_id],
        src.[inside_dir],
        src.[state],
        src.[id],
        src.[guest_os_info],
        src.[memory],
        src.[point_id],
        src.[link_id],
        src.[approx_size],
        src.[vmname],
        src.[process_id],
        src.[object_id],
		src.[parent_id],
        src.[aux_data],
        src.[display_name],
        src.[original_oib_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.OIBs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_OIBs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_OIBs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_OIBs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_OIBs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.OIBs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_LicensedHosts_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_LicensedHosts_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_LicensedHosts_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_LicensedHosts_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [lic_edition] int,
       [name] nvarchar(255),
       [is_licensed] bit,
       [type] int,
       [uuid] nvarchar(255),
       [cpu] int,
       [id] uniqueidentifier,
       [cores] int,
       [lic_tier] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([lic_edition], [name], [is_licensed], [type], [uuid], [cpu], [id], [cores], [lic_tier])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [lic_edition] int 'lic_edition',
       [name] nvarchar(255) 'name',
       [is_licensed] bit 'is_licensed',
       [type] int 'type',
       [uuid] nvarchar(255) 'uuid',
       [cpu] int 'cpu',
       [id] uniqueidentifier 'id',
       [cores] int 'cores',
       [lic_tier] int 'lic_tier'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.LicensedHosts]
    SET
        [70.LicensedHosts].[lic_edition] = src.[lic_edition],
        [70.LicensedHosts].[name] = src.[name],
        [70.LicensedHosts].[is_licensed] = src.[is_licensed],
        [70.LicensedHosts].[type] = src.[type],
        [70.LicensedHosts].[uuid] = src.[uuid],
        [70.LicensedHosts].[cpu] = src.[cpu],
        [70.LicensedHosts].[cores] = src.[cores],
        [70.LicensedHosts].[lic_tier] = src.[lic_tier]
    FROM [70.LicensedHosts] INNER JOIN @imported_changes src
    ON [70.LicensedHosts].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.LicensedHosts]([lic_edition], [name], [is_licensed], [type], [uuid], [cpu], [id], [cores], [lic_tier], db_instance_id)
    SELECT
        src.[lic_edition],
        src.[name],
        src.[is_licensed],
        src.[type],
        src.[uuid],
        src.[cpu],
        src.[id],
        src.[cores],
        src.[lic_tier],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.LicensedHosts] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_LicensedHosts_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_LicensedHosts_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_LicensedHosts_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_LicensedHosts_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.LicensedHosts]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Hosts_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Hosts_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Hosts_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Hosts_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [description] nvarchar(1024),
       [protocol] int,
       [info] nvarchar(255),
       [ip] nvarchar(50),
       [parent_id] uniqueidentifier,
       [api_version] int,
       [type] int,
       [win_creds] xml,
       [id] uniqueidentifier,
       [name] nvarchar(255),
       [reference] nvarchar(1024),
       [host_instance_id] varchar(255),
       [physical_host_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([description], [protocol], [info], [ip], [parent_id], [api_version], [type], [win_creds], [id], [name], [reference], [host_instance_id], [physical_host_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [description] nvarchar(1024) 'description',
       [protocol] int 'protocol',
       [info] nvarchar(255) 'info',
       [ip] nvarchar(50) 'ip',
       [parent_id] uniqueidentifier 'parent_id',
       [api_version] int 'api_version',
       [type] int 'type',
       [win_creds] xml 'win_creds',
       [id] uniqueidentifier 'id',
       [name] nvarchar(255) 'name',
       [reference] nvarchar(1024) 'reference',
       [host_instance_id] varchar(255) 'host_instance_id',
       [physical_host_id] uniqueidentifier 'physical_host_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Hosts]
    SET
        [70.Hosts].[description] = src.[description],
        [70.Hosts].[protocol] = src.[protocol],
        [70.Hosts].[info] = src.[info],
        [70.Hosts].[ip] = src.[ip],
        [70.Hosts].[parent_id] = src.[parent_id],
        [70.Hosts].[api_version] = src.[api_version],
        [70.Hosts].[type] = src.[type],
        [70.Hosts].[win_creds] = src.[win_creds],
        [70.Hosts].[name] = src.[name],
        [70.Hosts].[reference] = src.[reference],
        [70.Hosts].[host_instance_id] = src.[host_instance_id],
        [70.Hosts].[physical_host_id] = src.[physical_host_id]
    FROM [70.Hosts] INNER JOIN @imported_changes src
    ON [70.Hosts].id = src.id AND [70.Hosts].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Hosts]([description], [protocol], [info], [ip], [parent_id], [api_version], [type], [win_creds], [id], [name], [reference], [host_instance_id], [physical_host_id], db_instance_id)
    SELECT
        src.[description],
        src.[protocol],
        src.[info],
        src.[ip],
        src.[parent_id],
        src.[api_version],
        src.[type],
        src.[win_creds],
        src.[id],
        src.[name],
        src.[reference],
        src.[host_instance_id],
        src.[physical_host_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Hosts] trg
    ON src.id = trg.id AND src.db_instance_id = @dbInstanceId
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Hosts_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Hosts_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Hosts_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Hosts_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Hosts]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
	 AND [dbo].[70.Hosts].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Folders_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Folders_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Folders_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Folders_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [name] nvarchar(255),
       [parent_id] uniqueidentifier,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([name], [parent_id], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [name] nvarchar(255) 'name',
       [parent_id] uniqueidentifier 'parent_id',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Folders]
    SET
        [70.Folders].[name] = src.[name],
        [70.Folders].[parent_id] = src.[parent_id]
    FROM [70.Folders] INNER JOIN @imported_changes src
    ON [70.Folders].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Folders]([name], [parent_id], [id], db_instance_id)
    SELECT
        src.[name],
        src.[parent_id],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Folders] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Folders_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Folders_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Folders_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Folders_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Folders]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_VirtualLabs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_VirtualLabs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_VirtualLabs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_VirtualLabs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [host_id] uniqueidentifier,
       [vm_ref] nvarchar(1024),
       [description] nvarchar(255),
       [name] nvarchar(255),
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([host_id], [vm_ref], [description], [name], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [host_id] uniqueidentifier 'host_id',
       [vm_ref] nvarchar(1024) 'vm_ref',
       [description] nvarchar(255) 'description',
       [name] nvarchar(255) 'name',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.VirtualLabs]
    SET
        [70.VirtualLabs].[host_id] = src.[host_id],
        [70.VirtualLabs].[vm_ref] = src.[vm_ref],
        [70.VirtualLabs].[description] = src.[description],
        [70.VirtualLabs].[name] = src.[name]
    FROM [70.VirtualLabs] INNER JOIN @imported_changes src
    ON [70.VirtualLabs].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.VirtualLabs]([host_id], [vm_ref], [description], [name], [id], db_instance_id)
    SELECT
        src.[host_id],
        src.[vm_ref],
        src.[description],
        src.[name],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.VirtualLabs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_VirtualLabs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_VirtualLabs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_VirtualLabs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_VirtualLabs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.VirtualLabs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_ObjectsInApplicationGroups_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_ObjectsInApplicationGroups_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_ObjectsInApplicationGroups_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_ObjectsInApplicationGroups_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [effective_memory] bigint,
       [guest_os_info] xml,
       [options] xml,
       [id] uniqueidentifier,
       [order] int,
       [object_id] uniqueidentifier,
       [folder_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([effective_memory], [guest_os_info], [options], [id], [order], [object_id], [folder_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [effective_memory] bigint 'effective_memory',
       [guest_os_info] xml 'guest_os_info',
       [options] xml 'options',
       [id] uniqueidentifier 'id',
       [order] int 'order',
       [object_id] uniqueidentifier 'object_id',
       [folder_id] uniqueidentifier 'folder_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.ObjectsInApplicationGroups]
    SET
        [70.ObjectsInApplicationGroups].[effective_memory] = src.[effective_memory],
        [70.ObjectsInApplicationGroups].[guest_os_info] = src.[guest_os_info],
        [70.ObjectsInApplicationGroups].[options] = src.[options],
        [70.ObjectsInApplicationGroups].[order] = src.[order],
        [70.ObjectsInApplicationGroups].[object_id] = src.[object_id],
        [70.ObjectsInApplicationGroups].[folder_id] = src.[folder_id]
    FROM [70.ObjectsInApplicationGroups] INNER JOIN @imported_changes src
    ON [70.ObjectsInApplicationGroups].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.ObjectsInApplicationGroups]([effective_memory], [guest_os_info], [options], [id], [order], [object_id], [folder_id], db_instance_id)
    SELECT
        src.[effective_memory],
        src.[guest_os_info],
        src.[options],
        src.[id],
        src.[order],
        src.[object_id],
        src.[folder_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.ObjectsInApplicationGroups] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_ObjectsInApplicationGroups_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_ObjectsInApplicationGroups_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_ObjectsInApplicationGroups_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_ObjectsInApplicationGroups_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.ObjectsInApplicationGroups]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_DRRoles_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_DRRoles_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_DRRoles_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_DRRoles_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [effective_memory] bigint,
       [id] uniqueidentifier,
       [boot_delay] int,
       [test_script_file_full_name] nvarchar(max),
       [name] nvarchar(max),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([effective_memory], [id], [boot_delay], [test_script_file_full_name], [name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [effective_memory] bigint 'effective_memory',
       [id] uniqueidentifier 'id',
       [boot_delay] int 'boot_delay',
       [test_script_file_full_name] nvarchar(max) 'test_script_file_full_name',
       [name] nvarchar(max) 'name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.DRRoles]
    SET
        [70.DRRoles].[effective_memory] = src.[effective_memory],
        [70.DRRoles].[boot_delay] = src.[boot_delay],
        [70.DRRoles].[test_script_file_full_name] = src.[test_script_file_full_name],
        [70.DRRoles].[name] = src.[name]
    FROM [70.DRRoles] INNER JOIN @imported_changes src
    ON [70.DRRoles].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.DRRoles]([effective_memory], [id], [boot_delay], [test_script_file_full_name], [name], db_instance_id)
    SELECT
        src.[effective_memory],
        src.[id],
        src.[boot_delay],
        src.[test_script_file_full_name],
        src.[name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.DRRoles] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_DRRoles_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_DRRoles_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_DRRoles_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_DRRoles_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.DRRoles]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_JobSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_JobSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_JobSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_JobSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [log_xml] xml,
       [progress] int,
       [job_name] nvarchar(255),
       [result] int,
       [job_id] uniqueidentifier,
       [state] int,
       [job_type] int,
       [creation_time] datetime,
       [id] uniqueidentifier,
       [end_time] datetime,
       [operation] nvarchar(400),
       [control] int,
       [description] text,
       [log_text] ntext,
	   [usn] bigint,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([log_xml], [progress], [job_name], [result], [job_id], [state], [job_type], [creation_time], [id], [end_time], [operation], [control], [description], [log_text],[usn])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [log_xml] xml 'log_xml/*',
       [progress] int 'progress',
       [job_name] nvarchar(255) 'job_name',
       [result] int 'result',
       [job_id] uniqueidentifier 'job_id',
       [state] int 'state',
       [job_type] int 'job_type',
       [creation_time] datetime 'creation_time',
       [id] uniqueidentifier 'id',
       [end_time] datetime 'end_time',
       [operation] nvarchar(400) 'operation',
       [control] int 'control',
       [description] text 'description',
       [log_text] ntext 'log_text',
	   [usn] bigint 'usn'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET        
        [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time]),
        [end_time] = DATEADD( minute, -@TimeZoneShift, [end_time])

    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.JobSessions]
    SET
        [70.Backup.Model.JobSessions].[log_xml] = src.[log_xml],
        [70.Backup.Model.JobSessions].[progress] = src.[progress],
        [70.Backup.Model.JobSessions].[job_name] = src.[job_name],
        [70.Backup.Model.JobSessions].[result] = src.[result],
        [70.Backup.Model.JobSessions].[job_id] = src.[job_id],
        [70.Backup.Model.JobSessions].[state] = src.[state],
        [70.Backup.Model.JobSessions].[job_type] = src.[job_type],
        [70.Backup.Model.JobSessions].[creation_time] = src.[creation_time],
        [70.Backup.Model.JobSessions].[end_time] = src.[end_time],
        [70.Backup.Model.JobSessions].[operation] = src.[operation],
        [70.Backup.Model.JobSessions].[control] = src.[control],
        [70.Backup.Model.JobSessions].[description] = src.[description],
        [70.Backup.Model.JobSessions].[log_text] = src.[log_text],
		[70.Backup.Model.JobSessions].[usn] = src.[usn]
    FROM [70.Backup.Model.JobSessions] INNER JOIN @imported_changes src
    ON [70.Backup.Model.JobSessions].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.JobSessions]([log_xml], [progress], [job_name], [result], [job_id], [state], [job_type], [creation_time], [id], [end_time], [operation], [control], [description], [log_text], [usn], db_instance_id)
    SELECT
        src.[log_xml],
        src.[progress],
        src.[job_name],
        src.[result],
        src.[job_id],
        src.[state],
        src.[job_type],
        src.[creation_time],
        src.[id],
        src.[end_time],
        src.[operation],
        src.[control],
        src.[description],
        src.[log_text],
		src.[usn],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.JobSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_JobSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_JobSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_JobSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_JobSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.JobSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [order_num] int,
       [object_id] uniqueidentifier,
       [description] nvarchar(max),
       [powerOn_status] int,
       [restore_counter] int,
       [ping_status] int,
       [appliance_ip] nvarchar(80),
       [subnet_ip] nvarchar(80),
       [subnet_mask] nvarchar(80),
       [vm_ref] nvarchar(max),
       [state] int,
       [start_time] datetime,
       [drsession_id] uniqueidentifier,
       [total_steps] int,
       [percent] int,
       [finish_time] datetime,
       [object_name] nvarchar(max),
       [id] uniqueidentifier,
       [oib_id] uniqueidentifier,
       [heartbeat_status] int,
       [overall_status] int,
       [control] int,
       [type] int,
       [test_script_error_code] int,
       [powerOff_status] int,
       [vm_external_ip] nvarchar(80),
       [test_script_status] int,
       [test_scripts_results] xml,
       [oiag_id] uniqueidentifier,
       [processed_steps] int,
       [leave_powered_on] bit,
       [validation_status] int,
       [db_instance_id] uniqueidentifier,
	   [usn] bigint
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([order_num], [object_id], [description], [powerOn_status], [restore_counter], [ping_status], [appliance_ip], [subnet_ip], [subnet_mask], [vm_ref], [state], [start_time], [drsession_id], [total_steps], [percent], [finish_time], [object_name], [id], [oib_id], [heartbeat_status], [overall_status], [control], [type], [test_script_error_code], [powerOff_status], [vm_external_ip], [test_script_status], [test_scripts_results], [oiag_id], [processed_steps], [leave_powered_on], [validation_status], [usn])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [order_num] int 'order_num',
       [object_id] uniqueidentifier 'object_id',
       [description] nvarchar(max) 'description',
       [powerOn_status] int 'powerOn_status',
       [restore_counter] int 'restore_counter',
       [ping_status] int 'ping_status',
       [appliance_ip] nvarchar(80) 'appliance_ip',
       [subnet_ip] nvarchar(80) 'subnet_ip',
       [subnet_mask] nvarchar(80) 'subnet_mask',
       [vm_ref] nvarchar(max) 'vm_ref',
       [state] int 'state',
       [start_time] datetime 'start_time',
       [drsession_id] uniqueidentifier 'drsession_id',
       [total_steps] int 'total_steps',
       [percent] int 'percent',
       [finish_time] datetime 'finish_time',
       [object_name] nvarchar(max) 'object_name',
       [id] uniqueidentifier 'id',
       [oib_id] uniqueidentifier 'oib_id',
       [heartbeat_status] int 'heartbeat_status',
       [overall_status] int 'overall_status',
       [control] int 'control',
       [type] int 'type',
       [test_script_error_code] int 'test_script_error_code',
       [powerOff_status] int 'powerOff_status',
       [vm_external_ip] nvarchar(80) 'vm_external_ip',
       [test_script_status] int 'test_script_status',
       [test_scripts_results] xml 'test_scripts_results/*',
       [oiag_id] uniqueidentifier 'oiag_id',
       [processed_steps] int 'processed_steps',
       [leave_powered_on] bit 'leave_powered_on',
       [validation_status] int 'validation_status',
	   [usn] bigint 'usn'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET
        [start_time] = DATEADD( minute, -@TimeZoneShift, [start_time]),
        [finish_time] = DATEADD( minute, -@TimeZoneShift, [finish_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.SbTaskSessions]
    SET
        [70.Backup.Model.SbTaskSessions].[order_num] = src.[order_num],
        [70.Backup.Model.SbTaskSessions].[object_id] = src.[object_id],
        [70.Backup.Model.SbTaskSessions].[description] = src.[description],
        [70.Backup.Model.SbTaskSessions].[powerOn_status] = src.[powerOn_status],
        [70.Backup.Model.SbTaskSessions].[restore_counter] = src.[restore_counter],
        [70.Backup.Model.SbTaskSessions].[ping_status] = src.[ping_status],
        [70.Backup.Model.SbTaskSessions].[appliance_ip] = src.[appliance_ip],
        [70.Backup.Model.SbTaskSessions].[subnet_ip] = src.[subnet_ip],
        [70.Backup.Model.SbTaskSessions].[subnet_mask] = src.[subnet_mask],
        [70.Backup.Model.SbTaskSessions].[vm_ref] = src.[vm_ref],
        [70.Backup.Model.SbTaskSessions].[state] = src.[state],
        [70.Backup.Model.SbTaskSessions].[start_time] = src.[start_time],
        [70.Backup.Model.SbTaskSessions].[drsession_id] = src.[drsession_id],
        [70.Backup.Model.SbTaskSessions].[total_steps] = src.[total_steps],
        [70.Backup.Model.SbTaskSessions].[percent] = src.[percent],
        [70.Backup.Model.SbTaskSessions].[finish_time] = src.[finish_time],
        [70.Backup.Model.SbTaskSessions].[object_name] = src.[object_name],
        [70.Backup.Model.SbTaskSessions].[oib_id] = src.[oib_id],
        [70.Backup.Model.SbTaskSessions].[heartbeat_status] = src.[heartbeat_status],
        [70.Backup.Model.SbTaskSessions].[overall_status] = src.[overall_status],
        [70.Backup.Model.SbTaskSessions].[control] = src.[control],
        [70.Backup.Model.SbTaskSessions].[type] = src.[type],
        [70.Backup.Model.SbTaskSessions].[test_script_error_code] = src.[test_script_error_code],
        [70.Backup.Model.SbTaskSessions].[powerOff_status] = src.[powerOff_status],
        [70.Backup.Model.SbTaskSessions].[vm_external_ip] = src.[vm_external_ip],
        [70.Backup.Model.SbTaskSessions].[test_script_status] = src.[test_script_status],
        [70.Backup.Model.SbTaskSessions].[test_scripts_results] = src.[test_scripts_results],
        [70.Backup.Model.SbTaskSessions].[oiag_id] = src.[oiag_id],
        [70.Backup.Model.SbTaskSessions].[processed_steps] = src.[processed_steps],
        [70.Backup.Model.SbTaskSessions].[leave_powered_on] = src.[leave_powered_on],
        [70.Backup.Model.SbTaskSessions].[validation_status] = src.[validation_status],
		[70.Backup.Model.SbTaskSessions].[usn] = src.[usn]
    FROM [70.Backup.Model.SbTaskSessions] INNER JOIN @imported_changes src
    ON [70.Backup.Model.SbTaskSessions].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.SbTaskSessions]([order_num], [object_id], [description], [powerOn_status], [restore_counter], [ping_status], [appliance_ip], [subnet_ip], [subnet_mask], [vm_ref], [state], [start_time], [drsession_id], [total_steps], [percent], [finish_time], [object_name], [id], [oib_id], [heartbeat_status], [overall_status], [control], [type], [test_script_error_code], [powerOff_status], [vm_external_ip], [test_script_status], [test_scripts_results], [oiag_id], [processed_steps], [leave_powered_on], [validation_status], db_instance_id, [usn])
    SELECT
        src.[order_num],
        src.[object_id],
        src.[description],
        src.[powerOn_status],
        src.[restore_counter],
        src.[ping_status],
        src.[appliance_ip],
        src.[subnet_ip],
        src.[subnet_mask],
        src.[vm_ref],
        src.[state],
        src.[start_time],
        src.[drsession_id],
        src.[total_steps],
        src.[percent],
        src.[finish_time],
        src.[object_name],
        src.[id],
        src.[oib_id],
        src.[heartbeat_status],
        src.[overall_status],
        src.[control],
        src.[type],
        src.[test_script_error_code],
        src.[powerOff_status],
        src.[vm_external_ip],
        src.[test_script_status],
        src.[test_scripts_results],
        src.[oiag_id],
        src.[processed_steps],
        src.[leave_powered_on],
        src.[validation_status],
        src.db_instance_id,
		src.[usn]
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.SbTaskSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbTaskSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.SbTaskSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_SbSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_SbSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [preferred_date] datetime,
       [id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([preferred_date], [id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [preferred_date] datetime 'preferred_date',
       [id] uniqueidentifier 'id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes 
    SET [preferred_date] = DATEADD( minute, -@TimeZoneShift, [preferred_date])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.SbSessions]
    SET
        [70.Backup.Model.SbSessions].[preferred_date] = src.[preferred_date]
    FROM [70.Backup.Model.SbSessions] INNER JOIN @imported_changes src
    ON [70.Backup.Model.SbSessions].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.SbSessions]([preferred_date], [id], db_instance_id)
    SELECT
        src.[preferred_date],
        src.[id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.SbSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_SbSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_SbSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_SbSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.SbSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [is_startfull] bit,
       [total_size] bigint,
       [processed_objects] int,
       [is_retry] bit,
       [total_objects] int,
       [processed_size] bigint,
       [avg_speed] bigint,
       [job_source_type] int,
       [id] uniqueidentifier,
       [stored_size] bigint,
       [cur_point_id] uniqueidentifier,
	   [usn] bigint,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([is_startfull], [total_size], [processed_objects], [is_retry], [total_objects], [processed_size], [avg_speed], [job_source_type], [id], [stored_size], [cur_point_id], [usn])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [is_startfull] bit 'is_startfull',
       [total_size] bigint 'total_size',
       [processed_objects] int 'processed_objects',
       [is_retry] bit 'is_retry',
       [total_objects] int 'total_objects',
       [processed_size] bigint 'processed_size',
       [avg_speed] bigint 'avg_speed',
       [job_source_type] int 'job_source_type',
       [id] uniqueidentifier 'id',
       [stored_size] bigint 'stored_size',
       [cur_point_id] uniqueidentifier 'cur_point_id',
	   [usn] bigint 'usn'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.BackupJobSessions]
    SET
        [70.Backup.Model.BackupJobSessions].[is_startfull] = src.[is_startfull],
        [70.Backup.Model.BackupJobSessions].[total_size] = src.[total_size],
        [70.Backup.Model.BackupJobSessions].[processed_objects] = src.[processed_objects],
        [70.Backup.Model.BackupJobSessions].[is_retry] = src.[is_retry],
        [70.Backup.Model.BackupJobSessions].[total_objects] = src.[total_objects],
        [70.Backup.Model.BackupJobSessions].[processed_size] = src.[processed_size],
        [70.Backup.Model.BackupJobSessions].[avg_speed] = src.[avg_speed],
        [70.Backup.Model.BackupJobSessions].[job_source_type] = src.[job_source_type],
        [70.Backup.Model.BackupJobSessions].[stored_size] = src.[stored_size],
        [70.Backup.Model.BackupJobSessions].[cur_point_id] = src.[cur_point_id],
		[70.Backup.Model.BackupJobSessions].[usn] = src.[usn]		
    FROM [70.Backup.Model.BackupJobSessions] INNER JOIN @imported_changes src
    ON [70.Backup.Model.BackupJobSessions].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.BackupJobSessions]([is_startfull], [total_size], [processed_objects], [is_retry], [total_objects], [processed_size], [avg_speed], [job_source_type], [id], [stored_size], [cur_point_id], [usn],db_instance_id)
    SELECT
        src.[is_startfull],
        src.[total_size],
        src.[processed_objects],
        src.[is_retry],
        src.[total_objects],
        src.[processed_size],
        src.[avg_speed],
        src.[job_source_type],
        src.[id],
        src.[stored_size],
        src.[cur_point_id],
		src.[usn],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.BackupJobSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupJobSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.BackupJobSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [processed_size] bigint,
       [operation] nvarchar(400),
       [end_time] datetime,
       [object_name] nvarchar(2000),
       [log_xml] xml,
       [read_size] bigint,
       [stored_size] bigint,
       [object_id] uniqueidentifier,
       [processed_objects] int,
       [session_id] uniqueidentifier,
       [creation_time] datetime,
       [mode] int,
       [total_objects] int,
       [total_size] bigint,
       [reason] ntext,
       [change_tracking] bit,
       [status] int,
       [avg_speed] bigint,
	   [usn] bigint,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [processed_size], [operation], [end_time], [object_name], [log_xml], [read_size], [stored_size], [object_id], [processed_objects], [session_id], [creation_time], [mode], [total_objects], [total_size], [reason], [change_tracking], [status], [avg_speed],[usn])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [processed_size] bigint 'processed_size',
       [operation] nvarchar(400) 'operation',
       [end_time] datetime 'end_time',
       [object_name] nvarchar(2000) 'object_name',
       [log_xml] xml 'log_xml/*',
       [read_size] bigint 'read_size',
       [stored_size] bigint 'stored_size',
       [object_id] uniqueidentifier 'object_id',
       [processed_objects] int 'processed_objects',
       [session_id] uniqueidentifier 'session_id',
       [creation_time] datetime 'creation_time',
       [mode] int 'mode',
       [total_objects] int 'total_objects',
       [total_size] bigint 'total_size',
       [reason] ntext 'reason',
       [change_tracking] bit 'change_tracking',
       [status] int 'status',
       [avg_speed] bigint 'avg_speed',
	   [usn] bigint 'usn'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    UPDATE @imported_changes
    SET
        [creation_time] = DATEADD( minute, -@TimeZoneShift, [creation_time]),
        [end_time] = DATEADD( minute, -@TimeZoneShift, [end_time])
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.BackupTaskSessions]
    SET
        [70.Backup.Model.BackupTaskSessions].[processed_size] = src.[processed_size],
        [70.Backup.Model.BackupTaskSessions].[operation] = src.[operation],
        [70.Backup.Model.BackupTaskSessions].[end_time] = src.[end_time],
        [70.Backup.Model.BackupTaskSessions].[object_name] = src.[object_name],
        [70.Backup.Model.BackupTaskSessions].[log_xml] = src.[log_xml],
        [70.Backup.Model.BackupTaskSessions].[read_size] = src.[read_size],
        [70.Backup.Model.BackupTaskSessions].[stored_size] = src.[stored_size],
        [70.Backup.Model.BackupTaskSessions].[object_id] = src.[object_id],
        [70.Backup.Model.BackupTaskSessions].[processed_objects] = src.[processed_objects],
        [70.Backup.Model.BackupTaskSessions].[session_id] = src.[session_id],
        [70.Backup.Model.BackupTaskSessions].[creation_time] = src.[creation_time],
        [70.Backup.Model.BackupTaskSessions].[mode] = src.[mode],
        [70.Backup.Model.BackupTaskSessions].[total_objects] = src.[total_objects],
        [70.Backup.Model.BackupTaskSessions].[total_size] = src.[total_size],
        [70.Backup.Model.BackupTaskSessions].[reason] = src.[reason],
        [70.Backup.Model.BackupTaskSessions].[change_tracking] = src.[change_tracking],
        [70.Backup.Model.BackupTaskSessions].[status] = src.[status],
        [70.Backup.Model.BackupTaskSessions].[avg_speed] = src.[avg_speed],
		[70.Backup.Model.BackupTaskSessions].[usn] = src.[usn]		
    FROM [70.Backup.Model.BackupTaskSessions] INNER JOIN @imported_changes src
    ON [70.Backup.Model.BackupTaskSessions].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.BackupTaskSessions]([id], [processed_size], [operation], [end_time], [object_name], [log_xml], [read_size], [stored_size], [object_id], [processed_objects], [session_id], [creation_time], [mode], [total_objects], [total_size], [reason], [change_tracking], [status], [avg_speed], [usn],db_instance_id)
    SELECT
        src.[id],
        src.[processed_size],
        src.[operation],
        src.[end_time],
        src.[object_name],
        src.[log_xml],
        src.[read_size],
        src.[stored_size],
        src.[object_id],
        src.[processed_objects],
        src.[session_id],
        src.[creation_time],
        src.[mode],
        src.[total_objects],
        src.[total_size],
        src.[reason],
        src.[change_tracking],
        src.[status],
        src.[avg_speed],
		src.[usn],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.BackupTaskSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_BackupTaskSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.BackupTaskSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_LinkedJobs_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_LinkedJobs_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_LinkedJobs_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_LinkedJobs_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [linked_job_id] uniqueidentifier,
       [id] uniqueidentifier,
       [job_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([linked_job_id], [id], [job_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [linked_job_id] uniqueidentifier 'linked_job_id',
       [id] uniqueidentifier 'id',
       [job_id] uniqueidentifier 'job_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.LinkedJobs]
    SET
        [70.LinkedJobs].[linked_job_id] = src.[linked_job_id],
        [70.LinkedJobs].[job_id] = src.[job_id]
    FROM [70.LinkedJobs] INNER JOIN @imported_changes src
    ON [70.LinkedJobs].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.LinkedJobs]([linked_job_id], [id], [job_id], db_instance_id)
    SELECT
        src.[linked_job_id],
        src.[id],
        src.[job_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.LinkedJobs] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_LinkedJobs_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_LinkedJobs_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_LinkedJobs_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_LinkedJobs_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.LinkedJobs]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_SbVerificationRules_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_SbVerificationRules_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_SbVerificationRules_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_SbVerificationRules_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [options] xml,
       [job_id] uniqueidentifier,
       [object_type] int,
       [object_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [options], [job_id], [object_type], [object_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [options] xml 'options/*',
       [job_id] uniqueidentifier 'job_id',
       [object_type] int 'object_type',
       [object_id] uniqueidentifier 'object_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.SbVerificationRules]
    SET
        [70.SbVerificationRules].[options] = src.[options],
        [70.SbVerificationRules].[job_id] = src.[job_id],
        [70.SbVerificationRules].[object_type] = src.[object_type],
        [70.SbVerificationRules].[object_id] = src.[object_id]
    FROM [70.SbVerificationRules] INNER JOIN @imported_changes src
    ON [70.SbVerificationRules].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.SbVerificationRules]([id], [options], [job_id], [object_type], [object_id], db_instance_id)
    SELECT
        src.[id],
        src.[options],
        src.[job_id],
        src.[object_type],
        src.[object_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.SbVerificationRules] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_SbVerificationRules_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_SbVerificationRules_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_SbVerificationRules_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_SbVerificationRules_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.SbVerificationRules]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_BackupProxies_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BackupProxies_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_BackupProxies_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BackupProxies_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [name] nvarchar(max),
       [description] nvarchar(max),
       [type] int,
       [options] xml,
       [disabled] bit,
       [is_busy] bit,
       [is_unavailable] bit,
       [unique_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [description], [type], [options], [disabled], [is_busy], [is_unavailable], [unique_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [name] nvarchar(max) 'name',
       [description] nvarchar(max) 'description',
       [type] int 'type',
       [options] xml 'options/*',
       [disabled] bit 'disabled',
       [is_busy] bit 'is_busy',
       [is_unavailable] bit 'is_unavailable',
       [unique_id] uniqueidentifier 'unique_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.BackupProxies]
    SET
        [70.BackupProxies].[name] = src.[name],
        [70.BackupProxies].[description] = src.[description],
        [70.BackupProxies].[type] = src.[type],
        [70.BackupProxies].[options] = src.[options],
        [70.BackupProxies].[disabled] = src.[disabled],
        [70.BackupProxies].[is_busy] = src.[is_busy],
        [70.BackupProxies].[is_unavailable] = src.[is_unavailable],
        [70.BackupProxies].[unique_id] = src.[unique_id]
    FROM [70.BackupProxies] INNER JOIN @imported_changes src
    ON [70.BackupProxies].id = src.id and [70.BackupProxies].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.BackupProxies]([id], [name], [description], [type], [options], [disabled], [is_busy], [is_unavailable], [unique_id], db_instance_id)
    SELECT
        src.[id],
        src.[name],
        src.[description],
        src.[type],
        src.[options],
        src.[disabled],
        src.[is_busy],
        src.[is_unavailable],
        src.[unique_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.BackupProxies] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL and src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_BackupProxies_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BackupProxies_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_BackupProxies_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BackupProxies_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.BackupProxies]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table ) and [dbo].[70.BackupProxies].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_BackupRepositories_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BackupRepositories_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_BackupRepositories_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BackupRepositories_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [name] nvarchar(max),
       [description] nvarchar(max),
       [type] int,
       [host_id] uniqueidentifier,
       [mount_host_id] uniqueidentifier,
       [path] nvarchar(max),
       [options] xml,
       [is_busy] bit,
       [is_unavailable] bit,
       [is_full] bit,
       [total_space] bigint,
       [free_space] bigint,
       [unique_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [description], [type], [host_id], [mount_host_id], [path], [options], [is_busy], [is_unavailable], [is_full], [total_space], [free_space], [unique_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [name] nvarchar(max) 'name',
       [description] nvarchar(max) 'description',
       [type] int 'type',
       [host_id] uniqueidentifier 'host_id',
       [mount_host_id] uniqueidentifier 'mount_host_id',
       [path] nvarchar(max) 'path',
       [options] xml 'options/*',
       [is_busy] bit 'is_busy',
       [is_unavailable] bit 'is_unavailable',
       [is_full] bit 'is_full',
       [total_space] bigint 'total_space',
       [free_space] bigint 'free_space',
       [unique_id] uniqueidentifier 'unique_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.BackupRepositories]
    SET
        [70.BackupRepositories].[name] = src.[name],
        [70.BackupRepositories].[description] = src.[description],
        [70.BackupRepositories].[type] = src.[type],
        [70.BackupRepositories].[host_id] = src.[host_id],
        [70.BackupRepositories].[mount_host_id] = src.[mount_host_id],
        [70.BackupRepositories].[path] = src.[path],
        [70.BackupRepositories].[options] = src.[options],
        [70.BackupRepositories].[is_busy] = src.[is_busy],
        [70.BackupRepositories].[is_unavailable] = src.[is_unavailable],
        [70.BackupRepositories].[is_full] = src.[is_full],
        [70.BackupRepositories].[total_space] = src.[total_space],
        [70.BackupRepositories].[free_space] = src.[free_space],
        [70.BackupRepositories].[unique_id] = src.[unique_id]
    FROM [70.BackupRepositories] INNER JOIN @imported_changes src
    ON [70.BackupRepositories].id = src.id and [70.BackupRepositories].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.BackupRepositories]([id], [name], [description], [type], [host_id], [mount_host_id], [path], [options], [is_busy], [is_unavailable], [is_full], [total_space], [free_space], [unique_id], db_instance_id)
    SELECT
        src.[id],
        src.[name],
        src.[description],
        src.[type],
        src.[host_id],
        src.[mount_host_id],
        src.[path],
        src.[options],
        src.[is_busy],
        src.[is_unavailable],
        src.[is_full],
        src.[total_space],
        src.[free_space],
        src.[unique_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.BackupRepositories] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL and src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_BackupRepositories_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_BackupRepositories_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_BackupRepositories_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_BackupRepositories_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.BackupRepositories]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
	and [dbo].[70.BackupRepositories].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Credentials_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Credentials_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Credentials_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Credentials_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [user_name] nvarchar(255),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [user_name])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [user_name] nvarchar(255) 'user_name'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Credentials]
    SET
        [70.Credentials].[user_name] = src.[user_name]
    FROM [70.Credentials] INNER JOIN @imported_changes src
    ON [70.Credentials].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Credentials]([id], [user_name], db_instance_id)
    SELECT
        src.[id],
        src.[user_name],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Credentials] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Credentials_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Credentials_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Credentials_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Credentials_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Credentials]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [action] int,
       [usn] bigint,
       [options] xml,
       [initiator_sid] nvarchar(255),
       [initiator_name] nvarchar(255),
       [reason] nvarchar(max),
       [files_log_xml] xml,
       [platform] int,
       [multi_restore_id] uniqueidentifier,
       [restore_type] int,
       [oib_id] uniqueidentifier,
       [is_internal] bit,
       [oib_display_name] nvarchar(256),
       [oib_creation_time] datetime,
       [sub_type] int,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [action], [usn], [options], [initiator_sid], [initiator_name], [reason], [files_log_xml], [platform], [multi_restore_id], [restore_type], [oib_id], [is_internal], [oib_display_name], [oib_creation_time], [sub_type])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [action] int 'action',
       [usn] bigint 'usn',
       [options] xml 'options/*',
       [initiator_sid] nvarchar(255) 'initiator_sid',
       [initiator_name] nvarchar(255) 'initiator_name',
       [reason] nvarchar(max) 'reason',
       [files_log_xml] xml 'files_log_xml/*',
       [platform] int 'platform',
       [multi_restore_id] uniqueidentifier 'multi_restore_id',
       [restore_type] int 'restore_type',
       [oib_id] uniqueidentifier 'oib_id',
       [is_internal] bit 'is_internal',
       [oib_display_name] nvarchar(256) 'oib_display_name',
       [oib_creation_time] datetime 'oib_creation_time',
       [sub_type] int 'sub_type'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

	UPDATE @imported_changes 
	SET [files_log_xml] = '<Root TotalUsn="0" TotalId="0" />'
	WHERE [files_log_xml] IS NULL;

	UPDATE @imported_changes 
	SET [options] = ''
	WHERE [options] IS NULL;


    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.RestoreJobSessions]
    SET
        [70.Backup.Model.RestoreJobSessions].[action] = src.[action],
        [70.Backup.Model.RestoreJobSessions].[usn] = src.[usn],
        [70.Backup.Model.RestoreJobSessions].[options] = src.[options],
        [70.Backup.Model.RestoreJobSessions].[initiator_sid] = src.[initiator_sid],
        [70.Backup.Model.RestoreJobSessions].[initiator_name] = src.[initiator_name],
        [70.Backup.Model.RestoreJobSessions].[reason] = src.[reason],
        [70.Backup.Model.RestoreJobSessions].[files_log_xml] = src.[files_log_xml],
        [70.Backup.Model.RestoreJobSessions].[platform] = src.[platform],
        [70.Backup.Model.RestoreJobSessions].[multi_restore_id] = src.[multi_restore_id],
        [70.Backup.Model.RestoreJobSessions].[restore_type] = src.[restore_type],
        [70.Backup.Model.RestoreJobSessions].[oib_id] = src.[oib_id],
        [70.Backup.Model.RestoreJobSessions].[is_internal] = src.[is_internal],
        [70.Backup.Model.RestoreJobSessions].[oib_display_name] = src.[oib_display_name],
        [70.Backup.Model.RestoreJobSessions].[oib_creation_time] = src.[oib_creation_time],
        [70.Backup.Model.RestoreJobSessions].[sub_type] = src.[sub_type]
    FROM [70.Backup.Model.RestoreJobSessions] INNER JOIN @imported_changes src
    ON [70.Backup.Model.RestoreJobSessions].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.RestoreJobSessions]([id], [action], [usn], [options], [initiator_sid], [initiator_name], [reason], [files_log_xml], [platform], [multi_restore_id], [restore_type], [oib_id], [is_internal], [oib_display_name], [oib_creation_time], [sub_type], db_instance_id)
    SELECT
        src.[id],
        src.[action],
        src.[usn],
        src.[options],
        src.[initiator_sid],
        src.[initiator_name],
        src.[reason],
        src.[files_log_xml],
        src.[platform],
        src.[multi_restore_id],
        src.[restore_type],
        src.[oib_id],
        src.[is_internal],
        src.[oib_display_name],
        src.[oib_creation_time],
        src.[sub_type],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.RestoreJobSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreJobSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.RestoreJobSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_JobVssCredentials_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_JobVssCredentials_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_JobVssCredentials_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_JobVssCredentials_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [job_id] uniqueidentifier,
       [oij_id] uniqueidentifier,
       [credentials_id] uniqueidentifier,
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [job_id], [oij_id], [credentials_id])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [job_id] uniqueidentifier 'job_id',
       [oij_id] uniqueidentifier 'oij_id',
       [credentials_id] uniqueidentifier 'credentials_id'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.JobVssCredentials]
    SET
        [70.JobVssCredentials].[job_id] = src.[job_id],
        [70.JobVssCredentials].[oij_id] = src.[oij_id],
        [70.JobVssCredentials].[credentials_id] = src.[credentials_id]
    FROM [70.JobVssCredentials] INNER JOIN @imported_changes src
    ON [70.JobVssCredentials].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.JobVssCredentials]([id], [job_id], [oij_id], [credentials_id], db_instance_id)
    SELECT
        src.[id],
        src.[job_id],
        src.[oij_id],
        src.[credentials_id],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.JobVssCredentials] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_JobVssCredentials_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_JobVssCredentials_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_JobVssCredentials_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_JobVssCredentials_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.JobVssCredentials]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_PhysicalHosts_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_PhysicalHosts_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_PhysicalHosts_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_PhysicalHosts_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [name] nvarchar(max),
       [bios_uuid] nvarchar(255),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [name], [bios_uuid])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [name] nvarchar(max) 'name',
       [bios_uuid] nvarchar(255) 'bios_uuid'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.PhysicalHosts]
    SET
        [70.PhysicalHosts].[name] = src.[name],
        [70.PhysicalHosts].[bios_uuid] = src.[bios_uuid]
    FROM [70.PhysicalHosts] INNER JOIN @imported_changes src
    ON [70.PhysicalHosts].id = src.id AND [70.PhysicalHosts].db_instance_id = @dbInstanceId

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.PhysicalHosts]([id], [name], [bios_uuid], db_instance_id)
    SELECT
        src.[id],
        src.[name],
        src.[bios_uuid],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.PhysicalHosts] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL AND src.db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_PhysicalHosts_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_PhysicalHosts_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_PhysicalHosts_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_PhysicalHosts_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.PhysicalHosts]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
	AND [dbo].[70.PhysicalHosts].db_instance_id = @dbInstanceId
END
GO
-----------------------------------------------------


-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Changes]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Changes]') AND type in (N'P'))
     DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Changes]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Changes]
     @dbInstanceId uniqueidentifier,
     @timeZoneShift int,
     @importDoc XML
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @imported_changes table
    (
       [id] uniqueidentifier,
       [session_id] uniqueidentifier,
       [object_name] nvarchar(255),
       [object_id] uniqueidentifier,
       [status] int,
       [reason] ntext,
       [creation_time] datetime,
       [end_time] datetime,
       [operation] nvarchar(255),
       [db_instance_id] uniqueidentifier
    )

    /*              IMPORT XML DOCUMENT      */
    DECLARE @idoc int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @importDoc

    INSERT INTO @imported_changes([id], [session_id], [object_name], [object_id], [status], [reason], [creation_time], [end_time], [operation])
    SELECT *
    FROM OPENXML( @idoc, '/Root/row', 2)
    WITH
    (
       [id] uniqueidentifier 'id',
       [session_id] uniqueidentifier 'session_id',
       [object_name] nvarchar(255) 'object_name',
       [object_id] uniqueidentifier 'object_id',
       [status] int 'status',
       [reason] ntext 'reason',
       [creation_time] datetime 'creation_time',
       [end_time] datetime 'end_time',
       [operation] nvarchar(255) 'operation'
    )
    EXEC sp_xml_removedocument @idoc


    /*             ADD DBID  FIELD          */
    UPDATE @imported_changes
    SET db_instance_id= @dbInstanceId

    /*             TIMEZONE UPDATES         */
    /*             UPDATE EXISTING ROWS     */
    UPDATE [70.Backup.Model.RestoreTaskSessions]
    SET
        [70.Backup.Model.RestoreTaskSessions].[session_id] = src.[session_id],
        [70.Backup.Model.RestoreTaskSessions].[object_name] = src.[object_name],
        [70.Backup.Model.RestoreTaskSessions].[object_id] = src.[object_id],
        [70.Backup.Model.RestoreTaskSessions].[status] = src.[status],
        [70.Backup.Model.RestoreTaskSessions].[reason] = src.[reason],
        [70.Backup.Model.RestoreTaskSessions].[creation_time] = src.[creation_time],
        [70.Backup.Model.RestoreTaskSessions].[end_time] = src.[end_time],
        [70.Backup.Model.RestoreTaskSessions].[operation] = src.[operation]
    FROM [70.Backup.Model.RestoreTaskSessions] INNER JOIN @imported_changes src
    ON [70.Backup.Model.RestoreTaskSessions].id = src.id

    /*      INSERT NEW ROWS       */
    INSERT INTO [70.Backup.Model.RestoreTaskSessions]([id], [session_id], [object_name], [object_id], [status], [reason], [creation_time], [end_time], [operation], db_instance_id)
    SELECT
        src.[id],
        src.[session_id],
        src.[object_name],
        src.[object_id],
        src.[status],
        src.[reason],
        src.[creation_time],
        src.[end_time],
        src.[operation],
        src.db_instance_id
    FROM @imported_changes src LEFT OUTER JOIN [70.Backup.Model.RestoreTaskSessions] trg
    ON src.id = trg.id
    WHERE trg.id IS NULL
END
GO
-----------------------------------------------------




-----------------------------------------------------
--[dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Dels]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Dels]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Dels]
GO
CREATE PROCEDURE [dbo].[usp_Import_70_Backup_Model_RestoreTaskSessions_Dels]
    @deleted_objects_xml XML,
    @dbInstanceId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @deleted_objects_table table
    (
       obj_id  uniqueidentifier
    )

    /* importing deleted objects set  */
    DECLARE @idoc  int
    EXEC sp_xml_preparedocument @idoc OUTPUT, @deleted_objects_xml
    INSERT INTO @deleted_objects_table( obj_id )
    SELECT *
    FROM OPENXML( @idoc, N'/root/object',1 )
    WITH
    (
       obj_id uniqueidentifier '@id'
    )
    EXEC sp_xml_removedocument @idoc

    DELETE FROM [dbo].[70.Backup.Model.RestoreTaskSessions]
    WHERE id IN ( SELECT obj_id FROM @deleted_objects_table )
END
GO
-----------------------------------------------------


