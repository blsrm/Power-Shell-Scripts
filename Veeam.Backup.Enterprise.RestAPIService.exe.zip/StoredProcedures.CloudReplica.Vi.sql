﻿--------------------------------------------------------------------------------
-- AddViHardwarePlan
PRINT N'Creating [dbo].[AddViHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddViHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddViHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[AddViHardwarePlan]
		@id uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@description nvarchar(MAX),
		@hypervisorHostId uniqueidentifier,
		@parentType int,
		@parentName nvarchar(MAX),
		@parentReference nvarchar(MAX),
		@processorUsageLimitMhz int,
		@memoryUsageLimitMb int
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViHardwarePlans]
			   ([id]
			   ,[friendlyName]
			   ,[description]
			   ,[hypervisorHostId]
			   ,[parentType]
			   ,[parentName]
			   ,[parentReference]
			   ,[processorUsageLimitMhz]
			   ,[memoryUsageLimitMb]
			   ,[usn])
		 VALUES
			   (@id,
				@friendlyName,
				@description,
				@hypervisorHostId,
				@parentType,
				@parentName,
				@parentReference,
				@processorUsageLimitMhz,
				@memoryUsageLimitMb,
				0)
	END
GO

--------------------------------------------------------------------------------
-- UpdateViHardwarePlan
PRINT N'Creating [dbo].[UpdateViHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateViHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateViHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[UpdateViHardwarePlan]
		@id uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@description nvarchar(MAX),
		@hypervisorHostId uniqueidentifier,
		@parentType int,
		@parentName nvarchar(MAX),
		@parentReference nvarchar(MAX),
		@processorUsageLimitMhz int,
		@memoryUsageLimitMb int
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.ViHardwarePlans]
		SET
			[friendlyName] = @friendlyName,
			[description] = @description,
			[hypervisorHostId] = @hypervisorHostId,
			[parentType] = @parentType,
			[parentName] = @parentName,
			[parentReference] = @parentReference,
			[processorUsageLimitMhz] = @processorUsageLimitMhz,
			[memoryUsageLimitMb] = @memoryUsageLimitMb
		WHERE [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwarePlan
PRINT N'Creating [dbo].[RemoveViHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwarePlan]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.ViHardwarePlans] where [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- FindViHardwarePlan
PRINT N'Creating [dbo].[FindViHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[FindViHardwarePlan]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlans] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwarePlansByHypervisorHostId
PRINT N'Creating [dbo].[FindViHardwarePlansByHypervisorHostId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwarePlansByHypervisorHostId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwarePlansByHypervisorHostId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwarePlansByHypervisorHostId]
		@hypervisorHostId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlans] where [hypervisorHostId] = @hypervisorHostId
	END

GO

--------------------------------------------------------------------------------
-- FindAllViHardwarePlans
PRINT N'Creating [dbo].[FindAllViHardwarePlans]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllViHardwarePlans]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllViHardwarePlans]
GO

	CREATE PROCEDURE [dbo].[FindAllViHardwarePlans]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlans]
	END

GO

--------------------------------------------------------------------------------
-- AddViHardwarePlanDatastore
PRINT N'Creating [dbo].[AddViHardwarePlanDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddViHardwarePlanDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddViHardwarePlanDatastore]
GO

	CREATE PROCEDURE [dbo].[AddViHardwarePlanDatastore]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@viType nvarchar(MAX),
		@reference nvarchar(MAX),
		@rootPath nvarchar(MAX),
		@quotaGb int,
		@pbmProfileId nvarchar(MAX)
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViHardwarePlanDatastores]
			([id],
			[hardwarePlanId],
			[friendlyName],
			[viType],
			[reference],
			[rootPath],
			[quotaGb],
			[pbmProfileId],
			[usn])
			   
		 VALUES
			(@id,
			@hardwarePlanId,
			@friendlyName,
			@viType,
			@reference,
			@rootPath,
			@quotaGb,
			@pbmProfileId,
			0)
	END
GO

--------------------------------------------------------------------------------
-- UpdateViHardwarePlanDatastore
PRINT N'Creating [dbo].[UpdateViHardwarePlanDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateViHardwarePlanDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateViHardwarePlanDatastore]
GO

	CREATE PROCEDURE [dbo].[UpdateViHardwarePlanDatastore]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@viType nvarchar(MAX),
		@reference nvarchar(MAX),
		@rootPath nvarchar(MAX),
		@quotaGb int,
		@pbmProfileId nvarchar(MAX)
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.ViHardwarePlanDatastores]
		SET
			[hardwarePlanId] = @hardwarePlanId,
			[friendlyName] = @friendlyName,
			[viType] = @viType,
			[reference] = @reference,
			[rootPath] = @rootPath,
			[quotaGb] = @quotaGb,
			[pbmProfileId] = @pbmProfileId
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwarePlanDatastore
PRINT N'Creating [dbo].[RemoveViHardwarePlanDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwarePlanDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwarePlanDatastore]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwarePlanDatastore]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.ViHardwarePlanDatastores] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindViHardwarePlanDatastore
PRINT N'Creating [dbo].[FindViHardwarePlanDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwarePlanDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwarePlanDatastore]
GO

	CREATE PROCEDURE [dbo].[FindViHardwarePlanDatastore]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlanDatastores] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwarePlanDatastoreByHardwarePlanId
PRINT N'Creating [dbo].[FindViHardwarePlanDatastoreByHardwarePlanId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwarePlanDatastoreByHardwarePlanId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwarePlanDatastoreByHardwarePlanId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwarePlanDatastoreByHardwarePlanId]	
		@hardwarePlanId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlanDatastores] where [hardwarePlanId] = @hardwarePlanId
	END

GO

--------------------------------------------------------------------------------
-- FindAllViHardwarePlanDatastores
PRINT N'Creating [dbo].[FindAllViHardwarePlanDatastores]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllViHardwarePlanDatastores]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllViHardwarePlanDatastores]
GO

	CREATE PROCEDURE [dbo].[FindAllViHardwarePlanDatastores]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlanDatastores]
	END

GO

--------------------------------------------------------------------------------
-- AddViHardwarePlanNetwork
PRINT N'Creating [dbo].[AddViHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddViHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddViHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[AddViHardwarePlanNetwork]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@countWithInternent int,
		@countWithoutInternent int
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViHardwarePlanNetworks]
			([id],
			[hardwarePlanId],
			[countWithInternent],
			[countWithoutInternent],
			[usn])
			   
		 VALUES
			(@id,
			@hardwarePlanId,
			@countWithInternent,
			@countWithoutInternent,
			0)
	END
GO

--------------------------------------------------------------------------------
-- UpdateViHardwarePlanNetwork
PRINT N'Creating [dbo].[UpdateViHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateViHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateViHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[UpdateViHardwarePlanNetwork]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@countWithInternent int,
		@countWithoutInternent int
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.ViHardwarePlanNetworks]
		SET
			[hardwarePlanId] = @hardwarePlanId,
			[countWithInternent] = @countWithInternent,
			[countWithoutInternent] = @countWithoutInternent
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwarePlanNetwork
PRINT N'Creating [dbo].[RemoveViHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwarePlanNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.ViHardwarePlanNetworks] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindViHardwarePlanNetwork
PRINT N'Creating [dbo].[FindViHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[FindViHardwarePlanNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlanNetworks] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwarePlanNetworksByHardwarePlanId
PRINT N'Creating [dbo].[FindViHardwarePlanNetworksByHardwarePlanId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwarePlanNetworksByHardwarePlanId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwarePlanNetworksByHardwarePlanId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwarePlanNetworksByHardwarePlanId]	
		@hardwarePlanId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlanNetworks] where [hardwarePlanId] = @hardwarePlanId
	END

GO

--------------------------------------------------------------------------------
-- FindAllViHardwarePlanNetworks
PRINT N'Creating [dbo].[FindAllViHardwarePlanNetworks]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllViHardwarePlanNetworks]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllViHardwarePlanNetworks]
GO

	CREATE PROCEDURE [dbo].[FindAllViHardwarePlanNetworks]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwarePlanNetworks]
	END

GO

-- AddViHardwareQuota
PRINT N'Creating [dbo].[AddViHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddViHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddViHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[AddViHardwareQuota]
		@id uniqueidentifier,
		@tenantId uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@expireDate DATETIME,
		@folderReference nvarchar(MAX),
		@resourcePoolReference nvarchar(MAX),
		@isCorrespondsToPlan bit,
		@wan_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViHardwareQuotas]
			   ([id]
			   ,[tenantId]
			   ,[hardwarePlanId]
			   ,[expireDate]
			   ,[folderReference]
			   ,[resourcePoolReference]
			   ,[isCorrespondsToPlan]
			   ,[wan_id])
			   
		 VALUES
			   (@id,
			    @tenantId,
				@hardwarePlanId,
				@expireDate,
				@folderReference,
				@resourcePoolReference,
				@isCorrespondsToPlan,
				@wan_id)
	END
GO

--------------------------------------------------------------------------------
-- UpdateViHardwareQuota
PRINT N'Creating [dbo].[UpdateViHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateViHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateViHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[UpdateViHardwareQuota]
		@id uniqueidentifier,
		@tenantId uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@expireDate DATETIME,
		@folderReference nvarchar(MAX),
		@resourcePoolReference nvarchar(MAX),
		@isCorrespondsToPlan bit,
		@wan_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.ViHardwareQuotas]
		SET
			   [tenantId] = @tenantId,
			   [hardwarePlanId] = @hardwarePlanId,
			   [expireDate] = @expireDate,
			   [folderReference] = @folderReference,
			   [resourcePoolReference] = @resourcePoolReference,
			   [isCorrespondsToPlan] = @isCorrespondsToPlan,
			   [wan_id] = @wan_id
		WHERE [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwareQuota
PRINT N'Creating [dbo].[RemoveViHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwareQuota]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.ViHardwareQuotas] where [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- FindViHardwareQuota
PRINT N'Creating [dbo].[FindViHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuota]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotas] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotasByTenantId
PRINT N'Creating [dbo].[FindViHardwareQuotasByTenantId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotasByTenantId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotasByTenantId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotasByTenantId]
		@tenantId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotas] where [tenantId] = @tenantId
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotasByHardwarePlanId
PRINT N'Creating [dbo].[FindViHardwareQuotasByHardwarePlanId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotasByHardwarePlanId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotasByHardwarePlanId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotasByHardwarePlanId]
		@hardwarePlanId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotas] where [hardwarePlanId] = @hardwarePlanId
	END

GO

--------------------------------------------------------------------------------
-- FindAllViHardwareQuotas
PRINT N'Creating [dbo].[FindAllViHardwareQuotas]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllViHardwareQuotas]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllViHardwareQuotas]
GO

	CREATE PROCEDURE [dbo].[FindAllViHardwareQuotas]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotas]
	END

GO

--------------------------------------------------------------------------------
-- AddViHardwareQuotaDatastore
PRINT N'Creating [dbo].[AddViHardwareQuotaDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddViHardwareQuotaDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddViHardwareQuotaDatastore]
GO

	CREATE PROCEDURE [dbo].[AddViHardwareQuotaDatastore]
		@id uniqueidentifier,
		@hardwarePlanDatastoreId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@relativePath nvarchar(MAX)
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViHardwareQuotaDatastores]
			([id],
			[hardwarePlanDatastoreId],
			[hardwareQuotaId],
			[relativePath])
			   
		 VALUES
			(@id,
			@hardwarePlanDatastoreId,
			@hardwareQuotaId,
			@relativePath)
	END
GO

--------------------------------------------------------------------------------
-- UpdateViHardwareQuotaDatastore
PRINT N'Creating [dbo].[UpdateViHardwareQuotaDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateViHardwareQuotaDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateViHardwareQuotaDatastore]
GO

	CREATE PROCEDURE [dbo].[UpdateViHardwareQuotaDatastore]
		@id uniqueidentifier,
		@hardwarePlanDatastoreId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@relativePath nvarchar(MAX)
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.ViHardwareQuotaDatastores]
		SET
			[hardwarePlanDatastoreId] = @hardwarePlanDatastoreId,
			[hardwareQuotaId] = @hardwareQuotaId,
			[relativePath] = @relativePath
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwareQuotaDatastore
PRINT N'Creating [dbo].[RemoveViHardwareQuotaDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwareQuotaDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwareQuotaDatastore]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwareQuotaDatastore]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		exec [dbo].[RemoveViHardwareQuotaDatastoreUsageByQuotaId] @id
		delete from [dbo].[Backup.Model.ViHardwareQuotaDatastores] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaDatastore
PRINT N'Creating [dbo].[FindViHardwareQuotaDatastore]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaDatastore]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaDatastore]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaDatastore]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastores] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaDatastoresByHardwarePlanDatastoreId
PRINT N'Creating [dbo].[FindViHardwareQuotaDatastoresByHardwarePlanDatastoreId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaDatastoresByHardwarePlanDatastoreId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaDatastoresByHardwarePlanDatastoreId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaDatastoresByHardwarePlanDatastoreId]	
		@hardwarePlanDatastoreId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastores] where [hardwarePlanDatastoreId] = @hardwarePlanDatastoreId
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaDatastoresByHardwareQuotaId
PRINT N'Creating [dbo].[FindViHardwareQuotaDatastoresByHardwareQuotaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaDatastoresByHardwareQuotaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaDatastoresByHardwareQuotaId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaDatastoresByHardwareQuotaId]	
		@hardwareQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastores] where [hardwareQuotaId] = @hardwareQuotaId
	END

GO

--------------------------------------------------------------------------------
-- FindAllViHardwareQuotaDatastores
PRINT N'Creating [dbo].[FindAllViHardwareQuotaDatastores]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllViHardwareQuotaDatastores]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllViHardwareQuotaDatastores]
GO

	CREATE PROCEDURE [dbo].[FindAllViHardwareQuotaDatastores]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastores]
	END

GO

--------------------------------------------------------------------------------
-- SetViHardwareQuotaDatastoreUsage
PRINT N'Creating [dbo].[SetViHardwareQuotaDatastoreUsage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SetViHardwareQuotaDatastoreUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[SetViHardwareQuotaDatastoreUsage]
GO

	CREATE PROCEDURE [dbo].[SetViHardwareQuotaDatastoreUsage]
		@hardwareDatastoreQuotaId uniqueidentifier,
		@replicaId uniqueidentifier,
		@usageBytes bigint
	AS
	BEGIN
		SET XACT_ABORT ON;

		BEGIN TRAN

		declare @usn bigint
		exec [dbo].[IncrementUsn] @usn OUTPUT

		UPDATE [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] WITH (serializable)
		SET
			[usageBytes] = @usageBytes,
			[usn] = @usn
		WHERE [hardwareDatastoreQuotaId] = @hardwareDatastoreQuotaId and [replicaId] = @replicaId
			
		IF @@rowcount = 0
		BEGIN
			INSERT INTO [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages]
				([hardwareDatastoreQuotaId],
				[replicaId],
				[usageBytes],
				[usn])
			
			VALUES
				(@hardwareDatastoreQuotaId,
				@replicaId,
				@usageBytes,
				@usn)
		END

		COMMIT TRAN
	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwareQuotaDatastoreUsage
PRINT N'Creating [dbo].[RemoveViHardwareQuotaDatastoreUsage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwareQuotaDatastoreUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsage]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsage]
		@hardwareDatastoreQuotaId uniqueidentifier,
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		declare @id uniqueidentifier
		set @id = (select id from [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] where [hardwareDatastoreQuotaId] = @hardwareDatastoreQuotaId and [replicaId] = @replicaId)
		
		if @id is not null
		begin
			declare @usn bigint
			exec [dbo].[RemoveViHardwareQuotaDatastoreUsageById] @id
		end

	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwareQuotaDatastoreUsageById
PRINT N'Creating [dbo].[RemoveViHardwareQuotaDatastoreUsageById]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwareQuotaDatastoreUsageById]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsageById]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsageById]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		declare @usn bigint
		exec [dbo].[IncrementUsn] @usn OUTPUT
		
		delete from [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] where [id] = @id
		exec [dbo].[InsertTombStone] 'Backup.Model.ViHardwareQuotaDatastoreUsages', @id, @usn

	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwareQuotaDatastoreUsageByQuotaId
PRINT N'Creating [dbo].[RemoveViHardwareQuotaDatastoreUsageByQuotaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwareQuotaDatastoreUsageByQuotaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsageByQuotaId]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsageByQuotaId]
		@hardwareDatastoreQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		DECLARE @entryId uniqueidentifier
		DECLARE del CURSOR FOR SELECT id FROM [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] WHERE [hardwareDatastoreQuotaId] = @hardwareDatastoreQuotaId
		OPEN del

		FETCH NEXT FROM del INTO @entryId
		WHILE @@FETCH_STATUS = 0
		BEGIN
			exec [dbo].RemoveViHardwareQuotaDatastoreUsageById @entryId
			FETCH NEXT FROM del INTO @entryId
		END

		CLOSE del
		DEALLOCATE del

	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwareQuotaDatastoreUsageByReplicaId
PRINT N'Creating [dbo].[RemoveViHardwareQuotaDatastoreUsageByReplicaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwareQuotaDatastoreUsageByReplicaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsageByReplicaId]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwareQuotaDatastoreUsageByReplicaId]
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		DECLARE @entryId uniqueidentifier
		DECLARE del CURSOR FOR SELECT id FROM [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] WHERE [replicaId] = @replicaId
		OPEN del

		FETCH NEXT FROM del INTO @entryId
		WHILE @@FETCH_STATUS = 0
		BEGIN
			exec [dbo].RemoveViHardwareQuotaDatastoreUsageById @entryId
			FETCH NEXT FROM del INTO @entryId
		END

		CLOSE del
		DEALLOCATE del

	END
GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaDatastoreUsage
PRINT N'Creating [dbo].[FindViHardwareQuotaDatastoreUsage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaDatastoreUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaDatastoreUsage]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaDatastoreUsage]
		@hardwareDatastoreQuotaId uniqueidentifier,
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] where [hardwareDatastoreQuotaId] = @hardwareDatastoreQuotaId and [replicaId] = @replicaId
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaDatastoreUsagesByQuotaDatastoreId
PRINT N'Creating [dbo].[FindViHardwareQuotaDatastoreUsagesByQuotaDatastoreId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaDatastoreUsagesByQuotaDatastoreId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaDatastoreUsagesByQuotaDatastoreId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaDatastoreUsagesByQuotaDatastoreId]	
		@hardwareDatastoreQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] where [hardwareDatastoreQuotaId] = @hardwareDatastoreQuotaId
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaDatastoreUsagesByReplicaId
PRINT N'Creating [dbo].[FindViHardwareQuotaDatastoreUsagesByReplicaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaDatastoreUsagesByReplicaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaDatastoreUsagesByReplicaId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaDatastoreUsagesByReplicaId]	
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] where [replicaId] = @replicaId
	END

GO

--------------------------------------------------------------------------------
-- FindAllViHardwareQuotaDatastoreUsages
PRINT N'Creating [dbo].[FindAllViHardwareQuotaDatastoreUsages]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllViHardwareQuotaDatastoreUsages]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllViHardwareQuotaDatastoreUsages]
GO

	CREATE PROCEDURE [dbo].[FindAllViHardwareQuotaDatastoreUsages]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages]
	END

GO

--------------------------------------------------------------------------------
-- AddViHardwareQuotaNetwork
PRINT N'Creating [dbo].[AddViHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddViHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddViHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[AddViHardwareQuotaNetwork]
		@id uniqueidentifier,
		@hostNetworks xml,
		@hardwarePlanNetworkId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@name nvarchar(MAX),
		@vlanId int,
		@hasInternet bit,
		@ifaceNum int,
		@tenantInfo xml
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViHardwareQuotaNetworks]
			([id],
			[hostNetworks],
			[hardwarePlanNetworkId],
			[hardwareQuotaId],
			[name],
			[vlanId],
			[hasInternet],
			[ifaceNum],
			[tenantInfo])
			   
		 VALUES
			(@id,
			@hostNetworks,
			@hardwarePlanNetworkId,
			@hardwareQuotaId,
			@name,
			@vlanId,
			@hasInternet,
			@ifaceNum,
			@tenantInfo)
	END
GO

--------------------------------------------------------------------------------
-- UpdateViHardwareQuotaNetwork
PRINT N'Creating [dbo].[UpdateViHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateViHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateViHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[UpdateViHardwareQuotaNetwork]
		@id uniqueidentifier,
		@hardwarePlanNetworkId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@name nvarchar(MAX),
		@vlanId int,
		@hasInternet bit,
		@ifaceNum int,
		@tenantInfo xml
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.ViHardwareQuotaNetworks]
		SET
		    [hardwarePlanNetworkId] = @hardwarePlanNetworkId,
			[hardwareQuotaId] = @hardwareQuotaId,
			[name] = @name,
			[vlanId] = @vlanId,
			[hasInternet] = @hasInternet,
			[ifaceNum] = @ifaceNum,
			[tenantInfo] = @tenantInfo
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveViHardwareQuotaNetwork
PRINT N'Creating [dbo].[RemoveViHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveViHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveViHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[RemoveViHardwareQuotaNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.ViHardwareQuotaNetworks] where [id] = @id 
		
	END
GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaNetworkByTenantId
PRINT N'Creating [dbo].[FindViHardwareQuotaNetworkByTenantId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaNetworkByTenantId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaNetworkByTenantId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaNetworkByTenantId]
		@tenantId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaNetworks] n
			INNER JOIN [dbo].[Backup.Model.ViHardwareQuotas] q on n.hardwareQuotaId = q.id
			where q.tenantId = @tenantId 
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaNetwork
PRINT N'Creating [dbo].[FindViHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaNetworks] where id = @id
	END

GO

--------------------------------------------------------------------------------
-- FindViHardwareQuotaNetworksByHardwareQuotaId
PRINT N'Creating [dbo].[FindViHardwareQuotaNetworksByHardwareQuotaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViHardwareQuotaNetworksByHardwareQuotaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViHardwareQuotaNetworksByHardwareQuotaId]
GO

	CREATE PROCEDURE [dbo].[FindViHardwareQuotaNetworksByHardwareQuotaId]	
		@hardwareQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaNetworks] where [hardwareQuotaId] = @hardwareQuotaId
	END

GO

--------------------------------------------------------------------------------
-- FindAllViHardwareQuotaNetworks
PRINT N'Creating [dbo].[FindAllViHardwareQuotaNetworks]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllViHardwareQuotaNetworks]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllViHardwareQuotaNetworks]
GO

	CREATE PROCEDURE [dbo].[FindAllViHardwareQuotaNetworks]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.ViHardwareQuotaNetworks]
	END

GO

--------------------------------------------------------------------------------
-- GetAllViCloudTenantBackups
PRINT N'Creating [dbo].[GetAllViCloudTenantBackups]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllViCloudTenantBackups]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetAllViCloudTenantBackups]
GO

	CREATE PROCEDURE [dbo].[GetAllViCloudTenantBackups]	
		@tenant_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.ViCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.ViHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Tenants] t ON hq.tenantId = t.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE t.id = @tenant_id
	END

GO

--------------------------------------------------------------------------------
-- FindViCloudTenantBackup
PRINT N'Creating [dbo].[FindViCloudTenantBackup]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViCloudTenantBackup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViCloudTenantBackup]
GO

	CREATE PROCEDURE [dbo].[FindViCloudTenantBackup]	
		@tenant_id uniqueidentifier,
		@backup_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.ViCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.ViHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Tenants] t ON hq.tenantId = t.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE t.id = @tenant_id AND b.id = @backup_id
	END

GO

--------------------------------------------------------------------------------
-- FindViCloudTenantBackupById
PRINT N'Creating [dbo].[FindViCloudTenantBackupById]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViCloudTenantBackupById]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViCloudTenantBackupById]
GO

	CREATE PROCEDURE [dbo].[FindViCloudTenantBackupById]	
		@backup_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.ViCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.ViHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE b.id = @backup_id
	END

GO

--------------------------------------------------------------------------------
-- FindViCloudTenantBackupByJob
PRINT N'Creating [dbo].[FindViCloudTenantBackupByJob]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindViCloudTenantBackupByJob]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindViCloudTenantBackupByJob]
GO

	CREATE PROCEDURE [dbo].[FindViCloudTenantBackupByJob]	
		@tenant_id uniqueidentifier,
		@job_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.ViCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.ViHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Tenants] t ON hq.tenantId = t.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE t.id = @tenant_id AND b.job_id = @job_id
	END

GO

--------------------------------------------------------------------------------
-- LinkViCloudTenantBackupToQuota
PRINT N'Creating [dbo].[LinkViCloudTenantBackupToQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LinkViCloudTenantBackupToQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[LinkViCloudTenantBackupToQuota]
GO

	CREATE PROCEDURE [dbo].[LinkViCloudTenantBackupToQuota]	
		@backup_id uniqueidentifier,
		@quota_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViCloudTenantBackups] (backup_id, quota_id) VALUES (@backup_id, @quota_id)
	END

GO

--------------------------------------------------------------------------------
-- GetAllViCloudTenantBackupsByQuota
PRINT N'Creating [dbo].[GetAllViCloudTenantBackupsByQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllViCloudTenantBackupsByQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetAllViCloudTenantBackupsByQuota]
GO

	CREATE PROCEDURE [dbo].[GetAllViCloudTenantBackupsByQuota]	
		@quota_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.ViCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE cb.quota_id = @quota_id
	END

GO


--------------------------------------------------------------------------------
-- LinkViCloudObjectToQuota
PRINT N'Creating [dbo].[LinkViCloudObjectToQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LinkViCloudObjectToQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[LinkViCloudObjectToQuota]
GO

	CREATE PROCEDURE [dbo].[LinkViCloudObjectToQuota]	
		@object_id uniqueidentifier,
		@quota_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.ViCloudQuotaObjects] ([object_id], quota_id) VALUES (@object_id, @quota_id)
	END

GO
