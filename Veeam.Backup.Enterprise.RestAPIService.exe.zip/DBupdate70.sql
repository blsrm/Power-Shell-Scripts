IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.hosts](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nchar](255) NOT NULL,
 CONSTRAINT [PK_Tape.hosts] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.highest_committed_usn](
	[value] [bigint] NOT NULL
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.directories](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[host_id] [uniqueidentifier] NOT NULL,
	[parent_id] [bigint] NULL,
	[name] [nvarchar](255) NULL,
 CONSTRAINT [PK_Tape.directories] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [host_id] ON [dbo].[Tape.directories] 
(
	[host_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [name_directories] ON [dbo].[Tape.directories] 
(
	[name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [parent_id_name_directories] ON [dbo].[Tape.directories] 
(
	[parent_id] ASC,
	[name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.devices](
	[id] [uniqueidentifier] NOT NULL,
	[scsi_port] [int] NOT NULL,
	[scsi_bus] [int] NOT NULL,
	[scsi_target_id] [int] NOT NULL,
	[scsi_logical_unit_id] [int] NOT NULL,
	[type] [tinyint] NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[serial_number] [nvarchar](50) NOT NULL,
	[state] [tinyint] NOT NULL,
	[lock_id] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Tape.devices] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [lock_id_devices] ON [dbo].[Tape.devices] 
(
	[lock_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [serial_number_devices] ON [dbo].[Tape.devices] 
(
	[serial_number] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.deleted_usns](
	[id] [uniqueidentifier] NOT NULL,
	[usn] [bigint] NOT NULL,
	[table_name] [nvarchar](24) NOT NULL,
	[delete_time] [datetime] NOT NULL,
 CONSTRAINT [PK_Tape.deleted_usn] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [usn_table_name_deleted_usns] ON [dbo].[Tape.deleted_usns] 
(
	[usn] ASC,
	[table_name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.changers](
	[device_id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](max) NULL,
	[vendor_id] [nvarchar](8) NOT NULL,
	[product_id] [nvarchar](16) NOT NULL,
	[revision] [nvarchar](4) NOT NULL,
	[first_drive_number] [int] NOT NULL,
	[drive_count] [int] NOT NULL,
	[first_slot_number] [int] NOT NULL,
	[slot_count] [int] NOT NULL,
 CONSTRAINT [PK_Tape.changers] PRIMARY KEY CLUSTERED 
(
	[device_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.files](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[directory_id] [bigint] NOT NULL,
	[name] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_Tape.files] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [directory_id_files] ON [dbo].[Tape.files] 
(
	[directory_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [name_files] ON [dbo].[Tape.files] 
(
	[name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.libraries](
	[id] [uniqueidentifier] NOT NULL,
	[type] [tinyint] NOT NULL,
	[enabled] [bit] NOT NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
 CONSTRAINT [PK_Tape.libraries] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [type_libraries] ON [dbo].[Tape.libraries] 
(
	[type] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.jobs](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[description] [nvarchar](max) NULL,
	[type] [tinyint] NOT NULL,
	[options] [xml] NOT NULL,
	[schedule_enabled] [bit] NOT NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
 CONSTRAINT [PK_Tape.jobs] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.tape_mediums](
	[id] [uniqueidentifier] NOT NULL,
	[barcode] [nvarchar](256) NULL,
	[name] [nvarchar](max) NULL,
	[media_family_id] [int] NULL,
	[media_sequence_number] [int] NULL,
	[media_time] [datetime] NULL,
	[continuation] [bit] NULL,
	[location_type] [tinyint] NOT NULL,
	[location_library_id] [uniqueidentifier] NULL,
	[location_address] [int] NULL,
	[original_slot] [int] NULL,
	[media_pool_id] [uniqueidentifier] NOT NULL,
	[capacity] [bigint] NOT NULL,
	[remaining] [bigint] NOT NULL,
	[block_size] [int] NOT NULL,
	[partition_count] [int] NOT NULL,
	[is_write_protected] [bit] NOT NULL,
	[is_full] [bit] NOT NULL,
	[last_write_time] [datetime] NULL,
	[lock_id] [uniqueidentifier] NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
 CONSTRAINT [PK_Tape.tape_mediums] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE UNIQUE NONCLUSTERED INDEX [barcode_tape_mediums] ON [dbo].[Tape.tape_mediums] 
(
	[barcode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [is_write_protected_is_full_tape_mediums] ON [dbo].[Tape.tape_mediums] 
(
	[is_write_protected] ASC,
	[is_full] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [location_type_location_library_id_location_address_tape_mediums] ON [dbo].[Tape.tape_mediums] 
(
	[location_type] ASC,
	[location_library_id] ASC,
	[location_address] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [lock_id_tape_mediums] ON [dbo].[Tape.tape_mediums] 
(
	[lock_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [media_family_id_media_sequence_number_barcode_tape_mediums] ON [dbo].[Tape.tape_mediums] 
(
	[media_family_id] ASC,
	[media_sequence_number] ASC,
	[barcode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [media_pool_id_tape_mediums] ON [dbo].[Tape.tape_mediums] 
(
	[media_pool_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.tape_drives](
	[device_id] [uniqueidentifier] NOT NULL,
	[address] [int] NULL,
	[enabled] [bit] NOT NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
 CONSTRAINT [PK_Tape.tape_drives] PRIMARY KEY CLUSTERED 
(
	[device_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [enabled_tape_drives] ON [dbo].[Tape.tape_drives] 
(
	[enabled] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.media_pools](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[description] [nvarchar](max) NULL,
	[type] [tinyint] NOT NULL,
	[options] [xml] NOT NULL,
	[library_id] [uniqueidentifier] NOT NULL,
	[lock_id] [uniqueidentifier] NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
 CONSTRAINT [PK_Tape.media_pools] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [lock_id_media_pools] ON [dbo].[Tape.media_pools] 
(
	[lock_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [type_media_pools] ON [dbo].[Tape.media_pools] 
(
	[type] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.library_devices](
	[library_id] [uniqueidentifier] NOT NULL,
	[device_id] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Tape.library_devices] PRIMARY KEY CLUSTERED 
(
	[library_id] ASC,
	[device_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.sessions](
	[id] [uniqueidentifier] NOT NULL,
	[start_time] [datetime] NULL,
	[total_objects] [int] NOT NULL,
	[processed_objects] [int] NOT NULL,
	[total_size] [bigint] NOT NULL,
	[processed_size] [bigint] NOT NULL,
	[is_startfull] [bit] NOT NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
 CONSTRAINT [PK_Tape.sessions] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.backups](
	[id] [uniqueidentifier] NOT NULL,
	[job_id] [uniqueidentifier] NULL,
	[name] [nvarchar](max) NOT NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
 CONSTRAINT [PK_Tape.backups] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [job_id_backups] ON [dbo].[Tape.backups] 
(
	[job_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.backup_sets](
	[id] [uniqueidentifier] NOT NULL,
	[media_family_id] [int] NOT NULL,
	[number] [int] NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[write_time] [datetime] NOT NULL,
	[usn] [bigint] NOT NULL DEFAULT 0,
	[backup_id] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Tape.backup_sets] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [backup_id_backup_sets] ON [dbo].[Tape.backup_sets] 
(
	[backup_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [media_family_yd_number] ON [dbo].[Tape.backup_sets] 
(
	[media_family_id] ASC,
	[number] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [number_backup_sets] ON [dbo].[Tape.backup_sets] 
(
	[number] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [write_time] ON [dbo].[Tape.backup_sets] 
(
	[write_time] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.directory_versions](
	[directory_id] [bigint] NOT NULL,
	[backup_set_id] [uniqueidentifier] NOT NULL,
	[tape_medium_id] [uniqueidentifier] NOT NULL,
	[creation_time] [datetime] NOT NULL,
	[last_write_time] [datetime] NOT NULL,
	[attributes] [int] NOT NULL,
	[nacl_size] [int] NOT NULL,
	[data_offset] [int] NOT NULL,
	[tape_position] [bigint] NOT NULL,
 CONSTRAINT [PK_Tape.directory_versions] PRIMARY KEY CLUSTERED 
(
	[directory_id] ASC,
	[backup_set_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [last_write_time_directory_versions] ON [dbo].[Tape.directory_versions] 
(
	[last_write_time] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [tape_medium_id] ON [dbo].[Tape.directory_versions] 
(
	[tape_medium_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.file_versions](
	[file_id] [bigint] NOT NULL,
	[backup_set_id] [uniqueidentifier] NOT NULL,
	[creation_time] [datetime] NOT NULL,
	[last_write_time] [datetime] NOT NULL,
	[size] [bigint] NOT NULL,
	[attributes] [int] NOT NULL,
 CONSTRAINT [PK_Tape.file_versions] PRIMARY KEY CLUSTERED 
(
	[file_id] ASC,
	[backup_set_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [last_write_time_file_versions] ON [dbo].[Tape.file_versions] 
(
	[last_write_time] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE TABLE [dbo].[Tape.file_parts](
	[file_id] [bigint] NOT NULL,
	[backup_set_id] [uniqueidentifier] NOT NULL,
	[tape_medium_id] [uniqueidentifier] NOT NULL,
	[file_number] [int] NOT NULL,
	[data_size] [bigint] NOT NULL,
	[data_offset] [int] NOT NULL,
	[tape_position] [bigint] NOT NULL,
 CONSTRAINT [PK_Tape.file_parts] PRIMARY KEY CLUSTERED 
(
	[file_id] ASC,
	[backup_set_id] ASC,
	[tape_medium_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
CREATE NONCLUSTERED INDEX [tape_medium_id] ON [dbo].[Tape.file_parts] 
(
	[tape_medium_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'
CREATE TRIGGER [dbo].[Tape.after_delete_directories]
   ON  [dbo].[Tape.directories]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.directories] WHERE parent_id IN (SELECT id FROM deleted)
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_delete_libraries]
   ON  [dbo].[Tape.libraries]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''libraries'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_libraries]
   ON [dbo].[Tape.libraries]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		UPDATE [Tape.libraries] SET usn = @highest_committed_usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_update_libraries]
   ON  [dbo].[Tape.libraries] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier, @usn bigint
	
	DECLARE deleted_cursor CURSOR FOR SELECT id, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL 
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			UPDATE [Tape.libraries] SET usn = @highest_committed_usn WHERE @id = id
		END
		
		FETCH NEXT FROM deleted_cursor INTO @id, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_delete_jobs]
   ON  [dbo].[Tape.jobs]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''jobs'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_jobs]
   ON [dbo].[Tape.jobs]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		UPDATE [Tape.jobs] SET usn = @highest_committed_usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_update_jobs]
   ON  [dbo].[Tape.jobs] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier, @usn bigint
	
	DECLARE deleted_cursor CURSOR FOR SELECT id, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL 
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			UPDATE [Tape.jobs] SET usn = @highest_committed_usn WHERE @id = id
		END
		
		FETCH NEXT FROM deleted_cursor INTO @id, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_delete_tape_mediums]
   ON  [dbo].[Tape.tape_mediums]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''tape_mediums'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_tape_mediums]
   ON [dbo].[Tape.tape_mediums]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		UPDATE [Tape.tape_mediums] SET usn = @highest_committed_usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_update_tape_mediums]
   ON  [dbo].[Tape.tape_mediums] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- update usn
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier, @usn bigint
	
	DECLARE deleted_cursor CURSOR FOR SELECT id, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL 
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			UPDATE [Tape.tape_mediums] SET usn = @highest_committed_usn WHERE @id = id
		END
		
		FETCH NEXT FROM deleted_cursor INTO @id, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_delete_tape_drives]
   ON  [dbo].[Tape.tape_drives]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT device_id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''tape_drives'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_tape_drives]
   ON [dbo].[Tape.tape_drives]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT device_id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		UPDATE [Tape.tape_drives] SET usn = @highest_committed_usn WHERE @id = device_id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_update_tape_drives]
   ON  [dbo].[Tape.tape_drives] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier, @usn bigint
	
	DECLARE deleted_cursor CURSOR FOR SELECT device_id, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL 
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			UPDATE [Tape.tape_drives] SET usn = @highest_committed_usn WHERE @id = device_id
		END
		
		FETCH NEXT FROM deleted_cursor INTO @id, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_delete_media_pools] 
   ON  [dbo].[Tape.media_pools] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- update deleted_usns
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''media_pools'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
	
	-- move tapes to free pool
	
	UPDATE 
		[Tape.tape_mediums] 
	SET 
		media_pool_id = (SELECT id FROM [Tape.media_pools] WHERE [type] = 1)
	WHERE
		media_pool_id IN (SELECT id FROM deleted)
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_media_pools]
   ON [dbo].[Tape.media_pools]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		UPDATE [Tape.media_pools] SET usn = @highest_committed_usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_update_media_pools]
   ON  [dbo].[Tape.media_pools] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier, @usn bigint
	
	DECLARE deleted_cursor CURSOR FOR SELECT id, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL 
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			UPDATE [Tape.media_pools] SET usn = @highest_committed_usn WHERE @id = id
		END
		
		FETCH NEXT FROM deleted_cursor INTO @id, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_delete_sessions] 
   ON  [dbo].[Tape.sessions] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''sessions'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_sessions]
   ON [dbo].[Tape.sessions]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		UPDATE [Tape.sessions] SET usn = @highest_committed_usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_update_sessions]
   ON  [dbo].[Tape.sessions] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier, @usn bigint
	
	DECLARE deleted_cursor CURSOR FOR SELECT id, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL 
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			UPDATE [Tape.sessions] SET usn = @highest_committed_usn WHERE @id = id
		END
		FETCH NEXT FROM deleted_cursor INTO @id, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_delete_backup_sets] 
   ON [dbo].[Tape.backup_sets] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''backup_sets'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_backup_sets]
   ON [dbo].[Tape.backup_sets]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		UPDATE [Tape.backup_sets] SET usn = @highest_committed_usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_update_backup_sets]
   ON  [dbo].[Tape.backup_sets] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier, @usn bigint
	DECLARE deleted_cursor CURSOR FOR SELECT id, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL 
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			
			UPDATE [Tape.backup_sets] SET usn = @highest_committed_usn WHERE @id = id
		END
		
		FETCH NEXT FROM deleted_cursor INTO @id, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_directory_versions]
   ON [Tape.directory_versions]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
    UPDATE 
		[Tape.tape_mediums] 
	SET 
		last_write_time = GETDATE() 
	WHERE 
		id = (SELECT tape_medium_id FROM INSERTED)    
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
exec sp_executesql @stat = N'CREATE TRIGGER [Tape.after_insert_file_parts]
   ON [dbo].[Tape.file_parts]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
    UPDATE 
		[Tape.tape_mediums] 
	SET 
		last_write_time = GETDATE() 
	WHERE 
		id = (SELECT tape_medium_id FROM INSERTED)
END'
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 700)
BEGIN
ALTER TABLE [dbo].[Tape.changers]  WITH CHECK ADD  CONSTRAINT [FK_Tape.changers_devices] FOREIGN KEY([device_id])
REFERENCES [Tape.devices] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.changers] CHECK CONSTRAINT [FK_Tape.changers_devices]

ALTER TABLE [dbo].[Tape.files]  WITH CHECK ADD  CONSTRAINT [FK_Tape.files_directories] FOREIGN KEY([directory_id])
REFERENCES [Tape.directories] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.files] CHECK CONSTRAINT [FK_Tape.files_directories]

ALTER TABLE [dbo].[Tape.jobs] ADD  CONSTRAINT [DF__jobs__schedule_enabled]  DEFAULT ((1)) FOR [schedule_enabled]

ALTER TABLE [dbo].[Tape.tape_drives]  WITH CHECK ADD  CONSTRAINT [FK_Tape.tape_drives_devices] FOREIGN KEY([device_id])
REFERENCES [Tape.devices] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.tape_drives] CHECK CONSTRAINT [FK_Tape.tape_drives_devices]

ALTER TABLE [dbo].[Tape.tape_drives] ADD  CONSTRAINT [DF__tape_drives__enabled]  DEFAULT ((1)) FOR [enabled]

ALTER TABLE [dbo].[Tape.library_devices]  WITH CHECK ADD  CONSTRAINT [FK_Tape.library_devices_devices] FOREIGN KEY([device_id])
REFERENCES [Tape.devices] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.library_devices] CHECK CONSTRAINT [FK_Tape.library_devices_devices]

ALTER TABLE [dbo].[Tape.library_devices]  WITH CHECK ADD  CONSTRAINT [FK_Tape.library_devices_libraries] FOREIGN KEY([library_id])
REFERENCES [Tape.libraries] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.library_devices] CHECK CONSTRAINT [FK_Tape.library_devices_libraries]

ALTER TABLE [dbo].[Tape.sessions] ADD  CONSTRAINT [DF__sessions__total___47A6A41B]  DEFAULT ((0)) FOR [total_objects]

ALTER TABLE [dbo].[Tape.sessions] ADD  CONSTRAINT [DF__sessions__proces__489AC854]  DEFAULT ((0)) FOR [processed_objects]

ALTER TABLE [dbo].[Tape.sessions] ADD  CONSTRAINT [DF__sessions__total___498EEC8D]  DEFAULT ((0)) FOR [total_size]

ALTER TABLE [dbo].[Tape.sessions] ADD  CONSTRAINT [DF__sessions__proces__4A8310C6]  DEFAULT ((0)) FOR [processed_size]

ALTER TABLE [dbo].[Tape.sessions] ADD  CONSTRAINT [DF__sessions__is_sta__4B7734FF]  DEFAULT ((0)) FOR [is_startfull]

ALTER TABLE [dbo].[Tape.backups]  WITH CHECK ADD  CONSTRAINT [FK_Tape.backups_jobs] FOREIGN KEY([job_id])
REFERENCES [Tape.jobs] ([id])
ON DELETE SET NULL

ALTER TABLE [dbo].[Tape.backups] CHECK CONSTRAINT [FK_Tape.backups_jobs]

ALTER TABLE [dbo].[Tape.backup_sets]  WITH CHECK ADD  CONSTRAINT [FK_Tape.backup_sets_backup_sets] FOREIGN KEY([id])
REFERENCES [Tape.backup_sets] ([id])

ALTER TABLE [dbo].[Tape.backup_sets] CHECK CONSTRAINT [FK_Tape.backup_sets_backup_sets]

ALTER TABLE [dbo].[Tape.backup_sets]  WITH CHECK ADD  CONSTRAINT [FK_Tape.backups_sets_backups] FOREIGN KEY([backup_id])
REFERENCES [Tape.backups] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.backup_sets] CHECK CONSTRAINT [FK_Tape.backups_sets_backups]

ALTER TABLE [dbo].[Tape.directory_versions]  WITH CHECK ADD  CONSTRAINT [FK_Tape.directory_versions_backup_sets] FOREIGN KEY([backup_set_id])
REFERENCES [Tape.backup_sets] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.directory_versions] CHECK CONSTRAINT [FK_Tape.directory_versions_backup_sets]

ALTER TABLE [dbo].[Tape.directory_versions]  WITH CHECK ADD  CONSTRAINT [FK_Tape.directory_versions_directories] FOREIGN KEY([directory_id])
REFERENCES [Tape.directories] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.directory_versions] CHECK CONSTRAINT [FK_Tape.directory_versions_directories]

ALTER TABLE [dbo].[Tape.file_versions]  WITH CHECK ADD  CONSTRAINT [FK_Tape.file_versions_backup_sets] FOREIGN KEY([backup_set_id])
REFERENCES [Tape.backup_sets] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.file_versions] CHECK CONSTRAINT [FK_Tape.file_versions_backup_sets]

ALTER TABLE [dbo].[Tape.file_versions]  WITH CHECK ADD  CONSTRAINT [FK_Tape.file_versions_files] FOREIGN KEY([file_id])
REFERENCES [Tape.files] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.file_versions] CHECK CONSTRAINT [FK_Tape.file_versions_files]

ALTER TABLE [dbo].[Tape.file_parts]  WITH CHECK ADD  CONSTRAINT [FK_Tape.file_parts_file_versions] FOREIGN KEY([file_id], [backup_set_id])
REFERENCES [Tape.file_versions] ([file_id], [backup_set_id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.file_parts] CHECK CONSTRAINT [FK_Tape.file_parts_file_versions]

ALTER TABLE [dbo].[Tape.file_parts]  WITH CHECK ADD  CONSTRAINT [FK_Tape.file_parts_tape_mediums] FOREIGN KEY([tape_medium_id])
REFERENCES [Tape.tape_mediums] ([id])
ON DELETE CASCADE

ALTER TABLE [dbo].[Tape.file_parts] CHECK CONSTRAINT [FK_Tape.file_parts_tape_mediums]

INSERT INTO [dbo].[Tape.backups] ([id], [name]) VALUES ('437913A2-1D8E-4d74-BB0D-4FDEC6771A6C', 'Imported')
INSERT INTO [dbo].[Tape.highest_committed_usn] ([value]) VALUES (0)

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 700; END	

END
GO
--700
---------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 701)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 701; END	

END		
GO

--701
---------------------------------------------------------------------------
-----------------------------------------------------
--

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 702)
BEGIN

IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Disks]') AND [name] = 'diskId')
BEGIN
	ALTER TABLE [dbo].[Disks] ADD [diskId] nvarchar(255) not null default ''
	print 'New column {diskId} has been successfully added to dbo.Disks table'
END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 702; END
END		
GO
--702
-----------------------------------------------------
--

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 703)
BEGIN

DECLARE @mailOptionsId uniqueidentifier
DECLARE @xml xml
SET @mailOptionsId = '91bb166b-e197-48f7-a430-7904e013b30b'

SET @xml = (SELECT [value] from [dbo].[Options] WHERE [id] = @mailOptionsId)

DECLARE @str nvarchar(max)
SET @str = CAST (@xml as nvarchar(max))

SET @str = replace(@str, '<EncryptedPassword>', '<Password>')
SET @str = replace(@str, '</EncryptedPassword>', '</Password>')

UPDATE [dbo].[Options] SET
	[value] = @str
WHERE [id] = @mailOptionsId


IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 703; END
END		
GO
--703
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 704)
BEGIN

ALTER TABLE [Tape.hosts] ALTER COLUMN name [nvarchar](255) NOT NULL

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 704; END
END		
GO
--704
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 704)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 705; END
END		
GO
--705
---------------------------------------------------------------------------
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 705)
BEGIN
/*
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.volumes]') AND type in (N'U'))
	BEGIN

		CREATE TABLE [dbo].[Tape.volumes](
			[id] [uniqueidentifier] NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[name] [nvarchar](255) NULL,
			[device] [char](1) NULL,
		CONSTRAINT [PK_Tape.volumes] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	END
*/
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 706; END
END		
GO
--706
---------------------------------------------------------------------------
---------------------------------------------------------------------------
--

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version =706)
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = 'parent_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBs] add parent_id [uniqueidentifier] NULL
		PRINT 'New column {parent_id} has been successfully added to dbo.Backup.Model.OIBs'
    
		
	END
	    
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 707; END	
END		
GO
--707
---------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 707 AND current_version < 709)
BEGIN
	UPDATE [dbo].[Version] SET current_version = 709;
END		
GO
--709
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 710)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.changers]') and [name] = N'has_barcode_scanner')
	BEGIN
		ALTER TABLE [dbo].[Tape.changers] ADD [has_barcode_scanner] [bit] DEFAULT 0 NOT NULL

		PRINT 'New column [has_barcode_scanner] has been successfully added to [Tape.changers]'
	END

	IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_Tape.directories_Tape.hosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[Tape.directories]'))
	BEGIN
		ALTER TABLE [dbo].[Tape.directories] WITH CHECK ADD CONSTRAINT [FK_Tape.directories_Tape.hosts] FOREIGN KEY([host_id])
		REFERENCES [dbo].[Tape.hosts] ([id])
		ON DELETE CASCADE

		ALTER TABLE [dbo].[Tape.directories] CHECK CONSTRAINT [FK_Tape.directories_Tape.hosts]

		PRINT 'New foreign key [FK_Tape.directories_Tape.hosts] has been successfully added to [Tape.directories]'
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Tape.hosts]') AND name = N'hosts')
	BEGIN
		CREATE NONCLUSTERED INDEX [hosts] ON [dbo].[Tape.hosts] 
		(
			[name] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		PRINT 'New index [hosts] has been successfully added to [Tape.hosts]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and [name] = N'media_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [media_id] [uniqueidentifier] NULL

		PRINT 'New column [media_id] has been successfully added to [Tape.tape_mediums]'

		CREATE NONCLUSTERED INDEX [media_id] ON [dbo].[Tape.tape_mediums] 
		(
			[media_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		PRINT 'New index [media_id] has been successfully added to [Tape.tape_mediums]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and [name] = N'media_label')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [media_label] [nvarchar](255) NULL

		PRINT 'New column [media_label] has been successfully added to [Tape.tape_mediums]'
	END
		
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND name = N'barcode_tape_mediums')
	BEGIN
		DROP INDEX [barcode_tape_mediums] ON [dbo].[Tape.tape_mediums] WITH ( ONLINE = OFF )

		PRINT 'Old index [barcode_tape_mediums] has been successfully dropped in [Tape.tape_mediums]'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 710; END
END		
GO
--710
---------------------------------------------------------------------------


--711
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 710)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	UPDATE [dbo].[Backup.Model.Session.Filters] 
		SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>(([job_type] &gt; 3 AND [job_type] != 8 AND [job_type] &lt; 18) OR ([job_type] &gt; 40 AND [job_type] &lt; 43))</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>',
			[usn] = @usn
	WHERE [id]='BE4D46D0-5345-7171-9B36-7AF216D8DCF2' --Restore
	
	exec [dbo].[IncrementUsn] @usn OUTPUT
	UPDATE [dbo].[Backup.Model.Session.Filters]
		SET [data] ='<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 0 OR [job_type] = 40)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>',
			[usn] = @usn
	WHERE [id]='83B702D1-2C19-4ec1-BB5E-CB701CD77273' --Backup

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 711; END
END		
GO
--711
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 712)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.changers]') and [name] = N'drive_cleaning_required')
	BEGIN
		ALTER TABLE [dbo].[Tape.changers] ADD [drive_cleaning_required] [bit] DEFAULT 0 NOT NULL

		PRINT 'New column [drive_cleaning_required] has been successfully added to [Tape.changers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 712; END
END		
GO
--712
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 713)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') and [name] = N'physical_block_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [physical_block_address] [bigint] DEFAULT 0 NOT NULL

		PRINT 'New column [physical_block_address] has been successfully added to [Tape.backup_sets]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = N'format_logical_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.directory_versions] ADD [format_logical_address] [bigint] DEFAULT 0 NOT NULL

		PRINT 'New column [format_logical_address] has been successfully added to [Tape.directory_versions]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'format_logical_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] ADD [format_logical_address] [bigint] DEFAULT 0 NOT NULL

		PRINT 'New column [format_logical_address] has been successfully added to [Tape.file_parts]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 713; END
END		
GO
--713
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 714)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') and [name] = N'physical_block_address')
	BEGIN
--temporary fix	
		declare @constname	sysname,
				@cmd		varchar(1024)

		declare curs_constraints cursor for
			select 	name
			from 	sysobjects 
			where 	xtype in ('D')
			and	(status & 64) = 0
			and     parent_obj = OBJECT_ID(N'[dbo].[Tape.backup_sets]')

		open curs_constraints

		fetch next from curs_constraints into @constname
		while (@@fetch_status = 0)
		begin
			select @cmd = 'ALTER TABLE [dbo].[Tape.backup_sets] DROP CONSTRAINT [' + @constname + ']'
			exec(@cmd)
			fetch next from curs_constraints into @constname
		end

		close curs_constraints
		deallocate curs_constraints

--fix end
		ALTER TABLE [dbo].[Tape.backup_sets] DROP COLUMN [physical_block_address]
		PRINT 'Column [physical_block_address] has been successfully droppped in [Tape.backup_sets]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = N'nacl_size')
	BEGIN
		ALTER TABLE [dbo].[Tape.directory_versions] DROP COLUMN [nacl_size]
		PRINT 'Column [nacl_size] has been successfully droppped in [Tape.directory_versions]'
	END
	
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = N'data_offset')
	BEGIN
		ALTER TABLE [dbo].[Tape.directory_versions] DROP COLUMN [data_offset]
		PRINT 'Column [data_offset] has been successfully droppped in [Tape.directory_versions]'
	END
	
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = N'tape_position')
	BEGIN
		ALTER TABLE [dbo].[Tape.directory_versions] DROP COLUMN [tape_position]
		PRINT 'Column [tape_position] has been successfully droppped in [Tape.directory_versions]'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = N'physical_block_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.directory_versions] ADD [physical_block_address] [bigint] DEFAULT 0 NOT NULL

		PRINT 'New column [physical_block_address] has been successfully added to [Tape.directory_versions]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'data_size')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] DROP COLUMN [data_size]
		PRINT 'Column [data_size] has been successfully droppped in [Tape.file_parts]'
	END
	
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'data_offset')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] DROP COLUMN [data_offset]
		PRINT 'Column [data_offset] has been successfully droppped in [Tape.file_parts]'
	END
	
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'tape_position')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] DROP COLUMN [tape_position]
		PRINT 'Column [tape_position] has been successfully droppped in [Tape.file_parts]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'file_number')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] DROP COLUMN [file_number]
		PRINT 'Column [file_number] has been successfully droppped in [Tape.file_parts]'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'physical_block_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] ADD [physical_block_address] [bigint] DEFAULT 0 NOT NULL

		PRINT 'New column [physical_block_address] has been successfully added to [Tape.file_parts]'
	END

	ALTER TABLE [Tape.backup_sets] ADD DEFAULT ((0)) FOR [usn]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 714; END
END		
GO
--714
---------------------------------------------------------------------------

---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 715)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') AND [name] = 'platform')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD platform int NOT NULL DEFAULT(0)
	END
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 715; END	
END		
GO
--715
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- Upgrade data: Backup.Model.Backups
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 716)
BEGIN

UPDATE [dbo].[Backup.Model.Backups]
SET platform = 1 --EHyperV
WHERE job_source_type = 4 --ESourceType.HyperV

UPDATE [dbo].[Backup.Model.Backups]
SET platform = 0 --EVmWare
WHERE job_source_type != 4 --ESourceType.HyperV

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 716; END	
END		
GO
--716
---------------------------------------------------------------------------

---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 717)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') AND [name] = 'display_name')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBs] ADD display_name [nvarchar](1000) DEFAULT '' NOT NULL
	END
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 717; END	
END		
GO
--717
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- Upgrade data: Backup.Model.OIBs
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 718)
BEGIN

UPDATE [dbo].[Backup.Model.OIBs]
SET display_name = vmname

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 718; END	
END		
GO
--718
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 718)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.storage_map]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.storage_map](
			[tape_storage_id] [uniqueidentifier] NOT NULL,
			[file_id] [bigint] NOT NULL,
			[backup_set_id] [uniqueidentifier] NOT NULL,
			[backup_storage_id] [uniqueidentifier] NULL,
		 CONSTRAINT [PK_Tape.storage_map] PRIMARY KEY CLUSTERED 
		(
			[tape_storage_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Tape.storage_map]  WITH CHECK ADD  CONSTRAINT [FK_Tape.storages_Tape.file_versions] FOREIGN KEY([file_id], [backup_set_id])
		REFERENCES [dbo].[Tape.file_versions] ([file_id], [backup_set_id])
		ON DELETE CASCADE

		ALTER TABLE [dbo].[Tape.storage_map] CHECK CONSTRAINT [FK_Tape.storages_Tape.file_versions]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 719; END
END		
GO
--719
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 719)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'physical_block_address')
	BEGIN
		declare @constname	sysname,
				@cmd		varchar(1024)

		declare curs_constraints cursor for
			select 	name
			from 	sysobjects 
			where 	xtype in ('D')
			and	(status & 64) = 0
			and     parent_obj = OBJECT_ID(N'[dbo].[Tape.file_parts]')

		open curs_constraints

		fetch next from curs_constraints into @constname
		while (@@fetch_status = 0)
		begin
			select @cmd = 'ALTER TABLE [dbo].[Tape.file_parts] DROP CONSTRAINT [' + @constname + ']'
			exec(@cmd)
			fetch next from curs_constraints into @constname
		end

		close curs_constraints
		deallocate curs_constraints

		ALTER TABLE [dbo].[Tape.file_parts] DROP COLUMN [physical_block_address]
		PRINT 'Column [physical_block_address] has been successfully droppped in [Tape.file_parts]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') and [name] = N'physical_block_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [physical_block_address] [bigint] DEFAULT 0 NOT NULL
		PRINT 'New column [physical_block_address] has been successfully added to [Tape.backup_sets]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and [name] = N'format_logical_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [format_logical_address] [bigint] DEFAULT 0 NOT NULL
		PRINT 'New column [format_logical_address] has been successfully added to [Tape.tape_mediums]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 720; END
END		
GO
--720
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 720)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = N'physical_block_address')
	BEGIN
		declare @constname	sysname,
				@cmd		varchar(1024)

		declare curs_constraints cursor for
			select 	name
			from 	sysobjects 
			where 	xtype in ('D')
			and	(status & 64) = 0
			and     parent_obj = OBJECT_ID(N'[dbo].[Tape.directory_versions]')

		open curs_constraints

		fetch next from curs_constraints into @constname
		while (@@fetch_status = 0)
		begin
			select @cmd = 'ALTER TABLE [dbo].[Tape.directory_versions] DROP CONSTRAINT [' + @constname + ']'
			exec(@cmd)
			fetch next from curs_constraints into @constname
		end

		close curs_constraints
		deallocate curs_constraints

		ALTER TABLE [dbo].[Tape.directory_versions] DROP COLUMN [physical_block_address]
		PRINT 'Column [physical_block_address] has been successfully droppped in [Tape.directory_versions]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 721; END
END		
GO
--721
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 721)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.vm_objects]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.vm_objects](
			[vm_object_id] [uniqueidentifier] NOT NULL,
			[tape_object_id] [uniqueidentifier] NOT NULL,
		 CONSTRAINT [PK_Tape.vm_objects] PRIMARY KEY CLUSTERED 
		(
			[vm_object_id] ASC,
			[tape_object_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [tape_object_id] ON [dbo].[Tape.vm_objects] 
		(
			[tape_object_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		PRINT 'Table [Tape.storage_map] has been successfully created'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.storage_map]') and [name] = N'backup_storage_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.storage_map] DROP COLUMN [backup_storage_id]

		EXEC sp_rename '[dbo].[Tape.storage_map]', 'Tape.storages'

		PRINT 'Column [backup_storage_id] has been successfully droppped in [Tape.storage_map]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 722; END
END		
GO
--722
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 722)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 723; END
END		
GO
--723
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 723)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 724; END
END		
GO
--724
---------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 724)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.storages]') AND [name] = 'media_family_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.storages] ADD [media_family_id] [int] NOT NULL DEFAULT 0
		PRINT 'New column [media_family_id] has been successfully added to [Tape.storages]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.storages]') AND [name] = 'session_number')
	BEGIN
		ALTER TABLE [dbo].[Tape.storages] ADD [session_number] [int] NOT NULL DEFAULT 0
		PRINT 'New column [session_number] has been successfully added to [Tape.storages]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.storages]') AND [name] = 'format_logical_address')
	BEGIN
		ALTER TABLE [dbo].[Tape.storages] ADD [format_logical_address] [bigint] NOT NULL DEFAULT 0
		PRINT 'New column [format_logical_address] has been successfully added to [Tape.storages]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.storages]') AND [name] = 'location')
	BEGIN
		ALTER TABLE [dbo].[Tape.storages] ADD [location] [xml] NOT NULL DEFAULT N'<?xml version="1.0" encoding="utf-16"?>'
		PRINT 'New column [location] has been successfully added to [Tape.storages]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 725; END
END		
GO
--725
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 725)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 726; END
END		
GO
--726
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 726)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	INSERT INTO [dbo].[Backup.Model.Session.Filters] ([id],[name],[data],[usn])
	VALUES('FC0B6A9D-F476-49DA-9B11-6A21879C71CA',
		   'Tape',
		   '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 24 OR [job_type] = 25 OR [job_type] = 26 OR [job_type] = 27 OR [job_type] = 28 OR [job_type] = 29 OR [job_type] = 32)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
		   ,@usn)
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 727; END
END
GO
--727
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 727 AND current_version < 732)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 732; END
END		
GO

--------------------------------------------------------------------------------
-- Helpers

PRINT N'Creating auxiliary stored procedures (helpers)...'

--------------------------------------------------------------------------------
-- HrIsProcExists

PRINT N'[dbo].[HrIsProcExists]'

IF EXISTS(
	SELECT *
	FROM sys.objects
	WHERE object_id = OBJECT_ID(N'[dbo].[HrIsProcExists]') AND
	TYPE IN (N'P', N'PC')
	)
	DROP PROCEDURE [dbo].[HrIsProcExists]
GO

CREATE PROCEDURE [dbo].[HrIsProcExists]
	@proc NVARCHAR(256)
	AS
	BEGIN
		IF EXISTS(
			SELECT *
			FROM sys.objects
			WHERE object_id = OBJECT_ID(@proc) AND
			TYPE IN (N'P', N'PC')
			)
			RETURN 1;
		ELSE
			RETURN 0;
	END
GO

--------------------------------------------------------------------------------
-- HrDropProcIfExists

PRINT N'[dbo].[HrDropProcIfExists]'

DECLARE @result INT
EXEC @result = HrIsProcExists @proc = N'[dbo].[HrDropProcIfExists]'
IF @result = 1
	DROP PROCEDURE [dbo].[HrDropProcIfExists]
GO

CREATE PROCEDURE [dbo].[HrDropProcIfExists]
	@proc NVARCHAR(256)
	AS
	BEGIN
		DECLARE @result INT
		EXEC @result = HrIsProcExists @proc
		IF @result = 1
			BEGIN
				EXEC('DROP PROCEDURE' + @proc)
			END
	END
GO

--------------------------------------------------------------------------------
-- HrPreCreateProc

PRINT N'Creating [dbo].[HrPreCreateProc]'

EXEC HrDropProcIfExists @proc = N'[dbo].[HrPreCreateProc]'
GO

CREATE PROCEDURE [dbo].[HrPreCreateProc]
	@proc NVARCHAR(256)
	AS
	BEGIN
		PRINT N'Creating ' + @proc
		EXEC HrDropProcIfExists @proc
	END
GO

--------------------------------------------------------------------------------
-- HrTestCurrentVersion

PRINT N'[dbo].[HrTestCurrentVersion]'

EXEC HrDropProcIfExists @proc = N'[dbo].[HrTestCurrentVersion]'
GO

CREATE PROCEDURE [dbo].[HrTestCurrentVersion]
	@version INT
	AS
	BEGIN
		IF EXISTS (
			SELECT *
			FROM [dbo].[Version]
			WHERE current_version = @version
			)
			RETURN 1
		ELSE
			RETURN 0
	END
GO

--------------------------------------------------------------------------------
-- HrSetCurrentVersion

PRINT N'[dbo].[HrSetCurrentVersion]'

EXEC HrDropProcIfExists @proc = N'[dbo].[HrSetCurrentVersion]'
GO

CREATE PROCEDURE [dbo].[HrSetCurrentVersion]
	@version INT
	AS
	BEGIN
		UPDATE [dbo].[Version]
		SET current_version = @version;
	END
GO

--------------------------------------------------------------------------------
-- HrIsTableExists

PRINT N'[dbo].[HrIsTableExists]'

EXEC HrDropProcIfExists @proc = N'[dbo].[HrIsTableExists]'
GO

CREATE PROCEDURE [dbo].[HrIsTableExists]
	@table NVARCHAR(256)
	AS
	BEGIN
		IF EXISTS(
			SELECT *
			FROM sys.objects
			WHERE object_id = OBJECT_ID(@table) AND
			TYPE IN (N'U')
			)
			RETURN 1;
		ELSE
			RETURN 0;
	END
GO

--------------------------------------------------------------------------------
-- HrBeginUpdate

PRINT N'[dbo].[HrBeginUpdate]'

EXEC HrDropProcIfExists @proc = N'[dbo].[HrBeginUpdate]'
GO

CREATE PROCEDURE [dbo].[HrBeginUpdate]
	@version INT
	AS
	BEGIN
		DECLARE @result INT
		EXEC @result = HrTestCurrentVersion @version
		IF @result = 1
			PRINT N'Updating database version ' + CONVERT(NVARCHAR, @version) + N'...'
		ELSE
			PRINT N'Current database version ' + CONVERT(NVARCHAR, @version) + ' is up to date.'
	END
GO

--------------------------------------------------------------------------------
-- HrEndUpdate

PRINT N'[dbo].[HrEndUpdate]'

EXEC HrDropProcIfExists @proc = N'[dbo].[HrEndUpdate]'
GO

CREATE PROCEDURE [dbo].[HrEndUpdate]
	@version INT
	AS
	BEGIN
		DECLARE @result INT
		EXEC @result = HrTestCurrentVersion @version
		IF @result = 1
			BEGIN
				IF @@ERROR = 0
				BEGIN
					SET NOCOUNT ON
					DECLARE @new_version INT
					SET @new_version = @version + 1
					EXEC HrSetCurrentVersion @new_version
					PRINT N'Database version ' + CONVERT(NVARCHAR, @version) + N' was successfully updated.'
					PRINT N'New database version is ' + CONVERT(NVARCHAR, @new_version) + N'.'
				END
			END
	END
GO

--------------------------------------------------------------------------------
-- HrPreCreateTable

PRINT N'[dbo].[HrPreCreateTable]'

EXEC HrDropProcIfExists @proc = N'[dbo].[HrPreCreateTable]'
GO

CREATE PROCEDURE [dbo].[HrPreCreateTable]
	@version INT,
	@table NVARCHAR(256)
	AS
	BEGIN
		DECLARE @result INT
		EXEC @result = HrTestCurrentVersion @version
		IF @result = 1
			BEGIN
				EXEC @result = HrIsTableExists @table
				IF @result = 1
					RETURN 0
				ELSE
					BEGIN
						PRINT N'Create table ' + @table
						RETURN 1
					END
			END
		RETURN 0
	END
GO

--------------------------------------------------------------------------------

PRINT 'Auxiliary stored procedures (helpers) was successfully created.'

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 732)
BEGIN
		CREATE TABLE [dbo].[DataSources] (
			[id] UNIQUEIDENTIFIER NOT NULL UNIQUE DEFAULT (NEWID()),
			[name] NVARCHAR(256) NOT NULL,
			[description] NVARCHAR(MAX) NULL,
			[database_name] NVARCHAR(256) NOT NULL,
			[host_name] NVARCHAR(256) NOT NULL,
			[options] XML NULL,
			CONSTRAINT [PK_DataSources_id] PRIMARY KEY CLUSTERED (
				[id]
				)
				WITH (
					PAD_INDEX = OFF,
					STATISTICS_NORECOMPUTE = OFF,
					IGNORE_DUP_KEY = OFF,
					ALLOW_ROW_LOCKS = ON,
					ALLOW_PAGE_LOCKS = ON
					)
					ON [PRIMARY],
			CONSTRAINT [UQ_DataSources_name_database_host] UNIQUE (
				[name],
				[database_name],
				[host_name]
				)
				ON [PRIMARY]
		)
		ON [PRIMARY]

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 733; END
END		
GO

--------------------------------------------------------------------------------
IF EXISTS(SELECT 1 FROM [dbo].[Version] WHERE current_version = 733) 
BEGIN
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') and name = 'parent_schedule_id')
	BEGIN
		ALTER TABLE [dbo].[BJobs] ADD [parent_schedule_id] [uniqueidentifier] DEFAULT NULL;
		CREATE NONCLUSTERED INDEX ix_parent_schedule_id ON [dbo].[BJobs] (parent_schedule_id);
		PRINT 'New column [parent_schedule_id] has been successfully added to [BJobs]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 734; END
END
GO
--------------------------------------------------------------------------------
--Version 734

IF EXISTS(SELECT 1 FROM [dbo].[Version] WHERE current_version = 734) 
BEGIN
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 735; END
END
GO
--------------------------------------------------------------------------------
--Version 735

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 735)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 736; END
END		
GO
--------------------------------------------------------------------------------
--Version 736

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 736)
BEGIN
	if NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[PhysicalHosts]') and [name] = 'os_type')
	begin
			alter table [dbo].[PhysicalHosts] add os_type int DEFAULT 0  NOT null
			print 'New column {os_type} has been successfully added to dbo.PhysicalHosts table'					
	end

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 737; END
END		
GO
--------------------------------------------------------------------------------
--Version 737


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 737)
BEGIN
			
	UPDATE [dbo].[PhysicalHosts]
	SET [dbo].[PhysicalHosts].[os_type] = 5
	FROM [dbo].[PhysicalHosts], [dbo].[Hosts]
	WHERE [dbo].[PhysicalHosts].[id] = [dbo].[Hosts].[physical_host_id] AND [dbo].[Hosts].[type] = 7 AND [dbo].[PhysicalHosts].[os_type] = 0		

	print 'Upgraded values of os_type field for Hyper-V 2008 servers'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 738; END
END		
GO
--------------------------------------------------------------------------------
--Version 738

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 738)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 739; END
END		
GO
--------------------------------------------------------------------------------
--Version 739

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 739)
BEGIN
	if NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Hosts]') and [name] = 'host_instance_id')
	begin
			alter table [dbo].Hosts add host_instance_id nvarchar(255) DEFAULT null
			print 'New column {host_instance_id} has been successfully added to dbo.Hosts table'					
	end
	
	if NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[BObjects]') and [name] = 'unique_key_hash')
	begin
			alter table [dbo].BObjects add unique_key_hash varbinary(16) DEFAULT null
			print 'New column {unique_key_hash} has been successfully added to dbo.BObjects table'
	end
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 740; END
END		
GO
--------------------------------------------------------------------------------



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 740 AND current_version < 746)
BEGIN

	CREATE TABLE [dbo].[Hierarchy.VmsRecursiveInclusion](
			[id] as [container_key_hash] + [vm_key_hash] PERSISTED NOT NULL,
			[container_key_hash] [varbinary](16) NOT NULL,
			[vm_key_hash] [varbinary](16) NOT NULL
			CONSTRAINT [PK_Hierarchy.VmsRecursiveInclusion] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 746; END
END		
GO
--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 746 AND current_version < 749)
BEGIN
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and name = 'retention_reason')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [retention_reason] [nvarchar](max);
		PRINT 'New column [retention_reason] has been successfully added to [Tape.tape_mediums]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 749; END
END		
GO
--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 749)
BEGIN
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_drives]') and name = 'name')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_drives] ADD [name] [nvarchar](max);
		PRINT 'New column [name] has been successfully added to [Tape.tape_drives]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 750; END
END		
GO
--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 750)
BEGIN
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_drives]') and name = 'model')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_drives] ADD [model] [nvarchar](max);
		PRINT 'New column [model] has been successfully added to [Tape.tape_drives]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 751; END
END		
GO
--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 751 AND current_version < 757)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 757; END
END		
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 757)
BEGIN
	IF not exists (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Folders]') and [name] = 'platform')
		BEGIN
		ALTER TABLE dbo.Folders ADD platform int NOT NULL DEFAULT(0)
		PRINT 'New column {platform} has been successfully added to dbo.Folders table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 758; END
END		
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 758)
BEGIN
exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_tape_drives]
   ON  [dbo].[Tape.tape_drives] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @highest_committed_usn bigint, @device_id uniqueidentifier, @address int, @enabled bit, @name nvarchar(MAX), @model nvarchar(MAX), @usn bigint
	
	DECLARE deleted_cursor CURSOR FOR SELECT device_id, address, enabled, name, model, usn FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @device_id, @address, @enabled, @name, @model, @usn
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT @usn IS NULL AND EXISTS(SELECT * FROM inserted WHERE device_id = @device_id AND (address <> @address OR enabled <> @enabled OR name <> @name OR model <> @model))
		BEGIN
			EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
			UPDATE [Tape.tape_drives] SET usn = @highest_committed_usn WHERE @device_id = device_id
		END

		FETCH NEXT FROM deleted_cursor INTO @device_id, @address, @enabled, @name, @model, @usn
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 759; END
END
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 759)
BEGIN
	IF not exists (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[VirtualLabs]') and [name] = 'platform')
		BEGIN
		ALTER TABLE dbo.VirtualLabs ADD platform int NOT NULL DEFAULT(0)
		PRINT 'New column {platform} has been successfully added to dbo.VirtualLabs table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 760; END
END		
GO
--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 760 AND current_version < 762)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 762; END
END		
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 762)
BEGIN
	IF not exists (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.TemporaryBackups]') and [name] = 'temporary_storage')
		BEGIN
		ALTER TABLE [dbo].[Backup.TrackedActions.TemporaryBackups] ADD [temporary_storage] bit NOT NULL DEFAULT(0)
		PRINT 'New column {[temporary_storage]} has been successfully added to dbo.RegisterTemporaryBackup table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 763; END
END		
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 763 AND current_version < 769)
BEGIN
	IF not exists (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and [name] = 'retired')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [retired] bit NOT NULL DEFAULT(0)
		PRINT 'New column [retired] has been successfully added to [dbo].[Tape.tape_mediums] table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 769; END
END		
GO


--	================================================================================ --
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 769 AND current_version < 770)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 770; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 770)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WanAccelerators]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[WanAccelerators] 
		(
			[id] uniqueidentifier NOT NULL CONSTRAINT [DF_WanAccelerators_id]  DEFAULT (newid()),
			[name] nvarchar(max) NOT NULL,
			[description] nvarchar(max) NULL,
			[host_id] uniqueidentifier NOT NULL,
			[options] xml NOT NULL,
--			[is_busy] bit not null default 0,
--			[is_unavailable] bit not null default 0,
			[usn] bigint NOT NULL DEFAULT 0
			
			CONSTRAINT [PK_WanAccelerators] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		
		) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 771; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 771 AND current_version < 774)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 774; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 774)
BEGIN	
		
	EXEC sp_rename
		@objname = '[dbo].[Backup.Model.HPSanSnapshots]',
		@newname = 'Backup.Model.SanSnapshots',
		@objtype = 'OBJECT';
	    
	EXEC sp_rename
		@objname = '[dbo].[Backup.Model.SanSnapshots].iqn',
		@newname = 'iqn_or_wwn',
		@objtype = 'COLUMN'    
	    
	EXEC sp_rename
		@objname = '[dbo].[Backup.Model.HPSanVolumes]',
		@newname = 'Backup.Model.SanVolumes',
		@objtype = 'OBJECT'

	EXEC sp_rename
		@objname = '[dbo].[Backup.Model.SanVolumes].iqn',
		@newname = 'iqn_or_wwn',
		@objtype = 'COLUMN'
	    
	EXEC sp_rename
		@objname = '[dbo].[Backup.Model.SanVolumes].cluster_id',
		@newname = 'parent_id',
		@objtype = 'COLUMN'
	    
	EXEC sp_rename
		@objname = '[dbo].[Backup.Model.HpSanSnapshotStorages]',
		@newname = 'Backup.Model.SanSnapshotStorages',
		@objtype = 'OBJECT'

	EXEC sp_rename
		@objname = '[dbo].[Backup.Model.HpSanVolumeBackups]',
		@newname = 'Backup.Model.SanVolumeBackups',
		@objtype = 'OBJECT'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 775; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 775)
BEGIN	

	alter table [dbo].[Backup.Model.SanVolumes] add host_id uniqueidentifier
	print 'New column {host_id} has been successfully added to dbo.Backup.Model.SanVolumes table'					    
	
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 776; END
END
GO		

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 776)
BEGIN				    
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 777; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 777)
BEGIN	

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanHostsPlugins]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.SanHostsPlugins]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Backup_Model_SanHostsPlugins_id]  DEFAULT (newid()),
			[host_id] [uniqueidentifier] NOT NULL,
			[plugin_id] [uniqueidentifier] NOT NULL
			
		    CONSTRAINT [PK_Backup_Model_SanHostsPlugins_id] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]
		
		print 'New table [dbo].[Backup.Model.SanHostsPlugins] has been successfully created'					   	
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 778; END
END
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 778)
BEGIN	
	
	DECLARE @host_id uniqueidentifier
 
	DECLARE hpsanhosts_cursor CURSOR FOR
	SELECT [id] FROM [dbo].[Hosts]	WHERE [type] = 11 --HP P4000 hosts
	
	OPEN hpsanhosts_cursor
	FETCH NEXT FROM hpsanhosts_cursor into @host_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN	   
	   	   
	   INSERT INTO [dbo].[Backup.Model.SanHostsPlugins] ([host_id], [plugin_id]) VALUES (@host_id,'342B45F8-AF12-4291-B90E-D3594F123FBD')	
	   
	   FETCH NEXT FROM hpsanhosts_cursor into @host_id
	END

	CLOSE hpsanhosts_cursor
	DEALLOCATE hpsanhosts_cursor
	print 'Inserting links for plugins for existing HP P4000 hosts has been successfully completed'	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 779; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 779 AND current_version < 781)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 781; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 781 AND current_version < 782)
BEGIN

if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[WanAccelerators]') and [name] = 'is_busy')
begin
    alter table [dbo].[WanAccelerators] add [is_busy] bit not null default 0
    print 'New column {is_busy} has been successfully added to dbo.WanAccelerators table'
end

if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[WanAccelerators]') and [name] = 'is_unavailable')
begin
    alter table [dbo].[WanAccelerators] add [is_unavailable] bit not null default 0
    print 'New column {is_unavailable} has been successfully added to dbo.WanAccelerators table'
end
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 782; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 782 AND current_version < 785)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 785; END
END		
GO	

--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 785 AND current_version < 789)
BEGIN	

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'display_name' and objs.name = N'BObjects')
		BEGIN
			ALTER TABLE [dbo].[BObjects]
			ADD [display_name] nvarchar(256) DEFAULT '' NOT NULL
		END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 789; END
END
GO	

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 789)
BEGIN	

	UPDATE [BObjects]
		SET [BObjects].display_name = SUBSTRING( [BObjects].object_name, 0, 255 )

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 790; END
END
GO	

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 790 AND current_version < 793)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 793; END
END
GO


--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 793)
BEGIN

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanInitiatorsByProxy]') AND type in (N'U'))
BEGIN
		CREATE TABLE [dbo].[Backup.Model.SanInitiatorsByProxy](
		 [id] [uniqueidentifier] NOT NULL,
		 [proxy_id] [uniqueidentifier] NOT NULL,
		 [iqn_or_wwn] [nvarchar](255) NOT NULL,
		 [type] [int] NOT NULL
		 CONSTRAINT [PK_Backup.SanInitiatorsByProxy] PRIMARY KEY CLUSTERED 
		(
		 [id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 794; END
END
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 794)
BEGIN

exec sp_executesql @stat = N'
CREATE TRIGGER [dbo].[after_delete_backup_proxies]
   ON  [dbo].[BackupProxies]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [dbo].[Backup.Model.SanInitiatorsByProxy] WHERE proxy_id IN (SELECT id FROM deleted)
END'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 795; END
END
GO
--795
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 795)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	INSERT INTO [dbo].[Backup.Model.Session.Filters] ([id],[name],[data],[usn])
	VALUES('3C032C4A-D6C3-4C04-921E-55D7DDF9F859',
		   'Application Item Restore',
		   '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 48)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
		   ,@usn)
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 796; END
END
GO


--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 796 AND current_version < 797)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 797; END
END
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 797)
BEGIN

IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Backup.Model.SanSnapshots]') AND [name] = 'parent_snapshot_id')
BEGIN
	ALTER TABLE [dbo].[Backup.Model.SanSnapshots] add parent_snapshot_id uniqueidentifier DEFAULT null
	PRINT 'New column {parent_snapshot_id} has been successfully added to [dbo].[Backup.Model.SanSnapshots] table'
END

IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Backup.Model.SanSnapshots]') AND [name] = 'aux_data')
BEGIN
	ALTER TABLE [dbo].[Backup.Model.SanSnapshots] add aux_data xml DEFAULT null
	PRINT 'New column {aux_data} has been successfully added to [dbo].[Backup.Model.SanSnapshots] table'
END

IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Backup.Model.SanVolumes]') AND [name] = 'aux_data')
BEGIN
	ALTER TABLE [dbo].[Backup.Model.SanVolumes] add aux_data xml DEFAULT null
	PRINT 'New column {aux_data} has been successfully added to [dbo].[Backup.Model.SanVolumes] table'
END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 798; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 798)
BEGIN
	
	DECLARE @usn BIGINT
	EXEC [dbo].[IncrementUsn] @usn OUTPUT

	UPDATE [dbo].[Backup.Model.Session.Filters] 
	SET 
		[data] = '<ReportCriteria><Criterions><string>([job_type] = 3 OR [job_type] = 200 OR [job_type] = 201)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>',
		[usn] = @usn
	WHERE [id] = 'BE4D46D0-5345-4741-9B36-7AF216D8DCF3' -- SureBackup
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 799; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 800)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[HostComponents]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''HostComponents''
	end
	'

	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[WanAccelerators]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''WanAccelerators''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 800; END	
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 800 AND current_version < 802)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 802; END
END
GO


--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 802 AND current_version < 805)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumes]') AND [name] = 'san_type')
	BEGIN

		ALTER TABLE [dbo].[Backup.Model.SanVolumes] ADD san_type int DEFAULT 0 not null
		print 'New column {san_type} has been successfully added to [dbo].[Backup.Model.SanVolumes] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumes]') AND [name] = 'internal_id')
	BEGIN

		ALTER TABLE [dbo].[Backup.Model.SanVolumes] ADD internal_id [nvarchar](255) DEFAULT '' not null
		print 'New column {internal_id} has been successfully added to [dbo].[Backup.Model.SanVolumes] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshots]') AND [name] = 'internal_id')
	BEGIN

		ALTER TABLE [dbo].[Backup.Model.SanSnapshots] ADD internal_id [nvarchar](255) DEFAULT '' not null
		print 'New column {internal_id} has been successfully added to [dbo].[Backup.Model.SanSnapshots] table'		
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 805; END
END		
GO
--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 805)
BEGIN
	
	UPDATE [dbo].[Backup.Model.SanVolumes] SET [dbo].[Backup.Model.SanVolumes].internal_id = [dbo].[Backup.Model.SanVolumes].iqn_or_wwn
	print 'Column {internal_id} has been successfully updated from iqn_or_wwn colume at table SanVolumes'		
	
	UPDATE [dbo].[Backup.Model.SanSnapshots] SET [dbo].[Backup.Model.SanSnapshots].internal_id = [dbo].[Backup.Model.SanSnapshots].iqn_or_wwn
	print 'Column {internal_id} has been successfully updated from iqn_or_wwn colume at table SanSnapshots'		
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 806; END
END		
GO
--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 806 AND current_version < 810)
BEGIN
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 810; END
END		
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 810)
BEGIN

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeByProxyInitiators]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[Backup.Model.SanVolumeByProxyInitiators]
	(
		[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Backup_Model_SanVolumeByProxyInitiators_id]  DEFAULT (newid()),
		[volume_id] [uniqueidentifier] NOT NULL,
		[proxy_initiator_id] [uniqueidentifier] NOT NULL
		
	    CONSTRAINT [PK_Backup_Model_SanVolumeByProxyInitiators_id] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)
		WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
	)
	ON [PRIMARY]
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeByProxyInitiators]') AND name = N'IX_Backup_Model_SanVolumeByProxyInitiators_volume_id')
BEGIN
	CREATE NONCLUSTERED INDEX [IX_Backup_Model_SanVolumeByProxyInitiators_volume_id] ON [dbo].[Backup.Model.SanVolumeByProxyInitiators]
	(
		[volume_id] ASC
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END	

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeByProxyInitiators]') AND name = N'IX_Backup_Model_SanVolumeByProxyInitiators_proxy_initiator_id')
BEGIN
	CREATE NONCLUSTERED INDEX [IX_Backup_Model_SanVolumeByProxyInitiators_proxy_initiator_id] ON [dbo].[Backup.Model.SanVolumeByProxyInitiators]
	(
		[proxy_initiator_id] ASC
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END	

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 811; END
END		
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 811)
BEGIN

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[after_delete_san_volumes]') AND type in (N'TR'))
BEGIN
exec sp_executesql @stat = N'
	CREATE TRIGGER [dbo].[after_delete_san_volumes]
	   ON  [dbo].[Backup.Model.SanVolumes]
	   AFTER DELETE
	AS 
	BEGIN
		SET NOCOUNT ON;
		
		DELETE FROM [dbo].[Backup.Model.SanVolumeByProxyInitiators] WHERE volume_id IN (SELECT id FROM deleted)
		DELETE FROM [dbo].[Backup.Model.SanVolumeExportInfos] WHERE volume_id IN (SELECT id FROM deleted)
	END'
END

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[after_delete_san_initiator]') AND type in (N'TR'))
BEGIN
exec sp_executesql @stat = N'

	CREATE TRIGGER [dbo].[after_delete_san_initiator]
	   ON  [dbo].[Backup.Model.SanInitiatorsByProxy]
	   AFTER DELETE
	AS 
	BEGIN
		SET NOCOUNT ON;
		
		DELETE FROM [dbo].[Backup.Model.SanVolumeByProxyInitiators] WHERE proxy_initiator_id IN (SELECT id FROM deleted)
	END'
END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 812; END
END		
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 812 AND current_version < 816)
BEGIN
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 816; END
END		
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 816)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.Plugins](
			[plugin_id] [uniqueidentifier] NOT NULL,
			[enabled] [bit] NOT NULL,
			[current_version] [nvarchar](50) NOT NULL,
			CONSTRAINT [PK_Backup.Model.Plugins] PRIMARY KEY CLUSTERED 
		(
			[plugin_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 817; END	
END		
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 816)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.Plugins](
			[plugin_id] [uniqueidentifier] NOT NULL,
			[enabled] [bit] NOT NULL,
			[current_version] [nvarchar](50) NOT NULL,
			CONSTRAINT [PK_Backup.Model.Plugins] PRIMARY KEY CLUSTERED 
		(
			[plugin_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 817; END	
END		
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 817)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SbTaskSessions]') AND [name] = 'validation_status')
	BEGIN

		ALTER TABLE [dbo].[Backup.Model.SbTaskSessions] ADD [validation_status] int DEFAULT 7 not null
		print 'New column {san_type} has been successfully added to [dbo].[Backup.Model.SanVolumes] table'		
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 818; END
END		
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 818)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND [name] = 'compatible')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Plugins] ADD compatible bit DEFAULT 1 NOT NULL
		print 'New column {compatible} has been successfully added to [dbo].[Backup.Model.Plugins] table'		
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 819; END
END		
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 819 AND current_version < 820)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 820; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 820)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins] ') AND [name] = 'name')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Plugins] ADD [name] nvarchar(255) DEFAULT '' NOT NULL
		PRINT 'New column [name] has been successfully added to [dbo].[Backup.Model.Plugins]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins] ') AND [name] = 'kind')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Plugins] ADD [kind] nvarchar(255) DEFAULT '' NOT NULL
		PRINT 'New column [kind] has been successfully added to [dbo].[Backup.Model.Plugins]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins] ') AND [name] = 'module_path')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Plugins] ADD [module_path] nvarchar(MAX) DEFAULT '' NOT NULL
		PRINT 'New column [module] has been successfully added to [dbo].[Backup.Model.Plugins]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 821; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 821)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Backup.Model.Plugins] SET [enabled] = 0, compatible = 0 WHERE [module_path] = '' END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 822; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 822)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Credentials]') AND [name] = 'description')
	BEGIN
		ALTER TABLE [dbo].[Credentials] ADD [description] nvarchar(MAX) DEFAULT '' NOT NULL
		PRINT 'New column [description] has been successfully added to [dbo].[Credentials]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 823; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 823)
BEGIN

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND [name] = 'plugin_id')
	BEGIN
		exec sp_rename '[dbo].[Backup.Model.Plugins].[plugin_id]', 'id', 'COLUMN'
		PRINT 'Column [Backup.Model.Plugins].[plugin_id] has been successfully rename to [Backup.Model.Plugins].[id]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND [name] = 'current_version')
	BEGIN
		exec sp_rename '[dbo].[Backup.Model.Plugins].[current_version]', 'software_version', 'COLUMN'
		PRINT 'Column [Backup.Model.Plugins].[current_version] has been successfully rename to [Backup.Model.Plugins].[software_version]'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND [name] = 'db_version')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Plugins] ADD [db_version] int DEFAULT 0 NOT NULL
		PRINT 'New column [db_version] has been successfully added to [dbo].[Backup.Model.Plugins]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND [name] = 'usn')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Plugins] ADD [usn] bigint DEFAULT 0 NOT NULL
		PRINT 'New column [usn] has been successfully added to [dbo].[Backup.Model.Plugins]'
	END

	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.Plugins]''))
		BEGIN
			EXEC [dbo].[AddTrackChangeTriggers] N''Backup.Model.Plugins''
		END'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 824; END
END
GO

--------------------------------------------------------------------------------
-- Version 828

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 824 AND current_version < 828)
BEGIN

		CREATE TABLE [dbo].[ItemRestoreAudits] (
			[id] UNIQUEIDENTIFIER NOT NULL UNIQUE DEFAULT (NEWID()),
			[restore_session_id] UNIQUEIDENTIFIER NOT NULL,
			[restore_state] INT NOT NULL DEFAULT 0,
			[item_type] NVARCHAR(256) NOT NULL,
			[item_name] NVARCHAR(256) NOT NULL,
			[item_size] BIGINT NOT NULL DEFAULT 0,
			[restore_source] NVARCHAR(256) NOT NULL,
			[restore_target] NVARCHAR(256) NOT NULL,
			[start_time] DATETIME DEFAULT NULL,
			[finish_time] DATETIME DEFAULT NULL,
			[message] NVARCHAR(1024) DEFAULT '',
			[aux_data] XML NULL,
			CONSTRAINT [PK_ItemRestoreAudit_id] PRIMARY KEY CLUSTERED (
				[id]
				)
				WITH (
					PAD_INDEX = OFF,
					STATISTICS_NORECOMPUTE = OFF,
					IGNORE_DUP_KEY = OFF,
					ALLOW_ROW_LOCKS = ON,
					ALLOW_PAGE_LOCKS = ON
					)
					ON [PRIMARY],
			CONSTRAINT [UQ_ItemRestoreAudit_id_restore_session_id] UNIQUE (
				[id],
				[restore_session_id]
				)
				ON [PRIMARY]
		)
		ON [PRIMARY]

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 828; END
END		
GO


------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 828 AND current_version < 837)
BEGIN
	ALTER TABLE [dbo].[ItemRestoreAudits] ADD usn [bigint] DEFAULT 0 NOT NULL	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 837; END
END		
GO
----------


IF EXISTS (SELECT name FROM sysobjects WHERE name = 'd_ItemRestoreAudits' AND type = 'TR')
    DROP TRIGGER [dbo].[d_ItemRestoreAudits]
GO
	CREATE TRIGGER [dbo].[d_ItemRestoreAudits] on [dbo].[ItemRestoreAudits] FOR DELETE   
	AS 
	BEGIN
		SET NOCOUNT ON;
	
		declare @id uniqueidentifier
			select @id = id from deleted
			if not @id is null
				exec dbo.TrackChange N'ItemRestoreAudits', @id, 2
	END
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 837 AND current_version < 838)
BEGIN
	ALTER TABLE [dbo].[ItemRestoreAudits] ADD dest_type [int] DEFAULT 2 NOT NULL	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 838; END
END		
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 839)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.JobWanAccelerators]') AND type in (N'U'))
	begin
		CREATE TABLE [dbo].[Backup.Model.JobWanAccelerators](
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[job_id] [uniqueidentifier] NOT NULL,
			[accelerator_id] [uniqueidentifier] NOT NULL,
			[type] [int] NOT NULL,
			[usn] [bigint] NOT NULL DEFAULT 0,
		 CONSTRAINT [PK_JobAccelerators] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	end

    exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.JobWanAccelerators]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.JobWanAccelerators''
	end
	'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 839; END
END

GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 839 AND current_version < 844)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') and [name] = 'is_internal')
	begin
		alter table [dbo].[Backup.Model.RestoreJobSessions] add [is_internal] [bit] not null default 0
	end

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 844; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 844 AND current_version < 849)
BEGIN
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 849; END
END		
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 849)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JobObjectsState]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[JobObjectsState](
			[id] UNIQUEIDENTIFIER NOT NULL,
			[job_id] UNIQUEIDENTIFIER NOT NULL,
			[obj_id] UNIQUEIDENTIFIER NOT NULL,
			[creation_time] DATETIME NOT NULL,
			[data] XML NULL,
			CONSTRAINT [PK_JobObjectsState] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 850; END	
END		
GO

--
-----------------------------------------------------
--
-- BEGIN TRANSFORM DATA SSH/SOAP CREDS 
--
-- Condition: 850
--
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	DECLARE @credId as uniqueidentifier, @descr as nvarchar(max)

	DECLARE cred_cursor CURSOR FOR
	SELECT [Credentials].id, [Credentials].description FROM [dbo].[Credentials] WHERE [Credentials].description = ''
	OPEN cred_cursor

	FETCH NEXT FROM cred_cursor INTO @credId, @descr 
	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF EXISTS(SELECT * FROM [dbo].Hosts as h WHERE h.credentials_id <> '00000000-0000-0000-0000-000000000000' AND h.credentials_id = @credId)
				BEGIN
					UPDATE dbo.[Credentials] 
					SET [Credentials].description = N'Set by automated upgrade. Credentials for server ' + (SELECT name FROM [dbo].Hosts as h WHERE h.credentials_id = @credId)
					WHERE [Credentials].id = @credId
				END 
			IF EXISTS(SELECT * FROM [dbo].[Backup.Model.MruList] as m WHERE m.credential_id <> '00000000-0000-0000-0000-000000000000' AND m.credential_id = @credId)
				BEGIN
					UPDATE dbo.[Credentials] 
					SET [Credentials].description = N'Set by automated upgrade. Credentials for ' + (SELECT url FROM [dbo].[Backup.Model.MruList] as m WHERE m.credential_id = @credId)
					WHERE [Credentials].id = @credId
				END 
			IF EXISTS(SELECT * FROM [dbo].[BackupRepositories] as r WHERE r.share_creds_id <> '00000000-0000-0000-0000-000000000000' AND r.share_creds_id = @credId)
				BEGIN
					UPDATE dbo.[Credentials] 
					SET [Credentials].description = N'Set by automated upgrade. Credentials for shared folder ' + (SELECT name FROM [dbo].[BackupRepositories] as r WHERE r.share_creds_id = @credId)
					WHERE [Credentials].id = @credId
				END
		FETCH NEXT FROM cred_cursor INTO @credId, @descr 
		END
	CLOSE cred_cursor
	DEALLOCATE cred_cursor
END
GO

-- Ssh_creds
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND [name] = 'creds')
	BEGIN
		ALTER TABLE [dbo].[Ssh_creds] ADD [creds] uniqueidentifier NULL
		PRINT 'New column [creds] has been successfully added to [dbo].[Ssh_creds]'
	END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF NOT EXISTS (SELECT creds FROM [dbo].[Ssh_creds] WHERE creds IN ( SELECT [Credentials].id FROM [dbo].[Credentials])) AND
			EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND [name] = 'user') AND
			EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND [name] = 'password')
	BEGIN
		exec sp_executesql  N' 
		UPDATE [dbo].[Ssh_creds] 
		SET creds = NEWID()
		WHERE creds IS NULL AND [Ssh_creds].[user] <> N'''' AND [Ssh_creds].[password] IS NOT NULL
		IF(@@ROWCOUNT>0)
			BEGIN
			INSERT INTO [dbo].[Credentials] 
			SELECT creds, [user], [password] ,usn, N''Set by automated upgrade. Credentials for server '' + ISNULL((SELECT [name] FROM dbo.Hosts WHERE [id] = host_id),N'''')
			FROM [dbo].[Ssh_creds] 
			WHERE creds NOT IN
			  (
				 SELECT
				  [Credentials].id 
				 FROM
				   [dbo].[Credentials]
			  ) AND creds IS NOT NULL
			IF @@ROWCOUNT>0 
				BEGIN PRINT ''Credentials has been successfully copied from [dbo].[Ssh_creds] to [dbo].[Credentials]''
				END
			END'
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND ([name] = 'user'))
	BEGIN
		ALTER TABLE [dbo].[Ssh_creds]
		DROP COLUMN [user]
		IF @@Error = 0 BEGIN PRINT 'Columns user was successfully removed from [dbo].[Ssh_creds]' END
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND ([name] = 'password'))
	BEGIN
		ALTER TABLE [dbo].[Ssh_creds]
		DROP COLUMN [password]
		IF @@Error = 0 BEGIN PRINT 'Columns password was successfully removed from [dbo].[Ssh_creds]' END
	END
END
GO

--Soap_creds
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Soap_creds]') AND [name] = 'creds')
	BEGIN
		ALTER TABLE [dbo].[Soap_creds] ADD [creds] uniqueidentifier NULL
		PRINT 'New column [creds] has been successfully added to [dbo].[Soap_creds]'
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF NOT EXISTS (SELECT creds FROM [dbo].[Soap_creds] WHERE creds IN ( SELECT [Credentials].id FROM [dbo].[Credentials])) AND
			EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Soap_creds]') AND [name] = 'user') AND
			EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Soap_creds]') AND [name] = 'password')
	BEGIN
		exec sp_executesql N' 
		UPDATE [dbo].[Soap_creds] 
		SET creds = NEWID()
		WHERE creds IS NULL AND [Soap_creds].[user] <> N'''' AND [Soap_creds].[password] IS NOT NULL
		IF(@@ROWCOUNT>0)
			BEGIN
			INSERT INTO [dbo].[Credentials] 
			SELECT creds, [user], [password] ,usn, N''Set by automated upgrade. SOAP credentials for server  '' + ISNULL((SELECT [name] FROM dbo.Hosts WHERE [id] = host_id),N'''')
			FROM [dbo].[Soap_creds] 
			WHERE creds NOT IN
			  (
				 SELECT
				  [Credentials].id 
				 FROM
				   [dbo].[Credentials]
			  ) AND creds IS NOT NULL
			IF @@ROWCOUNT>0
				BEGIN PRINT ''Credentials has been successfully copied from [dbo].[Soap_creds] to [dbo].[Credentials]''
				END
			END'
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Soap_creds]') AND ([name] = 'user'))
	BEGIN
		ALTER TABLE [dbo].[Soap_creds]
		DROP COLUMN [user]
		IF @@Error = 0 BEGIN PRINT 'Columns user was successfully removed from [dbo].[Soap_creds]' END
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 850)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Soap_creds]') AND ([name] = 'password'))
	BEGIN
		ALTER TABLE [dbo].[Soap_creds]
		DROP COLUMN [password]
		IF @@Error = 0 BEGIN PRINT 'Columns password was successfully removed from [dbo].[Soap_creds]' END
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 850 AND current_version < 852)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 852; END
END	
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 852 AND current_version < 856)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 856; END
END	
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 856 AND current_version < 857)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 857; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 857 AND current_version < 858)
BEGIN
 IF  NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'JobVssCredentials')
	BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobCredentials]') AND [name] = 'object_id')
	BEGIN
		ALTER TABLE [dbo].[JobCredentials]
		ALTER COLUMN [object_id] uniqueidentifier NULL
	END
	PRINT 'Job credentials transform started'
	DECLARE @jobId as uniqueidentifier, 
	@objectId as uniqueidentifier, 
	@jobName as nvarchar(max), 
	@vss_options as XML, 
	@user_name as nvarchar(max), 
	@pass as nvarchar(max), 
	@nCredId as uniqueidentifier,
	@usn bigint,
	@object_name as nvarchar(2000) 
	
	DECLARE job_curs CURSOR FOR
	SELECT j.id, j.name, j.vss_options FROM [dbo].BJobs as j
	OPEN job_curs
	FETCH NEXT FROM job_curs INTO @jobId, @jobName, @vss_options
	WHILE @@FETCH_STATUS = 0
	BEGIN
	SELECT @user_name = User_Name.item.value('UserName[1]','nvarchar(max)'), @pass = User_Name.item.value('Password[1]','nvarchar(max)') 
	FROM @vss_options.nodes('/CVssOptions/Credentials') User_Name(item)
	IF @user_name IS NOT NULL AND @user_name<>N'' AND @pass IS NOT NULL 
	BEGIN
	IF NOT EXISTS (SELECT * FROM [dbo].[Credentials] as c WHERE c.user_name=@user_name AND c.password = @pass)
		BEGIN
			SET @nCredId = NEWID()
	        exec [dbo].[IncrementUsn] @usn OUTPUT	
			INSERT INTO [dbo].[Credentials](id, user_name, password, usn, description) 
			VALUES (@nCredId, @user_name, @pass, @usn, 'Set by automated upgrade for job ' +  isnull(@jobName, N''))
			exec [dbo].[IncrementUsn] @usn OUTPUT 
			INSERT INTO [dbo].[JobCredentials](id, job_id,object_id,credentials_id,usn)
			VALUES (NEWID(),@jobId, NULL, @nCredId,@usn )
			IF(@@ERROR =0) BEGIN PRINT 'Credentials for job ' + isnull(@jobName, N'') + 'was succesfully moved' END
		END
	ELSE
		BEGIN
		 SELECT @nCredId = c.id FROM [dbo].[Credentials] as c WHERE c.user_name=@user_name AND c.password = @pass
		 exec [dbo].[IncrementUsn] @usn OUTPUT
		 IF NOT EXISTS(SELECT * FROM [dbo].[JobCredentials] as jc WHERE jc.job_id =@jobId)
		 BEGIN
		 INSERT INTO [dbo].[JobCredentials](id, job_id, object_id, credentials_id, usn)
			VALUES (NEWID(),@jobId, NULL, @nCredId, @usn )
			IF(@@ERROR =0) BEGIN PRINT 'Credentials for job ' + isnull(@jobName, N'') + 'was succesfully moved' END
		 END
		END
	END
	SET @user_name = NULL
    SET @pass = NULL	
	FETCH NEXT FROM job_curs INTO @jobId, @jobName, @vss_options
	END 
	CLOSE job_curs;
    DEALLOCATE job_curs;
    IF(@@ERROR =0) BEGIN PRINT 'Job credentials transform successfully finished' END
    
    --Objects in Jobs transform
    PRINT 'Objects in jobs credentials transform started'
	DECLARE job_curs CURSOR FOR
	SELECT oj.job_id, jb.name, oj.id, o.object_name as objectName, oj.vss_options FROM [dbo].ObjectsInJobs as oj 
	LEFT OUTER JOIN [dbo].BJobs jb ON jb.id = oj.job_id 
	LEFT OUTER JOIN [dbo].BObjects o ON o.id = oj.object_id
	
	OPEN job_curs
	FETCH NEXT FROM job_curs INTO @jobId, @jobName, @objectId, @object_name, @vss_options
	WHILE @@FETCH_STATUS = 0
	BEGIN
	SELECT @user_name = User_Name.item.value('UserName[1]','nvarchar(max)'), @pass = User_Name.item.value('Password[1]','nvarchar(max)') 
	FROM @vss_options.nodes('/CVssOptions/Credentials') User_Name(item)
	IF @user_name IS NOT NULL AND @user_name<>N''  AND @pass IS NOT NULL 
	BEGIN
	IF NOT EXISTS (SELECT * FROM [dbo].[Credentials] as c WHERE c.user_name=@user_name AND c.password = @pass)
		BEGIN
			SET @nCredId = NEWID()
	        exec [dbo].[IncrementUsn] @usn OUTPUT
			INSERT INTO [dbo].[Credentials](id, user_name, password, usn, description) 
			VALUES (@nCredId, @user_name, @pass, @usn, N'Set by automated upgrade. Credentials for object ' + isnull(@object_name ,N'') + ' in job: ' +  isnull(@jobName,N''))
			exec [dbo].[IncrementUsn] @usn OUTPUT 
			INSERT INTO [dbo].[JobCredentials](id, job_id,object_id,credentials_id,usn)
			VALUES (NEWID(),@jobId, @objectId, @nCredId,@usn )
			IF(@@ERROR =0) BEGIN PRINT N'Credentials for object: ' +isnull(@object_name ,N'') +  N' in job ' + @jobName + N' was succesfully moved'  END
		END
	ELSE
		BEGIN
		 SELECT @nCredId = c.id FROM [dbo].[Credentials] as c WHERE c.user_name=@user_name AND c.password = @pass
		 exec [dbo].[IncrementUsn] @usn OUTPUT
		 IF NOT EXISTS(SELECT * FROM [dbo].[JobCredentials] as jc WHERE jc.job_id =@jobId AND jc.object_id = @objectId)
		 BEGIN
		 INSERT INTO [dbo].[JobCredentials](id, job_id, object_id, credentials_id, usn)
			VALUES (NEWID(),@jobId, @objectId, @nCredId, @usn )
			IF(@@ERROR =0) BEGIN PRINT N'Credentials for object: ' +isnull(@object_name ,N'') +  N' in job ' + @jobName + N' was succesfully moved'  END
		 END	
		END
	END
	SET @user_name = NULL
    SET @pass = NULL	
	FETCH NEXT FROM job_curs INTO @jobId, @jobName, @objectId, @object_name, @vss_options
	END 
	CLOSE job_curs;
    DEALLOCATE job_curs;
      
    IF(@@ERROR =0) BEGIN PRINT 'Objects in jobs credentials transform successfully finished' END
 
    IF  NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'JobVssCredentials')
	BEGIN
		DECLARE @result INT
		exec @result = sp_rename 'JobCredentials', 'JobVssCredentials' 
		IF(@result=0)BEGIN PRINT 'Table JobCredentials was successfully renamed to JobVssCredentials' END
	END
END
END

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 857 AND current_version < 863)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'source_storage')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [source_storage] int DEFAULT 0 not null
		print 'New column {source_storage} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 863; END
END	
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 863)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'source_proxy')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [source_proxy] int DEFAULT 0 not null
		print 'New column {source_proxy} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 864; END
END	
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 864)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'source_network')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [source_network] int DEFAULT 0 not null
		print 'New column {source_network} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 865; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 865)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'target_storage')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [target_storage] int DEFAULT 0 not null
		print 'New column {target_storage} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 866; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 865)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'target_proxy')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [target_proxy] int DEFAULT 0 not null
		print 'New column {target_proxy} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 866; END
END	
GO
  
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 866)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'target_network')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [target_network] int DEFAULT 0 not null
		print 'New column {target_network} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 867; END
END	
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 867 AND current_version < 869)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessionsProgress]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.BackupTaskSessionsProgress](
			[session_id] [uniqueidentifier] NOT NULL,
			[date] [datetime] NOT NULL,
			[transfered] [bigint] DEFAULT 0 NOT NULL,
			[processed] [bigint] DEFAULT 0 NOT NULL
		) 
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 869; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 869)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 870; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 870 AND current_version < 873)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'backed_up_size')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD [backed_up_size] bigint DEFAULT 0 not null
		print 'New column {backed_up_size} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'		
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 873; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 873 AND current_version < 875)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'target_proxy')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [target_proxy] int DEFAULT 0 not null
		print 'New column {target_proxy} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 875; END
END
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 875 AND current_version < 879)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 879; END
END	
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 879)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 880; END
END	
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 880 AND current_version < 886)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LinkedBackupRepositories]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[LinkedBackupRepositories](
			[id] [uniqueidentifier] NOT NULL,
			[job_id] [uniqueidentifier] NOT NULL,
			[linked_backup_repository_id] [uniqueidentifier] NOT NULL,
			[usn] [bigint] NOT NULL,
		 CONSTRAINT [PK_LinkedBackupRepositories] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [jobId] ON [dbo].[LinkedBackupRepositories]
		(
			[job_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		ALTER TABLE [dbo].[LinkedBackupRepositories] ADD  CONSTRAINT [DF_LinkedBackupRepositories_id]  DEFAULT (newid()) FOR [id]

		ALTER TABLE [dbo].[LinkedBackupRepositories] ADD  CONSTRAINT [DF_LinkedBackupRepositories_usn]  DEFAULT ((0)) FOR [usn]

		ALTER TABLE [dbo].[LinkedBackupRepositories]  WITH CHECK ADD  CONSTRAINT [FK_LinkedBackupRepositories_BackupRepositories] FOREIGN KEY([linked_backup_repository_id])
		REFERENCES [dbo].[BackupRepositories] ([id])
		ON UPDATE CASCADE
		ON DELETE CASCADE

		ALTER TABLE [dbo].[LinkedBackupRepositories] CHECK CONSTRAINT [FK_LinkedBackupRepositories_BackupRepositories]

		ALTER TABLE [dbo].[LinkedBackupRepositories]  WITH CHECK ADD  CONSTRAINT [FK_LinkedBackupRepositories_BJobs] FOREIGN KEY([job_id])
		REFERENCES [dbo].[BJobs] ([id])
		ON UPDATE CASCADE
		ON DELETE CASCADE

		ALTER TABLE [dbo].[LinkedBackupRepositories] CHECK CONSTRAINT [FK_LinkedBackupRepositories_BJobs]

		exec sp_executesql @stat = N'CREATE TRIGGER [dbo].[delete_LinkedBackupRepositories]
   ON [dbo].[LinkedBackupRepositories]
   FOR DELETE
AS 
BEGIN
	SET NOCOUNT ON;

	DECLARE @id uniqueidentifier
	SELECT @id = id FROM deleted
	IF NOT @id IS NULL exec dbo.TrackChange ''LinkedBackupRepositories'', @id, 2
END'

		exec sp_executesql @stat = N'CREATE TRIGGER [dbo].[insert_LinkedBackupRepositories]
   ON [dbo].[LinkedBackupRepositories]
   FOR INSERT
AS 
BEGIN
	SET NOCOUNT ON;

	DECLARE @id uniqueidentifier
	SELECT @id = id FROM inserted
	IF NOT @id IS NULL exec dbo.TrackChange ''LinkedBackupRepositories'', @id, 0
END'

		exec sp_executesql @stat = N'CREATE TRIGGER [dbo].[update_LinkedBackupRepositories]
   ON [dbo].[LinkedBackupRepositories]
   FOR UPDATE
AS 
BEGIN
	SET NOCOUNT ON;

	DECLARE @id uniqueidentifier
	SELECT @id = id FROM inserted
	IF NOT @id IS NULL exec dbo.TrackChange ''LinkedBackupRepositories'', @id, 1
END'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 886; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 886)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'description')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [description] nvarchar(max) NULL
		print 'New column {description} has been successfully added to [dbo].[Tape.tape_mediums] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 887; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 887)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'media_set_name')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [media_set_name] nvarchar(max) NULL
		print 'New column {media_set_name} has been successfully added to [dbo].[Tape.tape_mediums] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 888; END
END	
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 888)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'oib_display_name')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.RestoreJobSessions] ADD [oib_display_name] nvarchar(256) NOT NULL DEFAULT ''
		print 'New column {oib_display_name} has been successfully added to [dbo].[Backup.Model.RestoreJobSessions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 889; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 889)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'oib_creation_time')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.RestoreJobSessions] ADD [oib_creation_time] datetime NOT NULL DEFAULT ''--1900-01-01 00:00:00.000
		print 'New column {oib_creation_time} has been successfully added to [dbo].[Backup.Model.RestoreJobSessions] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 890; END
END	
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 890 AND current_version < 891)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 891; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 891)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'state')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [state] int NOT NULL DEFAULT 0
		print 'New column {state} has been successfully added to [dbo].[Backup.Model.Storages] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 892; END
END	
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 892)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.changers]') AND [name] = 'first_ieport_number')
	BEGIN
		ALTER TABLE [dbo].[Tape.changers] ADD [first_ieport_number] int NOT NULL DEFAULT 0
		print 'New column {first_ieport_number} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [ieport_count] int NOT NULL DEFAULT 0
		print 'New column {ieport_count} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [first_cleaner_slot_number] int NOT NULL DEFAULT 0
		print 'New column {first_cleaner_slot_number} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [cleaner_slot_count] int NOT NULL DEFAULT 0
		print 'New column {cleaner_slot_count} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [magazine_size] int NOT NULL DEFAULT 0
		print 'New column {magazine_size} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [features0] bigint NOT NULL DEFAULT 0
		print 'New column {features0} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [features1] bigint NOT NULL DEFAULT 0
		print 'New column {features1} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [move_from_slot] tinyint NOT NULL DEFAULT 0
		print 'New column {move_from_slot} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [move_from_ieport] tinyint NOT NULL DEFAULT 0
		print 'New column {move_from_ieport} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [move_from_drive] tinyint NOT NULL DEFAULT 0
		print 'New column {move_from_drive} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [exchange_from_slot] tinyint NOT NULL DEFAULT 0
		print 'New column {exchange_from_slot} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [exchange_from_ieport] tinyint NOT NULL DEFAULT 0
		print 'New column {exchange_from_ieport} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [exchange_from_drive] tinyint NOT NULL DEFAULT 0
		print 'New column {exchange_from_drive} has been successfully added to [dbo].[Tape.changers] table'		

		ALTER TABLE [dbo].[Tape.changers] ADD [lock_unlock_capabilities] tinyint NOT NULL DEFAULT 0
		print 'New column {lock_unlock_capabilities} has been successfully added to [dbo].[Tape.changers] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 893; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 893 AND current_version < 894)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 894; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 894)
BEGIN

	DECLARE @usn BIGINT
	EXEC [dbo].[IncrementUsn] @usn OUTPUT	
	INSERT INTO [dbo].[Backup.Model.Session.Filters] ([id],[name],[data],[usn])
	VALUES('2D31AD69-154D-4152-8B7A-6F2BAF950324',
		   'Backup Copy',
		   '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 51)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
		   ,@usn)

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 895; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 895 AND current_version < 900)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Hierarchy.VmsRecursiveInclusion]') AND [name] = 'vm_real_name')
	BEGIN
		ALTER TABLE [dbo].[Hierarchy.VmsRecursiveInclusion] ADD [vm_real_name] nvarchar(256) NOT NULL DEFAULT N''
		print 'New column {vm_real_name} has been successfully added to [dbo].[Hierarchy.VmsRecursiveInclusion] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 900; END
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 900 AND current_version < 906)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 906; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 906)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[VmssVms] ') AND [name] = 'vm_ref')
	BEGIN
		ALTER TABLE [dbo].[VmssVms] ADD [vm_ref] [nvarchar](400) DEFAULT NULL
		print 'New column {vm_ref} has been successfully added to [dbo].[VmssVms] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 907; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 907 AND current_version < 913)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 913; END
END
GO
-- Processing speed for WAN
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 913)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 914; END
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 914 AND current_version < 918)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 918; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 918)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.jobs]') AND [name] = 'full_mediapool_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.jobs] ADD [full_mediapool_id] [uniqueidentifier] not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {full_mediapool_id} has been successfully added to [dbo].[Tape.jobs] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.jobs]') AND [name] = 'incremental_mediapool_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.jobs] ADD [incremental_mediapool_id] [uniqueidentifier] not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {incremental_mediapool_id} has been successfully added to [dbo].[Tape.jobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 919; END
END
GO
-- Adding default Linux FLR appliance credentials
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 919)
BEGIN
	IF NOT EXISTS (SELECT * FROM [dbo].[Credentials] WHERE id = '70275B03-E805-49E1-9535-1867C62371E2')

	BEGIN
		exec sp_executesql @stat = N'
			DECLARE @usn BIGINT
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
		
			INSERT INTO [dbo].[Credentials] VALUES (''70275B03-E805-49E1-9535-1867C62371E2'', N''root'',N'''', @usn, N''FLR helper appliance credentials'')
			print ''default Linux FLR appliance credentials added to [dbo].[Credentials] table'''
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 920; END
END
GO

-- Adding work details for restore task sessions
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 920)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreTaskSessions]') AND [name] = 'work_details')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.RestoreTaskSessions] ADD [work_details] [xml] NOT NULL DEFAULT N'<?xml version="1.0" encoding="utf-16"?>'
		print 'New column {work_details} has been successfully added to [dbo].[Backup.Model.RestoreTaskSessions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 921; END
END
GO
--Adding licenses tiers
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 921  AND current_version < 925)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND [name] = 'lic_tier')
	BEGIN
		ALTER TABLE [dbo].[LicensedHosts] ADD [lic_tier] [int] NOT NULL DEFAULT 0
		print 'New column {lic_tier} has been successfully added to [dbo].[LicensedHosts] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 925; END
END
GO

------------------------------------------------------------------
-- IF ANOTHER SCRIPTS WAS UPDATED:
-- 1. UNCOMMENT AND INCREMENT VERSION
-- 2. MAKE SURE THAT THE SCRIPT VERSIONS EQUALS TO THE VERSIONS OF THE CONFIG FILE.
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 925 AND current_version < 928)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 928; END
END
GO

--Adding failover plan tables
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 928)
BEGIN
	IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'FailoverPlans'))
	BEGIN
		CREATE TABLE [dbo].[FailoverPlans](
			[id] [uniqueidentifier] NOT NULL,
			[Name] [nvarchar](max) NOT NULL,
			[Description] [nvarchar](max) NULL,
			[Delay] [int] NOT NULL,
			[State] [int] NOT NULL,
			[CreationTime] [datetime] NOT NULL,
			[SendSNMP] [bit] NOT NULL,
			[SendEmail] [bit] NOT NULL,
			[Platform] [int] NOT NULL,
			[NotificationEmails] [nvarchar](max) NULL,
			[Count] [int] NOT NULL,
		 CONSTRAINT [PK_FailoverPlans] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
		PRINT N'dbo.FailoverPlans table successfully added.'
	END
	IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'OibsInFailover'))
	BEGIN
		CREATE TABLE [dbo].[OibsInFailover](
		[id] [uniqueidentifier] NOT NULL,
		[PlanId] [uniqueidentifier] NOT NULL,
		[OibId] [uniqueidentifier] NOT NULL,
		[OrderNo] [int] NOT NULL,
	 CONSTRAINT [PK_OibsInFailover] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	PRINT N'dbo.FailoverPlans table successfully added.'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 929; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 929)
BEGIN
IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[FailoverPlans]') AND [name] = 'Delay')
	BEGIN
		ALTER TABLE [dbo].[FailoverPlans]
		DROP COLUMN [Delay]
		print 'Column {Delay} has been successfully removed to [dbo].[FailoverPlans] table'	
	END	
	
IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[OibsInFailover]') AND [name] = 'Delay')
	BEGIN
		ALTER TABLE [dbo].[OibsInFailover] ADD [Delay] int not null
		print 'New column {Delay} has been successfully added to [dbo].[OibsInFailover] table'		
	END	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 930; END
END
GO
--Stored proc for OibinFailover 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 930 AND current_version < 933)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 933; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 933 AND current_version < 934)
BEGIN
BEGIN
		ALTER TABLE [dbo].[FailoverPlans] ADD [usn] bigint not null
		print 'New column {usn} has been successfully added to [dbo].[FailoverPlans] table'		
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 934; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 935)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JobSourceRepositories]') AND type in (N'U'))
	begin
		CREATE TABLE [dbo].[JobSourceRepositories](
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[job_id] [uniqueidentifier] NOT NULL,
			[repository_id] [uniqueidentifier] NOT NULL,
			[usn] [bigint] NOT NULL DEFAULT 0,
		 CONSTRAINT [PK_JobSourceRep] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	end

    exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[JobSourceRepositories]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''JobSourceRepositories''
	end
	'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 935; END
END

GO

-- Adding source_wan and target_wan fields for bottleneck
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 935 AND current_version < 937)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'source_wan')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD [source_wan] int DEFAULT -1 not null
		print 'New column {source_wan} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'target_wan')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD [target_wan] int DEFAULT -1 not null
		print 'New column {target_wan} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'source_wan')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [source_wan] int DEFAULT -1 not null
		print 'New column {source_wan} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'target_wan')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [target_wan] int DEFAULT -1 not null
		print 'New column {target_wan} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 937; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 937 AND current_version < 942)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 942; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 942 AND current_version < 943)
BEGIN
IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[OibsInFailover]') AND [name] = 'ObjectId')
	BEGIN
		DECLARE @result INT
		EXEC @result = sp_rename '[dbo].[OibsInFailover].[OibId]', 'ObjectId', 'COLUMN'
		IF(@result=0)
		BEGIN 
			PRINT 'Column [OibsInFailover].[OibId] was successfully renamed to ObjectId' 
		END
	END
IF  NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'ObjectsInFailover')
	BEGIN
		exec @result = sp_rename 'OibsInFailover', 'ObjectsInFailover' 
		IF(@result=0)
		BEGIN 
			PRINT 'Table [OibsInFailover] was successfully renamed to [ObjectsInFailover]' 
		END
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 943; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 943 AND current_version < 944)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'last_compact_time')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [last_compact_time] datetime NULL
		print 'New column {last_compact_time} has been successfully added to [dbo].[Backup.Model.Storages] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 944; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 944 AND current_version < 945)
BEGIN
	ALTER TABLE [Backup.Model.Storages] ALTER COLUMN last_compact_time datetime NULL

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 945; END
END		
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 945 AND current_version < 946)
BEGIN
	ALTER TABLE [LicensedHosts] ALTER COLUMN lic_tier int NULL

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 946; END
END		
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 946 AND current_version < 949)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 949; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 949)
BEGIN

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobVssCredentials]') AND [name] = 'object_id')
	BEGIN
		exec sp_rename '[dbo].[JobVssCredentials].[object_id]', 'oij_id', 'COLUMN'
		PRINT 'Column [JobVssCredentials].[object_id] has been successfully rename to [dbo].[JobVssCredentials].[oij_id]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 950; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 950 AND current_version < 951)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 951; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 951 AND current_version < 952)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[FailoverPlans]'))
	begin
		exec [dbo].[AddTrackChangeTriggers] N'FailoverPlans'
	end
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 952; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 952)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'total_used_size')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD [total_used_size] bigint DEFAULT 0 not null
		print 'New column {total_used_size} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'total_used_size')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [total_used_size] bigint DEFAULT 0 not null
		print 'New column {total_used_size} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 953; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 953 AND current_version < 957)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'cleaner')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [cleaner] BIT DEFAULT 0 NOT NULL
		print 'New column {cleaner} has been successfully added to [dbo].[Tape.tape_mediums] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 957; END
END
GO
  

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 957 AND current_version < 965)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') AND [name] = 'original_oib_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [original_oib_id] uniqueidentifier NOT NULL DEFAULT '00000000-0000-0000-0000-000000000000'
		print 'New column {original_oib_id} has been successfully added to [dbo].[Backup.Model.OIBs] table'		
	END

 	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 965; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 965 AND current_version < 967)
BEGIN

	UPDATE [dbo].[Backup.Model.OIBs]
		SET [dbo].[Backup.Model.OIBs].[original_oib_id] = [dbo].[Backup.Model.OIBs].[id]

 	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 967; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 967)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	INSERT INTO [dbo].[Backup.Model.Session.Filters] ([id],[name],[data],[usn])
	VALUES('BE43B98F-F888-4150-BF88-372AF0F334AD',
		   'FailoverPlan',
		   '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 202 OR [job_type] = 203)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
		   ,@usn)
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 968; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 968)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Credentials]') AND [name] = 'visible')
	BEGIN
		ALTER TABLE [dbo].[Credentials] ADD [visible] bit NOT NULL DEFAULT 1
		print 'New column {visible} has been successfully added to [dbo].[Credentials] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 969; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 969 AND current_version < 972)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'format_logical_address_size')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [format_logical_address_size] int NOT NULL DEFAULT 0
		print 'New column {format_logical_address_size} has been successfully added to [dbo].[Tape.tape_mediums] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 972; END
END
GO

-- For StoredProcUpdate
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 972 AND current_version < 974)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 974; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 974)
BEGIN

	ALTER TABLE [dbo].[VmssVms] ALTER COLUMN [xml_config] [xml]
	print 'Change column {xml_config} type to {xml} on [dbo].[VmssVms] table'

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[VmssVms]') AND [name] = 'restore_platform')
	BEGIN
		ALTER TABLE [dbo].[VmssVms] ADD [restore_platform] int NOT NULL DEFAULT 0
		print 'New column {restore_platform} has been successfully added to [dbo].[VmssVms] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 975; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 975)
BEGIN

	UPDATE [dbo].[VmssVms]
	SET [dbo].[VmssVms].[restore_platform] = (
		SELECT o.[platform] 
		FROM 
			[dbo].[BObjects] o
		INNER JOIN [Backup.Model.OIBs] oibs 
			ON oibs.[object_id] = o.[id]
		WHERE oibs.id = [dbo].[VmssVms].[oib])

	print 'Updating [dbo].[VmssVms].[restore_platform] column'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 976; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 976 AND current_version < 978)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 978; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 978 AND current_version < 979)
BEGIN
	IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Tape.backup_sets_backup_sets]') AND parent_object_id = OBJECT_ID(N'[dbo].[Tape.backup_sets]'))
	BEGIN
		ALTER TABLE [Tape.backup_sets] DROP CONSTRAINT [FK_Tape.backup_sets_backup_sets]

		PRINT 'Old foreign key [FK_Tape.backup_sets_backup_sets] has been successfully dropped in [Tape.backup_sets]'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'pending')
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [pending] bit NOT NULL DEFAULT 0
		print 'New column {pending} has been successfully added to [dbo].[Tape.backup_sets] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 979; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 979 AND current_version < 985)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 985; END
END
GO


------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 985 AND current_version < 986)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.JobSessions]') AND name = N'IX_Backup.Model.JobSessions_orig_session_id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Backup.Model.JobSessions_orig_session_id] ON [dbo].[Backup.Model.JobSessions] 
		( 
		[orig_session_id] ASC 
		) 
		INCLUDE ( [job_type]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] 
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 986; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 986 AND current_version < 987)
BEGIN
exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_media_pools] 
   ON  [dbo].[Tape.media_pools] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- update deleted_usns
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''media_pools'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
	
	-- move tapes to free pool
	
	UPDATE 
		[Tape.tape_mediums] 
	SET 
		media_pool_id = (SELECT id FROM [Tape.media_pools] WHERE [type] = 1 AND library_id = d.library_id)
	FROM 
		[Tape.tape_mediums] t INNER JOIN deleted d ON t.media_pool_id = d.id
END'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 987; END
END
GO


------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 987 )
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[ProxyAgents]') and [name] = 'pid')
	BEGIN
		ALTER TABLE [dbo].[ProxyAgents] add pid [int] NOT NULL DEFAULT 0
		PRINT 'New column {pid} has been successfully added to dbo.ProxyAgents'
    		
	END
	    
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 988; END	
END		
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 988 AND current_version < 990)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 990; END
END
GO

-----------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 990 )
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Backup.Model.JobSessions]') and [name] = 'pid')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.JobSessions] add pid [int] NOT NULL DEFAULT 0
		PRINT 'New column {pid} has been successfully added to dbo.[Backup.Model.JobSessions]'
    		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 991; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 991 AND current_version < 1005)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1005; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1005 AND current_version < 1006)
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Volumes]') and [name] = 'max_hard_snapshots_count')
	BEGIN
		ALTER TABLE [dbo].[Volumes] add max_hard_snapshots_count [int] NOT NULL DEFAULT 0
		PRINT 'New column {max_hard_snapshots_count} has been successfully added to dbo.[Volumes]'
    		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1006 END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1006 AND current_version < 1007)
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[SmbFileShares]') and [name] = 'max_snapshots_count')
	BEGIN
		ALTER TABLE [dbo].[SmbFileShares] add max_snapshots_count [int] NOT NULL DEFAULT 0
		PRINT 'New column {max_snapshots_count} has been successfully added to dbo.[SmbFileShares]'
    		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1007 END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1007 AND current_version < 1008)
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[PhysHost_Volume]') and [name] = 'max_soft_snapshots_count')
	BEGIN
		ALTER TABLE [dbo].[PhysHost_Volume] add max_soft_snapshots_count [int] NOT NULL DEFAULT 0
		PRINT 'New column {max_soft_snapshots_count} has been successfully added to dbo.[PhysHost_Volume]'
    		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1008 END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1008 AND current_version < 1010)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1010; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1010)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.StorageProfiles]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.TrackedActions.StorageProfiles] (
		[id] [uniqueidentifier] primary key NOT NULL,
		[vcd_host_id] [uniqueidentifier] NOT NULL,	
		[org_vdc] nvarchar(2000) NOT NULL,	
		[data] xml NOT NULL,
		)
	END
		
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.StorageProfiles.Leases]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.TrackedActions.StorageProfiles.Leases] (
		[action_id] [uniqueidentifier] NOT NULL,
		[lease_id] [uniqueidentifier] NOT NULL		
		)
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1011 END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1011)
BEGIN	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.StorageProfiles.Leases]') AND name = N'IX_Backup.TrackedActions.StorageProfiles.Leases_ActionId')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Backup.TrackedActions.StorageProfiles.Leases_ActionId] ON [dbo].[Backup.TrackedActions.StorageProfiles.Leases]
		(
			[action_id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.StorageProfiles.Leases]') AND name = N'IX_Backup.TrackedActions.StorageProfiles.Leases_LeaseId')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Backup.TrackedActions.StorageProfiles.Leases_LeaseId] ON [dbo].[Backup.TrackedActions.StorageProfiles.Leases]
		(
			[lease_id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1012 END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1012 AND current_version < 1013)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1013; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 1014)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[SbVerificationRules]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''SbVerificationRules''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1014; END	
END
GO

-------------------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1014)
BEGIN

	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[BackupRepositories]') and [name] = 'unique_id')
	BEGIN
		ALTER TABLE [dbo].[BackupRepositories] ADD unique_id uniqueidentifier NOT NULL DEFAULT (newid())
		PRINT 'New column {unique_id} has been successfully added to dbo.BackupRepositories' 
	END
	
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[BackupProxies]') and [name] = 'unique_id')
	BEGIN
		ALTER TABLE [dbo].[BackupProxies] ADD unique_id uniqueidentifier NOT NULL DEFAULT (newid())
		PRINT 'New column {unique_id} has been successfully added to dbo.BackupProxies' 
	END
	    
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1015; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1015 AND current_version < 1016)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1016; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1016 AND current_version < 1017)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.media_families]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.media_families](
			[id] [int] NOT NULL,
			[name] [nvarchar](max) NOT NULL,
			[format_logical_address_size] [int] NOT NULL,
		 CONSTRAINT [PK_Tape.media_families] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		exec sp_executesql N'
		INSERT INTO [Tape.media_families] (id, name, format_logical_address_size)
		SELECT DISTINCT media_family_id, media_set_name, format_logical_address_size
		FROM [Tape.tape_mediums]
		WHERE media_family_id IS NOT NULL'

		ALTER TABLE [dbo].[Tape.tape_mediums]  WITH CHECK ADD  CONSTRAINT [FK_Tape.tape_mediums_Tape.media_families] FOREIGN KEY([media_family_id])
		REFERENCES [dbo].[Tape.media_families] ([id])

		ALTER TABLE [dbo].[Tape.tape_mediums] CHECK CONSTRAINT [FK_Tape.tape_mediums_Tape.media_families]
		
		print 'New table [dbo].[Tape.media_families] has been successfully created'					   	
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and [name] = N'media_set_name')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] DROP COLUMN [media_set_name]
		PRINT 'Column [media_set_name] has been successfully droppped in [Tape.tape_mediums]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and [name] = N'format_logical_address_size')
	BEGIN
		DECLARE @command nvarchar(MAX)

		SELECT @command = 'ALTER TABLE [Tape.tape_mediums] DROP CONSTRAINT [' + d.name + ']'
		FROM sys.tables t
		INNER JOIN sys.default_constraints d ON d.parent_object_id = t.object_id  
		INNER JOIN sys.columns c ON c.object_id = t.object_id AND c.column_id = d.parent_column_id
		WHERE t.name = 'Tape.tape_mediums' AND c.name = 'format_logical_address_size'

		exec sp_executesql @command

		ALTER TABLE [dbo].[Tape.tape_mediums] DROP COLUMN [format_logical_address_size]
		PRINT 'Column [format_logical_address_size] has been successfully droppped in [Tape.tape_mediums]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1017; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1017 AND current_version < 1018)
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = 'media_sequence_number')
	BEGIN
		ALTER TABLE [dbo].[Tape.directory_versions] ADD [media_sequence_number] int NOT NULL DEFAULT 0
		PRINT 'New column {media_sequence_number} has been successfully added to dbo.[Tape.directory_versions]'
	END

	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = 'media_sequence_number')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] ADD [media_sequence_number] int NOT NULL DEFAULT 0
		PRINT 'New column {media_sequence_number} has been successfully added to dbo.[Tape.file_parts]'
	END

	exec sp_executesql N'
	UPDATE [Tape.file_parts] 
	SET [media_sequence_number] = tm.[media_sequence_number]
	FROM [Tape.file_parts] fp 
	INNER JOIN [Tape.tape_mediums] tm ON fp.tape_medium_id = tm.id'

	exec sp_executesql N'
	UPDATE [Tape.directory_versions] 
	SET [media_sequence_number] = tm.[media_sequence_number]
	FROM [Tape.directory_versions] dv
	INNER JOIN [Tape.tape_mediums] tm ON dv.tape_medium_id = tm.id'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1018; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1018 AND current_version < 1019)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.directory_versions]') and [name] = N'tape_medium_id')
	BEGIN
		DROP INDEX [tape_medium_id] ON [dbo].[Tape.directory_versions] 
		ALTER TABLE [dbo].[Tape.directory_versions] DROP CONSTRAINT [PK_Tape.directory_versions]
		ALTER TABLE [dbo].[Tape.directory_versions] DROP COLUMN [tape_medium_id]
		PRINT 'Column [tape_medium_id] has been successfully droppped in [Tape.directory_versions]'

		ALTER TABLE [dbo].[Tape.directory_versions] ADD  CONSTRAINT [PK_Tape.directory_versions] PRIMARY KEY CLUSTERED 
		(
			[directory_id] ASC,
			[backup_set_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') and [name] = N'tape_medium_id')
	BEGIN
		DROP INDEX [tape_medium_id] ON [dbo].[Tape.file_parts]
		ALTER TABLE [dbo].[Tape.file_parts] DROP CONSTRAINT [PK_Tape.file_parts]
		ALTER TABLE [dbo].[Tape.file_parts] DROP CONSTRAINT [FK_Tape.file_parts_tape_mediums]
		ALTER TABLE [dbo].[Tape.file_parts] DROP COLUMN [tape_medium_id]
		PRINT 'Column [tape_medium_id] has been successfully droppped in [Tape.file_parts]'

		ALTER TABLE [dbo].[Tape.file_parts] ADD  CONSTRAINT [PK_Tape.file_parts] PRIMARY KEY CLUSTERED 
		(
			[file_id] ASC,
			[backup_set_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	exec sp_executesql @stat = N'
	ALTER TRIGGER [dbo].[Tape.after_insert_file_parts]
	   ON [dbo].[Tape.file_parts]
	   AFTER INSERT
	AS 
	BEGIN
		SET NOCOUNT ON;
		UPDATE 
			[Tape.tape_mediums] 
		SET 
			last_write_time = GETDATE() 
		WHERE 
			id = 
			(
				SELECT tm.id 
				FROM INSERTED fp
				INNER JOIN [Tape.backup_sets] bs ON fp.backup_set_id = bs.id
				INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
			)
	END'

	exec sp_executesql @stat = N'
	ALTER TRIGGER [dbo].[Tape.after_insert_directory_versions]
	   ON [dbo].[Tape.directory_versions]
	   AFTER INSERT
	AS 
	BEGIN
		SET NOCOUNT ON;
		UPDATE 
			[Tape.tape_mediums] 
		SET 
			last_write_time = GETDATE() 
		WHERE 
			id = 
			(
				SELECT tm.id 
				FROM INSERTED dv
				INNER JOIN [Tape.backup_sets] bs ON dv.backup_set_id = bs.id
				INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND dv.media_sequence_number = tm.media_sequence_number
			)
	END'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1019; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1019 AND current_version < 1021)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1021; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1021 AND current_version < 1022)
BEGIN
	ALTER TABLE [dbo].[Tape.directory_versions] DROP CONSTRAINT [PK_Tape.directory_versions]
	ALTER TABLE [dbo].[Tape.directory_versions] ADD  CONSTRAINT [PK_Tape.directory_versions] PRIMARY KEY CLUSTERED 
	(
		[directory_id] ASC,
		[backup_set_id] ASC,
		[media_sequence_number] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	ALTER TABLE [dbo].[Tape.file_parts] DROP CONSTRAINT [PK_Tape.file_parts]
	ALTER TABLE [dbo].[Tape.file_parts] ADD  CONSTRAINT [PK_Tape.file_parts] PRIMARY KEY CLUSTERED 
	(
		[file_id] ASC,
		[backup_set_id] ASC,
		[media_sequence_number] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1022; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1022 AND current_version < 1026)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1026; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1026 AND current_version < 1027)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = N'has_sharepoint')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [has_sharepoint] bit NOT NULL DEFAULT 0
			PRINT 'New column {has_sharepoint} has been successfully added to dbo.[Backup.Model.OIBs]'
		END
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = N'has_sql')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [has_sql] bit NOT NULL DEFAULT 0
			PRINT 'New column {has_sql} has been successfully added to dbo.[Backup.Model.OIBs]'
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1027; END
	END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1027 AND current_version < 1031)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1031; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1031 AND current_version < 1032)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Hosts]') and [name] = N'runtime_info')
	BEGIN
		ALTER TABLE dbo.Hosts ADD "runtime_info" xml null
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1032; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1032 AND current_version < 1034)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1034; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1034 AND current_version < 1035)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'gfs_period')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD gfs_period int NOT NULL DEFAULT 0
		print 'New column {gfs_period} has been successfully added to [dbo].[Backup.Model.Storages] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1035; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1035 AND current_version < 1038)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1038; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1038 AND current_version < 1039)
BEGIN
	DECLARE @xmlDoc xml
	DECLARE @text nvarchar(max)
	SET @xmlDoc = (SELECT [value]
	FROM [dbo].[Options]
	WHERE [id] = '91bb166b-e197-48f7-a430-7904e013b30b')

	SET @text = cast(@xmlDoc as nvarchar(max))
	SET @text = replace(@text, 'Job %JobName% completed: %JobResult%', '[%Time%][%JobResult%] %JobName% (%VmCount% VMs) %Issues%')
	SET @xmlDoc = cast(@text as xml)

	UPDATE dbo.Options SET value = @xmlDoc WHERE id = '91bb166b-e197-48f7-a430-7904e013b30b'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1039; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1039)
BEGIN

	DECLARE @retain_opt_id uniqueidentifier
	DECLARE @retain_opt xml
	DECLARE @retain_months int
	DECLARE @retain_weeks int
	DECLARE @retain_days int

	SET @retain_opt_id  ='326EE145-E5E9-40B6-9B2B-7CB8ACF93164'

	SET @retain_opt = (SELECT TOP(1) [value] FROM [dbo].[Options] WHERE [id] = @retain_opt_id)

	SET @retain_months = @retain_opt.query('CSessionKeep/Keep').value('.', 'int')

	IF @retain_months > 0
	BEGIN
		SET @retain_weeks = ROUND(@retain_months * 4.348, 0)
		SET @retain_days = @retain_weeks * 7

		SET @retain_opt.modify('
			replace value of (CSessionKeep/Keep[1]/text())[1]
			with sql:variable("@retain_days")
			')

		UPDATE [dbo].[Options] SET
			[value] = @retain_opt
		WHERE
			[id] = @retain_opt_id
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1040; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1040 AND current_version < 1047)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ProxyAgents]') AND [name] = 'lease_id')
	BEGIN
		ALTER TABLE [dbo].[ProxyAgents] ADD [lease_id] uniqueidentifier NOT NULL DEFAULT '00000000-0000-0000-0000-000000000000'
		print 'New column {lease_id} has been successfully added to [dbo].[ProxyAgents] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1047; END
END
GO

if exists (select * from [dbo].[Version] where current_version < 1054)
begin
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') and [name] = N'object_platform')
	begin
		alter table [dbo].[Backup.Model.BackupTaskSessions] add object_platform int
		print 'New column [object_platform] has been successfully added to [Backup.Model.BackupTaskSessions]'
	end
end
go


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1047 AND current_version < 1062)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1062; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1062)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportInfos]') AND type in (N'U'))
	BEGIN
	
		PRINT N'Creating [dbo].[Backup.Model.SanVolumeExportInfos] table'
	
		CREATE TABLE [dbo].[Backup.Model.SanVolumeExportInfos]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Backup_Model_SanVolumeExportInfos_id]  DEFAULT (newid()),
			[volume_id] [uniqueidentifier] NOT NULL,
			[server_iqn_or_wwn] [nvarchar](512) NOT NULL,
			[lun_id] [int] NOT NULL
		
			CONSTRAINT [PK_Backup_Model_SanVolumeExportInfos_id] PRIMARY KEY NONCLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1063; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1063)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') AND [name] = 'incomplete')
	BEGIN
		ALTER TABLE [dbo].[Tape.file_parts] ADD [incomplete] [bit] NULL
		print 'New column {incomplete} has been successfully added to [dbo].[Tape.file_parts] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1064; END
END
GO


------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1064 AND current_version < 1065)
BEGIN
	ALTER TABLE [dbo].[ItemRestoreAudits] ADD dest_host nvarchar(256) DEFAULT NULL NULL
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1065; END
END		
GO

----------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1065 AND current_version < 1066)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1066; END
END
GO
--Oibs view include has_sharepoint flag
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1066 AND current_version < 1068)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1068; END
END
GO

--726
---------------------------------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1068)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 24 OR [job_type] = 25 OR [job_type] = 26 OR [job_type] = 27 OR [job_type] = 28 OR [job_type] = 29 OR [job_type] = 32 OR [job_type] = 33)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = 'FC0B6A9D-F476-49DA-9B11-6A21879C71CA'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1069; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1069 AND current_version < 1071)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1071; END
END
GO


------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1071 AND current_version < 1072)
BEGIN
	ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD job_algorithm int DEFAULT 2 NOT NULL

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1072; END
END		
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1072 AND current_version < 1073)
BEGIN
	ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD session_algorithm int DEFAULT 2 NOT NULL
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1073; END
END		
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1073 AND current_version < 1074)
BEGIN
	EXEC sp_rename 'dbo.ItemRestoreAudits.restore_target', 'destination', 'COLUMN';
	ALTER TABLE [dbo].[ItemRestoreAudits] DROP COLUMN [restore_source]
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1074; END
END		
GO

------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1074 AND current_version < 1086)
BEGIN

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_libraries]
   ON  [dbo].[Tape.libraries]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] ''Tape.libraries'', @id, @usn
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_insert_libraries]
   ON [dbo].[Tape.libraries]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.libraries] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_libraries]
   ON  [dbo].[Tape.libraries] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.libraries] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_jobs]
   ON  [dbo].[Tape.jobs]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] ''Tape.jobs'', @id, @usn
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_insert_jobs]
   ON [dbo].[Tape.jobs]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.jobs] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_jobs]
   ON  [dbo].[Tape.jobs] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.jobs] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_tape_mediums]
   ON  [dbo].[Tape.tape_mediums]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] ''Tape.tape_mediums'', @id, @usn
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_insert_tape_mediums]
   ON [dbo].[Tape.tape_mediums]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.tape_mediums] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_tape_mediums]
   ON  [dbo].[Tape.tape_mediums] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- update usn
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.tape_mediums] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_tape_drives]
   ON  [dbo].[Tape.tape_drives]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT device_id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] ''Tape.tape_drives'', @id, @usn
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_insert_tape_drives]
   ON [dbo].[Tape.tape_drives]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT device_id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.tape_drives] SET usn = @usn WHERE @id = device_id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_tape_drives]
   ON  [dbo].[Tape.tape_drives] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT device_id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.tape_drives] SET usn = @usn WHERE @id = device_id
		
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_sessions] 
   ON  [dbo].[Tape.sessions] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] ''Tape.sessions'', @id, @usn
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_insert_sessions]
   ON [dbo].[Tape.sessions]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.sessions] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_sessions]
   ON  [dbo].[Tape.sessions] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.sessions] SET usn = @usn WHERE @id = id

		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_backup_sets] 
   ON [dbo].[Tape.backup_sets] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] ''Tape.backup_sets'', @id, @usn
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_insert_backup_sets]
   ON [dbo].[Tape.backup_sets]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.backup_sets] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_backup_sets]
   ON  [dbo].[Tape.backup_sets] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier

	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.backup_sets] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_media_pools] 
   ON  [dbo].[Tape.media_pools] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- update deleted_usns
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] ''Tape.media_pools'', @id, @usn
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
	
	-- move tapes to free pool
	
	UPDATE 
		[Tape.tape_mediums] 
	SET 
		media_pool_id = (SELECT id FROM [Tape.media_pools] WHERE [type] = 1 AND library_id = d.library_id)
	FROM 
		[Tape.tape_mediums] t INNER JOIN deleted d ON t.media_pool_id = d.id
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_insert_media_pools]
   ON [dbo].[Tape.media_pools]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE inserted_cursor CURSOR FOR SELECT id FROM inserted
	OPEN inserted_cursor
	
	FETCH NEXT FROM inserted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.media_pools] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM inserted_cursor INTO @id
	END
	
	CLOSE inserted_cursor
	DEALLOCATE inserted_cursor
END'

exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_update_media_pools]
   ON  [dbo].[Tape.media_pools] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.media_pools] SET usn = @usn WHERE @id = id
		
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1086; END
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1086 AND current_version < 1089)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1089; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1089 AND current_version < 1090)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'backup_total_size')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD backup_total_size bigint NOT NULL DEFAULT 0
		print 'New column {backup_total_size} successfully added to [dbo].[Backup.Model.BackupJobSessions] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1090; END
END	
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1090 AND current_version < 1093)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 24 OR [job_type] = 25 OR [job_type] = 26 OR [job_type] = 27 OR [job_type] = 28 OR [job_type] = 29 OR [job_type] = 32 OR [job_type] = 33 OR [job_type] = 34)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = 'FC0B6A9D-F476-49DA-9B11-6A21879C71CA'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1093; END
END
GO

--
-----------------------------------------------------
-- 7.0.0.521
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1093 AND current_version < 1094)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1094; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1094 AND current_version < 1095)
BEGIN
	ALTER TABLE [dbo].[Backup.Model.Plugins] ADD [ps_module_path] [nvarchar](max) NOT NULL DEFAULT ''
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1095; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1095 AND current_version < 1098)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 24 OR [job_type] = 25 OR [job_type] = 26 OR [job_type] = 27 OR [job_type] = 28 OR [job_type] = 29 OR [job_type] = 32 OR [job_type] = 33 OR [job_type] = 34 OR [job_type] = 35)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = 'FC0B6A9D-F476-49DA-9B11-6A21879C71CA'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1098; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1098 AND current_version < 1103)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1103; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1103)
BEGIN
	DECLARE @value nvarchar(10)
	SET @value = (SELECT CASE WHEN count(*) = 0 THEN 'True' ELSE 'False' END FROM [dbo].[BJobs] WHERE [type] = 0 OR [type] = 1)

	DECLARE @id uniqueidentifier
	SET @id = 'E452B26D-0A27-4910-8B6F-BD3C86FFDB74'

	IF EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = @id)
	BEGIN
		UPDATE
			[dbo].[Options]
		SET
			[value] = @value
		WHERE
			[id] = @id
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[Options]
			([id], [name], [value])
		VALUES
			(@id, 'ParallelProcessing', @value)
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1104; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1104 and current_version < 1111)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1111; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1111 and current_version < 1113)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'sub_type')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.RestoreJobSessions] ADD sub_type int NOT NULL DEFAULT 0
		print 'New column {sub_type} successfully added to [dbo].[Backup.Model.RestoreJobSessions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1113; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1113 and current_version < 1115)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JobVmDisksState]') AND type in (N'U'))
	BEGIN
	
		PRINT N'Creating [dbo].[JobVmDisksState] table'
	
		CREATE TABLE [dbo].[JobVmDisksState]
		(
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[job_object_state_id] [uniqueidentifier] NOT NULL,
			[disk_key] [nvarchar](512) NOT NULL,
			[aux_data] [xml] NOT NULL
		
			CONSTRAINT [PK_JobVmDisksState_id] PRIMARY KEY NONCLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]

		ALTER TABLE [dbo].[JobVmDisksState] WITH CHECK ADD CONSTRAINT [FK_JobVmDisksState.job_object_state_id] FOREIGN KEY([job_object_state_id])
		REFERENCES [dbo].[JobObjectsState] ([id])
		ON DELETE CASCADE
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1115; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1115)
BEGIN
	ALTER TABLE [dbo].[Hosts] ADD [host_unique_id] nvarchar(255) null
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1116; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1116)
BEGIN
	
	CREATE TABLE [dbo].[Events.JobSessionEvents](
			[id] [uniqueidentifier] NOT NULL,
			[event_type] [int] NOT NULL,
			[event_time] datetime NOT NULL DEFAULT(getdate()),
			[job_session_id] [uniqueidentifier] NOT NULL,
			[param0] nvarchar(255) NULL,
			[param1] nvarchar(255) NULL,
			[param2] nvarchar(255) NULL,
			[param3] nvarchar(255) NULL,
			[param4] nvarchar(255) NULL,
			[param5] nvarchar(255) NULL
			CONSTRAINT [PK_Events.JobSessionEvents] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

	CREATE TABLE [dbo].[Events.TaskSessionEvents](
			[id] [uniqueidentifier] NOT NULL,
			[event_type] [int] NOT NULL,
			[event_time] datetime NOT NULL DEFAULT(getdate()),
			[job_session_id] [uniqueidentifier] NOT NULL,
			[task_session_id] [uniqueidentifier] NOT NULL,
			[param0] nvarchar(255) NULL,
			[param1] nvarchar(255) NULL,
			[param2] nvarchar(255) NULL,
			[param3] nvarchar(255) NULL,
			[param4] nvarchar(255) NULL,
			[param5] nvarchar(255) NULL
			CONSTRAINT [PK_Events.TaskSessionEvents] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1117; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1117)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1118; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1118)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Events.JobSessionEvents]') AND [name] = 'event_time')
	BEGIN
		ALTER TABLE [dbo].[Events.JobSessionEvents] ADD [event_time] datetime not null DEFAULT(getdate())
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1119; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1119)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Events.TaskSessionEvents]') AND [name] = 'event_time')
	BEGIN
		ALTER TABLE [dbo].[Events.TaskSessionEvents] ADD [event_time] datetime not null DEFAULT(getdate())
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1120; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1120)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportInfos]') and [name] = N'protocol')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumeExportInfos] ADD protocol int
		PRINT 'New column [protocol] has been successfully added to [Backup.Model.SanVolumeExportInfos]'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportInfos]') and [name] = N'source_server_iqn_or_wwn')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumeExportInfos] ADD source_server_iqn_or_wwn [nvarchar](512)
		PRINT 'New column [source_server_iqn_or_wwn] has been successfully added to [Backup.Model.SanVolumeExportInfos]'
	END


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1121; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1121 and current_version < 1131)
BEGIN

exec sp_executesql @stat = N'ALTER TRIGGER [dbo].[Tape.after_update_tape_mediums]
   ON  [dbo].[Tape.tape_mediums] 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- update usn
	DECLARE @usn bigint, @id uniqueidentifier, @address int

	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor

	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE [Tape.tape_mediums] SET usn = @usn WHERE @id = id

		FETCH NEXT FROM deleted_cursor INTO @id
	END

	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor

	DECLARE moved_cursor CURSOR FOR 
	SELECT d.location_library_id, d.location_address FROM deleted d INNER JOIN inserted i ON d.id = i.id WHERE d.location_type = 0 AND i.location_type <> 0
	OPEN moved_cursor

	FETCH NEXT FROM moved_cursor INTO @id, @address
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE td SET td.usn = @usn FROM [Tape.tape_drives] td INNER JOIN [Tape.library_devices] ld ON td.device_id = ld.device_id WHERE td.address = @address

		FETCH NEXT FROM moved_cursor INTO @id, @address
	END

	CLOSE moved_cursor
	DEALLOCATE moved_cursor

	DECLARE moved_cursor CURSOR FOR 
	SELECT i.location_library_id, i.location_address FROM deleted d INNER JOIN inserted i ON d.id = i.id WHERE d.location_type <> 0 AND i.location_type = 0
	OPEN moved_cursor

	FETCH NEXT FROM moved_cursor INTO @id, @address
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		UPDATE td SET td.usn = @usn FROM [Tape.tape_drives] td INNER JOIN [Tape.library_devices] ld ON td.device_id = ld.device_id WHERE td.address = @address

		FETCH NEXT FROM moved_cursor INTO @id, @address
	END

	CLOSE moved_cursor
	DEALLOCATE moved_cursor
END'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1131; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1131 AND current_version < 1132)
BEGIN
	DECLARE @usn bigint
	EXEC [dbo].[IncrementUsn] @usn OUTPUT

	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 24 OR [job_type] = 25 OR [job_type] = 26 OR [job_type] = 27 OR [job_type] = 28 OR [job_type] = 29 OR [job_type] = 32 OR [job_type] = 33 OR [job_type] = 34 OR [job_type] = 35 OR [job_type] = 36)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = 'FC0B6A9D-F476-49DA-9B11-6A21879C71CA'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1132; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1132)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportToProxyLunId]') AND type in (N'U'))
	BEGIN
	
		PRINT N'Creating [dbo].[Backup.Model.SanVolumeExportToProxyLunId] table'
						
		CREATE TABLE [dbo].[Backup.Model.SanVolumeExportToProxyLunId]
		(			
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Backup_Model_SanVolumeExportToProxyLunId_id]  DEFAULT (newid()),
			[san_initiator_id] [uniqueidentifier] NOT NULL,
			[san_host_id] [uniqueidentifier] NOT NULL,
			[lun_id] [int] NOT NULL,
			[init_time] [datetime] NOT NULL,
			[ttl_min] [int] NOT NULL		
			
			CONSTRAINT [PK_Backup_Model_SanVolumeExportToProxyLunId_id] PRIMARY KEY NONCLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]
	END
		
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportToProxyLunId]') AND name = N'IX_Backup.Model.SanVolumeExportToProxyLunIds_LunId')
	BEGIN
		PRINT N'Creating [IX_Backup.Model.SanVolumeExportToProxyLunIds_LunId] index'
		
		CREATE NONCLUSTERED INDEX [IX_Backup.Model.SanVolumeExportToProxyLunIds_LunId] ON [dbo].[Backup.Model.SanVolumeExportToProxyLunId]
		(
			[lun_id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportToProxyLunId]') AND name = N'IX_Backup.Model.SanVolumeExportToProxyLunIds_SanInitiatorId')
	BEGIN
		PRINT N'Creating [IX_Backup.Model.SanVolumeExportToProxyLunIds_SanInitiatorId] index'
	
		CREATE NONCLUSTERED INDEX [IX_Backup.Model.SanVolumeExportToProxyLunIds_SanInitiatorId] ON [dbo].[Backup.Model.SanVolumeExportToProxyLunId]
		(
			[san_initiator_id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportToProxyLunId]') AND name = N'IX_Backup.Model.SanVolumeExportToProxyLunIds_SanHostId')
	BEGIN
		PRINT N'Creating [IX_Backup.Model.SanVolumeExportToProxyLunIds_SanHostId] index'
	
		CREATE NONCLUSTERED INDEX [IX_Backup.Model.SanVolumeExportToProxyLunIds_SanHostId] ON [dbo].[Backup.Model.SanVolumeExportToProxyLunId]
		(
			[san_host_id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1133; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1133 and current_version < 1137)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1137; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1137 AND current_version < 1138)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') AND [name] = 'creation_time')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD [creation_time] datetime NULL
		print 'New column {creation_time} has been successfully added to [dbo].[Backup.Model.Backups] table'		
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1138; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1138 AND current_version < 1139)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WanGlobalCacheCorruptedDiskRoles]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[WanGlobalCacheCorruptedDiskRoles](
			[src_wan_id] [varchar](255) NOT NULL,
			[tgt_wan_id] [varchar](255) NOT NULL,
			[disk_role] [varchar](255) NOT NULL
			) ON [PRIMARY]
		print 'New table {WanGlobalCacheCorruptedDiskRoles} has been successfully added'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1139; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1139 and current_version < 1140)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1140; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1140 and current_version < 1143)
BEGIN
	ALTER TABLE [dbo].[ItemRestoreAudits] ADD source nvarchar(256) DEFAULT '' NOT NULL

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1143; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1143 and current_version < 1144)
BEGIN
	UPDATE [dbo].[Backup.Model.Backups]
	SET target_type = 5
	WHERE job_source_type = 4 AND
	job_target_type = 1 AND
	target_type =	0;

	UPDATE [dbo].[BJobs]
	SET [target_type] = 5
	WHERE [type] = 1 AND
	[platform]= 1 AND
	[target_type] = 0;

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1144; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1144 and current_version < 1156)
BEGIN
	ALTER TABLE [dbo].[Backup.Model.JobSessions] ADD [reason] [ntext] NULL

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1156; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1156 and current_version < 1157)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1157; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1157 and current_version < 1159)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1159; END
END
GO

-- Adding read_average_size and transport_type fields
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1159 AND current_version < 1160)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'transport_type')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD [transport_type] int DEFAULT 0 not null
		print 'New column {transport_type} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'read_average_size')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD [read_average_size] bigint DEFAULT 0 not null
		print 'New column {read_average_size} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'		
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'read_average_size')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupTaskSessions] ADD [read_average_size] bigint DEFAULT 0 not null
		print 'New column {read_average_size} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1160; END
END	
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1160 and current_version < 1164)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1164; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1164)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SbSessions]') AND [name] = 'platform')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SbSessions] ADD [platform] int DEFAULT 0 not null
		print 'New column {platform} has been successfully added to [dbo].[Backup.Model.SbSessions] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1165; END
END	
GO

--
-----------------------------------------------------
-- 7.0.0.663
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1165 AND current_version < 1167)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'creation_mode')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD creation_mode int NOT NULL DEFAULT 0
		print 'New column {creation_mode} has been successfully added to [dbo].[Backup.Model.Storages] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1167; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1167 and current_version < 1170)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1170; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1170)
BEGIN
	UPDATE
		[dbo].[BJobs]
	SET
		[options] = Temp.options
	FROM
	(
		SELECT
			[id],
			cast(replace(cast([options] as nvarchar(max)), '</JobOptionsRoot>', '  ' + '<UseSanSnapshots>False</UseSanSnapshots>' + CHAR(13) + '</JobOptionsRoot>') as xml) AS options
		FROM
			[dbo].[BJobs]
		WHERE
			([type] = 0 OR [type] = 1) AND charindex('<UseSanSnapshots>', cast([options] as nvarchar(max))) = 0 AND charindex('<JobOptionsRoot>', cast([options] as nvarchar(max))) <> 0
	) AS Temp
	WHERE
		[dbo].[BJobs].[id] = Temp.id

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1171; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1171 and current_version < 1173)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1173; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1173 AND current_version < 1175)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'expiration_date')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD expiration_date datetime NULL
		print 'New column {expiration_date} has been successfully added to [dbo].[Backup.Model.Storages] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1176; END
END	
GO

--
-----------------------------------------------------
-- 7.0.0.690
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1176 and current_version < 1179) 
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1179; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1179 and current_version < 1180)
BEGIN
	IF NOT EXISTS(SELECT * FROM sys.indexes WHERE Name = 'IX_VmWareSnapshots_Snapshot_Ref_And_Host_name')
	BEGIN
		CREATE CLUSTERED INDEX [IX_VmWareSnapshots_Snapshot_Ref_And_Host_name] ON [dbo].[VmWareSnapshots]
		(
			[snapshot_ref] ASC,
			[host_name] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_VmWareSnapshots_Snapshot_Ref_And_Host_name} has been successfully added to [dbo].[VmWareSnapshots] table'
	END
	
	IF NOT EXISTS(SELECT * FROM sys.indexes WHERE Name = 'IX_VmWareSnapshots_Session_Id')
	BEGIN	
		CREATE NONCLUSTERED INDEX [IX_VmWareSnapshots_Session_Id] ON [dbo].[VmWareSnapshots]
		(
			[session_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_VmWareSnapshots_Session_Id} has been successfully added to [dbo].[VmWareSnapshots] table'
	END

	IF NOT EXISTS(SELECT * FROM sys.indexes WHERE Name = 'IX_VmWareSnapshots_Job_Id')
	BEGIN	
		CREATE NONCLUSTERED INDEX [IX_VmWareSnapshots_Job_Id] ON [dbo].[VmWareSnapshots]
		(
			[job_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_VmWareSnapshots_Job_Id} has been successfully added to [dbo].[VmWareSnapshots] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1180; END
END
GO

--
-----------------------------------------------------
-- 7.0.0.715
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1180 and current_version < 1181)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1181; END
END
GO

-- Adding os_platform for PhysicalHosts
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1181)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[PhysicalHosts]') AND [name] = 'os_platform')
	BEGIN
		ALTER TABLE [dbo].[PhysicalHosts] ADD [os_platform] int not null DEFAULT 100
		print 'New column {os_platform} has been successfully added to [dbo].[PhysicalHosts] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1191; END
END
GO

-- Updating localhost os platform
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1191)
BEGIN
	BEGIN 
		UPDATE [dbo].[PhysicalHosts]
		SET [os_platform] = 1
		WHERE [id] = 'D7C4FF97-B99B-4d1f-884D-283B7B6B9EE3'
		print 'Local host {os_platform} has been updated to x64(1)'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1192; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1192 and current_version < 1194)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1194; END
END
GO

if exists(select 1 from [dbo].[Version] where current_version = 1194)
begin
		update 
			[dbo].[Options] 
		set 
			[value].modify('replace value of (/CMailOptions/Subject/text())[1] with ("[%JobResult%] %JobName% (%VmCount% VMs) %Issues%")') 
		where 
			[id] = '91BB166B-E197-48F7-A430-7904E013B30B'
		and 
			[value].value('(/CMailOptions/Subject)[1]', 'nvarchar(max)') = '[%Time%][%JobResult%] %JobName% (%VmCount% VMs) %Issues%'
	
		if @@error = 0 update [dbo].[Version] SET current_version = 1195; 
end

go

--
-----------------------------------------------------
-- 7.0.0.764
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1195 and current_version < 1196)
BEGIN
	UPDATE [dbo].[ObjectsInJobs] SET [disk_filter] = [disk_filter] + ';16000;16001;16002;16003;16004;16005;16006;16008;16009;16010;16011;16012;16013;16014;16015;16016;16017;16018;16019;16020;16021;16022;16023;16024;16025;16026;16027;16028;16029;16030;16031;16032;16033;16034;16035;16036;16038;16039;16040;16041;16042;16043;16044;16045;16046;16047;16048;16049;16050;16051;16052;16053;16054;16055;16056;16057;16058;16059;16060;16061;16062;16063;16064;16065;16066;16068;16069;16070;16071;16072;16073;16074;16075;16076;16077;16078;16079;16080;16081;16082;16083;16084;16085;16086;16087;16088;16089;16090;16091;16092;16093;16094;16095;16096;16098;16099;16100;16101;16102;16103;16104;16105;16106;16107;16108;16109;16110;16111;16112;16113;16114;16115;16116;16117;16118;16119' WHERE [disk_filter] not like '%16000%'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1196; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1196 and current_version < 1197)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1197; END
END
GO

-- Alter incorrect trigger
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1197)
BEGIN
	exec sp_executesql @stat = N'ALTER trigger [dbo].[d_Backup_Model_BackupTaskSessions] on [dbo].[Backup.Model.BackupTaskSessions] for delete 
	as 	begin  
		declare @id uniqueidentifier
		declare delEnumerator cursor
			for select id from deleted
			
		open delEnumerator
		fetch next from delEnumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''Backup.Model.BackupTaskSessions'', @id, 2
		  fetch next from delEnumerator into @id
		end
			
		close delEnumerator
		deallocate delEnumerator
	end'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1198; END
END
GO

PRINT N'Creating [dbo].[FindTableColumnIndexes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindTableColumnIndexes]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[FindTableColumnIndexes]
GO

CREATE FUNCTION [dbo].[FindTableColumnIndexes]
(
	@table_name nvarchar(128),
	@column_name nvarchar(128)
)
RETURNS
	@table TABLE
	(
		table_name nvarchar(128),
		index_name nvarchar(128),
		column_name nvarchar(128)
	)
AS
BEGIN
	INSERT @table(table_name, index_name, column_name)
	SELECT
		sys.objects.name,
		sys.indexes.name,
		sys.columns.name
	FROM
		sys.objects
	INNER JOIN
		sys.indexes
	ON
		sys.objects.object_id = sys.indexes.object_id
	INNER JOIN
		sys.index_columns
	ON
		sys.index_columns.object_id = sys.indexes.object_id AND sys.index_columns.index_id = sys.indexes.index_id
	INNER JOIN
		sys.columns
	ON
		sys.columns.object_id = sys.index_columns.object_id AND sys.columns.column_id = sys.index_columns.column_id
	WHERE
		sys.objects.type_desc = N'USER_TABLE' AND sys.objects.name = @table_name AND sys.columns.name = @column_name

	RETURN
END
GO

PRINT N'Creating [dbo].[CreateTableColumnIndex]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CreateTableColumnIndex]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CreateTableColumnIndex]
GO

CREATE PROCEDURE [dbo].[CreateTableColumnIndex]
	@table_name nvarchar(128),
	@column_name nvarchar(128),
	@index_name nvarchar(128)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @table table(table_name nvarchar(128), index_name nvarchar(128), column_name nvarchar(128))

	INSERT INTO
		@table
	SELECT
		*
	FROM
		[dbo].[FindTableColumnIndexes](@table_name, @column_name)

	IF NOT EXISTS (SELECT * FROM @table)
	BEGIN
		DECLARE @command nvarchar(max)

		SET @command = 
			'CREATE NONCLUSTERED INDEX [' + @index_name + '] ON dbo.[' + @table_name + ']' + CHAR(13) + CHAR(10) +
			'(' + CHAR(13) + CHAR(10) +
			'	[' + @column_name + '] ASC' + CHAR(13) + CHAR(10) +
			')' + CHAR(13) + CHAR(10) +
			'WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]'

		--PRINT @command

		EXEC(@command)

		PRINT 'New index [' + @index_name + '] has been successfully added to [' + @table_name + ']'
	END
	ELSE
	BEGIN
		DECLARE @join varchar(max);

		SELECT
			@join = CASE
				WHEN @join IS NULL
				THEN t.index_name
				ELSE @join + ', ' + t.index_name
			END
		FROM
			@table AS t
		
		PRINT 'Warning: column [' + @column_name + '] already has index(es): ' + @join
	END
END
GO

--
-----------------------------------------------------
-- 7.0.0.833
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1198)
BEGIN
	PRINT 'Starting new indexes creation at ' + convert(nvarchar, getdate(), 21)

	-- [dbo].[Backup.Model.BackupJobSessions]: [usn]
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.BackupJobSessions', N'usn', N'IX_Backup.Model.BackupJobSessions_Usn'

	-- [dbo].[Backup.Model.Backups]: [usn]
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.Backups', N'usn', N'IX_Backup.Model.Backups_Usn'

	-- [dbo].[Backup.Model.BackupTaskSessions]: [creation_time], [end_time], [usn]
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.BackupTaskSessions', N'creation_time', N'IX_Backup.Model.BackupTaskSessions_CreationTime'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.BackupTaskSessions', N'end_time', N'IX_Backup.Model.BackupTaskSessions_EndTime'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.BackupTaskSessions', N'usn', N'IX_Backup.Model.BackupTaskSessions_Usn'
	
	-- [dbo].[Backup.Model.JobSessions]: [creation_time], [end_time], [usn]
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.JobSessions', N'creation_time', N'IX_Backup.Model.JobSessions_CreationTime'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.JobSessions', N'end_time', N'IX_Backup.Model.JobSessions_EndTime'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.JobSessions', N'usn', N'IX_Backup.Model.JobSessions_Usn'

	-- [dbo].[Backup.Model.OIBs]: [object_id], [point_id], [storage_id], [link_id], [usn]
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.OIBs', N'object_id', N'IX_Backup.Model.OIBs_ObjectId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.OIBs', N'point_id', N'IX_Backup.Model.OIBs_PointId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.OIBs', N'storage_id', N'IX_Backup.Model.OIBs_StorageId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.OIBs', N'link_id', N'IX_Backup.Model.OIBs_LinkId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.OIBs', N'usn', N'IX_Backup.Model.OIBs_usn'

	-- [dbo].[Backup.Model.Points]: [backup_id], [group_id], [link_id], [usn]
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.Points', N'backup_id', N'IX_Backup.Model.Points_BackupId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.Points', N'group_id', N'IX_Backup.Model.Points_GroupId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.Points', N'link_id', N'IX_Backup.Model.Points_LinkId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.Points', N'usn', N'IX_Backup.Model.Points_Usn'

	-- [dbo].[Backup.Model.Storages]: [backup_id], [usn]
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.Storages', N'backup_id', N'IX_Backup.Model.Storages_BackupId'
	EXEC dbo.CreateTableColumnIndex N'Backup.Model.Storages', N'usn', N'IX_Backup.Model.Storages_Usn'

	PRINT 'Ending new indexes creation at ' + convert(nvarchar, getdate(), 21)

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1199; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1199)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ViSnapshots]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViSnapshots](
			[id] [uniqueidentifier] NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[host_name] [nvarchar](1024) NOT NULL,
			[snapshot_ref] [nvarchar](1024) NOT NULL,
			[session_id] [uniqueidentifier] NOT NULL,
			[job_id] [uniqueidentifier] NOT NULL,
			[vm_ref] [nvarchar](1024) NOT NULL,
			[description] [nvarchar](1024) NOT NULL
		 CONSTRAINT [PK_Backup.Model.ViSnapshots] PRIMARY KEY CLUSTERED 
		([id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.ViSnapshots] ADD  CONSTRAINT [DF_Backup.Model.ViSnapshots_id]  DEFAULT (newid()) FOR [id]

		PRINT 'Table [dbo].[Backup.Model.ViSnapshots] has been successfully created'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ViSnapshotAttachments]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViSnapshotAttachments](
			[id] [uniqueidentifier] NOT NULL,
			[snapshot_id] [uniqueidentifier] NOT NULL,
			[description] [nvarchar](1024) NOT NULL,
			[proxy_id] [uniqueidentifier] NOT NULL,
			[transport_type] [nvarchar](1024) NOT NULL
		CONSTRAINT [PK_Backup.Model.ViSnapshotAttachments] PRIMARY KEY CLUSTERED 
		([id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	
		ALTER TABLE [dbo].[Backup.Model.ViSnapshotAttachments] ADD  CONSTRAINT [DF_Backup.Model.ViSnapshotAttachments_id]  DEFAULT (newid()) FOR [id]
		ALTER TABLE [dbo].[Backup.Model.ViSnapshotAttachments] ADD  CONSTRAINT [FK_Backup.Model.ViSnapshotAttachments_Backup.Model.ViSnapshots] FOREIGN KEY([snapshot_id])
			REFERENCES [dbo].[Backup.Model.ViSnapshots] ([id])
			ON UPDATE CASCADE
			ON DELETE CASCADE

		PRINT 'Table [dbo].[Backup.Model.ViSnapshotAttachments] has been successfully created'
	END

	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[VmWareSnapshots]') AND type in (N'U'))
	BEGIN
		DROP TABLE [dbo].[VmWareSnapshots]
		PRINT 'Table [dbo].[VmWareSnapshots] has been successfully dropped'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1200; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1200)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1201; END
END
GO

--
-----------------------------------------------------
-- 7.0.0.870
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1201 AND current_version < 1205)
BEGIN
	--UPDATE REPORT VIEW:
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	UPDATE [Backup.Model.Session.Filters] SET 
	[data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] &gt; 17 AND [job_type] &lt; 21 OR [job_type] = 53)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>',
	[usn] = @usn
	WHERE [id] = '95600FC2-2E51-4AEC-9053-CC784A5CEEEB'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1205; END
END
GO

