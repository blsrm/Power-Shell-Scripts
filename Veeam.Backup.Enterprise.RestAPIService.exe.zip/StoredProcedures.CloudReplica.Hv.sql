﻿--------------------------------------------------------------------------------
-- AddHvHardwarePlan
PRINT N'Creating [dbo].[AddHvHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHvHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHvHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[AddHvHardwarePlan]
		@id uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@description nvarchar(MAX),
		@hypervisorHostId uniqueidentifier,
		@processorUsageLimitCores int,
		@memoryUsageLimitMb int
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvHardwarePlans]
			   ([id]
			   ,[friendlyName]
			   ,[description]
			   ,[hypervisorHostId]
			   ,[processorUsageLimitCores]
			   ,[memoryUsageLimitMb]
			   ,[usn])
		 VALUES
			   (@id,
				@friendlyName,
				@description,
				@hypervisorHostId,
				@processorUsageLimitCores,
				@memoryUsageLimitMb,
				0)
	END
GO

--------------------------------------------------------------------------------
-- UpdateHvHardwarePlan
PRINT N'Creating [dbo].[UpdateHvHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHvHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHvHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[UpdateHvHardwarePlan]
		@id uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@description nvarchar(MAX),
		@hypervisorHostId uniqueidentifier,
		@processorUsageLimitCores int,
		@memoryUsageLimitMb int
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.HvHardwarePlans]
		SET
			[friendlyName] = @friendlyName,
			[description] = @description,
			[hypervisorHostId] = @hypervisorHostId,
			[processorUsageLimitCores] = @processorUsageLimitCores,
			[memoryUsageLimitMb] = @memoryUsageLimitMb
		WHERE [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwarePlan
PRINT N'Creating [dbo].[RemoveHvHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwarePlan]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.HvHardwarePlans] where [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- FindHvHardwarePlan
PRINT N'Creating [dbo].[FindHvHardwarePlan]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwarePlan]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwarePlan]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwarePlan]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlans] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwarePlansByHypervisorHostId
PRINT N'Creating [dbo].[FindHvHardwarePlansByHypervisorHostId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwarePlansByHypervisorHostId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwarePlansByHypervisorHostId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwarePlansByHypervisorHostId]
		@hypervisorHostId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlans] where [hypervisorHostId] = @hypervisorHostId
	END

GO

--------------------------------------------------------------------------------
-- FindAllHvHardwarePlans
PRINT N'Creating [dbo].[FindAllHvHardwarePlans]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllHvHardwarePlans]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllHvHardwarePlans]
GO

	CREATE PROCEDURE [dbo].[FindAllHvHardwarePlans]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlans]
	END

GO

--------------------------------------------------------------------------------
-- AddHvHardwarePlanVolume
PRINT N'Creating [dbo].[AddHvHardwarePlanVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHvHardwarePlanVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHvHardwarePlanVolume]
GO

	CREATE PROCEDURE [dbo].[AddHvHardwarePlanVolume]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@volumePath nvarchar(MAX),
		@quotaGb int
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvHardwarePlanVolumes]
			([id],
			[hardwarePlanId],
			[friendlyName],
			[volumePath],
			[quotaGb],
			[usn])
			   
		 VALUES
			(@id,
			@hardwarePlanId,
			@friendlyName,
			@volumePath,
			@quotaGb,
			0)
	END
GO

--------------------------------------------------------------------------------
-- UpdateHvHardwarePlanVolume
PRINT N'Creating [dbo].[UpdateHvHardwarePlanVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHvHardwarePlanVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHvHardwarePlanVolume]
GO

	CREATE PROCEDURE [dbo].[UpdateHvHardwarePlanVolume]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@volumePath nvarchar(MAX),
		@quotaGb int
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.HvHardwarePlanVolumes]
		SET
			[hardwarePlanId] = @hardwarePlanId,
			[friendlyName] = @friendlyName,
			[volumePath] = @volumePath,
			[quotaGb] = @quotaGb
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwarePlanVolume
PRINT N'Creating [dbo].[RemoveHvHardwarePlanVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwarePlanVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwarePlanVolume]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwarePlanVolume]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.HvHardwarePlanVolumes] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindHvHardwarePlanVolume
PRINT N'Creating [dbo].[FindHvHardwarePlanVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwarePlanVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwarePlanVolume]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwarePlanVolume]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlanVolumes] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwarePlanVolumeByHardwarePlanId
PRINT N'Creating [dbo].[FindHvHardwarePlanVolumeByHardwarePlanId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwarePlanVolumeByHardwarePlanId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwarePlanVolumeByHardwarePlanId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwarePlanVolumeByHardwarePlanId]	
		@hardwarePlanId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlanVolumes] where [hardwarePlanId] = @hardwarePlanId
	END

GO

--------------------------------------------------------------------------------
-- FindAllHvHardwarePlanVolumes
PRINT N'Creating [dbo].[FindAllHvHardwarePlanVolumes]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllHvHardwarePlanVolumes]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllHvHardwarePlanVolumes]
GO

	CREATE PROCEDURE [dbo].[FindAllHvHardwarePlanVolumes]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlanVolumes]
	END

GO

--------------------------------------------------------------------------------
-- AddHvHardwarePlanNetwork
PRINT N'Creating [dbo].[AddHvHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHvHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHvHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[AddHvHardwarePlanNetwork]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@countWithInternent int,
		@countWithoutInternent int
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvHardwarePlanNetworks]
			([id],
			[hardwarePlanId],
			[countWithInternent],
			[countWithoutInternent],
			[usn])
			   
		 VALUES
			(@id,
			@hardwarePlanId,
			@countWithInternent,
			@countWithoutInternent,
			0)
	END
GO

--------------------------------------------------------------------------------
-- UpdateHvHardwarePlanNetwork
PRINT N'Creating [dbo].[UpdateHvHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHvHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHvHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[UpdateHvHardwarePlanNetwork]
		@id uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@countWithInternent int,
		@countWithoutInternent int
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.HvHardwarePlanNetworks]
		SET
			[hardwarePlanId] = @hardwarePlanId,
			[countWithInternent] = @countWithInternent,
			[countWithoutInternent] = @countWithoutInternent
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwarePlanNetwork
PRINT N'Creating [dbo].[RemoveHvHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwarePlanNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.HvHardwarePlanNetworks] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindHvHardwarePlanNetwork
PRINT N'Creating [dbo].[FindHvHardwarePlanNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwarePlanNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwarePlanNetwork]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwarePlanNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlanNetworks] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwarePlanNetworksByHardwarePlanId
PRINT N'Creating [dbo].[FindHvHardwarePlanNetworksByHardwarePlanId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwarePlanNetworksByHardwarePlanId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwarePlanNetworksByHardwarePlanId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwarePlanNetworksByHardwarePlanId]	
		@hardwarePlanId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlanNetworks] where [hardwarePlanId] = @hardwarePlanId
	END

GO

--------------------------------------------------------------------------------
-- FindAllHvHardwarePlanNetworks
PRINT N'Creating [dbo].[FindAllHvHardwarePlanNetworks]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllHvHardwarePlanNetworks]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllHvHardwarePlanNetworks]
GO

	CREATE PROCEDURE [dbo].[FindAllHvHardwarePlanNetworks]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwarePlanNetworks]
	END

GO

--------------------------------------------------------------------------------
-- AddHvHardwareQuota
PRINT N'Creating [dbo].[AddHvHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHvHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHvHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[AddHvHardwareQuota]
		@id uniqueidentifier,
		@tenantId uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@expireDate DATETIME,
		@isCorrespondsToPlan bit,
		@wan_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvHardwareQuotas]
			   ([id]
			   ,[tenantId]
			   ,[hardwarePlanId]
			   ,[expireDate]
			   ,[isCorrespondsToPlan]
			   ,[wan_id])
			   
		 VALUES
			   (@id,
			    @tenantId,
				@hardwarePlanId,
				@expireDate,
				@isCorrespondsToPlan,
				@wan_id)
	END
GO

--------------------------------------------------------------------------------
-- UpdateHvHardwareQuota
PRINT N'Creating [dbo].[UpdateHvHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHvHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHvHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[UpdateHvHardwareQuota]
		@id uniqueidentifier,
		@tenantId uniqueidentifier,
		@hardwarePlanId uniqueidentifier,
		@expireDate DATETIME,
		@isCorrespondsToPlan bit,
		@wan_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.HvHardwareQuotas]
		SET
			   [tenantId] = @tenantId,
			   [hardwarePlanId] = @hardwarePlanId,
			   [expireDate] = @expireDate,
			   [isCorrespondsToPlan] = @isCorrespondsToPlan,
			   [wan_id] = @wan_id
		WHERE [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwareQuota
PRINT N'Creating [dbo].[RemoveHvHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwareQuota]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.HvHardwareQuotas] where [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuota
PRINT N'Creating [dbo].[FindHvHardwareQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuota]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuota]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotas] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotasByTenantId
PRINT N'Creating [dbo].[FindHvHardwareQuotasByTenantId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotasByTenantId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotasByTenantId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotasByTenantId]
		@tenantId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotas] where [tenantId] = @tenantId
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotasByHardwarePlanId
PRINT N'Creating [dbo].[FindHvHardwareQuotasByHardwarePlanId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotasByHardwarePlanId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotasByHardwarePlanId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotasByHardwarePlanId]
		@hardwarePlanId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotas] where [hardwarePlanId] = @hardwarePlanId
	END

GO

--------------------------------------------------------------------------------
-- FindAllHvHardwareQuotas
PRINT N'Creating [dbo].[FindAllHvHardwareQuotas]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllHvHardwareQuotas]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllHvHardwareQuotas]
GO

	CREATE PROCEDURE [dbo].[FindAllHvHardwareQuotas]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotas]
	END

GO


--------------------------------------------------------------------------------
-- AddHvHardwareQuotaVolume
PRINT N'Creating [dbo].[AddHvHardwareQuotaVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHvHardwareQuotaVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHvHardwareQuotaVolume]
GO

	CREATE PROCEDURE [dbo].[AddHvHardwareQuotaVolume]
		@id uniqueidentifier,
		@hardwarePlanVolumeId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@relativePath nvarchar(MAX)
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvHardwareQuotaVolumes]
			([id],
			[hardwarePlanVolumeId],
			[hardwareQuotaId],
			[relativePath])
			   
		 VALUES
			(@id,
			@hardwarePlanVolumeId,
			@hardwareQuotaId,
			@relativePath)
	END
GO

--------------------------------------------------------------------------------
-- UpdateHvHardwareQuotaVolume
PRINT N'Creating [dbo].[UpdateHvHardwareQuotaVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHvHardwareQuotaVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHvHardwareQuotaVolume]
GO

	CREATE PROCEDURE [dbo].[UpdateHvHardwareQuotaVolume]
		@id uniqueidentifier,
		@hardwarePlanVolumeId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@relativePath nvarchar(MAX)
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.HvHardwareQuotaVolumes]
		SET
			[hardwarePlanVolumeId] = @hardwarePlanVolumeId,
			[hardwareQuotaId] = @hardwareQuotaId,
			[relativePath] = @relativePath
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwareQuotaVolume
PRINT N'Creating [dbo].[RemoveHvHardwareQuotaVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwareQuotaVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwareQuotaVolume]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwareQuotaVolume]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		exec [dbo].[RemoveHvHardwareQuotaVolumeUsageByQuotaId] @id
		delete from [dbo].[Backup.Model.HvHardwareQuotaVolumes] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaVolume
PRINT N'Creating [dbo].[FindHvHardwareQuotaVolume]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaVolume]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaVolume]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaVolume]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumes] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaVolumesByHardwarePlanVolumeId
PRINT N'Creating [dbo].[FindHvHardwareQuotaVolumesByHardwarePlanVolumeId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaVolumesByHardwarePlanVolumeId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaVolumesByHardwarePlanVolumeId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaVolumesByHardwarePlanVolumeId]	
		@hardwarePlanVolumeId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumes] where [hardwarePlanVolumeId] = @hardwarePlanVolumeId
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaVolumesByHardwareQuotaId
PRINT N'Creating [dbo].[FindHvHardwareQuotaVolumesByHardwareQuotaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaVolumesByHardwareQuotaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaVolumesByHardwareQuotaId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaVolumesByHardwareQuotaId]	
		@hardwareQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumes] where [hardwareQuotaId] = @hardwareQuotaId
	END

GO

--------------------------------------------------------------------------------
-- FindAllHvHardwareQuotaVolumes
PRINT N'Creating [dbo].[FindAllHvHardwareQuotaVolumes]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllHvHardwareQuotaVolumes]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllHvHardwareQuotaVolumes]
GO

	CREATE PROCEDURE [dbo].[FindAllHvHardwareQuotaVolumes]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumes]
	END

GO

--------------------------------------------------------------------------------
-- AddHvHardwareQuotaNetwork
PRINT N'Creating [dbo].[AddHvHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHvHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHvHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[AddHvHardwareQuotaNetwork]
		@id uniqueidentifier,
		@hardwarePlanNetworkId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@name nvarchar(MAX),
		@switchName nvarchar(MAX),
		@vlanId int,
		@hasInternet bit,
		@ifaceNum int,
		@tenantInfo xml
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvHardwareQuotaNetworks]
			([id],
			[hardwarePlanNetworkId],
			[hardwareQuotaId],
			[name],
			[switchName],
			[vlanId],
			[hasInternet],
			[ifaceNum],
			[tenantInfo])
			   
		 VALUES
			(@id,
			@hardwarePlanNetworkId,
			@hardwareQuotaId,
			@name,
			@switchName,
			@vlanId,
			@hasInternet,
			@ifaceNum,
			@tenantInfo)
	END
GO

--------------------------------------------------------------------------------
-- UpdateHvHardwareQuotaNetwork
PRINT N'Creating [dbo].[UpdateHvHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHvHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHvHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[UpdateHvHardwareQuotaNetwork]
		@id uniqueidentifier,
		@hardwarePlanNetworkId uniqueidentifier,
		@hardwareQuotaId uniqueidentifier,
		@name nvarchar(MAX),
		@switchName nvarchar(MAX),
		@vlanId int,
		@hasInternet bit,
		@ifaceNum int,
		@tenantInfo xml
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.HvHardwareQuotaNetworks]
		SET
		    [hardwarePlanNetworkId] = @hardwarePlanNetworkId,
			[hardwareQuotaId] = @hardwareQuotaId,
			[name] = @name,
			[switchName] = @switchName,
			[vlanId] = @vlanId,
			[hasInternet] = @hasInternet,
			[ifaceNum] = @ifaceNum,
			[tenantInfo] = @tenantInfo
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwareQuotaNetwork
PRINT N'Creating [dbo].[RemoveHvHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwareQuotaNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.HvHardwareQuotaNetworks] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaNetwork
PRINT N'Creating [dbo].[FindHvHardwareQuotaNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaNetwork]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaNetworks] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaNetworksByHardwarePlanNetworkId
PRINT N'Creating [dbo].[FindHvHardwareQuotaNetworksByHardwarePlanNetworkId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaNetworksByHardwarePlanNetworkId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaNetworksByHardwarePlanNetworkId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaNetworksByHardwarePlanNetworkId]	
		@hardwarePlanNetworkId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaNetworks] where [hardwarePlanNetworkId] = @hardwarePlanNetworkId
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaNetworksByHardwareQuotaId
PRINT N'Creating [dbo].[FindHvHardwareQuotaNetworksByHardwareQuotaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaNetworksByHardwareQuotaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaNetworksByHardwareQuotaId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaNetworksByHardwareQuotaId]	
		@hardwareQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaNetworks] where [hardwareQuotaId] = @hardwareQuotaId
	END

GO

--------------------------------------------------------------------------------
-- FindAllHvHardwareQuotaNetworks
PRINT N'Creating [dbo].[FindAllHvHardwareQuotaNetworks]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllHvHardwareQuotaNetworks]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllHvHardwareQuotaNetworks]
GO

	CREATE PROCEDURE [dbo].[FindAllHvHardwareQuotaNetworks]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaNetworks]
	END

GO

--------------------------------------------------------------------------------
-- LinkHvCloudTenantBackupToQuota
PRINT N'Creating [dbo].[LinkHvCloudTenantBackupToQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LinkHvCloudTenantBackupToQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[LinkHvCloudTenantBackupToQuota]
GO

	CREATE PROCEDURE [dbo].[LinkHvCloudTenantBackupToQuota]	
		@backup_id uniqueidentifier,
		@quota_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvCloudTenantBackups] (backup_id, quota_id) VALUES (@backup_id, @quota_id)
	END

GO

--------------------------------------------------------------------------------
-- GetAllHvCloudTenantBackups
PRINT N'Creating [dbo].[GetAllHvCloudTenantBackups]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllHvCloudTenantBackups]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetAllHvCloudTenantBackups]
GO

	CREATE PROCEDURE [dbo].[GetAllHvCloudTenantBackups]	
		@tenant_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.HvCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.HvHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Tenants] t ON hq.tenantId = t.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE t.id = @tenant_id
	END

GO

--------------------------------------------------------------------------------
-- FindHvCloudTenantBackup
PRINT N'Creating [dbo].[FindHvCloudTenantBackup]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvCloudTenantBackup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvCloudTenantBackup]
GO

	CREATE PROCEDURE [dbo].[FindHvCloudTenantBackup]	
		@tenant_id uniqueidentifier,
		@backup_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.HvCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.HvHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Tenants] t ON hq.tenantId = t.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE t.id = @tenant_id AND b.id = @backup_id
	END

GO

--------------------------------------------------------------------------------
-- FindHvCloudTenantBackupById
PRINT N'Creating [dbo].[FindHvCloudTenantBackupById]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvCloudTenantBackupById]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvCloudTenantBackupById]
GO

	CREATE PROCEDURE [dbo].[FindHvCloudTenantBackupById]	
		@backup_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.HvCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.HvHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE b.id = @backup_id
	END

GO

--------------------------------------------------------------------------------
-- FindHvCloudTenantBackupByJob
PRINT N'Creating [dbo].[FindHvCloudTenantBackupByJob]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvCloudTenantBackupByJob]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvCloudTenantBackupByJob]
GO

	CREATE PROCEDURE [dbo].[FindHvCloudTenantBackupByJob]	
		@tenant_id uniqueidentifier,
		@job_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.HvCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.HvHardwareQuotas] hq ON cb.quota_id = hq.id
			INNER JOIN [dbo].[Tenants] t ON hq.tenantId = t.id
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE t.id = @tenant_id AND b.job_id = @job_id
	END

GO

--------------------------------------------------------------------------------
-- GetAllHvCloudTenantBackupsByQuota
PRINT N'Creating [dbo].[GetAllHvCloudTenantBackupsByQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllHvCloudTenantBackupsByQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetAllHvCloudTenantBackupsByQuota]
GO

	CREATE PROCEDURE [dbo].[GetAllHvCloudTenantBackupsByQuota]	
		@quota_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT cb.quota_id, b.* from [dbo].[Backup.Model.HvCloudTenantBackups] cb
			INNER JOIN [dbo].[Backup.Model.Backups] b ON cb.backup_id = b.id
		WHERE cb.quota_id = @quota_id
	END

GO

--------------------------------------------------------------------------------
-- SetHvHardwareQuotaVolumeUsage
PRINT N'Creating [dbo].[SetHvHardwareQuotaVolumeUsage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SetHvHardwareQuotaVolumeUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[SetHvHardwareQuotaVolumeUsage]
GO

	CREATE PROCEDURE [dbo].[SetHvHardwareQuotaVolumeUsage]
		@hardwareVolumeQuotaId uniqueidentifier,
		@replicaId uniqueidentifier,
		@usageBytes bigint
	AS
	BEGIN
		SET XACT_ABORT ON;

		BEGIN TRAN
		
		declare @usn bigint
		exec [dbo].[IncrementUsn] @usn OUTPUT

		UPDATE [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] WITH (serializable)
		SET
			[usageBytes] = @usageBytes,
			[usn] = @usn
		WHERE [hardwareVolumeQuotaId] = @hardwareVolumeQuotaId and [replicaId] = @replicaId
			
		IF @@rowcount = 0
		BEGIN
			INSERT INTO [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages]
				([hardwareVolumeQuotaId],
				[replicaId],
				[usageBytes],
				[usn])
			
			VALUES
				(@hardwareVolumeQuotaId,
				@replicaId,
				@usageBytes,
				@usn)
		END

		COMMIT TRAN
	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwareQuotaVolumeUsage
PRINT N'Creating [dbo].[RemoveHvHardwareQuotaVolumeUsage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwareQuotaVolumeUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsage]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsage]
		@hardwareVolumeQuotaId uniqueidentifier,
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		declare @id uniqueidentifier
		set @id = (select id from [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] where [hardwareVolumeQuotaId] = @hardwareVolumeQuotaId and [replicaId] = @replicaId)
		
		if @id is not null
		begin
			declare @usn bigint
			exec [dbo].[RemoveHvHardwareQuotaVolumeUsageById] @id
		end

	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwareQuotaVolumeUsageById
PRINT N'Creating [dbo].[RemoveHvHardwareQuotaVolumeUsageById]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwareQuotaVolumeUsageById]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsageById]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsageById]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		declare @usn bigint
		exec [dbo].[IncrementUsn] @usn OUTPUT
		
		delete from [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] where [id] = @id
		exec [dbo].[InsertTombStone] 'Backup.Model.HvHardwareQuotaVolumeUsages', @id, @usn

	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwareQuotaVolumeUsageByQuotaId
PRINT N'Creating [dbo].[RemoveHvHardwareQuotaVolumeUsageByQuotaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwareQuotaVolumeUsageByQuotaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsageByQuotaId]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsageByQuotaId]
		@hardwareVolumeQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		DECLARE @entryId uniqueidentifier
		DECLARE del CURSOR FOR SELECT id FROM [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] WHERE [hardwareVolumeQuotaId] = @hardwareVolumeQuotaId
		OPEN del

		FETCH NEXT FROM del INTO @entryId
		WHILE @@FETCH_STATUS = 0
		BEGIN
			exec [dbo].RemoveHvHardwareQuotaVolumeUsageById @entryId
			FETCH NEXT FROM del INTO @entryId
		END

		CLOSE del
		DEALLOCATE del

	END
GO

--------------------------------------------------------------------------------
-- RemoveHvHardwareQuotaVolumeUsageByReplicaId
PRINT N'Creating [dbo].[RemoveHvHardwareQuotaVolumeUsageByReplicaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveHvHardwareQuotaVolumeUsageByReplicaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsageByReplicaId]
GO

	CREATE PROCEDURE [dbo].[RemoveHvHardwareQuotaVolumeUsageByReplicaId]
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		DECLARE @entryId uniqueidentifier
		DECLARE del CURSOR FOR SELECT id FROM [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] WHERE [replicaId] = @replicaId
		OPEN del

		FETCH NEXT FROM del INTO @entryId
		WHILE @@FETCH_STATUS = 0
		BEGIN
			exec [dbo].RemoveHvHardwareQuotaVolumeUsageById @entryId
			FETCH NEXT FROM del INTO @entryId
		END

		CLOSE del
		DEALLOCATE del

	END
GO



--------------------------------------------------------------------------------
-- FindHvHardwareQuotaVolumeUsage
PRINT N'Creating [dbo].[FindHvHardwareQuotaVolumeUsage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaVolumeUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaVolumeUsage]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaVolumeUsage]
		@hardwareVolumeQuotaId uniqueidentifier,
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] where [hardwareVolumeQuotaId] = @hardwareVolumeQuotaId and [replicaId] = @replicaId
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaDatastoreUsagesByQuotaDatastoreId
PRINT N'Creating [dbo].[FindHvHardwareQuotaVolumeUsagesByQuotaVolumeId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaVolumeUsagesByQuotaVolumeId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaVolumeUsagesByQuotaVolumeId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaVolumeUsagesByQuotaVolumeId]	
		@hardwareVolumeQuotaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] where [hardwareVolumeQuotaId] = @hardwareVolumeQuotaId
	END

GO

--------------------------------------------------------------------------------
-- FindHvHardwareQuotaDatastoreUsagesByReplicaId
PRINT N'Creating [dbo].[FindHvHardwareQuotaVolumeUsagesByReplicaId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindHvHardwareQuotaVolumeUsagesByReplicaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindHvHardwareQuotaVolumeUsagesByReplicaId]
GO

	CREATE PROCEDURE [dbo].[FindHvHardwareQuotaVolumeUsagesByReplicaId]	
		@replicaId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] where [replicaId] = @replicaId
	END

GO

--------------------------------------------------------------------------------
-- FindAllHvHardwareQuotaDatastoreUsages
PRINT N'Creating [dbo].[FindAllHvHardwareQuotaVolumeUsages]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllHvHardwareQuotaVolumeUsages]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllHvHardwareQuotaVolumeUsages]
GO

	CREATE PROCEDURE [dbo].[FindAllHvHardwareQuotaVolumeUsages]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages]
	END

GO

--------------------------------------------------------------------------------
-- LinkHvCloudObjectToQuota
PRINT N'Creating [dbo].[LinkHvCloudObjectToQuota]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LinkHvCloudObjectToQuota]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[LinkHvCloudObjectToQuota]
GO

	CREATE PROCEDURE [dbo].[LinkHvCloudObjectToQuota]	
		@object_id uniqueidentifier,
		@quota_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.HvCloudQuotaObjects] ([object_id], quota_id) VALUES (@object_id, @quota_id)
	END

GO
