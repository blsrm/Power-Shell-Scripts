﻿-------------------------------------------------------------------------------
-- AddCloudConnectHost
PRINT N'Creating [dbo].[AddCloudConnectHost]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddCloudConnectHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddCloudConnectHost]
GO

	CREATE PROCEDURE [dbo].[AddCloudConnectHost]
		@id uniqueidentifier,
		@providerId uniqueidentifier,
		@platform int,
		@friendlyName nvarchar(MAX),
		@options xml,
		@isUnavailable bit,
		@isWanEnabled bit,
		@processorUsageLimitMhz int,
		@memoryUsageLimitMb int
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.CloudConnectHosts]
			   ([id]
			   ,[providerId]
			   ,[platform]
			   ,[friendlyName]
			   ,[options]
			   ,[usn]
			   ,[isUnavailable]
			   ,[isWanEnabled]
			   ,[processorUsageLimitMhz]
			   ,[memoryUsageLimitMb])
			   
		 VALUES
			   (@id,
				@providerId,
				@platform,
				@friendlyName,
				@options,
				0,
				@isUnavailable,
				@isWanEnabled,
				@processorUsageLimitMhz,
				@memoryUsageLimitMb)
	END
GO

--------------------------------------------------------------------------------
-- UpdateCloudConnectHost
PRINT N'Creating [dbo].[UpdateCloudConnectHost]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateCloudConnectHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateCloudConnectHost]
GO

	CREATE PROCEDURE [dbo].[UpdateCloudConnectHost]
		@id uniqueidentifier,
		@providerId uniqueidentifier,
		@platform int,
		@friendlyName nvarchar(MAX),
		@options xml,
		@isUnavailable bit,
		@isWanEnabled bit,
		@processorUsageLimitMhz int,
		@memoryUsageLimitMb int
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.CloudConnectHosts]
		SET
			   [providerId] = @providerId,
			   [platform] = @platform,
			   [friendlyName] = @friendlyName,
			   [options] = @options,
			   [isUnavailable] = @isUnavailable,
			   [isWanEnabled] = @isWanEnabled,
			   [processorUsageLimitMhz] = @processorUsageLimitMhz,
			   [memoryUsageLimitMb] = @memoryUsageLimitMb
		WHERE [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- RemoveCloudConnectHost
PRINT N'Creating [dbo].[RemoveCloudConnectHost]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveCloudConnectHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveCloudConnectHost]
GO

	CREATE PROCEDURE [dbo].[RemoveCloudConnectHost]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.CloudConnectHosts] where [id] = @id

	END
GO

--------------------------------------------------------------------------------
-- FindCloudConnectHost
PRINT N'Creating [dbo].[FindCloudConnectHost]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectHost]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectHost]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectHosts] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindCloudConnectHostsByProviderId
PRINT N'Creating [dbo].[FindCloudConnectHostsByProviderId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectHostsByProviderId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectHostsByProviderId]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectHostsByProviderId]
		@providerId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectHosts] where [providerId] = @providerId
	END

GO

--------------------------------------------------------------------------------
-- FindCloudConnectHostsByPlatform
PRINT N'Creating [dbo].[FindCloudConnectHostsByPlatform]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectHostsByPlatform]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectHostsByPlatform]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectHostsByPlatform]
		@platform int
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectHosts] where [platform] = @platform
	END

GO

--------------------------------------------------------------------------------
-- FindCloudConnectHostsByByProviderIdAndPlatform
PRINT N'Creating [dbo].[FindCloudConnectHostsByByProviderIdAndPlatform]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectHostsByByProviderIdAndPlatform]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectHostsByByProviderIdAndPlatform]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectHostsByByProviderIdAndPlatform]
		@providerId uniqueidentifier,
		@platform int
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectHosts] where [providerId] = @providerId and [platform] = @platform
	END

GO

--------------------------------------------------------------------------------
-- FindAllCloudConnectHosts
PRINT N'Creating [dbo].[FindAllCloudConnectHosts]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllCloudConnectHosts]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllCloudConnectHosts]
GO

	CREATE PROCEDURE [dbo].[FindAllCloudConnectHosts]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectHosts]
	END

GO

--------------------------------------------------------------------------------
-- AddCloudConnectStorage
PRINT N'Creating [dbo].[AddCloudConnectStorage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddCloudConnectStorage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddCloudConnectStorage]
GO

	CREATE PROCEDURE [dbo].[AddCloudConnectStorage]
		@id uniqueidentifier,
		@availableHostId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@quotaGb int,
		@usedSizeInBytes bigint,
		@options xml,
		@isUnavailable bit
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.CloudConnectStorages]
			([id],
			[availableHostId],
			[friendlyName],
			[quotaGb],
			[usedSizeInBytes],
			[options],
			[usn],
			[isUnavailable])
			   
		 VALUES
			(@id,
			@availableHostId,
			@friendlyName,
			@quotaGb,
			@usedSizeInBytes,
			@options,
			0,
			@isUnavailable)
	END
GO

--------------------------------------------------------------------------------
-- UpdateCloudConnectStorage
PRINT N'Creating [dbo].[UpdateCloudConnectStorage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateCloudConnectStorage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateCloudConnectStorage]
GO

	CREATE PROCEDURE [dbo].[UpdateCloudConnectStorage]
		@id uniqueidentifier,
		@availableHostId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@quotaGb int,
		@usedSizeInBytes bigint,
		@options xml,
		@isUnavailable bit
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.CloudConnectStorages]
		SET
			[availableHostId] = @availableHostId,
			[friendlyName] = @friendlyName,
			[quotaGb] = @quotaGb,
			[usedSizeInBytes] = @usedSizeInBytes,
			[options] = @options,
			[isUnavailable] = @isUnavailable
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveCloudConnectStorage
PRINT N'Creating [dbo].[RemoveCloudConnectStorage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveCloudConnectStorage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveCloudConnectStorage]
GO

	CREATE PROCEDURE [dbo].[RemoveCloudConnectStorage]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.CloudConnectStorages] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindCloudConnectStorage
PRINT N'Creating [dbo].[FindCloudConnectStorage]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectStorage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectStorage]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectStorage]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectStorages] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindCloudConnectStoragesByHostId
PRINT N'Creating [dbo].[FindCloudConnectStoragesByHostId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectStoragesByHostId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectStoragesByHostId]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectStoragesByHostId]
		@availableHostId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectStorages] where [availableHostId] = @availableHostId
	END

GO

--------------------------------------------------------------------------------
-- FindAllCloudConnectStorages
PRINT N'Creating [dbo].[FindAllCloudConnectStorages]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllCloudConnectStorages]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllCloudConnectStorages]
GO

	CREATE PROCEDURE [dbo].[FindAllCloudConnectStorages]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectStorages]
	END

GO

--------------------------------------------------------------------------------
-- AddCloudConnectNetwork
PRINT N'Creating [dbo].[AddCloudConnectNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddCloudConnectNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddCloudConnectNetwork]
GO

	CREATE PROCEDURE [dbo].[AddCloudConnectNetwork]
		@id uniqueidentifier,
		@availableHostId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@defaultGateway nvarchar(18),
		@isUnavailable bit,
		@hasInternet bit
	AS
	BEGIN
		SET NOCOUNT ON;

		INSERT INTO [dbo].[Backup.Model.CloudConnectNetworks]
			([id],
			[availableHostId],
			[friendlyName],
			[defaultGateway],
			[isUnavailable],
			[hasInternet])
			   
		 VALUES
			(@id,
			@availableHostId,
			@friendlyName,
			@defaultGateway,
			@isUnavailable,
			@hasInternet)
	END
GO

--------------------------------------------------------------------------------
-- UpdateCloudConnectNetwork
PRINT N'Creating [dbo].[UpdateCloudConnectNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateCloudConnectNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateCloudConnectNetwork]
GO

	CREATE PROCEDURE [dbo].[UpdateCloudConnectNetwork]
		@id uniqueidentifier,
		@availableHostId uniqueidentifier,
		@friendlyName nvarchar(MAX),
		@defaultGateway nvarchar(18),
		@isUnavailable bit,
		@hasInternet bit
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.CloudConnectNetworks]
		SET
			[availableHostId] = @availableHostId,
			[friendlyName] = @friendlyName,
			[defaultGateway] = @defaultGateway,
			[isUnavailable] = @isUnavailable,
			[hasInternet] = @hasInternet
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- SetCloudConnectNetworkDefaultGateway
PRINT N'Creating [dbo].[SetCloudConnectNetworkDefaultGateway]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SetCloudConnectNetworkDefaultGateway]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[SetCloudConnectNetworkDefaultGateway]
GO

	CREATE PROCEDURE [dbo].[SetCloudConnectNetworkDefaultGateway]
		@id uniqueidentifier,
		@defaultGateway nvarchar(18)
	AS
	BEGIN
		SET NOCOUNT ON;

		UPDATE [dbo].[Backup.Model.CloudConnectNetworks]
		SET
			[defaultGateway] = @defaultGateway
		WHERE [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- RemoveCloudConnectNetwork
PRINT N'Creating [dbo].[RemoveCloudConnectNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveCloudConnectNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RemoveCloudConnectNetwork]
GO

	CREATE PROCEDURE [dbo].[RemoveCloudConnectNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		delete from [dbo].[Backup.Model.CloudConnectNetworks] where [id] = @id
		
	END
GO

--------------------------------------------------------------------------------
-- FindCloudConnectNetwork
PRINT N'Creating [dbo].[FindCloudConnectNetwork]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectNetwork]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectNetwork]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectNetwork]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectNetworks] where [id] = @id
	END

GO

--------------------------------------------------------------------------------
-- FindCloudConnectNetworksByHostId
PRINT N'Creating [dbo].[FindCloudConnectNetworksByHostId]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindCloudConnectNetworksByHostId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindCloudConnectNetworksByHostId]
GO

	CREATE PROCEDURE [dbo].[FindCloudConnectNetworksByHostId]
		@availableHostId uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectNetworks] where availableHostId = @availableHostId
	END

GO

--------------------------------------------------------------------------------
-- FindAllCloudConnectNetworks
PRINT N'Creating [dbo].[FindAllCloudConnectNetworks]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindAllCloudConnectNetworks]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindAllCloudConnectNetworks]
GO

	CREATE PROCEDURE [dbo].[FindAllCloudConnectNetworks]	
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT * from [dbo].[Backup.Model.CloudConnectNetworks]
	END

GO

--------------------------------------------------------------------------------
-- AddTenantApplianceUsage
PRINT N'Creating [dbo].[AddTenantApplianceUsage]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddTenantApplianceUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddTenantApplianceUsage]
GO
	CREATE PROCEDURE [dbo].[AddTenantApplianceUsage]
		@appliance_id uniqueidentifier,
		@replica_id uniqueidentifier,
		@vm_ip_info xml

	AS
	BEGIN
		SET NOCOUNT ON;	
		
		INSERT INTO	[dbo].[Backup.Model.CloudApplianceTenantSideUsages]
			(	[appliance_id],
				[replica_id],
				[vm_ip_info]
			)
		VALUES
			(	@appliance_id,
				@replica_id,
				@vm_ip_info
			)
	END
GO

--------------------------------------------------------------------------------
-- GetTenantApplianceUsagesByApplianceId
PRINT N'Creating [dbo].[GetTenantApplianceUsagesByApplianceId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetTenantApplianceUsagesByApplianceId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetTenantApplianceUsagesByApplianceId]
GO

	CREATE PROCEDURE [dbo].[GetTenantApplianceUsagesByApplianceId]
		@appliance_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT 
			*
		FROM
			[dbo].[Backup.Model.CloudApplianceTenantSideUsages]
		WHERE
			[appliance_id] = @appliance_id
		
	END

GO

--------------------------------------------------------------------------------
-- GetTenantApplianceUsagesByReplicaId
PRINT N'Creating [dbo].[GetTenantApplianceUsagesByReplicaId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetTenantApplianceUsagesByReplicaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetTenantApplianceUsagesByReplicaId]
GO

	CREATE PROCEDURE [dbo].[GetTenantApplianceUsagesByReplicaId]
		@Replica_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT 
			*
		FROM
			[dbo].[Backup.Model.CloudApplianceTenantSideUsages]
		WHERE
			[Replica_id] = @Replica_id
		
	END

GO

--------------------------------------------------------------------------------
-- DeleteTenantApplianceUsage
PRINT N'Creating [dbo].[DeleteTenantApplianceUsage]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteTenantApplianceUsage]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteTenantApplianceUsage]
GO

	CREATE PROCEDURE [dbo].[DeleteTenantApplianceUsage]
		@appliance_id UNIQUEIDENTIFIER,
		@replica_id UNIQUEIDENTIFIER
	AS
	BEGIN
		SET NOCOUNT ON;	
		DELETE FROM [dbo].[Backup.Model.CloudApplianceTenantSideUsages]			
		WHERE
			[appliance_id] = @appliance_id AND [replica_id] = @replica_id
	END

GO

--------------------------------------------------------------------------------
-- DeleteTenantApplianceUsageByReplicaId
PRINT N'Creating [dbo].[DeleteTenantApplianceUsageByReplicaId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteTenantApplianceUsageByReplicaId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteTenantApplianceUsageByReplicaId]
GO

	CREATE PROCEDURE [dbo].[DeleteTenantApplianceUsageByReplicaId]
		@replica_id UNIQUEIDENTIFIER
	AS
	BEGIN
		SET NOCOUNT ON;	
		DELETE FROM [dbo].[Backup.Model.CloudApplianceTenantSideUsages]			
		WHERE
			[replica_id] = @replica_id
	END

GO

--------------------------------------------------------------------------------
-- GetTenantApplianceUsages
PRINT N'Creating [dbo].[GetTenantApplianceUsages]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetTenantApplianceUsages]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetTenantApplianceUsages]
GO

	CREATE PROCEDURE [dbo].[GetTenantApplianceUsages]
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT 
			*
		FROM
			[dbo].[Backup.Model.CloudApplianceTenantSideUsages]
	END
GO

--------------------------------------------------------------------------------
-- SetCloudProviderReportingStateChanged
PRINT N'Creating [dbo].[SetCloudProviderReportingStateChanged]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SetCloudProviderReportingStateChanged]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[SetCloudProviderReportingStateChanged]
GO

	CREATE PROCEDURE [dbo].[SetCloudProviderReportingStateChanged]
		@providerId uniqueidentifier
	AS
	BEGIN
		SET XACT_ABORT ON;
		declare @usn bigint
		exec [dbo].[IncrementUsn] @usn OUTPUT
		

		BEGIN TRAN

		UPDATE [dbo].[Backup.Model.CloudProviders.Reporting] WITH (serializable)
		SET
			[usn] = @usn
		WHERE [providerId] = @providerId
			
		IF @@rowcount = 0
		BEGIN
			INSERT INTO [dbo].[Backup.Model.CloudProviders.Reporting] (
				[providerId],
				[usn])
			
			VALUES
				(@providerId,
				@usn)
		END

		COMMIT TRAN
	END
GO

--------------------------------------------------------------------------------
-- SetCloudProviderReportingUsn
PRINT N'Creating [dbo].[SetCloudProviderReportingUsn]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SetCloudProviderReportingUsn]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[SetCloudProviderReportingUsn]
GO

	CREATE PROCEDURE [dbo].[SetCloudProviderReportingUsn]
		@providerId uniqueidentifier,
		@providerUsn bigint
	AS
	BEGIN
		SET XACT_ABORT ON;
		declare @usn bigint
		exec [dbo].[IncrementUsn] @usn OUTPUT

		BEGIN TRAN

		UPDATE [dbo].[Backup.Model.CloudProviders.Reporting] WITH (serializable)
		SET
			[usn] = @usn,
			[providerUsn] = @providerUsn
		WHERE [providerId] = @providerId
			
		IF @@rowcount = 0
		BEGIN
			INSERT INTO [dbo].[Backup.Model.CloudProviders.Reporting] (
				[providerId],
				[usn],
				[providerUsn])
			
			VALUES
				(@providerId,
				@usn,
				@providerUsn)
		END

		COMMIT TRAN
	END
GO

--------------------------------------------------------------------------------
-- IsCloudProviderReportingStateChanged
PRINT N'Creating [dbo].[IsCloudProviderReportingStateChanged]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IsCloudProviderReportingStateChanged]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[IsCloudProviderReportingStateChanged]
GO

	CREATE PROCEDURE [dbo].[IsCloudProviderReportingStateChanged]
		@providerId uniqueidentifier,
		@usn bigint
	AS
	BEGIN

		SELECT CAST(
			CASE WHEN EXISTS(SELECT 1 FROM [dbo].[Backup.Model.CloudProviders.Reporting] where providerId = @providerId and usn > @usn)
				THEN 1 
				ELSE 0 
			END 
		AS BIT)

	END
GO