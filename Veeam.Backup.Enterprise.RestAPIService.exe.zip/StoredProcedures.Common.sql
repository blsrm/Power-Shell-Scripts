﻿
--------------------------------------------------------------------------------
-- DropIndex
PRINT N'Creating [dbo].[DropIndex]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[DropIndex]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[DropIndex];
GO

CREATE PROCEDURE [dbo].[DropIndex]
    @table_name VARCHAR(MAX) ,
    @index_name VARCHAR(MAX)
AS
    BEGIN

        DECLARE @sql NVARCHAR(1000);
        SET @sql = 'DROP INDEX [' + @index_name + '] on [' + @table_name
            + '];';
	
        EXEC sp_executesql @sql;
    END;

GO

--------------------------------------------------------------------------------
-- [DropForeignKey]
PRINT N'Creating [dbo].[DropForeignKey]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[DropForeignKey]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[DropForeignKey];
GO


CREATE PROCEDURE [dbo].[DropForeignKey]
    @table_name VARCHAR(MAX) ,
    @FK_name VARCHAR(MAX)
AS
    BEGIN

        DECLARE @sql NVARCHAR(1000);
        SET @sql = 'ALTER TABLE [' + @table_name + '] DROP [' + @FK_name
            + '];';
	
        EXEC sp_executesql @sql;
    END;

GO


--------------------------------------------------------------------------------
-- [DropPrimaryKey]
PRINT N'Creating [dbo].[DropPrimaryKey]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[DropPrimaryKey]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[DropPrimaryKey];
GO

CREATE PROCEDURE [dbo].[DropPrimaryKey]
    @table_name VARCHAR(MAX) ,
    @PK_name VARCHAR(MAX)
AS
    BEGIN

        DECLARE @sql NVARCHAR(1000);
        SET @sql = 'ALTER TABLE [' + @table_name + '] DROP [' + @PK_name + ']';
	
        EXEC sp_executesql @sql;
    END;

GO


--------------------------------------------------------------------------------
-- [CreateForeignKey]
PRINT N'Creating [dbo].[CreateForeignKey]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CreateForeignKey]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CreateForeignKey];
GO


CREATE PROCEDURE [dbo].[CreateForeignKey]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX) ,
    @referenced_table_name VARCHAR(MAX) ,
    @referenced_column_names VARCHAR(MAX)
AS
    BEGIN

	
        DECLARE @column_names_underscored VARCHAR(MAX);
        SELECT  @column_names_underscored = ( SELECT    [dbo].[ConvertToUnderscoredString](@column_names)
                                            );

        DECLARE @fk_name VARCHAR(MAX);
        SET @fk_name = 'FK_' + @table_name + '_' + @referenced_table_name;

        DECLARE @sql NVARCHAR(1000);
        SET @sql = 'ALTER TABLE [' + @table_name
            + '] WITH NOCHECK ADD CONSTRAINT [' + @fk_name + '] 
		FOREIGN KEY (' + @column_names + ') 
		REFERENCES [' + @referenced_table_name + '] ('
            + @referenced_column_names + '); ' + 'ALTER TABLE [' + @table_name
            + '] CHECK CONSTRAINT [' + @fk_name + '];'; 
	
	
        EXEC sp_executesql @sql;

    END;

GO


--------------------------------------------------------------------------------
-- [CreateNonClusteredIndex]
PRINT N'Creating [dbo].[CreateNonClusteredIndex]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CreateNonClusteredIndex]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CreateNonClusteredIndex];
GO


CREATE PROCEDURE [dbo].[CreateNonClusteredIndex]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX) ,
    @include_columns VARCHAR(MAX) = NULL
AS
    BEGIN
        DECLARE @index_type VARCHAR(MAX);
        SET @index_type = 'NonClustered';
        IF ( ( SELECT   [dbo].[CheckIfIndexWithTheSameNameExists](@table_name,
                                                              @column_names,
                                                              @index_type,
                                                              @include_columns)
             ) = 0 )
            BEGIN
                IF ( @include_columns IS NOT NULL )
                    BEGIN
                        EXEC [dbo].[CreateIndexWithIncludeColumns] @table_name,
                            @column_names, @include_columns;
                    END;
                ELSE
                    IF ( ( SELECT   [dbo].[CheckIfIndexExistsByColumnNames](@table_name,
                                                              @column_names,
                                                              @index_type) AS result
                         ) = 1 )
                        PRINT 'Requested index on ' + @table_name
                            + ' table already exists';
                IF ( ( SELECT   [dbo].[CheckIfIndexExistsByColumnNames](@table_name,
                                                              @column_names,
                                                              @index_type) AS result
                     ) = 0 )
                    BEGIN
                        EXEC [dbo].[CreateIndex] @table_name, @column_names,
                            @index_type;
                        IF @@ERROR = 0
                            PRINT 'Nonclustered index was created on table '
                                + @table_name + ', columns ' + @column_names;
                    END;
            END;
        ELSE
            PRINT 'Index with the same name already exists';
    END;


GO


--------------------------------------------------------------------------------
-- [CreatePrimaryKey]
PRINT N'Creating [dbo].[CreatePrimaryKey]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CreatePrimaryKey]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CreatePrimaryKey];
GO

CREATE PROCEDURE [dbo].[CreatePrimaryKey]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX) ,
    @index_type VARCHAR(MAX)
AS
    BEGIN

        DECLARE @column_names_underscored VARCHAR(MAX);
        SELECT  @column_names_underscored = ( SELECT    [dbo].[ConvertToUnderscoredString](@column_names)
                                            );

        DECLARE @pk_name VARCHAR(MAX);
        SET @pk_name = 'PK_' + @table_name + '_' + @column_names_underscored;


        DECLARE @sql VARCHAR(300);
        SELECT  @sql = 'ALTER TABLE [' + ( @table_name )
                + '] WITH CHECK ADD CONSTRAINT [' + ( @pk_name )
                + '] PRIMARY KEY ' + @index_type + ' (' + @column_names + ')';

        EXEC(@sql);

    END;

GO


--------------------------------------------------------------------------------
-- [CreatePrimaryKeyWithClusteredIndex]
PRINT N'Creating [dbo].[CreatePrimaryKeyWithClusteredIndex]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CreatePrimaryKeyWithClusteredIndex]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CreatePrimaryKeyWithClusteredIndex];
GO


CREATE PROCEDURE [dbo].[CreatePrimaryKeyWithClusteredIndex]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX)
AS
    BEGIN

        DECLARE @index_type VARCHAR(100);
        SET @index_type = 'Clustered';

        EXEC [CreatePrimaryKeyWithIndex] @table_name, @column_names,
            @index_type;

    END;

GO


--------------------------------------------------------------------------------
-- [RecreateClusteredIndex]
PRINT N'Creating [dbo].[RecreateClusteredIndex]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[RecreateClusteredIndex]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[RecreateClusteredIndex];
GO

CREATE PROCEDURE [dbo].[RecreateClusteredIndex]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX)
AS
    BEGIN
        DECLARE @index_type VARCHAR(MAX);
        SET @index_type = 'CLUSTERED';
        DECLARE @table_name_bracketed VARCHAR(MAX);
        SET @table_name_bracketed = '[' + @table_name + ']';
        DECLARE @clustered_index_name VARCHAR(100);
        SET @clustered_index_name = ( SELECT    name
                                      FROM      sys.indexes
                                      WHERE     object_id = OBJECT_ID(@table_name_bracketed)
                                                AND type = 1
                                    );
        DECLARE @matching_nonclustered_PK VARCHAR(MAX);
        SET @matching_nonclustered_PK = ( SELECT    *
                                          FROM      [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames](@table_name,
                                                              @column_names)
                                        );

	-- Check that primary key is nonclustered and PK doesn't match clustered index columns --
        IF EXISTS ( SELECT  *
                    FROM    sys.indexes AS i
                            INNER JOIN sys.index_columns AS ic ON i.object_id = ic.object_id
                                                              AND i.index_id = ic.index_id
                    WHERE   i.is_primary_key = 1
                            AND i.type <> 1
                            AND OBJECT_NAME(ic.object_id) = @table_name )
            AND @matching_nonclustered_PK IS NULL
            BEGIN
                EXEC [dbo].[DropIndex] @table_name, @clustered_index_name;
                EXEC [CreateIndex] @table_name, @column_names, @index_type;
            END;
	-- Else we need to handle primary and foreign keys first --
        ELSE
	-- Find and drop dependent foreign keys before dropping the primary key --
            DECLARE @foreign_keys_parent_index VARCHAR(MAX);
        IF @matching_nonclustered_PK IS NULL
            SET @foreign_keys_parent_index = @clustered_index_name;
        ELSE
            SET @foreign_keys_parent_index = @matching_nonclustered_PK;
		
        IF OBJECT_ID('tempdb..#fk_info') IS NOT NULL
            DROP TABLE #fk_info;
        BEGIN 
            SELECT  * ,
                    DENSE_RANK() OVER ( ORDER BY fk_name ) AS index_number
            INTO    #fk_info
            FROM    [dbo].[FindForeignKeysByTableAndIndexName](@table_name,
                                                              @foreign_keys_parent_index)
            ORDER BY fk_name ,
                    column_id;
            DECLARE @fk_table_name VARCHAR(MAX);
            DECLARE @fk_name VARCHAR(MAX);
            DECLARE cur CURSOR LOCAL FAST_FORWARD
            FOR
                SELECT  fk_table_name ,
                        fk_name
                FROM    #fk_info;
            OPEN cur;
            FETCH NEXT FROM cur INTO @fk_table_name, @fk_name;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    EXEC [dbo].[DropForeignKey] @fk_table_name, @fk_name;
                    FETCH NEXT FROM cur INTO @fk_table_name, @fk_name;
                END;
            CLOSE cur;
            DEALLOCATE cur;
        END;
        IF EXISTS ( SELECT  *
                    FROM    [dbo].[FindPrimaryKeyByTable](@table_name) )
            BEGIN
	-- Save primary key columns before dropping--
                SELECT  *
                INTO    #pk_columns
                FROM    [FindPrimaryKeyColumnsByTable](@table_name); 
                DECLARE @pk_name VARCHAR(MAX);
	-- Drop primary key before recreating the clustered index --
                SET @pk_name = ( SELECT *
                                 FROM   [dbo].[FindPrimaryKeyByTable](@table_name)
                               );
                EXEC [dbo].[DropPrimaryKey] @table_name, @pk_name;
            END;
        IF EXISTS ( SELECT  *
                    FROM    sys.indexes
                    WHERE   object_id = OBJECT_ID(@table_name_bracketed)
                            AND type = 1 )
            BEGIN
                EXEC [dbo].[DropIndex] @table_name, @clustered_index_name;
            END;
	-- Check if we can simply replace nonclustered primary key with clustered one --	
        IF ( @matching_nonclustered_PK IS NOT NULL )
            BEGIN
                EXEC [CreatePrimaryKey] @table_name, @column_names,
                    'Clustered';
            END;
        ELSE
            BEGIN
	-- Otherwise, first create clustered index --
                EXEC [CreateIndex] @table_name, @column_names, @index_type;
	-- And then recreate primary key -- 
                IF OBJECT_ID('tempdb..#pk_columns') IS NOT NULL
                    BEGIN
                        DECLARE @primary_key_columns VARCHAR(MAX);
                        SET @primary_key_columns = '';
                        SELECT  @primary_key_columns = @primary_key_columns
                                + columns + ','
                        FROM    #pk_columns;
                        SELECT  @primary_key_columns = SUBSTRING(@primary_key_columns,
                                                              1,
                                                              LEN(@primary_key_columns)
                                                              - 1);
                        EXEC [CreatePrimaryKey] @table_name,
                            @primary_key_columns, 'NonClustered';
                    END;
            END;
	-- Recreate foreign keys
        IF OBJECT_ID('tempdb..#fk_info') IS NOT NULL
            BEGIN
                DECLARE @fk_table_name_to_create VARCHAR(MAX);
                DECLARE @fk_column_names VARCHAR(MAX);
                DECLARE @referenced_column_names VARCHAR(MAX);
                DECLARE @referenced_table_name VARCHAR(MAX);
                DECLARE @number_of_indexes INT;
                SET @number_of_indexes = ( SELECT   MAX(index_number)
                                           FROM     #fk_info
                                         );
                DECLARE @i INT;
                SET @i = 0;
                WHILE ( @i < @number_of_indexes )
                    BEGIN
                        SET @fk_table_name_to_create = ( SELECT DISTINCT
                                                              FK_TABLE_NAME
                                                         FROM #fk_info
                                                         WHERE
                                                              index_number = @i
                                                       );
                        SET @fk_column_names = '';
                        IF EXISTS ( SELECT  column_name + ','
                                    FROM    #fk_info
                                    WHERE   index_number = @i )
                            BEGIN
                                SELECT  @fk_column_names = @fk_column_names
                                        + column_name + ','
                                FROM    #fk_info
                                WHERE   index_number = @i;
                                SELECT  @fk_column_names = SUBSTRING(@fk_column_names,
                                                              1,
                                                              LEN(@fk_column_names)
                                                              - 1);
                                SET @referenced_table_name = ( SELECT DISTINCT
                                                              REFERENCED_TABLE_NAME
                                                              FROM
                                                              #fk_info
                                                              WHERE
                                                              index_number = @i
                                                             );
                                SET @referenced_column_names = '';
                                SELECT  @referenced_column_names = @referenced_column_names
                                        + referenced_column_name + ','
                                FROM    #fk_info
                                WHERE   index_number = @i;
                                SELECT  @referenced_column_names = SUBSTRING(@referenced_column_names,
                                                              1,
                                                              LEN(@referenced_column_names)
                                                              - 1);
                                EXEC [CreateForeignKey] @fk_table_name_to_create,
                                    @fk_column_names, @referenced_table_name,
                                    @referenced_column_names;
                            END;
                        SET @i = @i + 1;
                    END;
            END;
-- Check is there's nonclustered index on the same columns and drop them --
        IF ( ( SELECT   [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames](@table_name,
                                                              @column_names) AS result
             ) = 1 )
            BEGIN
                PRINT 'Dropping redundant nonclustered indexes';
                EXEC [dbo].[DropNonClusteredIndexesByColumnNames] @table_name,
                    @column_names;
            END;
    END;


GO

--------------------------------------------------------------------------------
-- [CreateIndex]
PRINT N'Creating [dbo].[CreateIndex]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CreateIndex]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CreateIndex];
GO

CREATE PROCEDURE [dbo].[CreateIndex]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX) ,
    @index_type VARCHAR(MAX)
AS
    BEGIN

        DECLARE @column_names_underscored VARCHAR(MAX);
        SELECT  @column_names_underscored = ( SELECT    [dbo].[ConvertToUnderscoredString](@column_names)
                                            );

        DECLARE @index_name VARCHAR(MAX);

        IF ( @index_type = 'Clustered' )
            SET @index_name = 'CI_' + @table_name + '_'
                + @column_names_underscored;

        IF ( @index_type = 'NonClustered' )
            SET @index_name = 'IX_' + @table_name + '_'
                + @column_names_underscored;

		SET @index_name = SUBSTRING(@index_name, 1, 120)

        DECLARE @sql NVARCHAR(MAX);
        SET @sql = 'CREATE ' + @index_type + ' INDEX [' + @index_name
            + '] ON dbo.[' + @table_name + ']' + CHAR(13) + CHAR(10) + '('
            + CHAR(13) + CHAR(10) + '	' + @column_names + ' ASC' + CHAR(13)
            + CHAR(10) + ')' + CHAR(13) + CHAR(10)
            + 'WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]';

        EXEC(@sql);

    END;

GO


--------------------------------------------------------------------------------
-- [CreateIndexWithIncludeColumns]
PRINT N'Creating [dbo].[CreateIndexWithIncludeColumns]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CreateIndexWithIncludeColumns]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CreateIndexWithIncludeColumns];
GO


CREATE PROCEDURE [dbo].[CreateIndexWithIncludeColumns]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX) ,
    @include_columns VARCHAR(MAX)
AS
    BEGIN
        DECLARE @column_names_underscored VARCHAR(MAX);
        SELECT  @column_names_underscored = ( SELECT    [dbo].[ConvertToUnderscoredString](@column_names)
                                            );
        SELECT  @column_names_underscored = @column_names_underscored + '_'
                + ( SELECT  [dbo].[ConvertToUnderscoredString](@include_columns)
                  );
        DECLARE @index_name VARCHAR(MAX);
        SET @index_name = 'IX_' + @table_name + '_'
            + @column_names_underscored;

		SET @index_name = SUBSTRING(@index_name, 1, 120)

        DECLARE @sql NVARCHAR(MAX);
        SET @sql = 'CREATE NONCLUSTERED' + ' INDEX [' + @index_name
            + '] ON dbo.[' + @table_name + ']' + CHAR(13) + CHAR(10) + '('
            + CHAR(13) + CHAR(10) + '	' + @column_names + ' ASC' + CHAR(13)
            + CHAR(10) + ')' + CHAR(13) + CHAR(10) + 'INCLUDE (' + CHAR(13)
            + CHAR(10) + @include_columns + ')'
            + 'WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]';
        EXEC(@sql);
    END;


GO


--------------------------------------------------------------------------------
-- [CheckAndCreateIndexWithIncludeColumns]
PRINT N'Creating [dbo].[CheckAndCreateIndexWithIncludeColumns]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CheckAndCreateIndexWithIncludeColumns]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CheckAndCreateIndexWithIncludeColumns];
GO

CREATE PROCEDURE [dbo].[CheckAndCreateIndexWithIncludeColumns]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX) ,
    @include_columns VARCHAR(MAX)
AS
    BEGIN

        DECLARE @index_type VARCHAR(MAX);
        SET @index_type = 'NonClustered';

        IF ( ( SELECT   [dbo].[CheckIfIndexExistsByColumnNames](@table_name,
                                                              @column_names,
                                                              @index_type) AS result
             ) = 1 )
            PRINT 'Requested index on ' + @table_name
                + ' table already exists';

        IF ( ( SELECT   [dbo].[CheckIfIndexExistsByColumnNames](@table_name,
                                                              @column_names,
                                                              @index_type) AS result
             ) = 0 )
            BEGIN
                EXEC [dbo].[CreateIndexWithIncludeColumns] @table_name,
                    @column_names, @include_columns;

                IF @@ERROR = 0
                    PRINT 'Index was successfully added';
            END;
    END;

GO


--------------------------------------------------------------------------------
-- [DropNonClusteredIndexesByColumnNames]
PRINT N'Creating [dbo].[DropNonClusteredIndexesByColumnNames]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[DropNonClusteredIndexesByColumnNames]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[DropNonClusteredIndexesByColumnNames];
GO

CREATE PROCEDURE [dbo].[DropNonClusteredIndexesByColumnNames]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX)
AS
    BEGIN

        SELECT  *
        INTO    #index_names
        FROM    [dbo].[GetNonClusteredIndexNamesByColumnNames](@table_name,
                                                              @column_names);

        DECLARE @index_name VARCHAR(MAX);

        DECLARE cur CURSOR LOCAL FAST_FORWARD
        FOR
            SELECT  index_name
            FROM    #index_names;

        OPEN cur;
        FETCH NEXT FROM cur INTO @index_name;
        WHILE @@FETCH_STATUS = 0
            BEGIN
                EXEC [dbo].[DropIndex] @table_name, @index_name;
                FETCH NEXT FROM cur INTO @index_name;
            END;
        CLOSE cur;
        DEALLOCATE cur;
    END;

GO


--------------------------------------------------------------------------------
-- [CreateClusteredIndex]
PRINT N'Creating [dbo].[CreateClusteredIndex]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CreateClusteredIndex]')
                    AND type IN ( N'P', N'PC' ) )
    DROP PROCEDURE [dbo].[CreateClusteredIndex];
GO

CREATE PROCEDURE [dbo].[CreateClusteredIndex]
    @table_name VARCHAR(MAX) ,
    @column_names VARCHAR(MAX)
AS
    BEGIN
        DECLARE @index_type VARCHAR(MAX);
        SET @index_type = 'CLUSTERED';
        DECLARE @table_name_bracketed VARCHAR(MAX);
        SET @table_name_bracketed = '[' + @table_name + ']';

-- Check if there's a matching nonclustered primary key that we want to drop --

        IF ( ( SELECT   [dbo].[CheckIfIndexWithTheSameNameExists](@table_name,
                                                              @column_names,
                                                              @index_type,
                                                              NULL)
             ) = 0 )
            BEGIN
                IF EXISTS ( SELECT  *
                            FROM    [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames](@table_name,
                                                              @column_names) )
                    BEGIN
                        EXEC [RecreateClusteredIndex] @table_name,
                            @column_names;
                        IF @@ERROR = 0
                            PRINT 'Clustered index was created on table '
                                + @table_name + ', columns ' + @column_names;
                    END;
                ELSE
-- Check if there's already a clustered index. --
                    IF EXISTS ( SELECT  *
                                FROM    sys.indexes
                                WHERE   object_id = OBJECT_ID(@table_name_bracketed)
                                        AND type = 1 )
                        BEGIN
-- Check if clustered Index is the one we need. --
                            IF ( ( SELECT   [dbo].[CheckIfIndexExistsByColumnNames](@table_name,
                                                              @column_names,
                                                              @index_type) AS result
                                 ) = 1 )
                                BEGIN
                                    PRINT 'Requested index on ' + @table_name
                                        + ' table already exists';
                                END;
-- Else we need to recreate a clustered index on the required column --
                            ELSE
                                BEGIN
                                    EXEC [RecreateClusteredIndex] @table_name,
                                        @column_names;
                                    IF @@ERROR = 0
                                        PRINT 'Clustered index was created on table '
                                            + @table_name + ', columns '
                                            + @column_names;
                                END;
                        END;

-- If there's no clustered index on the table just create it --
                    ELSE
                        BEGIN
                            EXEC [CreateIndex] @table_name, @column_names,
                                @index_type;
                            IF @@ERROR = 0
                                PRINT 'Clustered index was created on table '
                                    + @table_name + ', columns '
                                    + @column_names;
                        END;
            END;
        ELSE
            PRINT 'Index with the same name already exists';
    END;

GO


