﻿-- 2616

--------------------------------------------------------------------------------
--
-- Begin Upgrade
--
--------------------------------------------------------------------------------
SET NOCOUNT ON

DECLARE @db_version int
SET @db_version = (SELECT max([current_version]) FROM [dbo].[Version])

PRINT ''
PRINT 'Begin database upgrade...'
PRINT [dbo].[System.FormatString]('\t[Time Stamp]="%s"', convert(varchar, getdate(), 113))
PRINT [dbo].[System.TransformCppText]('\t[Current Version]="8.0"')
PRINT [dbo].[System.TransformCppText]('\t[Next Version]="9.0"')
PRINT [dbo].[System.FormatString]('\t[Database Version]="%s"', @db_version)
PRINT [dbo].[System.FormatString]('\t[Server Name]="%s"', @@servername)
PRINT [dbo].[System.FormatString]('\t[Process ID]="%s"', @@spid)
PRINT [dbo].[System.FormatString]('\t[User Name]="%s"', SYSTEM_USER)
PRINT ''

GO


-------------------------------------------------------------------------------
--
-- [dbo].[Temp.XmlNodeExist]
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[Temp.XmlNodeExist]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.XmlNodeExist]'
GO

	CREATE FUNCTION [dbo].[Temp.XmlNodeExist] (
		@xml as xml,
		@name as nvarchar(255))
	RETURNS bit
	AS
	BEGIN
		RETURN CASE WHEN (@xml.exist('//*[local-name() = sql:variable("@name")]') = 0)
			THEN 0
			ELSE 1
		END
	END
GO

-------------------------------------------------------------------------------
--
-- [dbo].[Temp.XmlNodeValue]
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[Temp.XmlNodeValue]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.XmlNodeValue]'
GO

	CREATE FUNCTION [dbo].[Temp.XmlNodeValue] (
		@xml as xml,
		@name as nvarchar(255),
		@default as nvarchar(max))
	RETURNS nvarchar(max)
	AS
	BEGIN
		RETURN CASE WHEN (@xml.exist('//*[local-name() = sql:variable("@name")]') = 0)
			THEN @default
			ELSE @xml.value('(//*[local-name() = sql:variable("@name")])[1]', 'nvarchar(max)')
		END
	END
GO

-------------------------------------------------------------------------------
--
-- [dbo].[Temp.ConvertTransactionLogsProcessing]
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[Temp.ConvertTransactionLogsProcessing]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.ConvertTransactionLogsProcessing]'
GO

	CREATE FUNCTION [dbo].[Temp.ConvertTransactionLogsProcessing] (
		@name as nvarchar(255))
	RETURNS int
	AS
	BEGIN
		DECLARE @result as int

		SET @result = CASE @name
			WHEN 'Never' THEN 0
			WHEN 'OnlyOnSuccessJob' THEN 1
			WHEN 'Always' THEN 1
			ELSE 1
		END

		RETURN @result
	END
GO

-------------------------------------------------------------------------------
--
-- [dbo].[Temp.ConvertGuestIndexingType]
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[Temp.ConvertGuestIndexingType]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.ConvertGuestIndexingType]'
GO

	CREATE FUNCTION [dbo].[Temp.ConvertGuestIndexingType] (
		@name as nvarchar(255))
	RETURNS int
	AS
	BEGIN
		DECLARE @result as int

		SET @result = CASE @name
			WHEN 'EveryFolders' THEN 1
			WHEN 'ExceptSpecifiedFolders' THEN 3
			WHEN 'SpecifiedFolders' THEN 2
			ELSE 0
		END

		RETURN @result
	END
GO

-------------------------------------------------------------------------------
--
-- [dbo].[Temp.ConvertVssOptions]
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[Temp.ConvertVssOptions]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.ConvertVssOptions]'
GO

	CREATE FUNCTION [dbo].[Temp.ConvertVssOptions] (
		@vss_options as xml)
	RETURNS xml
	AS
	BEGIN
		DECLARE @result as xml

		IF @vss_options.exist('/*') = 0
		BEGIN
			RETURN @result
		END

		IF @vss_options.exist('/GuestProcessingOptions') = 1
		BEGIN
			RETURN @vss_options
		END

		-- <GuestProcessingOptions>
		SET @result = '<GuestProcessingOptions/>'

		IF @vss_options.value('count(/*/*)', 'int') = 0
		BEGIN
			RETURN @result
		END

		DECLARE @value nvarchar(max)
		DECLARE @xml xml

		-- <GuestProcessingOptions><IsFirstUsage>
		SET @value = [dbo].[Temp.XmlNodeValue](@vss_options, 'IsFirstUsage', 'True')
		SET @result.modify('insert <IsFirstUsage>{sql:variable("@value")}</IsFirstUsage> as last into (/*)[1]')

		-- <GuestProcessingOptions><VssSnapshotOptions>
		SET @result.modify('insert <VssSnapshotOptions/> as last into (/GuestProcessingOptions)[1]')

		-- <GuestProcessingOptions><VssSnapshotOptions><Enabled>
		SET @value = [dbo].[Temp.XmlNodeValue](@vss_options, 'Enabled', 'False')
		SET @result.modify('insert <Enabled>{sql:variable("@value")}</Enabled> as last into (/GuestProcessingOptions/VssSnapshotOptions)[1]')

		-- <GuestProcessingOptions><VssSnapshotOptions><IgnoreErrors>
		SET @value = [dbo].[Temp.XmlNodeValue](@vss_options, 'IgnoreErrors', 'True')
		SET @result.modify('insert <IgnoreErrors>{sql:variable("@value")}</IgnoreErrors> as last into (/GuestProcessingOptions/VssSnapshotOptions)[1]')

		-- <GuestProcessingOptions><VssSnapshotOptions><IsCopyOnly>
		SET @value = [dbo].[Temp.XmlNodeValue](@vss_options, 'TransactionLogsTruncation', 'TruncateOnlyOnSuccessJob')
		SET @value = [dbo].[Temp.ConvertTransactionLogsProcessing](@value)

		IF @value = 0
		BEGIN
			SET @result.modify('insert <IsCopyOnly>True</IsCopyOnly> as last into (/GuestProcessingOptions/VssSnapshotOptions)[1]')
		END

		-- <GuestProcessingOptions><SqlBackupOptions>
		SET @result.modify('insert <SqlBackupOptions/> as last into (/GuestProcessingOptions)[1]')
		SET @result.modify('insert <TransactionLogsProcessing>{sql:variable("@value")}</TransactionLogsProcessing> as last into (/GuestProcessingOptions/SqlBackupOptions)[1]')

		-- <GuestProcessingOptions><ExchangeBackupOptions>
		SET @result.modify('insert <ExchangeBackupOptions/> as last into (/GuestProcessingOptions)[1]')

		-- <GuestProcessingOptions><WinGuestFSIndexingOptions>
		SET @result.modify('insert <WinGuestFSIndexingOptions/> as last into (/GuestProcessingOptions)[1]')
		SET @value = [dbo].[Temp.XmlNodeValue](@vss_options, 'GuestFSIndexingType', 'None')
		SET @value = [dbo].[Temp.ConvertGuestIndexingType](@value)

		-- <GuestProcessingOptions><WinGuestFSIndexingOptions><Type>
		SET @result.modify('insert <Type>{sql:variable("@value")}</Type> as last into (/GuestProcessingOptions/WinGuestFSIndexingOptions)[1]')

		-- <GuestProcessingOptions><WinGuestFSIndexingOptions><IncludedFolders>
		SET @result.modify('insert <IncludedFolders/> as last into (/GuestProcessingOptions/WinGuestFSIndexingOptions)[1]')

		IF @vss_options.exist('/CVssOptions/IncludedIndexingFolders/*') = 1
		BEGIN
			SET @xml = (SELECT T.c.value('.', 'nvarchar(max)') as [Folder] FROM @vss_options.nodes('/CVssOptions/IncludedIndexingFolders/*') T(c) FOR XML RAW (''), ELEMENTS)
			SET @result = (SELECT @result, @xml 'TempNode' FOR XML PATH(''), TYPE)
			SET @result.modify('insert /TempNode/* into (/GuestProcessingOptions/WinGuestFSIndexingOptions/IncludedFolders)[1]')
			SET @result.modify('delete /TempNode')
		END

		-- <GuestProcessingOptions><WinGuestFSIndexingOptions><ExcludedFolders>
		SET @result.modify('insert <ExcludedFolders/> as last into (/GuestProcessingOptions/WinGuestFSIndexingOptions)[1]')

		IF @vss_options.exist('/CVssOptions/ExcludedIndexingFolders/*') = 1
		BEGIN
			SET @xml = (SELECT T.c.value('.', 'nvarchar(max)') as [Folder] FROM @vss_options.nodes('/CVssOptions/ExcludedIndexingFolders/*') T(c) FOR XML RAW (''), ELEMENTS)
			SET @result = (SELECT @result, @xml 'TempNode' FOR XML PATH(''), TYPE)
			SET @result.modify('insert /TempNode/* into (/GuestProcessingOptions/WinGuestFSIndexingOptions/ExcludedFolders)[1]')
			SET @result.modify('delete /TempNode')
		END

		-- <GuestProcessingOptions><LinGuestFSIndexingOptions>
		SET @result.modify('insert <LinGuestFSIndexingOptions/> as last into (/GuestProcessingOptions)[1]')
		SET @value = [dbo].[Temp.XmlNodeValue](@vss_options, 'LinGuestFSIndexingType', 'None')
		SET @value = [dbo].[Temp.ConvertGuestIndexingType](@value)

		-- <GuestProcessingOptions><LinGuestFSIndexingOptions><Type>
		SET @result.modify('insert <Type>{sql:variable("@value")}</Type> as last into (/GuestProcessingOptions/LinGuestFSIndexingOptions)[1]')

		-- <GuestProcessingOptions><LinGuestFSIndexingOptions><IncludedFolders>
		SET @result.modify('insert <IncludedFolders/> as last into (/GuestProcessingOptions/LinGuestFSIndexingOptions)[1]')

		IF @vss_options.exist('/CVssOptions/LinIncludedIndexingFolders/*') = 1
		BEGIN
			SET @xml = (SELECT T.c.value('.', 'nvarchar(max)') as [Folder] FROM @vss_options.nodes('/CVssOptions/LinIncludedIndexingFolders/*') T(c) FOR XML RAW (''), ELEMENTS)
			SET @result = (SELECT @result, @xml 'TempNode' FOR XML PATH(''), TYPE)
			SET @result.modify('insert /TempNode/* into (/GuestProcessingOptions/LinGuestFSIndexingOptions/IncludedFolders)[1]')
			SET @result.modify('delete /TempNode')
		END

		-- <GuestProcessingOptions><LinGuestFSIndexingOptions><ExcludedFolders>
		SET @result.modify('insert <ExcludedFolders/> as last into (/GuestProcessingOptions/LinGuestFSIndexingOptions)[1]')

		IF @vss_options.exist('/CVssOptions/LinExcludedIndexingFolders/*') = 1
		BEGIN
			SET @xml = (SELECT T.c.value('.', 'nvarchar(max)') as [Folder] FROM @vss_options.nodes('/CVssOptions/LinExcludedIndexingFolders/*') T(c) FOR XML RAW (''), ELEMENTS)
			SET @result = (SELECT @result, @xml 'TempNode' FOR XML PATH(''), TYPE)
			SET @result.modify('insert /TempNode/* into (/GuestProcessingOptions/LinGuestFSIndexingOptions/ExcludedFolders)[1]')
			SET @result.modify('delete /TempNode')
		END

		--<GuestProcessingOptions><WinCredsId>
		--SET @result.modify('insert <WinCredsId>00000000-0000-0000-0000-000000000000</WinCredsId> as last into (/GuestProcessingOptions)[1]')

		--<GuestProcessingOptions><LinCredsId>
		--SET @result.modify('insert <LinCredsId>00000000-0000-0000-0000-000000000000</LinCredsId> as last into (/GuestProcessingOptions)[1]')

		--<GuestProcessingOptions><OracleBackupOptions><SysdbaCredsId>
		--SET @result.modify('insert <OracleBackupOptions><SysdbaCredsId>00000000-0000-0000-0000-000000000000</SysdbaCredsId></OracleBackupOptions> as last into (/GuestProcessingOptions)[1]')

		RETURN @result
	END
GO


--------------------------------------------------------------------------------
--
-- Job VSS Options Upgrade
--
--------------------------------------------------------------------------------
PRINT 'Begin upgrading job VSS options'

DECLARE @count int
SET @count = 0

DECLARE backup_jobs_cursor CURSOR FOR
SELECT
	[id],
	[name],
	[type],
	[vss_options]
FROM
	[dbo].[BJobs]
WHERE
	[vss_options].exist('/GuestProcessingOptions') = 0

OPEN backup_jobs_cursor

DECLARE @id uniqueidentifier
DECLARE @name nvarchar(255)
DECLARE @type int
DECLARE @vss_options xml

FETCH NEXT FROM
	backup_jobs_cursor
INTO
	@id,
	@name,
	@type,
	@vss_options

WHILE @@fetch_status = 0
BEGIN
	PRINT [dbo].[System.TransformCppText]('BEGIN ITERATION')
	PRINT [dbo].[System.FormatString]('\t[Id]="%s"', @id)
	PRINT [dbo].[System.FormatString]('\t[Type]="%s"', @type)
	PRINT [dbo].[System.FormatString]('\t[Name]="%s"', @name)
	PRINT [dbo].[System.TransformCppText]('\t[VssOptions]=')
	PRINT [dbo].[System.FormatXmlDocument](@vss_options, 2, DEFAULT)
	PRINT ''

	SET @vss_options = [dbo].[Temp.ConvertVssOptions](@vss_options)

	PRINT [dbo].[System.TransformCppText]('\tUpdating job VSS options:')
	PRINT [dbo].[System.TransformCppText]('\t\t[VssOptions]=')
	PRINT [dbo].[System.FormatXmlDocument](@vss_options, 3, DEFAULT)
	PRINT ''

	UPDATE
		[dbo].[BJobs]
	SET
		[vss_options] = @vss_options
	WHERE CURRENT OF
		backup_jobs_cursor

	SET @count = @count + 1

	FETCH NEXT FROM
		backup_jobs_cursor
	INTO
		@id,
		@name,
		@type,
		@vss_options

	PRINT [dbo].[System.TransformCppText]('END ITERATION')
END

CLOSE backup_jobs_cursor
DEALLOCATE backup_jobs_cursor

PRINT 'End upgrading job VSS options'
PRINT [dbo].[System.FormatString]('\t[Job Count]="%s"', @count)
PRINT ''
GO


--------------------------------------------------------------------------------
--
-- OIJ VSS Options Upgrade
--
--------------------------------------------------------------------------------
PRINT 'Begin upgrading OIJ VSS options'

DECLARE @count int
SET @count = 0

DECLARE object_in_jobs_cursor CURSOR FOR
SELECT
	[id],
	[job_id],
	[object_id],
	[vss_options]
FROM
	[dbo].[ObjectsInJobs]
WHERE
	[vss_options].exist('/GuestProcessingOptions') = 0

OPEN object_in_jobs_cursor

DECLARE @id uniqueidentifier
DECLARE @job_id uniqueidentifier
DECLARE @object_id uniqueidentifier
DECLARE @vss_options xml

FETCH NEXT FROM
	object_in_jobs_cursor
INTO
	@id,
	@job_id,
	@object_id,
	@vss_options

WHILE @@fetch_status = 0
BEGIN
	PRINT [dbo].[System.TransformCppText]('BEGIN ITERATION')
	PRINT [dbo].[System.FormatString]('\t[Id]="%s"', @id)
	PRINT [dbo].[System.FormatString]('\t[JobId]="%s"', @job_id)
	PRINT [dbo].[System.FormatString]('\t[ObjectId]="%s"', @object_id)
	PRINT [dbo].[System.TransformCppText]('\t[VssOptions]=')
	PRINT [dbo].[System.FormatXmlDocument](@vss_options, 2, DEFAULT)
	PRINT ''

	SET @vss_options = [dbo].[Temp.ConvertVssOptions](@vss_options)

	PRINT [dbo].[System.TransformCppText]('\tUpdating OIJ VSS options:')
	PRINT [dbo].[System.TransformCppText]('\t\t[VssOptions]=')
	PRINT [dbo].[System.FormatXmlDocument](@vss_options, 3, DEFAULT)
	PRINT ''

	UPDATE
		[dbo].[ObjectsInJobs]
	SET
		[vss_options] = @vss_options
	WHERE CURRENT OF
		object_in_jobs_cursor

	SET @count = @count + 1

	FETCH NEXT FROM
		object_in_jobs_cursor
	INTO
		@id,
		@job_id,
		@object_id,
		@vss_options

	PRINT [dbo].[System.TransformCppText]('END ITERATION')
END

CLOSE object_in_jobs_cursor
DEALLOCATE object_in_jobs_cursor

PRINT 'End upgrading oij VSS options'
PRINT [dbo].[System.FormatString]('\t[Job Count]="%s"', @count)
PRINT ''
GO


--------------------------------------------------------------------------------
--
-- Job Options Upgrade
--
--------------------------------------------------------------------------------
PRINT 'Begin upgrading job options'

DECLARE @count int
SET @count = 0
DECLARE @flag bit

DECLARE jobs_cursor CURSOR FOR
SELECT
	[id],
	[name],
	[type],
	[options]
FROM
	[dbo].[BJobs]
WHERE
	-- Backup, Replica
	[type] = 0 OR [type] = 1

OPEN jobs_cursor

DECLARE @id uniqueidentifier
DECLARE @name nvarchar(255)
DECLARE @type int
DECLARE @options xml

FETCH NEXT FROM
	jobs_cursor
INTO
	@id,
	@name,
	@type,
	@options

WHILE @@fetch_status = 0
BEGIN
	PRINT [dbo].[System.TransformCppText]('BEGIN ITERATION')
	PRINT [dbo].[System.FormatString]('\t[Id]="%s"', @id)
	PRINT [dbo].[System.FormatString]('\t[Name]="%s"', @name)
	PRINT [dbo].[System.FormatString]('\t[Type]="%s"', @type)
	PRINT [dbo].[System.TransformCppText]('\t[Options]=')
	PRINT [dbo].[System.FormatXmlDocument](@options, 2, DEFAULT)
	PRINT ''

	SET @flag = 0

	-- Backup, Replica
	IF (@type = 0 OR @type = 1) AND @options.exist('/JobOptionsRoot/DirtyBlocksNullingEnabled') = 0
	BEGIN
		SET @options.modify('insert <DirtyBlocksNullingEnabled>False</DirtyBlocksNullingEnabled> as last into (/*)[1]')
		SET @flag = 1
	END

	-- Backup
	IF @type = 0 AND @options.exist('/JobOptionsRoot/GenerationPolicy') = 0
	BEGIN
		SET @options.modify('insert <GenerationPolicy><EnableRecheck>False</EnableRecheck></GenerationPolicy> as last into (/*)[1]')
		SET @flag = 1
	END

	IF @flag = 1
	BEGIN
		PRINT [dbo].[System.TransformCppText]('\tUpdating job options:')
		PRINT [dbo].[System.TransformCppText]('\t\t[Options]=')
		PRINT [dbo].[System.FormatXmlDocument](@options, 3, DEFAULT)
		PRINT ''

		UPDATE
			[dbo].[BJobs]
		SET
			[options] = @options
		WHERE CURRENT OF
			jobs_cursor
	END

	FETCH NEXT FROM
		jobs_cursor
	INTO
		@id,
		@name,
		@type,
		@options

	PRINT [dbo].[System.TransformCppText]('END ITERATION')
END

CLOSE jobs_cursor
DEALLOCATE jobs_cursor

PRINT 'End upgrading job options'
PRINT [dbo].[System.FormatString]('\t[Job Count]="%s"', @count)
PRINT ''
GO


--------------------------------------------------------------------------------
--
-- Guest Proxy Upgrade
--
--------------------------------------------------------------------------------
PRINT 'Begin upgrading guest proxies'

PRINT 'Getting local host ID...'

DECLARE @localhost_id uniqueidentifier
SET @localhost_id = (SELECT TOP 1 [id] FROM [dbo].[Hosts] WHERE [type] = 3)

PRINT [dbo].[System.FormatString]('\t[ID]="%s"', cast(@localhost_id as nvarchar(255)))
PRINT ''

DECLARE @count int
SET @count = 0

DECLARE guestprocessing_jobs_cursor CURSOR FOR
SELECT
	[id],
	[name],
	[vss_options]
FROM
	[dbo].[BJobs]
WHERE
	-- Backup, Replica, Copy
	([type] = 0 OR [type] = 1 OR ([type] = 2 AND [job_source_type] != 3)) AND [vss_options].exist('/GuestProcessingOptions/GuestProxyAutoDetect') = 0

OPEN guestprocessing_jobs_cursor

DECLARE @id uniqueidentifier
DECLARE @name nvarchar(255)
DECLARE @vss_options xml

FETCH NEXT FROM
	guestprocessing_jobs_cursor
INTO
	@id,
	@name,
	@vss_options

WHILE @@fetch_status = 0
BEGIN
	PRINT [dbo].[System.TransformCppText]('BEGIN ITERATION')
	PRINT [dbo].[System.FormatString]('\t[Id]="%s"', @id)
	PRINT [dbo].[System.FormatString]('\t[Name]="%s"', @name)
	PRINT [dbo].[System.TransformCppText]('\t[VssOptions]=')
	PRINT [dbo].[System.FormatXmlDocument](@vss_options, 2, DEFAULT)
	PRINT ''

	SET @vss_options.modify('insert <GuestProxyAutoDetect>False</GuestProxyAutoDetect> as last into (/*)[1]')

	PRINT [dbo].[System.TransformCppText]('\tUpdating VSS options:')
	PRINT [dbo].[System.TransformCppText]('\t\t[VssOptions]=')
	PRINT [dbo].[System.FormatXmlDocument](@vss_options, 3, DEFAULT)
	PRINT ''

	UPDATE
		[dbo].[BJobs]
	SET
		[vss_options] = @vss_options
	WHERE CURRENT OF
		guestprocessing_jobs_cursor

	IF EXISTS (SELECT * FROM [dbo].[Backup.Model.JobProxies] WHERE [job_id] = @id AND [proxy_id] = @localhost_id AND [type] = 2)
	BEGIN
		PRINT [dbo].[System.TransformCppText]('\tGuest proxy already exists:')
		PRINT [dbo].[System.FormatString]('\t\t[JobID]="%s"', @id)
		PRINT [dbo].[System.FormatString]('\t\t[ProxyID]="%s"', @localhost_id)
		PRINT ''
	END
	ELSE
	BEGIN
		DECLARE @usn bigint
		EXEC [dbo].[IncrementUsn] @usn OUTPUT

		PRINT [dbo].[System.TransformCppText]('\tInserting job proxy:')
		PRINT [dbo].[System.FormatString]('\t\t[JobID]="%s"', @id)
		PRINT [dbo].[System.FormatString]('\t\t[ProxyID]="%s"', @localhost_id)
		PRINT [dbo].[System.FormatString]('\t\t[Type]="%s"', 2)
		PRINT [dbo].[System.FormatString]('\t\t[Usn]="%s"', @usn)
		PRINT ''

		INSERT INTO [dbo].[Backup.Model.JobProxies]
			([id], [job_id], [proxy_id], [type], [usn])
		VALUES
			(newid(), @id, @localhost_id, 2, @usn)
	END

	SET @count = @count + 1

	FETCH NEXT FROM
		guestprocessing_jobs_cursor
	INTO
		@id,
		@name,
		@vss_options

	PRINT [dbo].[System.TransformCppText]('END ITERATION')
END

CLOSE guestprocessing_jobs_cursor
DEALLOCATE guestprocessing_jobs_cursor

PRINT 'End upgrading guest proxies'
PRINT [dbo].[System.FormatString]('\t[Job Count]="%s"', @count)
PRINT ''
GO


--------------------------------------------------------------------------------
--
-- Job Default Options Upgrade
--
--------------------------------------------------------------------------------
PRINT 'Begin upgrading job default options'

DECLARE @count int
SET @count = 0

DECLARE @content as nvarchar(max)
SET @content = 
	'<PreCommand>
		<CCustomCommand xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		</CCustomCommand>
	</PreCommand>
	<PostCommand>
		<CCustomCommand xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		</CCustomCommand>
	</PostCommand>
	<FullBackupMonthlyScheduleOptions>
		<CFullBackupMonthlyScheduleOptions xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		</CFullBackupMonthlyScheduleOptions>
	</FullBackupMonthlyScheduleOptions>
	<TransformFullToSyntethic>True</TransformFullToSyntethic>
	<EnableFullBackup>False</EnableFullBackup>'

DECLARE @options_table table([id] uniqueidentifier, [name] nvarchar(50), [v80_value] xml, [v90_value] xml)

INSERT INTO @options_table ([id], [name], [v80_value])
SELECT 'DAC610E6-751E-462E-A066-5671F461ABF2', 'vi_backup_adv_opt', '<CViJobAdvancedOptions>' + @content + '</CViJobAdvancedOptions>'
UNION ALL
SELECT '6D68763E-1A01-4B12-BF64-4C95E03F2BD0', 'vcd_backup_adv_opt', '<CViJobAdvancedOptions>' + @content + '</CViJobAdvancedOptions>'	
UNION ALL
SELECT '161978C6-6114-47DF-ADC9-B45BF68D6E08', 'hv_backup_adv_opt', '<CHvJobAdvancedOptions>' + @content + '</CHvJobAdvancedOptions>'

UPDATE @options_table SET [v90_value] = [v80_value]
UPDATE @options_table SET [v90_value].modify('replace value of (/*/TransformFullToSyntethic/text())[1] with "False"')
UPDATE @options_table SET [v90_value].modify('replace value of (/*/EnableFullBackup/text())[1] with "False"')

DECLARE options_table_cursor CURSOR FOR	SELECT [id], [name], [v80_value], [v90_value] FROM @options_table

OPEN options_table_cursor

DECLARE @id uniqueidentifier
DECLARE @name as nvarchar(50)
DECLARE @v80_value as xml
DECLARE @v90_value as xml
DECLARE @db_value xml

FETCH NEXT FROM options_table_cursor INTO @id, @name, @v80_value, @v90_value

WHILE @@fetch_status = 0
BEGIN
	PRINT [dbo].[System.TransformCppText]('BEGIN ITERATION')

	PRINT [dbo].[System.FormatString]('\t[Id]="%s"', @id)
	PRINT [dbo].[System.FormatString]('\t[Name]="%s"', @name)

	IF EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = @id)
	BEGIN
		SELECT @db_value = [value] FROM [dbo].[Options] WHERE [id] = @id

		PRINT [dbo].[System.TransformCppText]('\t[Value]=')
		PRINT [dbo].[System.FormatXmlDocument](@db_value, 2, DEFAULT)

		IF [dbo].[System.CompareXml](@v80_value, @db_value, 'TRUE') = 'TRUE'
		BEGIN
			PRINT [dbo].[System.FormatString]('\tSTATUS: Option "%s" is V80 default', @id)
			PRINT [dbo].[System.TransformCppText]('\tACTION: Delete')

			DELETE FROM [dbo].[Options] WHERE [id] = @id

			SET @count = @count + 1
		END
		ELSE
		BEGIN
			PRINT [dbo].[System.FormatString]('\tSTATUS: Option "%s" is not V80 default', @id)
			PRINT [dbo].[System.TransformCppText]('\tACTION: none')
		END
	END
	ELSE
	BEGIN
		PRINT [dbo].[System.FormatString]('\tSTATUS: Option "%s" not exist', @id)
		PRINT [dbo].[System.TransformCppText]('\tACTION: Insert')
		PRINT [dbo].[System.TransformCppText]('\t\t[Value]=')
		PRINT [dbo].[System.FormatXmlDocument](@v90_value, 3, DEFAULT)

		INSERT INTO [dbo].[Options] (id, name, value) VALUES (@id, @name, @v90_value)

		SET @count = @count + 1
	END

	FETCH NEXT FROM options_table_cursor INTO @id, @name, @v80_value, @v90_value

	PRINT [dbo].[System.TransformCppText]('END ITERATION')
END

CLOSE options_table_cursor
DEALLOCATE options_table_cursor

PRINT 'End upgrading job default options'
PRINT [dbo].[System.FormatString]('\t[Options Count]="%s"', @count)
PRINT ''
GO


--------------------------------------------------------------------------------
--
-- End Upgrade
--
--------------------------------------------------------------------------------
PRINT 'Deleting [dbo].[Temp.ConvertGuestIndexingType]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.ConvertGuestIndexingType]'

PRINT 'Deleting [dbo].[Temp.ConvertTransactionLogsProcessing]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.ConvertTransactionLogsProcessing]'

PRINT 'Deleting [dbo].[Temp.ConvertVssOptions]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.ConvertVssOptions]'

PRINT 'Deleting [dbo].[Temp.XmlNodeValue]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.XmlNodeValue]'

PRINT 'Deleting [dbo].[Temp.XmlNodeExist]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[Temp.XmlNodeExist]'

PRINT ''
PRINT 'Finishing database upgrade...'
PRINT [dbo].[System.FormatString]('\t[Total Read]="%s"', @@total_read)
PRINT [dbo].[System.FormatString]('\t[Total Write]="%s"', @@total_write)
PRINT [dbo].[System.FormatString]('\t[Total Errors]="%s"', @@total_errors)
PRINT [dbo].[System.FormatString]('\t[End Date]="%s"', convert(varchar, getdate(), 113))
PRINT ''
GO
