﻿--------------------------------------------------------------------------------
-- MaxValue
PRINT N'Creating [dbo].[MaxValue]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MaxValue]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[MaxValue];
GO

CREATE FUNCTION [dbo].[MaxValue] ( @x1 BIGINT, @x2 BIGINT )
RETURNS BIGINT
AS
    BEGIN
        IF ( @x1 > @x2 )
            RETURN @x1;
        IF ( @x1 < @x2 )
            RETURN @x2;
        RETURN @x1;
    END;

GO


--------------------------------------------------------------------------------
-- MaxValue3
PRINT N'Creating [dbo].[MaxValue3]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MaxValue3]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[MaxValue3];
GO

CREATE FUNCTION [dbo].[MaxValue3]
    (
      @x1 BIGINT ,
      @x2 BIGINT ,
      @x3 BIGINT
    )
RETURNS BIGINT
AS
    BEGIN
        DECLARE @result BIGINT;
        SELECT  @result = 0;
        IF ( @x1 > @result )
            SELECT  @result = @x1;
        IF ( @x2 > @result )
            SELECT  @result = @x2;
        IF ( @x3 > @result )
            SELECT  @result = @x3;
        RETURN @result;
    END;

GO

--------------------------------------------------------------------------------
-- MaxValue4
PRINT N'Creating [dbo].[MaxValue4]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MaxValue4]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[MaxValue4];
GO

CREATE FUNCTION [dbo].[MaxValue4]
    (
      @x1 BIGINT ,
      @x2 BIGINT ,
      @x3 BIGINT ,
      @x4 BIGINT
    )
RETURNS BIGINT
AS
    BEGIN
        DECLARE @result BIGINT;
        SELECT  @result = 0;
        IF ( @x1 > @result )
            SELECT  @result = @x1;
        IF ( @x2 > @result )
            SELECT  @result = @x2;
        IF ( @x3 > @result )
            SELECT  @result = @x3;
        IF ( @x4 > @result )
            SELECT  @result = @x4;
        RETURN @result;
    END;

GO


--------------------------------------------------------------------------------
-- MaxValue5
PRINT N'Creating [dbo].[MaxValue5]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MaxValue5]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[MaxValue5];
GO

CREATE FUNCTION [dbo].[MaxValue5]
    (
      @x1 BIGINT ,
      @x2 BIGINT ,
      @x3 BIGINT ,
      @x4 BIGINT ,
      @x5 BIGINT
    )
RETURNS BIGINT
AS
    BEGIN
        DECLARE @result BIGINT;
        SELECT  @result = 0;
        IF ( @x1 > @result )
            SELECT  @result = @x1;
        IF ( @x2 > @result )
            SELECT  @result = @x2;
        IF ( @x3 > @result )
            SELECT  @result = @x3;
        IF ( @x4 > @result )
            SELECT  @result = @x4;
        IF ( @x5 > @result )
            SELECT  @result = @x5;		
        RETURN @result;
    END;

GO

--------------------------------------------------------------------------------
-- MaxValue6
PRINT N'Creating [dbo].[MaxValue6]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MaxValue6]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[MaxValue6];
GO

CREATE FUNCTION [dbo].[MaxValue6]
    (
      @val1 BIGINT ,
      @val2 BIGINT ,
      @val3 BIGINT ,
      @val4 BIGINT ,
      @val5 BIGINT ,
      @val6 BIGINT
	)
RETURNS BIGINT
AS
    BEGIN
        DECLARE @result BIGINT;
        SELECT  @result = 0;
        IF ( @val1 > @result )
            SELECT  @result = @val1;
        IF ( @val2 > @result )
            SELECT  @result = @val2;
        IF ( @val3 > @result )
            SELECT  @result = @val3;
        IF ( @val4 > @result )
            SELECT  @result = @val4;
        IF ( @val5 > @result )
            SELECT  @result = @val5;
        IF ( @val6 > @result )
            SELECT  @result = @val6;
        RETURN @result;
    END;
GO


--------------------------------------------------------------------------------
-- MinValue
PRINT N'Creating [dbo].[MinValue]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MinValue]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[MinValue];
GO

CREATE FUNCTION [dbo].[MinValue] ( @x1 INT, @x2 INT )
RETURNS INT
AS
    BEGIN
        IF ( @x1 > @x2 )
            RETURN @x2;
        IF ( @x1 < @x2 )
            RETURN @x1;
        RETURN @x1;
    END;

GO

--------------------------------------------------------------------------------
-- Split
PRINT N'Creating [dbo].[Split]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[Split]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[Split];
GO

CREATE FUNCTION [dbo].[Split]
    (
      @text NVARCHAR(MAX) ,
      @delimiter CHAR(1) = ' '
    )
RETURNS @Strings TABLE
    (
      position INT IDENTITY
                   PRIMARY KEY ,
      value INT
    )
AS
    BEGIN
        DECLARE @INDEX INT;    
        SET @INDEX = -1;
        WHILE ( LEN(@text) > 0 )
            BEGIN        
                SET @INDEX = CHARINDEX(@delimiter, @text);        
                IF ( @INDEX = 0 )
                    AND ( LEN(@text) > 0 )
                    BEGIN   
                        INSERT  INTO @Strings
                        VALUES  ( @text );   
                        BREAK;
                    END;        
                IF ( @INDEX > 1 )
                    BEGIN   
                        INSERT  INTO @Strings
                        VALUES  ( LEFT(@text, @INDEX - 1) );   
                        SET @text = RIGHT(@text, ( LEN(@text) - @INDEX ));
                    END;
                ELSE
                    SET @text = RIGHT(@text, ( LEN(@text) - @INDEX ));
            END;
        RETURN;
    END;

GO


--------------------------------------------------------------------------------
-- ParseIdList
PRINT N'Creating [dbo].[ParseIdList]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[ParseIdList]')
                    AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ) )
    DROP FUNCTION [dbo].[ParseIdList];
GO

CREATE FUNCTION [dbo].[ParseIdList] ( @xmlTable XML )
RETURNS @xml TABLE
    (
      [id] UNIQUEIDENTIFIER
    )
AS
    BEGIN
        WITH    pXml
                  AS ( SELECT   dataset.rowset.value('id[1]',
                                                     'uniqueidentifier') AS id
                       FROM     @xmlTable.nodes('/dataset/row') AS dataset ( rowset )
                     )
            INSERT  @xml
                    SELECT  *
                    FROM    pXml;
        RETURN;
    END;
GO


IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MaxValue7]')
                    AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ) )
    DROP FUNCTION [dbo].[MaxValue7];
GO
CREATE FUNCTION [dbo].[MaxValue7]
    (
      @val1 BIGINT ,
      @val2 BIGINT ,
      @val3 BIGINT ,
      @val4 BIGINT ,
      @val5 BIGINT ,
      @val6 BIGINT ,
      @val7 BIGINT
	)
RETURNS BIGINT
AS
    BEGIN
        DECLARE @result BIGINT;
        SELECT  @result = 0;
        IF ( @val1 > @result )
            SELECT  @result = @val1;
        IF ( @val2 > @result )
            SELECT  @result = @val2;
        IF ( @val3 > @result )
            SELECT  @result = @val3;
        IF ( @val4 > @result )
            SELECT  @result = @val4;
        IF ( @val5 > @result )
            SELECT  @result = @val5;
        IF ( @val6 > @result )
            SELECT  @result = @val6;
        IF ( @val7 > @result )
            SELECT  @result = @val7;
        RETURN @result;
    END;
GO

--------------------------------------------------------------------------------
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[MaxValue2]')
                    AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ) )
    DROP FUNCTION [dbo].[MaxValue2];
GO
CREATE FUNCTION [dbo].[MaxValue2] ( @x1 BIGINT, @x2 BIGINT )
RETURNS BIGINT
AS
    BEGIN
        DECLARE @result BIGINT;
        SELECT  @result = 0;
        IF ( @x1 > @result )
            SELECT  @result = @x1;
        IF ( @x2 > @result )
            SELECT  @result = @x2;
        RETURN @result;
    END;
GO

-- [dbo].[FindIndexColumnsByIndexAndTableName] --

PRINT N'Creating [dbo].[FindForeignKeysByTableAndIndexName]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[FindForeignKeysByTableAndIndexName]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[FindForeignKeysByTableAndIndexName]; 
GO

CREATE FUNCTION [dbo].[FindForeignKeysByTableAndIndexName]
    (
      @table_name NVARCHAR(MAX) ,
      @index_name NVARCHAR(MAX)
    )
RETURNS @table TABLE
    (
      fk_name NVARCHAR(MAX) ,
      fk_table_name NVARCHAR(MAX) ,
      column_name NVARCHAR(MAX) ,
      referenced_table_name NVARCHAR(MAX) ,
      referenced_column_name NVARCHAR(MAX) ,
      column_id NVARCHAR(MAX)
    )
AS
    BEGIN

        WITH    foreign_keys
                  AS ( SELECT   obj.name AS FK_NAME ,
                                tab1.name AS [table] ,
                                col1.name AS [column] ,
                                tab2.name AS [referenced_table] ,
                                col2.name AS [referenced_column] ,
                                fkc.constraint_column_id AS column_id
                       FROM     sys.foreign_key_columns fkc
                                INNER JOIN sys.objects obj ON obj.object_id = fkc.constraint_object_id
                                INNER JOIN sys.tables tab1 ON tab1.object_id = fkc.parent_object_id
                                INNER JOIN sys.schemas sch ON tab1.schema_id = sch.schema_id
                                INNER JOIN sys.columns col1 ON col1.column_id = parent_column_id
                                                              AND col1.object_id = tab1.object_id
                                INNER JOIN sys.tables tab2 ON tab2.object_id = fkc.referenced_object_id
                                INNER JOIN sys.columns col2 ON col2.column_id = referenced_column_id
                                                              AND col2.object_id = tab2.object_id
                     )
            INSERT  @table
                    ( fk_name ,
                      fk_table_name ,
                      column_name ,
                      referenced_table_name ,
                      referenced_column_name ,
                      column_id
                    )
                    SELECT  *
                    FROM    foreign_keys
                    WHERE   referenced_table = @table_name
                            AND referenced_column IN (
                            SELECT  *
                            FROM    [FindIndexColumnsByIndexAndTableName](@table_name,
                                                              @index_name) );

        RETURN;
    END;

GO

-- [dbo].[FindIndexColumnsByIndexAndTableName] --

PRINT N'Creating [dbo].[FindIndexColumnsByIndexAndTableName]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[FindIndexColumnsByIndexAndTableName]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[FindIndexColumnsByIndexAndTableName]; 
GO


CREATE FUNCTION [dbo].[FindIndexColumnsByIndexAndTableName]
    (
      @table_name NVARCHAR(MAX) ,
      @index_name NVARCHAR(MAX)
    )
RETURNS @table TABLE
    (
      column_name NVARCHAR(MAX)
    )
AS
    BEGIN

        INSERT  @table
                ( column_name
                )
                SELECT  col.name AS column_name
                FROM    sys.indexes ind
                        INNER JOIN sys.index_columns ic ON ind.object_id = ic.object_id
                                                           AND ind.index_id = ic.index_id
                        INNER JOIN sys.columns col ON ic.object_id = col.object_id
                                                      AND ic.column_id = col.column_id
                        INNER JOIN sys.tables t ON ind.object_id = t.object_id
                WHERE   t.name = @table_name
                        AND ind.name = @index_name
                ORDER BY t.name ,
                        ind.name ,
                        ind.index_id ,
                        ic.index_column_id; 

        RETURN;
    END;

GO

-- [dbo].[FindPrimaryKeyByTable] --

PRINT N'Creating [dbo].[FindPrimaryKeyByTable]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[FindPrimaryKeyByTable]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[FindPrimaryKeyByTable]; 
GO

CREATE FUNCTION [dbo].[FindPrimaryKeyByTable]
    (
      @table_name NVARCHAR(MAX)
    )
RETURNS @table TABLE ( PK_name NVARCHAR(MAX) )
AS
    BEGIN

	
        WITH    primary_keys
                  AS ( SELECT   i.name AS indexName ,
                                OBJECT_NAME(ic.object_id) AS tableName ,
                                COL_NAME(ic.object_id, ic.column_id) AS columnName
                       FROM     sys.indexes AS i
                                INNER JOIN sys.index_columns AS ic ON i.object_id = ic.object_id
                                                              AND i.index_id = ic.index_id
                       WHERE    i.is_primary_key = 1
                     )
            INSERT  INTO @table
                    SELECT DISTINCT
                            indexName
                    FROM    primary_keys
                    WHERE   tableName = @table_name;

        RETURN;
    END;

GO


-- [dbo].[GetSortedIndexColumns] --

PRINT N'Creating [dbo].[GetSortedIndexColumns]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[GetSortedIndexColumns]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[GetSortedIndexColumns]; 
GO



CREATE FUNCTION [dbo].[GetSortedIndexColumns]
    (
      @table_name NVARCHAR(MAX)
    )
RETURNS @table TABLE
    (
      table_name NVARCHAR(MAX) ,
      index_name NVARCHAR(MAX) ,
      column_name NVARCHAR(MAX) ,
      index_type NVARCHAR(MAX) ,
      is_primary_key INT ,
      index_number INT ,
      column_number INT
    )
AS
    BEGIN
        WITH    index_columns
                  AS ( SELECT   sys.objects.name AS table_name ,
                                sys.indexes.name AS index_name ,
                                sys.columns.name AS column_name ,
                                sys.indexes.type_desc ,
                                sys.indexes.is_primary_key ,
                                DENSE_RANK() OVER ( ORDER BY sys.indexes.name ) AS index_number ,
                                ROW_NUMBER() OVER ( PARTITION BY sys.indexes.name ORDER BY sys.indexes.name ) AS column_number
                       FROM     sys.objects
                                INNER JOIN sys.indexes ON sys.objects.object_id = sys.indexes.object_id
                                INNER JOIN sys.index_columns ON sys.index_columns.object_id = sys.indexes.object_id
                                                              AND sys.index_columns.index_id = sys.indexes.index_id
                                INNER JOIN sys.columns ON sys.columns.object_id = sys.index_columns.object_id
                                                          AND sys.columns.column_id = sys.index_columns.column_id
                       WHERE    sys.objects.type_desc = N'USER_TABLE'
                                AND sys.objects.name = @table_name
                     )
            INSERT  @table
                    ( table_name ,
                      index_name ,
                      column_name ,
                      index_type ,
                      is_primary_key ,
                      index_number ,
                      column_number
                    )
                    SELECT  *
                    FROM    index_columns;
        RETURN;
    END;


GO


-- [dbo].[SplitString] --

PRINT N'Creating [dbo].[SplitString]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[SplitString]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[SplitString]; 
GO


CREATE FUNCTION [dbo].[SplitString]
    (
      @text NVARCHAR(MAX) ,
      @delimiter CHAR(1) = ' '
    )
RETURNS @Strings TABLE
    (
      position INT IDENTITY
                   PRIMARY KEY ,
      value VARCHAR(200)
    )
AS
    BEGIN
        DECLARE @INDEX INT;    
        SET @INDEX = -1;
        WHILE ( LEN(@text) > 0 )
            BEGIN        
                SET @INDEX = CHARINDEX(@delimiter, @text);        
                IF ( @INDEX = 0 )
                    AND ( LEN(@text) > 0 )
                    BEGIN   
                        INSERT  INTO @Strings
                        VALUES  ( @text );   
                        BREAK;
                    END;        
                IF ( @INDEX > 1 )
                    BEGIN   
                        INSERT  INTO @Strings
                        VALUES  ( LEFT(@text, @INDEX - 1) );   
                        SET @text = RIGHT(@text, ( LEN(@text) - @INDEX ));
                    END;
                ELSE
                    SET @text = RIGHT(@text, ( LEN(@text) - @INDEX ));
            END;
        RETURN;
    END;

GO


-- [dbo].[CheckIfIndexExistsByColumnNames] --

PRINT N'Creating [dbo].[CheckIfIndexExistsByColumnNames]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CheckIfIndexExistsByColumnNames]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[CheckIfIndexExistsByColumnNames]; 
GO


CREATE FUNCTION [dbo].[CheckIfIndexExistsByColumnNames]
    (
      @table_name NVARCHAR(MAX) ,
      @column_names NVARCHAR(MAX) ,
      @index_type NVARCHAR(MAX)
    )
RETURNS INT
AS
    BEGIN

        DECLARE @i INT;
        SET @i = 0;
        DECLARE @index_exists INT;
        SET @index_exists = 0;

        WHILE ( @i < 256 )
            BEGIN
                IF NOT EXISTS ( SELECT  position ,
                                        value ,
                                        @index_type AS index_type
                                FROM    dbo.SplitString(@column_names, ',')
                                EXCEPT
                                SELECT  column_number ,
                                        column_name ,
                                        index_type
                                FROM    [GetSortedIndexColumns](@table_name)
                                WHERE   index_number = @i )
                    BEGIN
                        SET @index_exists = '1';
                        BREAK;
                    END;
                ELSE
                    SET @i = @i + 1;
                CONTINUE;
            END;
        RETURN @index_exists;
    END;

GO


-- [dbo].[CheckIfIndexExistsByIndexName] --

PRINT N'Creating [dbo].[CheckIfIndexExistsByIndexName]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CheckIfIndexExistsByIndexName]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[CheckIfIndexExistsByIndexName];
GO


CREATE FUNCTION [dbo].[CheckIfIndexExistsByIndexName]
    (
      @table_name NVARCHAR(MAX) ,
      @index_name NVARCHAR(MAX) ,
      @index_type NVARCHAR(MAX)
    )
RETURNS INT
AS
    BEGIN

        DECLARE @table_name_bracketed NVARCHAR(MAX); 
        SET @table_name_bracketed = '[' + @table_name + ']';
        DECLARE @clustered_index_name VARCHAR(100);
        SET @clustered_index_name = ( SELECT    name
                                      FROM      sys.indexes
                                      WHERE     object_id = OBJECT_ID(@table_name_bracketed)
                                                AND type = 1
                                    );

        DECLARE @column_names VARCHAR(100);
        SET @column_names = '';
        SELECT  @column_names = @column_names + column_name + ','
        FROM    [FindIndexColumnsByIndexAndTableName](@table_name,
                                                      @clustered_index_name);
        SELECT  @column_names = SUBSTRING(@column_names, 1,
                                          LEN(@column_names) - 1);



        DECLARE @index_exists INT;
        SET @index_exists = ( SELECT    [dbo].[CheckIfIndexExistsByColumnNames](@table_name,
                                                              @column_names,
                                                              @index_type) AS a
                            );

        RETURN @index_exists;
    END;

GO


-- [dbo].[ConvertToUnderscoredString] --

PRINT N'Creating [dbo].[ConvertToUnderscoredString]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[ConvertToUnderscoredString]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[ConvertToUnderscoredString];
GO

CREATE FUNCTION [dbo].[ConvertToUnderscoredString]
    (
      @column_names NVARCHAR(MAX)
    )
RETURNS VARCHAR(MAX)
AS
    BEGIN

        DECLARE @column_names_underscored VARCHAR(MAX);
        SET @column_names_underscored = '';
        SELECT  @column_names_underscored = @column_names_underscored + value
                + '_'
        FROM    dbo.SplitString(@column_names, ',');
        SELECT  @column_names_underscored = SUBSTRING(@column_names_underscored,
                                                      1,
                                                      LEN(@column_names_underscored)
                                                      - 1);

        RETURN 	@column_names_underscored;
	
    END;

GO


-- [dbo].[FindPrimaryKeyColumnsByTable] --

PRINT N'Creating [dbo].[FindPrimaryKeyColumnsByTable]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[FindPrimaryKeyColumnsByTable]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[FindPrimaryKeyColumnsByTable];
GO


CREATE FUNCTION [dbo].[FindPrimaryKeyColumnsByTable]
    (
      @table_name NVARCHAR(MAX)
    )
RETURNS @table TABLE ( columns NVARCHAR(MAX) )
AS
    BEGIN
        WITH    primary_keys
                  AS ( SELECT   i.name AS indexName ,
                                OBJECT_NAME(ic.object_id) AS tableName ,
                                COL_NAME(ic.object_id, ic.column_id) AS columnName
                       FROM     sys.indexes AS i
                                INNER JOIN sys.index_columns AS ic ON i.object_id = ic.object_id
                                                              AND i.index_id = ic.index_id
                       WHERE    i.is_primary_key = 1
                     )
            INSERT  INTO @table
                    SELECT  columnName
                    FROM    primary_keys
                    WHERE   tableName = @table_name;
		
        RETURN;
    END;

GO


-- [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames] --

PRINT N'Creating [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames];
GO

CREATE FUNCTION [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames]
    (
      @table_name NVARCHAR(MAX) ,
      @column_names NVARCHAR(MAX)
    )
RETURNS INT
AS
    BEGIN
        DECLARE @i INT;
        SET @i = 0;
        DECLARE @index_exists INT;
        SET @index_exists = 0;
        WHILE ( @i < 256 )
            BEGIN
                IF NOT EXISTS ( ( SELECT    position ,
                                            value
                                  FROM      dbo.SplitString(@column_names, ',')
                                  EXCEPT
                                  SELECT    column_number ,
                                            column_name
                                  FROM      [GetSortedIndexColumns](@table_name)
                                  WHERE     index_number = @i
                                            AND index_type = 'NonClustered'
                                )
                                UNION ALL
                                ( SELECT    column_number ,
                                            column_name
                                  FROM      [GetSortedIndexColumns](@table_name)
                                  WHERE     index_number = @i
                                            AND index_type = 'NonClustered'
                                  EXCEPT
                                  SELECT    position ,
                                            value
                                  FROM      dbo.SplitString(@column_names, ',')
                                ) )
                    BEGIN
                        SET @index_exists = '1';
                        BREAK;
                    END;
                ELSE
                    SET @i = @i + 1;
                CONTINUE;
            END;
        RETURN @index_exists;
    END;

GO


-- [dbo].[GetNonClusteredIndexNamesByColumnNames] --

PRINT N'Creating [dbo].[GetNonClusteredIndexNamesByColumnNames]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[GetNonClusteredIndexNamesByColumnNames]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[GetNonClusteredIndexNamesByColumnNames];
GO


CREATE FUNCTION [dbo].[GetNonClusteredIndexNamesByColumnNames]
    (
      @table_name NVARCHAR(MAX) ,
      @column_names NVARCHAR(MAX)
    )
RETURNS @table TABLE
    (
      index_name VARCHAR(MAX)
    )
AS
    BEGIN
        DECLARE @i INT;
        SET @i = 0;
        DECLARE @index_exists INT;
        SET @index_exists = 0;


        WHILE ( @i < 256 )
            BEGIN
                INSERT  INTO @table
                        SELECT  index_name
                        FROM    [GetSortedIndexColumns](@table_name)
                        WHERE   index_number = @i
                                AND is_primary_key = 0
                                AND NOT EXISTS ( ( SELECT   position ,
                                                            value
                                                   FROM     dbo.SplitString(@column_names,
                                                              ',')
                                                   EXCEPT
                                                   SELECT   column_number ,
                                                            column_name
                                                   FROM     [GetSortedIndexColumns](@table_name)
                                                   WHERE    index_number = @i
                                                            AND index_type = 'NonClustered'
                                                 )
                                                 UNION ALL
                                                 ( SELECT   column_number ,
                                                            column_name
                                                   FROM     [GetSortedIndexColumns](@table_name)
                                                   WHERE    index_number = @i
                                                            AND index_type = 'NonClustered'
                                                   EXCEPT
                                                   SELECT   position ,
                                                            value
                                                   FROM     dbo.SplitString(@column_names,
                                                              ',')
                                                 ) );
	 
                SET @i = @i + 1;
            END;

        RETURN;
    END;

GO


-- [dbo].[CheckIfIndexWithTheSameNameExists] --

PRINT N'Creating [dbo].[CheckIfIndexWithTheSameNameExists]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[CheckIfIndexWithTheSameNameExists]')
                    AND type IN ( N'FN' ) )
    DROP FUNCTION [dbo].[CheckIfIndexWithTheSameNameExists];
GO


CREATE FUNCTION [dbo].[CheckIfIndexWithTheSameNameExists]
    (
      @table_name VARCHAR(MAX) ,
      @column_names VARCHAR(MAX) ,
      @index_type VARCHAR(MAX) ,
      @include_columns VARCHAR(MAX) = NULL
    )
RETURNS INT
AS
    BEGIN
        DECLARE @index_name VARCHAR(MAX);
        DECLARE @index_exists INT;
        SET @index_exists = 0;
        DECLARE @table_name_bracketed VARCHAR(MAX);
        SET @table_name_bracketed = '[' + @table_name + ']';
        DECLARE @column_names_underscored VARCHAR(MAX);
        SELECT  @column_names_underscored = ( SELECT    [dbo].[ConvertToUnderscoredString](@column_names)
                                            );
        IF ( @index_type = 'Clustered' )
            BEGIN
                SET @index_name = 'PK_' + @table_name + '_'
                    + @column_names_underscored;
				SET @index_name = SUBSTRING(@index_name, 1, 120)
                IF EXISTS ( SELECT  *
                            FROM    sys.indexes
                            WHERE   name = @index_name
                                    AND object_id = OBJECT_ID(@table_name_bracketed)
                                    AND type = '1' )
                    BEGIN
                        SET @index_exists = 1;
                    END;
                ELSE
                    SET @index_name = 'CI_' + @table_name + '_'
                        + @column_names_underscored;
                IF EXISTS ( SELECT  *
                            FROM    sys.indexes
                            WHERE   name = @index_name
                                    AND object_id = OBJECT_ID(@table_name_bracketed)
                                    AND type = '1' )
                    BEGIN
                        SET @index_exists = 1;
                    END;
            END;
        IF ( @index_type = 'Nonclustered'
             AND @include_columns IS NULL
           )
            BEGIN
                SET @index_name = 'IX_' + @table_name + '_'
                    + @column_names_underscored;
				SET @index_name = SUBSTRING(@index_name, 1, 120)
                IF EXISTS ( SELECT  *
                            FROM    sys.indexes
                            WHERE   name = @index_name
                                    AND object_id = OBJECT_ID(@table_name_bracketed)
                                    AND type = '2' )
                    BEGIN
                        SET @index_exists = 1;
                    END;
            END;
        IF ( @index_type = 'Nonclustered'
             AND @include_columns IS NOT NULL
           )
            BEGIN
                SELECT  @column_names_underscored = @column_names_underscored
                        + '_'
                        + ( SELECT  [dbo].[ConvertToUnderscoredString](@include_columns)
                          );
                SET @index_name = 'IX_' + @table_name + '_'
                    + @column_names_underscored;
				SET @index_name = SUBSTRING(@index_name, 1, 120)
                IF EXISTS ( SELECT  *
                            FROM    sys.indexes
                            WHERE   name = @index_name
                                    AND object_id = OBJECT_ID(@table_name_bracketed)
                                    AND type = '2' )
                    BEGIN
                        SET @index_exists = 1;
                    END;
            END;
        RETURN @index_exists;
    END;



GO

	-- [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames] --
PRINT N'Creating [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames]';
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames]')
                    AND type IN ( N'TF' ) )
    DROP FUNCTION [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames];
GO

CREATE FUNCTION [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames]
    (
      @table_name NVARCHAR(MAX) ,
      @column_names NVARCHAR(MAX)
    )
RETURNS @table TABLE
    (
      index_name VARCHAR(MAX)
    )
AS
    BEGIN
        DECLARE @i INT;
        SET @i = 0;
        DECLARE @index_exists INT;
        SET @index_exists = 0;
        WHILE ( @i < 256 )
            BEGIN
                INSERT  INTO @table
                        SELECT  index_name
                        FROM    [GetSortedIndexColumns](@table_name)
                        WHERE   index_number = @i
                                AND is_primary_key = 1
                                AND NOT EXISTS ( ( SELECT   position ,
                                                            value
                                                   FROM     dbo.SplitString(@column_names,
                                                              ',')
                                                   EXCEPT
                                                   SELECT   column_number ,
                                                            column_name
                                                   FROM     [GetSortedIndexColumns](@table_name)
                                                   WHERE    index_number = @i
                                                            AND index_type = 'NonClustered'
                                                 )
                                                 UNION ALL
                                                 ( SELECT   column_number ,
                                                            column_name
                                                   FROM     [GetSortedIndexColumns](@table_name)
                                                   WHERE    index_number = @i
                                                            AND index_type = 'NonClustered'
                                                   EXCEPT
                                                   SELECT   position ,
                                                            value
                                                   FROM     dbo.SplitString(@column_names,
                                                              ',')
                                                 ) );
                SET @i = @i + 1;
            END;
        RETURN;
    END;
GO

--------------------------------------------------------------------------------
--
-- System.DeleteFunction
--
-- Delete function from database.
--
-- Parameters:
--     @function_name - specifies function name
--
-- Example:
--     EXEC [dbo].[System.DeleteFunction] '[dbo].[System.TransformCppText]'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.DeleteFunction]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[System.DeleteFunction]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[System.DeleteFunction]
GO

	CREATE PROCEDURE [dbo].[System.DeleteFunction]
		@function_name nvarchar(max)
	AS
	BEGIN
		IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(@function_name) AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
		BEGIN
			DECLARE @command nvarchar(max)
			SET @command = 'DROP FUNCTION ' + @function_name
			EXEC (@command)
		END
	END
GO


--------------------------------------------------------------------------------
--
-- System.DeleteProcedure
--
-- Delete stored procedure from database.
--
-- Parameters:
--     @procedure_name - specifies stored procedure name
--
-- Example:
--     EXEC [dbo].[System.DeleteProcedure] '[dbo].[System.DeleteFunction]'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.DeleteProcedure]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[System.DeleteProcedure]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[System.DeleteProcedure]
GO

	CREATE PROCEDURE [dbo].[System.DeleteProcedure]
		@procedure_name nvarchar(max)
	AS
	BEGIN
		IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(@procedure_name) AND type in (N'P', N'PC'))
		BEGIN
			DECLARE @command nvarchar(max)
			SET @command = 'DROP PROCEDURE ' + @procedure_name
			EXEC (@command)
		END
	END
GO

--------------------------------------------------------------------------------
--
-- System.DeleteTable
--
-- Delete table from database.
--
-- Parameters:
--     @table_name - specifies table name
--
-- Example:
--     EXEC [dbo].[System.DeleteTable] '[dbo].[System.Log]'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.DeleteTable]'
EXEC [dbo].[System.DeleteProcedure] '[dbo].[System.DeleteTable]'
GO

	CREATE PROCEDURE [dbo].[System.DeleteTable]
		@table_name nvarchar(max)
	AS
	BEGIN
		IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(@table_name) AND type in (N'U'))
		BEGIN
			DECLARE @command nvarchar(max)
			SET @command = 'DROP TABLE ' + @table_name
			EXEC (@command)
		END
	END
GO

--------------------------------------------------------------------------------
--
-- System.IsEmptyString
--
-- Validates is string null/empty
--
-- Parameters:
--     @str - specifies input text for validation
--
-- Result:
--     'TRUE' - string is NULL/''
--     'FALSE' - string is not NULL/''
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.IsEmptyString]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.IsEmptyString]'
GO

	CREATE FUNCTION [dbo].[System.IsEmptyString] (
		@str nvarchar(max))
	RETURNS bit
	AS
	BEGIN
		IF (@str = NULL OR len(@str) = 0)
			RETURN 'TRUE'

		RETURN 'FALSE'
	END
GO

--------------------------------------------------------------------------------
--
-- System.IsBlankString
--
-- Validates is string null/empty or contains space/tab(s) only
--
-- Parameters:
--     @str - specifies input text for validation
--
-- Result:
--     'TRUE' - string is NULL/''/' '/CHAR(9)
--     'FALSE' - string is not NULL/''/' '/CHAR(9)
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.IsBlankString]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.IsBlankString]'
GO

	CREATE FUNCTION [dbo].[System.IsBlankString] (
		@str nvarchar(max))
	RETURNS bit
	AS
	BEGIN
		IF ([dbo].[System.IsEmptyString](@str) = 'FALSE')
		BEGIN
			IF (patindex([dbo].[System.TransformCppText]('%[^ \t]%'), @str collate SQL_Latin1_General_CP1_CI_AS) > 0)
				RETURN 'FALSE'
		END

		RETURN 'TRUE'
	END
GO

--------------------------------------------------------------------------------
--
-- System.RightTrimString
--
-- Trim a string from the right using the set of symbols
-- (equal to System.LeftTrimString).
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.RightTrimString]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.RightTrimString]'
GO

	CREATE FUNCTION [dbo].[System.RightTrimString] (
		@str nvarchar(max),
		@pattern nvarchar(255))
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @internal_pattern nvarchar(max)
		SET @internal_pattern = [dbo].[System.FormatString]('%%[%s]', @pattern)

		DECLARE @index bigint
		SET @index = -1

		WHILE (1 = 1)
		BEGIN
			DECLARE @position bigint		
			SET @position = patindex(@internal_pattern, @str collate SQL_Latin1_General_CP1_CI_AS)
			IF (@position = 0)
				BREAK
	
			SET @index = @position - 1
			SET @internal_pattern = @internal_pattern + '_'
		END

		IF (@index <> -1)
			SET @str = substring(@str, 1, @index)

		RETURN @str
	END
GO

--------------------------------------------------------------------------------
--
-- System.EscapeText
--
-- Transform text to be included into XML nodes.
--
-- Parameters:
--     @text - specifies input text
--
-- Result: escaped string
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.EscapeText]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.EscapeText]'
GO

	CREATE FUNCTION [dbo].[System.EscapeText] ( @text nvarchar(max) )
	RETURNS nvarchar(max)
	AS
	BEGIN
		SET @text = replace(@text, '<', '&lt;')
		SET @text = replace(@text, '>', '&gt;')
		SET @text = replace(@text, '&', '&amp;')
		SET @text = replace(@text, '"', '&quot;')
		SET @text = replace(@text, '''', '&apos;')

		RETURN @text
	END
GO

--------------------------------------------------------------------------------
--
-- System.SplitString
--
-- Splits input string into array using separator
--
-- Parameters:
--     @str       - specifies input text
--     @separator - specifies separator (one or more symbols)
--
-- Result: string array
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.SplitString]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.SplitString]'
GO

	CREATE FUNCTION [dbo].[System.SplitString] (
		@str nvarchar(max),
		@separator nvarchar(10))
	RETURNS @array table ( element nvarchar(max) )
	AS
	BEGIN
		IF ([dbo].[System.IsEmptyString](@str) = 'TRUE')
			RETURN

		IF ([dbo].[System.IsEmptyString](@separator) = 'TRUE')
		BEGIN
			INSERT INTO @array (element) VALUES (@str)
			RETURN
		END

		DECLARE @start bigint
		SET @start = 0

		WHILE ('TRUE' = 'TRUE')
		BEGIN
			DECLARE @element nvarchar(max)

			DECLARE @position bigint
			SET @position = charindex(@separator, @str, @start)

			IF (@position = 0)
				SET @element = substring(@str, @start, len(@str) - @start + 1)
			ELSE
				SET @element = substring(@str, @start, @position - @start)

			INSERT INTO @array (element) VALUES (@element)

			IF (@position = 0)
				BREAK

			SET @start = @position + len(@separator)
		END

		RETURN
	END
GO

--------------------------------------------------------------------------------
--
-- System.TransformCppText
--
-- Replaces control symbols in the input string using CPP-style:
--    \t -> CHAR(9)
--    \n -> CHAR(10)
--    \r -> CHAR(13)
--
-- Parameters:
--     @text - specifies input text for replecement
--
-- Example:
--     DECLARE @text nvarchar(255)
--     SET @text = [dbo].[System.TransformCppText]('\t\tFirst\r\nSecond\r\nThird')
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.TransformCppText]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.TransformCppText]'
GO

	CREATE FUNCTION [dbo].[System.TransformCppText] (
		@text nvarchar(max))
	RETURNS nvarchar(max)
	AS
	BEGIN
		SET @text = replace(@text, '\t', CHAR(9))
		SET @text = replace(@text, '\n', CHAR(10))
		SET @text = replace(@text, '\r', CHAR(13))

		RETURN @text
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatString
-- System.FormatString2
-- System.FormatString3
-- System.FormatString4
-- System.FormatString5
-- System.FormatString6
-- System.FormatString7
-- System.FormatString8
-- System.FormatString9
--
-- Wrapper for "xp_sprintf" extended stored procedure
--
-- Parameters:
--     @format     - specifies a text with format specifier(s)
--     @arg0-@arg9 - specifies input parameters for format specifier(s)
--
-- Result:
--     Returns formatted string.
--
-- Remarks:
--     1. "%s" format specifier is supported only.
--     2. @format parameter lenght is restricted by 255 symbols (by the system)
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatString]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString]'
GO

	CREATE FUNCTION [dbo].[System.FormatString] (
		@format nvarchar(255),
		@arg0 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString2]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString2]'
GO

	CREATE FUNCTION [dbo].[System.FormatString2] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString3]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString3]'
GO

	CREATE FUNCTION [dbo].[System.FormatString3] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant,
		@arg2 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1, @arg2
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString4]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString4]'
GO

	CREATE FUNCTION [dbo].[System.FormatString4] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant,
		@arg2 sql_variant,
		@arg3 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1, @arg2, @arg3
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString5]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString5]'
GO

	CREATE FUNCTION [dbo].[System.FormatString5] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant,
		@arg2 sql_variant,
		@arg3 sql_variant,
		@arg4 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1, @arg2, @arg3, @arg4
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString6]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString6]'
GO

	CREATE FUNCTION [dbo].[System.FormatString6] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant,
		@arg2 sql_variant,
		@arg3 sql_variant,
		@arg4 sql_variant,
		@arg5 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1, @arg2, @arg3, @arg4, @arg5
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString7]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString7]'
GO

	CREATE FUNCTION [dbo].[System.FormatString7] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant,
		@arg2 sql_variant,
		@arg3 sql_variant,
		@arg4 sql_variant,
		@arg5 sql_variant,
		@arg6 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1, @arg2, @arg3, @arg4, @arg5, @arg6
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString8]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString8]'
GO

	CREATE FUNCTION [dbo].[System.FormatString8] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant,
		@arg2 sql_variant,
		@arg3 sql_variant,
		@arg4 sql_variant,
		@arg5 sql_variant,
		@arg6 sql_variant,
		@arg7 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1, @arg2, @arg3, @arg4, @arg5, @arg6, @arg7
		RETURN @result
	END
GO

PRINT 'Creating [dbo].[System.FormatString9]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatString9]'
GO

	CREATE FUNCTION [dbo].[System.FormatString9] (
		@format nvarchar(255),
		@arg0 sql_variant,
		@arg1 sql_variant,
		@arg2 sql_variant,
		@arg3 sql_variant,
		@arg4 sql_variant,
		@arg5 sql_variant,
		@arg6 sql_variant,
		@arg7 sql_variant,
		@arg8 sql_variant)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @result nvarchar(255)
		SET @format = [dbo].[System.TransformCppText](@format)
		EXEC xp_sprintf @result OUTPUT, @format, @arg0, @arg1, @arg2, @arg3, @arg4, @arg5, @arg6, @arg7, @arg8
		RETURN @result
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatText
--
-- Formats text for indented output.
--
-- Parameters:
--     @text   - specifies input text buffer
--     @count  - specifies prefix count
--     @prefix - specifies prefix pattern
--
-- Example:
--     SET @value = '123\n234\n345'
--     PRINT [dbo].[System.FormatText](@value, 2, DEFAULT)
--
--	Output:
--     "		123"
--     "		234"
--     "		345"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatText]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatText]'
GO

	CREATE FUNCTION [dbo].[System.FormatText] (
		@text nvarchar(max),
		@count int,
		@prefix nvarchar(255) = '\t')
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @str nvarchar(255)
		SET @str = replicate(@prefix, @count)	

		SET @text = replace(@text, [dbo].[System.TransformCppText]('\n'), '\n' + @str)

		IF (len(@text) != 0)
		BEGIN
			SET @text = @str + @text
		END

		SET @text = [dbo].[System.TransformCppText](@text)
		RETURN @text
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatXmlText
--
-- Formats XML text for indented output.
--
-- Parameters:
--     @text   - specifies input XML text
--     @count  - specifies prefix count
--     @prefix - specifies prefix pattern
--
-- Example:
--     SET @value = '<a>Load</a><b>Test</b>'
--     PRINT [dbo].[System.FormatXmlText](@value, 2, DEFAULT)
--
--	Output:
--     "		<a>Load</a>"
--     "		<b>Test</b>"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatXmlText]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatXmlText]'
GO

	CREATE FUNCTION [dbo].[System.FormatXmlText] (
		@text nvarchar(max),
		@count int,
		@prefix nvarchar(255) = '\t')
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @str nvarchar(255)
		SET @str = replicate(@prefix, @count)	

		SET @text = replace(@text, '><', '>\r\n' + @str + '<')

		IF (len(@text) != 0)
		BEGIN
			SET @text = @str + @text
		END

		SET @text = [dbo].[System.TransformCppText](@text)
		RETURN @text
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatXmlDocument
--
-- Formats XML for output.
--
-- Parameters:
--     @document - specifies XML document
--     @count    - specifies prefix count
--     @prefix   - specifies prefix pattern
--
-- Example:
--     SET @document = '<root><A><B>123</B></A></root>'
--     PRINT [dbo].[System.FormatXmlDocument](@document, 2, DEFAULT)
--
--	Output:
--     "		<root>"
--     "		<A>"
--     "		<B>123</B>"
--     "		</A>"
--     "		</root>"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatXmlDocument]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatXmlDocument]'
GO

	CREATE FUNCTION [dbo].[System.FormatXmlDocument] (
		@document xml,
		@count int,
		@prefix nvarchar(255) = '\t')
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @text nvarchar(max)
		SET @text = cast(@document as nvarchar(max))
		RETURN [dbo].[System.FormatXmlText](@text, @count, @prefix)
	END
GO

--------------------------------------------------------------------------------
--
-- Date/Time Utilities
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatDateTime]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatDateTime]'
GO

	CREATE FUNCTION [dbo].[System.FormatDateTime] (@value datetime)
	RETURNS nvarchar(255)
	AS
	BEGIN
		--SET @value = dateadd(hour, datediff(hh, getutcdate(), getdate()), @value)
		RETURN convert(nvarchar, @value, 20)
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatIso8601DateTime
--
-- Formats datetime using ISO8601 rules.
--
-- Parameters:
--     @value - specifies datetime to formatting
--
-- Examples:
--     '2008-10-23T18:52:47.513'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatIso8601DateTime]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatIso8601DateTime]'
GO

	CREATE FUNCTION [dbo].[System.FormatIso8601DateTime] (@value datetime)
	RETURNS nvarchar(255)
	AS
	BEGIN
		SET @value = dateadd(hour, datediff(hh, getutcdate(), getdate()), @value)

		-- ISO 8601 format: international standard - works with any language setting
        -- '2006-09-07T16:42:31.301'
		DECLARE @str_iso8601 nvarchar(100)
		SET @str_iso8601 = convert(varchar, @value, 126)

		IF (patindex('%[.]%', @str_iso8601 collate SQL_Latin1_General_CP1_CI_AS) = 0)
			SET @str_iso8601 = @str_iso8601 + '.'

		SET @str_iso8601 = @str_iso8601 + replicate('0', 27 - len(@str_iso8601))

		DECLARE @time_zone int
		SET @time_zone = datediff(hh, getutcdate(), getdate())

		DECLARE @str_time_zone nvarchar(100)
		SET @str_time_zone = right(replicate('0', 2) + convert(varchar, abs(@time_zone)), 2)

		IF (sign(@time_zone) = -1)
			SET @str_time_zone = '-' + @str_time_zone
		ELSE
			SET @str_time_zone = '+' + @str_time_zone

		-- '2011-10-31T15:06:52.9434222+04:00'
		RETURN [dbo].[System.FormatString2]('%s%s:00', @str_iso8601, @str_time_zone)
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatUtcInvariantDateTime
--
-- Formats datetime to UTC format using invariant culture.
--
-- Parameters:
--     @value - specifies datetime to formatting
--
-- Examples:
--     '10/25/2011 07:41:18'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatUtcInvariantDateTime]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatUtcInvariantDateTime]'
GO

	CREATE FUNCTION [dbo].[System.FormatUtcInvariantDateTime] (@value datetime)
	RETURNS nvarchar(255)
	AS
	BEGIN
		-- UTC format: invariant culture
		DECLARE @utc datetime
		SET @utc = dateadd(hh, datediff(hh, getdate(), getutcdate()), @value)
		RETURN convert(nvarchar, @utc, 101) + ' ' + convert(nvarchar, @utc, 108)
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatDateTimeDiff
--
-- Formats difference between two datetime values.
--
-- Parameters:
--     @start_time - specifies start time
--     @end_time   - specifies end time
--
-- Comment:
--     DO NOT use this function if difference is more than 24 hours (days, etc).
--
-- Examples:
--     '00:02:03'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatDateTimeDiff]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatDateTimeDiff]'
GO

	CREATE FUNCTION [dbo].[System.FormatDateTimeDiff] (
		@start_time datetime,
		@end_time datetime)
	RETURNS nvarchar(255)
	AS
	BEGIN
		RETURN convert(varchar,(@end_time - @start_time), 108)
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSizeInKb
--
-- Returns size of file system item in "Kb".
--
-- Parameters:
--     @size - file system item size in bytes
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSizeInKb]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSizeInKb]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSizeInKb] (
		@size bigint)
	RETURNS float
	AS
	BEGIN
		RETURN @size / 1024.;
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSizeInMb
--
-- Returns size of file system item in "Mb".
--
-- Parameters:
--     @size - file system item size in bytes
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSizeInMb]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSizeInMb]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSizeInMb] (
		@size bigint)
	RETURNS float
	AS
	BEGIN
		RETURN @size / 1048576.;
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSizeInGb
--
-- Returns size of file system item in "Gb".
--
-- Parameters:
--     @size - file system item size in bytes
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSizeInGb]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSizeInGb]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSizeInGb] (
		@size bigint)
	RETURNS float
	AS
	BEGIN
		RETURN @size / 1073741824.;
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSizeInTb
--
-- Returns size of file system item in "Tb".
--
-- Parameters:
--     @size - file system item size in bytes
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSizeInTb]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSizeInTb]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSizeInTb] (
		@size bigint)
	RETURNS float
	AS
	BEGIN
		RETURN @size / 1099511627776.;
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatSize
--
-- Formats size of file system item for visualization.
--
-- Parameters:
--     @size - file system item size in bytes
--
-- Result:
--     Formatted string in form of '10.00 Mb'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatSize]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatSize]'
GO

	CREATE FUNCTION [dbo].[System.FormatSize] (
		@size bigint)
	RETURNS nvarchar(255)
	AS
	BEGIN
		IF ([dbo].[System.GetFileSizeInMb](@size) < 1)
			RETURN [dbo].[System.FormatString]('%s KB', cast([dbo].[System.GetFileSizeInKb](@size) as decimal(18, 2)))

		IF ([dbo].[System.GetFileSizeInGb](@size) < 1)
			RETURN [dbo].[System.FormatString]('%s MB', cast([dbo].[System.GetFileSizeInMb](@size) as decimal(18, 2)))

		IF ([dbo].[System.GetFileSizeInTb](@size) < 1)
			RETURN [dbo].[System.FormatString]('%s GB', cast([dbo].[System.GetFileSizeInGb](@size) as decimal(18, 2)))

		RETURN [dbo].[System.FormatString]('%s TB', cast([dbo].[System.GetFileSizeInTb](@size) as decimal(18, 2)))
	END
GO

--------------------------------------------------------------------------------
--
-- System.FormatRate
--
-- Formats speed of file system operations for visualization.
--
-- Parameters:
--     @size - speed in bytes per seconds
--
-- Result:
--     Formatted string in form of '10.00 Mb/s'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FormatRate]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FormatRate]'
GO

	CREATE FUNCTION [dbo].[System.FormatRate] (
		@speed bigint)
	RETURNS nvarchar(255)
	AS
	BEGIN
		IF ([dbo].[System.GetFileSizeInMb](@speed) < 1)
			RETURN [dbo].[System.FormatString]('%s KB/s', round([dbo].[System.GetFileSizeInKb](@speed), 0))

		IF ([dbo].[System.GetFileSizeInGb](@speed) < 1)
			RETURN [dbo].[System.FormatString]('%s MB/s', round([dbo].[System.GetFileSizeInMb](@speed), 0))

		RETURN [dbo].[System.FormatString]('%s GB/s', round([dbo].[System.GetFileSizeInGb](@speed), 0))
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSystemType
--
-- Returns file system type which is based on path inside FS.
--
-- Parameters:
--     @path - specifies FS path
--
-- Result:
--     -1 - Unknown FS
--      0 - Windows path (C:\Windows\...)
--      1 - Linux path (/store/folder/...)
--      2 - UNC path (\\SERVER\share\...)
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSystemType]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSystemType]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSystemType] (
		@path nvarchar(max))
	RETURNS int
	AS 
	BEGIN	
		SET @path = ltrim(rtrim(@path))

		IF (len(@path) != 0)
		BEGIN
			DECLARE @index bigint
			
			SET @index = patindex('[A-Za-z]:', @path collate SQL_Latin1_General_CP1_CI_AS)
			IF (@index > 0)
				RETURN 0

			SET @index = patindex('[A-Za-z]:\%', @path collate SQL_Latin1_General_CP1_CI_AS)
			IF (@index > 0)
				RETURN 0

			SET @index = patindex('/[^/]%', @path collate SQL_Latin1_General_CP1_CI_AS)
			IF (@index > 0)
				RETURN 1
	
			SET @index = patindex('\\[^\]%', @path collate SQL_Latin1_General_CP1_CI_AS)
			IF (@index > 0)
				RETURN 2
		END

		RETURN -1
	END
GO

--------------------------------------------------------------------------------
--
-- System.FileSystemIsRoot
--
-- Returns a flag to defines if file system path is Windows root drive or not.
--
-- Parameters:
--     @path - specifies root path
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FileSystemIsRoot]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FileSystemIsRoot]'
GO

	CREATE FUNCTION [dbo].[System.FileSystemIsRoot] (
		@path nvarchar(max))
	RETURNS bit
	AS 
	BEGIN
		SET @path = ltrim(rtrim(@path))

		DECLARE @index bigint

		SET @index = patindex('[A-Za-z]:', @path collate SQL_Latin1_General_CP1_CI_AS)
		IF (@index > 0)
			RETURN 'TRUE'

		SET @index = patindex('[A-Za-z]:[\/]', @path collate SQL_Latin1_General_CP1_CI_AS)
		IF (@index > 0)
			RETURN 'TRUE'

		RETURN 'FALSE'
	END
GO

--------------------------------------------------------------------------------
--
-- System.FileSystemComparePaths
--
-- Compares two paths in different or equal FS in depending on theirs types.
--
-- Parameters:
--     @path1 - specifies first FS path
--     @path2 - specifies second FS path
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FileSystemComparePaths]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FileSystemComparePaths]'
GO

	CREATE FUNCTION [dbo].[System.FileSystemComparePaths] (
		@path1 nvarchar(max),
		@path2 nvarchar(max))
	RETURNS bit
	AS 
	BEGIN	
		SET @path1 = [dbo].[System.FileSystemRemoveSeparator](@path1)
		SET @path2 = [dbo].[System.FileSystemRemoveSeparator](@path2)

		DECLARE @type1 int
		SET @type1 = [dbo].[System.GetFileSystemType](@path1)

		DECLARE @type2 int
		SET @type2 = [dbo].[System.GetFileSystemType](@path2)

--     -1 - Unknown FS
--      0 - Windows path (C:\Windows\...)
--      1 - Linux path (/store/folder/...)
--      2 - UNC path (\\SERVER\share\...)

		IF ((@type1 != @type2) OR (@type1 = 1 AND @type2 = 1))
			RETURN CASE WHEN (cast(@path1 as varbinary(max)) = cast(@path2 as varbinary(max))) THEN 'TRUE' ELSE 'FALSE' END

		RETURN CASE WHEN (@path1 = @path2) THEN 'TRUE' ELSE 'FALSE' END
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSystemParentFolder
--
-- Returns parent folder of specified path inside FS.
--
-- Parameters:
--     @path - specifies FS path
--
-- Result:
--     Returns parent folder or '' in a case of error.
--
-- Remarks:
--     UNC, Linux and Windows FS are supported.
--
-- Example:
--     PRINT [dbo].[System.GetFileSystemParentFolder]('D:\123\ABC')
-- 
-- Output:
--     "D:\123"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSystemParentFolder]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSystemParentFolder]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSystemParentFolder] (
		@path nvarchar(max))
	RETURNS nvarchar(max)
	AS 
	BEGIN	
		SET @path = ltrim(rtrim(@path))

		IF (len(@path) != 0)
		BEGIN
			DECLARE @reverse nvarchar(max)
			SET @reverse = reverse(@path)

			DECLARE @index bigint

			SET @index = patindex('%\%[^\]\\', @reverse collate SQL_Latin1_General_CP1_CI_AS)
			IF (@index = 0) 
			BEGIN
				SET @index = patindex('%/%[^/]/', @reverse collate SQL_Latin1_General_CP1_CI_AS)
				IF (@index = 0)
				BEGIN
					SET @index = patindex('%\%\:[A-Za-z]', @reverse collate SQL_Latin1_General_CP1_CI_AS)
					IF (@index = 0) RETURN ''					
				END
			END

			RETURN substring(@path, 0, len(@path) - @index + 1)
		END

		RETURN ''
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSystemParentFolderEx
--
-- Returns parent folder of specified path inside FS.
--
-- Parameters:
--     @path - specifies FS path
--
-- Result:
--     Returns parent folder or '' in a case of error.
--
-- Remarks:
--     UNC, Linux and Windows FS are supported.
--
-- Example:
--     PRINT [dbo].[System.GetFileSystemParentFolderEx]('D:\123\ABC')
-- 
-- Output:
--     "D:\123"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSystemParentFolderEx]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSystemParentFolderEx]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSystemParentFolderEx] (
		@path nvarchar(max))
	RETURNS nvarchar(max)
	AS 
	BEGIN
		SET @path = ltrim(rtrim(@path))
		IF (len(@path) = 0)
			RETURN ''  -- Error
		
		DECLARE @temp nvarchar(max)
		SET @temp = reverse(@path)

		DECLARE @pattern nvarchar(255)
		DECLARE @separator nvarchar(255)
		
		DECLARE @start bigint

		-- Windows
		SET @pattern = '%[\/]:[A-Za-z]'
		SET @separator = '[\/]'
		
		SET @start = patindex(@pattern, @temp collate SQL_Latin1_General_CP1_CI_AS)
		IF (@start = 0)
		BEGIN
			-- Share
			SET @pattern = '%[^\]\%[^\]\\'
			SET @separator = '[\]'

			SET @start = patindex(@pattern, @temp collate SQL_Latin1_General_CP1_CI_AS)
			IF (@start <> 0)
			BEGIN
				SET @start = @start + 2
			END
			ELSE
			BEGIN
				-- Linux
				SET @pattern = '%[^/]/'
				SET @separator = '[/]'
				
				SET @start = patindex(@pattern, @temp collate SQL_Latin1_General_CP1_CI_AS)
				IF (@start <> 0)
				BEGIN
					SET @start = @start + 1
				END
				ELSE
				BEGIN
					RETURN ''  -- Error
				END
			END
		END

		-- Processing
		DECLARE @index bigint
		SET @index = 1

		DECLARE @skip bit
		SET @skip = 'TRUE'

		DECLARE @char nvarchar
		DECLARE @flag bit
		
		WHILE (1 = 1)
		BEGIN
			IF (@index >= @start)
			BEGIN
				SET @index = @index - 1
				BREAK
			END

			SET @char = substring(@temp, @index, 1)

			SET @flag = 'FALSE'
	
			IF (patindex(@separator, @char collate SQL_Latin1_General_CP1_CI_AS) <> 0)
				SET @flag = 'TRUE'
	
			IF (@flag = 'FALSE' AND @skip = 'TRUE')
				SET @skip = 'FALSE'
	
			IF (@skip = 'FALSE' AND @flag = 'TRUE')
				BREAK

			SET @index = @index + 1
		END
		
		RETURN substring(@path, 1, len(@path) - @index)
	END
GO

--------------------------------------------------------------------------------
--
-- System.GetFileSystemSeparators
--
-- Returns separator symbols which is using by FS.
--
-- Parameters:
--     @type          - specifies FS type
--     @all_supported - specifies flag to return standard or all separators
--
-- Result:
--     Returns separator symbol or '' in a case of error.
--
-- Remarks:
--     UNC, Linux and Windows FS are supported.
--
-- Example:
--     PRINT [dbo].[System.GetFileSystemSeparator]('D:\123\ABC')
--
-- Output:
--     "\"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.GetFileSystemSeparators]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.GetFileSystemSeparators]'
GO

	CREATE FUNCTION [dbo].[System.GetFileSystemSeparators] (
		@type int,
		@all_supported bit = 'FALSE')
	RETURNS nvarchar(255)
	AS 
	BEGIN
		IF (@type = 0 AND @all_supported = 'TRUE')
		BEGIN
			RETURN '\/'
		END

		IF (@type = 0 OR @type = 2)
			RETURN '\'
		
		IF (@type = 1)
			RETURN '/'

		RETURN ''
	END
GO

--------------------------------------------------------------------------------
--
-- System.FileSystemRemoveSeparator
--
-- Remove one or more separators in the end of path.
--
-- Parameters:
--     @path - specifies the input path
--
-- Example:
--     PRINT [dbo].[System.FileSystemRemoveSeparator]('D:\123\\\\\\\\\\\///////\/\/\')
-- 
-- Output:
--     "D:\123"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FileSystemRemoveSeparator]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FileSystemRemoveSeparator]'
GO

	CREATE FUNCTION [dbo].[System.FileSystemRemoveSeparator] (
		@path nvarchar(max))
	RETURNS nvarchar(max)
	AS 
	BEGIN	
		SET @path = ltrim(rtrim(@path))

		DECLARE @type int
		SET @type = [dbo].[System.GetFileSystemType](@path)

		DECLARE @separators nvarchar(255)
		SET @separators = [dbo].[System.GetFileSystemSeparators](@type, 'TRUE')

		SET @path = [dbo].[System.RightTrimString](@path, @separators)

		IF ([dbo].[System.FileSystemIsRoot](@path) = 'TRUE')
		BEGIN
			DECLARE @separator nvarchar(255)
			SET @separator = [dbo].[System.GetFileSystemSeparators](@type, DEFAULT)

			SET @path = @path + @separator
		END

		RETURN @path
	END
GO

--------------------------------------------------------------------------------
--
-- System.FileSystemAddSeparator
--
-- Add optional separator to the end of path.
--
-- Parameters:
--     @path - specifies the input path
--
-- Example:
--     PRINT [dbo].[System.FileSystemAddSeparator]('D:\123\\\\\\\\\')
-- 
-- Output:
--     "D:\123\"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FileSystemAddSeparator]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FileSystemAddSeparator]'
GO

	CREATE FUNCTION [dbo].[System.FileSystemAddSeparator] (
		@path nvarchar(max))
	RETURNS nvarchar(max)
	AS 
	BEGIN	
		DECLARE @type int
		SET @type = [dbo].[System.GetFileSystemType](@path)

		DECLARE @separator nvarchar(255)
		SET @separator = [dbo].[System.GetFileSystemSeparators](@type, DEFAULT)

		SET @path = [dbo].[System.FileSystemRemoveSeparator](@path)

		IF ([dbo].[System.FileSystemIsRoot](@path) = 'FALSE')
		BEGIN
			SET @path = @path + @separator
		END	

		RETURN @path
	END
GO

--------------------------------------------------------------------------------
--
-- System.FileSystemBuildPath
--
-- Build new FS path using folder and item paths.
--
-- Parameters:
--     @folder - specifies folder path
--     @ite    - specifies item path
--
-- Result:
--     Returns new FS path or '' in a case of error.
--
-- Example:
--     PRINT [dbo].[System.FileSystemBuildPath]('D:\123\ABC', '2')
-- 
-- Output:
--     "D:\123\ABC\2"
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.FileSystemBuildPath]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.FileSystemBuildPath]'
GO

	CREATE FUNCTION [dbo].[System.FileSystemBuildPath] (
		@folder nvarchar(max),
		@item nvarchar(max))
	RETURNS nvarchar(max)
	AS 
	BEGIN	
		SET @folder = ltrim(rtrim(@folder))
		SET @item = ltrim(rtrim(@item))

		IF (len(@folder) != 0)
		BEGIN
			SET @folder = [dbo].[System.FileSystemRemoveSeparator](@folder)

			IF (len(@item) != 0)
				SET @folder = [dbo].[System.FileSystemAddSeparator](@folder)
		END

		RETURN @folder + @item
	END
GO

--------------------------------------------------------------------------------
--
-- System.CreateXmlLogRecord
--
-- Creates XML log record.
--
-- Parameters:
--     @id          - specifies position index of XML log record
--     @time        - specifies creation time
--     @title       - specifies log record's title
--     @make_pretty - specifies flag for optional title processing
--
-- Example:
--     <Log
--         Cookie=""
--         Usn="0"
--         Status="ESucceeded"
--         Style="ENone"
--         Id="12"
--         Time="2011-10-21T23:49:46.343"
--         UtcTime="10/21/2011 19:49:46"
--         StartTime="2011-10-21T23:49:46.343"
--     >
--         <Title>Failed to create VM locker</Title>
--         <Description/>
--     </Log>'
--
--------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.CreateXmlLogRecord]'
EXEC [dbo].[System.DeleteFunction] '[dbo].[System.CreateXmlLogRecord]'
GO

	CREATE FUNCTION [dbo].[System.CreateXmlLogRecord] (
		@id bigint,
		@time datetime,
		@title nvarchar(max),
		@make_pretty bit)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @str_time nvarchar(255)
		DECLARE @str_utc_time nvarchar(255)

		IF (@make_pretty = 'TRUE')
		BEGIN
			SET @title = ltrim(@title)
			SET @title = [dbo].[System.RightTrimString](@title, '. ')
			SET @title = [dbo].[System.EscapeText](@title)
		END

		SET @str_time = [dbo].[System.FormatIso8601DateTime](@time)
		SET @str_utc_time = [dbo].[System.FormatUtcInvariantDateTime](@time)

		RETURN
			'<Log Cookie="" Usn="0" Status="ESucceeded" Style="ENone" Id="' + cast(@id as nvarchar(255)) + 
			'" Time="' + @str_time + '" UtcTime="' + @str_utc_time + '" StartTime="' + @str_time + 
			'"><Title>' + @title + '</Title><Description/></Log>'
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.CompareString]
--
-- Compares two strings using case sensitive (CS) or case insensitive (CI) algorithm.
--
-- Returns:
--     'FALSE' - strings are different
--     'TRUE'  - strings are NULL or equal
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.CompareString]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.CompareString]'
GO

	CREATE FUNCTION [dbo].[System.CompareString] (
		@left as nvarchar(max),
		@right as nvarchar(max),
		@ignore_case as bit = 'TRUE')
	RETURNS bit
	AS
	BEGIN
		IF @left IS NULL AND @right IS NULL
			RETURN 'TRUE'

		IF @left IS NULL OR @right IS NULL
			RETURN 'FALSE'

		IF @ignore_case = 'TRUE'
		BEGIN
			IF @left = @right collate SQL_Latin1_General_CP1_CI_AS
				RETURN 'TRUE'
		END
		ELSE
		BEGIN
			IF @left = @right collate SQL_Latin1_General_CP1_CS_AS
				RETURN 'TRUE'
		END

		RETURN 'FALSE'
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeAttrCount]
--
-- Gets node attributes count.
--
-- Returns:
--     0 - node is NULL
--     N - node attributes count
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeAttrCount]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeAttrCount]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeAttrCount] (
		@node as xml)
	RETURNS int
	AS
	BEGIN
		IF @node IS NULL
			RETURN 0

		RETURN @node.value('count(/*/@*)', 'int')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeAttrExistByIndex]
--
-- Tests if node attribute with specified index exists.
--
-- Return:
--     'FALSE' - node is NULL, attribute not exist, index out of range
--     'TRUE'  - node attribute exists
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeAttrExistByIndex]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeAttrExistByIndex]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeAttrExistByIndex] (
		@node as xml,
		@attr_index as int)
	RETURNS bit
	AS
	BEGIN
		IF @node IS NULL
			RETURN 'FALSE'

		RETURN @node.exist('(/*/@*[sql:variable("@attr_index")])[1]')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeAttrNameByIndex]
--
-- Gets node attribute name by index (starts from 1).
--
-- Return:
--     NULL - node is NULL, index is out of range
--     name - node attribute name
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeAttrNameByIndex]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeAttrNameByIndex]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeAttrNameByIndex] (
		@node as xml,
		@attr_index as int)
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF @node IS NULL
			RETURN NULL

		RETURN @node.value('local-name((/*/@*[sql:variable("@attr_index")])[1])', 'nvarchar(max)')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeAttrValueByIndex]
--
-- Gets node attribute value by index (starts from 1).
--
-- Return:
--     NULL - node is NULL, index is out of range
--     name - node attribute value
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeAttrValueByIndex]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeAttrValueByIndex]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeAttrValueByIndex] (
		@node as xml,
		@attr_index as int,
		@default_value as nvarchar(max) = NULL)
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF @node IS NULL
			RETURN @default_value

		IF [dbo].[System.XmlNodeAttrExistByIndex](@node, @attr_index) = 'FALSE'
			RETURN @default_value

		RETURN @node.value('(/*/@*[sql:variable("@attr_index")])[1]', 'nvarchar(max)')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeAttrs]
--
-- Gets node attributes.
--
-- Return:
--     | index | name | value |
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeAttrs]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeAttrs]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeAttrs] (
		@node as xml)
	RETURNS @results table([index] int, [name] nvarchar(max), [value] nvarchar(max))
	AS
	BEGIN
		DECLARE @count as int
		SET @count = [dbo].[System.XmlNodeAttrCount](@node)

		DECLARE @index as int
		SET @index = 1

		WHILE @index <= @count
		BEGIN
			INSERT INTO @results
				([index], [name], [value])
			VALUES
				(@index, [dbo].[System.XmlNodeAttrNameByIndex](@node, @index), [dbo].[System.XmlNodeAttrValueByIndex](@node, @index, default))

			SET @index = @index + 1
		END

		RETURN
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeAttrExistByName]
--
-- Tests if node attribute with specified name exists.
--
-- Return:
--     'FALSE' - node is NULL, attribute not exist, CS names
--     'TRUE'  - node attribute exists
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeAttrExistByName]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeAttrExistByName]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeAttrExistByName] (
		@node as xml,
		@attr_name as nvarchar(max),
		@ignore_case as bit = 'TRUE')
	RETURNS bit
	AS
	BEGIN
		IF @ignore_case = 'TRUE'
		BEGIN
			IF EXISTS (SELECT [name] FROM [dbo].[System.XmlNodeAttrs](@node) WHERE [name] = @attr_name collate SQL_Latin1_General_CP1_CI_AS)
				RETURN 'TRUE'
		END
		ELSE
		BEGIN
			IF EXISTS (SELECT [name] FROM [dbo].[System.XmlNodeAttrs](@node) WHERE [name] = @attr_name collate SQL_Latin1_General_CP1_CS_AS)
				RETURN 'TRUE'
		END

		RETURN 'FALSE'
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeAttrValueByName]
--
-- Gets node attribute value by name.
--
-- Return:
--     default - node is NULL, attribute not exist, CS name
--     value   - node attribute value
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeAttrValueByName]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeAttrValueByName]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeAttrValueByName] (
		@node as xml,
		@attr_name as nvarchar(max),
		@default_value as nvarchar(max) = NULL,
		@ignore_case as bit = 'TRUE')
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @value as nvarchar(max)

		IF @ignore_case = 'TRUE'
		BEGIN
			SELECT TOP(1) @value = [value] FROM [dbo].[System.XmlNodeAttrs](@node) WHERE [name] = @attr_name collate SQL_Latin1_General_CP1_CI_AS
		END
		ELSE
		BEGIN
			SELECT TOP(1) @value = [value] FROM [dbo].[System.XmlNodeAttrs](@node) WHERE [name] = @attr_name collate SQL_Latin1_General_CP1_CS_AS
		END

		IF @@ROWCOUNT = 0
			RETURN @default_value

		RETURN @value
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeName]
--
-- Gets current node name.
--
-- Return:
--     NULL - current node is NULL
--     name - current node name
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeName]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeName]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeName] (
		@node as xml)
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF @node IS NULL
			RETURN NULL

		RETURN @node.value('(local-name((/*)[1]))', 'nvarchar(max)')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlNodeValue]
--
-- Gets current node value.
--
-- Return:
--     NULL  - current node is NULL
--     value - current node value
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlNodeValue]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlNodeValue]'
GO

	CREATE FUNCTION [dbo].[System.XmlNodeValue] (
		@node as xml)
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF @node IS NULL
			RETURN NULL

		RETURN @node.value('(/*/text())[1]', 'nvarchar(max)')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlGlobalNodeExist]
--
-- Tests for global node existing. Case sensitive.
--
-- Return:
--     'FALSE' - root node is NULL or global node not exist
--     'TRUE'  - global node exist
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlGlobalNodeExist]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlGlobalNodeExist]'
GO

	CREATE FUNCTION [dbo].[System.XmlGlobalNodeExist] (
		@node as xml,
		@node_name as nvarchar(max))
	RETURNS bit
	AS
	BEGIN
		IF @node IS NULL
			RETURN 'FALSE'

		RETURN @node.exist('//*[local-name()=sql:variable("@node_name")]')
	END
GO

-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlGlobalNodeValue]
--
-- Gets global node value.
--
-- Result:
--     default - root node is NULL or global node not exist
--     value   - global node value
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlGlobalNodeValue]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlGlobalNodeValue]'
GO

	CREATE FUNCTION [dbo].[System.XmlGlobalNodeValue] (
		@node as xml,
		@node_name as nvarchar(max),
		@default_value as nvarchar(max) = NULL)
	RETURNS nvarchar(max)
	AS
	BEGIN
		RETURN CASE WHEN [dbo].[System.XmlGlobalNodeExist](@node, @node_name) = 'FALSE'
			THEN @default_value
			ELSE @node.value('(//*[local-name()=sql:variable("@node_name")]/text())[1]', 'nvarchar(max)')
		END
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodeCount]
--
-- Gets child nodes count.
--
-- Returns:
--     0 - node is NULL
--     N - child nodes count
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodeCount]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodeCount]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodeCount] (
		@node as xml)
	RETURNS int
	AS
	BEGIN
		IF @node IS NULL
			RETURN 0

		RETURN @node.value('count(/*/*)', 'int')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodeByIndex]
--
-- Gets child node by index (starts from 1).
--
-- Return:
--     NULL - node is NULL, index is out of range
--     name - child node
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodeByIndex]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodeByIndex]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodeByIndex] (
		@node as xml,
		@child_index as int)
	RETURNS xml
	AS
	BEGIN
		IF @node IS NULL
			RETURN NULL

		RETURN @node.query('/*/*[sql:variable("@child_index")]')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodeExistByIndex]
--
-- Tests child node for existing by index (starts from 1).
--
-- Return:
--     'FALSE' - node is NULL, index is out of range
--     'TRUE'  - child node name
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodeExistByIndex]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodeExistByIndex]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodeExistByIndex] (
		@node as xml,
		@child_index as int)
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF @node IS NULL
			RETURN NULL

		RETURN @node.exist('/*/*[sql:variable("@child_index")]')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodeNameByIndex]
--
-- Gets child node name by index (starts from 1).
--
-- Return:
--     NULL - node is NULL, index is out of range
--     name - child node name
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodeNameByIndex]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodeNameByIndex]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodeNameByIndex] (
		@node as xml,
		@child_index as int)
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF @node IS NULL
			RETURN NULL

		RETURN @node.value('local-name((/*/*[sql:variable("@child_index")])[1])', 'nvarchar(max)')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodeValueByIndex]
--
-- Gets child node value by index (starts from 1).
--
-- Return:
--     default - node is NULL, index is out of range, child node not exist
--     name    - child node value
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodeValueByIndex]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodeValueByIndex]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodeValueByIndex] (
		@node as xml,
		@child_index as int,
		@default_value as nvarchar(max) = NULL)
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF @node IS NULL
			RETURN @default_value

		IF [dbo].[System.XmlChildNodeExistByIndex](@node, @child_index) = 'FALSE'
			RETURN @default_value

		RETURN @node.value('(/*/*[sql:variable("@child_index")]/text())[1]', 'nvarchar(max)')
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodes]
--
-- Gets child nodes.
--
-- Return:
--     | index | name | value |
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodes]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodes]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodes] (
		@node as xml)
	RETURNS @results table([index] int, [name] nvarchar(max), [value] nvarchar(max))
	AS
	BEGIN
		DECLARE @count as int
		SET @count = [dbo].[System.XmlChildNodeCount](@node)

		DECLARE @index as int
		SET @index = 1

		WHILE @index <= @count
		BEGIN
			INSERT INTO @results
				([index], [name], [value])
			VALUES
				(@index, [dbo].[System.XmlChildNodeNameByIndex](@node, @index), [dbo].[System.XmlChildNodeValueByIndex](@node, @index, default))

			SET @index = @index + 1
		END

		RETURN
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodeExistByName]
--
-- Tests if child node with specified name exists.
--
-- Return:
--     'FALSE' - node is NULL, child node not exist, CS names
--     'TRUE'  - child node exist
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodeExistByName]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodeExistByName]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodeExistByName] (
		@node as xml,
		@child_name as nvarchar(max),
		@ignore_case as bit)
	RETURNS bit
	AS
	BEGIN
		IF @ignore_case = 'TRUE'
		BEGIN
			IF EXISTS (SELECT [name] FROM [dbo].[System.XmlChildNodes](@node) WHERE [name] = @child_name collate SQL_Latin1_General_CP1_CI_AS)
				RETURN 'TRUE'
		END
		ELSE
		BEGIN
			IF EXISTS (SELECT [name] FROM [dbo].[System.XmlChildNodes](@node) WHERE [name] = @child_name collate SQL_Latin1_General_CP1_CS_AS)
				RETURN 'TRUE'
		END

		RETURN 'FALSE'
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.XmlChildNodeValueByName]
--
-- Gets child node value by name.
--
-- Return:
--     default - node is NULL, attribute not exist, CS name
--     value   - child node vlaue
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.XmlChildNodeValueByName]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.XmlChildNodeValueByName]'
GO

	CREATE FUNCTION [dbo].[System.XmlChildNodeValueByName] (
		@node as xml,
		@child_name as nvarchar(max),
		@default_value as nvarchar(max) = NULL,
		@ignore_case as bit = 'TRUE')
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @value as nvarchar(max)

		DECLARE @child_nodes table([index] int, [name] nvarchar(max), [value] nvarchar(max))

		INSERT INTO @child_nodes ([index], [name], [value])
		SELECT [index], [name], [value] FROM [dbo].[System.XmlChildNodes](@node)

		IF @ignore_case = 'TRUE'
		BEGIN
			IF NOT EXISTS (SELECT TOP(1) * FROM @child_nodes WHERE [name] = @child_name collate SQL_Latin1_General_CP1_CI_AS)
				RETURN @default_value

			SELECT TOP(1) @value = [value] FROM @child_nodes WHERE [name] = @child_name collate SQL_Latin1_General_CP1_CI_AS
		END
		ELSE
		BEGIN
			IF NOT EXISTS (SELECT TOP(1) * FROM @child_nodes WHERE [name] = @child_name collate SQL_Latin1_General_CP1_CS_AS)
				RETURN @default_value

			SELECT TOP(1) @value = [value] FROM @child_nodes WHERE [name] = @child_name collate SQL_Latin1_General_CP1_CS_AS
		END

		RETURN @value
	END
GO


-------------------------------------------------------------------------------
--
-- [dbo].[System.CompareXml]
--
-- Compares two xml using case sensitive (CS) or case insensitive (CI) algorithm.
--
-- Returns:
--     'FALSE' - xmls are different
--     'TRUE'  - xmls are NULL or equal
--
-------------------------------------------------------------------------------
PRINT 'Creating [dbo].[System.CompareXml]'
	EXEC [dbo].[System.DeleteFunction] '[dbo].[System.CompareXml]'
GO

	CREATE FUNCTION [dbo].[System.CompareXml] (
		@left as xml,
		@right as xml,
		@ignore_case as bit)
	RETURNS bit
	AS
	BEGIN
		DECLARE @left_index as int
		DECLARE @right_index as int
		DECLARE @flag as bit

		IF @left IS NULL AND @right IS NULL
			RETURN 'TRUE'

		IF @left IS NULL OR @right IS NULL
			RETURN 'FALSE'

		-- Compare nodes names

		DECLARE @left_node_name as nvarchar(max)
		DECLARE @right_node_name as nvarchar(max)

		SET @left_node_name = [dbo].[System.XmlNodeName](@left)
		SET @right_node_name = [dbo].[System.XmlNodeName](@right)

		IF [dbo].[System.CompareString](@left_node_name, @right_node_name, @ignore_case) = 'FALSE'
			RETURN 'FALSE'

		-- Compare nodes values

		DECLARE @left_node_value as nvarchar(max)
		DECLARE @right_node_value as nvarchar(max)

		SET @left_node_value = [dbo].[System.XmlNodeValue](@left)
		SET @right_node_value = [dbo].[System.XmlNodeValue](@right)

		IF [dbo].[System.CompareString](@left_node_value, @right_node_value, @ignore_case) = 'FALSE'
			RETURN 'FALSE'

		-- Compare nodes attributes count
        
		DECLARE @left_attrs_count as int
		DECLARE @right_attrs_count as int

		SET @left_attrs_count = [dbo].[System.XmlNodeAttrCount](@left)
		SET @right_attrs_count = [dbo].[System.XmlNodeAttrCount](@right)

		IF @left_attrs_count <> @right_attrs_count
			RETURN 'FALSE'

		-- Compare child nodes count

		DECLARE @left_childs_count as int
		DECLARE @right_childs_count as int

		SET @left_childs_count = [dbo].[System.XmlChildNodeCount](@left)
		SET @right_childs_count = [dbo].[System.XmlChildNodeCount](@right)

		IF @left_childs_count <> @right_childs_count
			RETURN 'FALSE'

		-- Compare nodes attributes
		
		DECLARE @left_attr_name as nvarchar(max)
		DECLARE @left_attr_value as nvarchar(max)

		DECLARE @right_attr_name as nvarchar(max)
		DECLARE @right_attr_value as nvarchar(max)
		
		SET @left_index = 1

		WHILE @left_index <= @left_attrs_count
		BEGIN
			SET @left_attr_name = [dbo].[System.XmlNodeAttrNameByIndex](@left, @left_index)
			SET @left_attr_value = [dbo].[System.XmlNodeAttrValueByIndex](@left, @left_index, default)

			SET @right_index = 1
			SET @flag = 'FALSE'

			WHILE @right_index <= @right_attrs_count
			BEGIN
				SET @right_attr_name = [dbo].[System.XmlNodeAttrNameByIndex](@right, @right_index)
				SET @right_attr_value = [dbo].[System.XmlNodeAttrValueByIndex](@right, @right_index, default)

				IF [dbo].[System.CompareString](@left_attr_name, @right_attr_name, @ignore_case) = 'TRUE' AND [dbo].[System.CompareString](@left_attr_value, @right_attr_value, @ignore_case) = 'TRUE'
				BEGIN
					SET @flag = 'TRUE'
					BREAK
				END

				SET @right_index = @right_index + 1
			END

			IF @flag = 'FALSE'
				RETURN 'FALSE'

			SET @left_index = @left_index + 1
		END

		-- Compare child nodes

		DECLARE @left_child as xml
		DECLARE @right_child as xml
		
		SET @left_index = 1

		WHILE @left_index <= @left_childs_count
		BEGIN
			SET @left_child = [dbo].[System.XmlChildNodeByIndex](@left, @left_index)

			SET @right_index = 1
			SET @flag = 'FALSE'

			WHILE @right_index <= @right_childs_count
			BEGIN
				SET @right_child = [dbo].[System.XmlChildNodeByIndex](@right, @right_index)

				IF [dbo].[System.CompareXml](@left_child, @right_child, @ignore_case) = 'TRUE'
				BEGIN
					SET @flag = 'TRUE'
					BREAK
				END

				SET @right_index = @right_index + 1
			END

			IF @flag = 'FALSE'
				RETURN 'FALSE'

			SET @left_index = @left_index + 1
		END

		RETURN 'TRUE'
	END
GO
