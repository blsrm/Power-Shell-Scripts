/********* Hosts **************************************/
 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Hosts]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Hosts]
		(
				[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Hosts_id]  DEFAULT (newid()),
				[type] [int] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[ip] [nvarchar](50) NULL,
				[parent_id] [uniqueidentifier] NULL,
				[info] [nvarchar](255) NOT NULL DEFAULT (''),
				[description] [nvarchar](1024) NOT NULL DEFAULT (''),
				[protocol] [int] NOT NULL DEFAULT ((0)),
				[reference] [nvarchar](1024) NOT NULL DEFAULT (''),
				[api_version] [int] NOT NULL DEFAULT ((0)),
				[db_instance_id] [uniqueidentifier] NULL,
				[win_creds] [xml] NOT NULL,
				CONSTRAINT [PK_Hosts] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
				CONSTRAINT [IX_Hosts] UNIQUE NONCLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		) 
		ON [PRIMARY]
	END
GO

/********* Folders **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Folders]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Folders]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Folders_id]  DEFAULT (newid()),
			[parent_id] [uniqueidentifier] NULL,
			[name] [nvarchar](255) NULL,
			[db_instance_id] [uniqueidentifier] NULL,
		    CONSTRAINT [PK_Folders] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]
	END
GO

/********* Version **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Version]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Version]([current_version] int) ON [PRIMARY]
	END
GO

/********* ObjectsInJobs **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Folder_Host]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Folder_Host]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Folder_Host_id]  DEFAULT (newid()),
			[folder_id] [uniqueidentifier] NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL,
			CONSTRAINT [PK_Folder_Host] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		) 
		ON [PRIMARY]
	END
GO

/********* ObjectsInJobs **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ObjectsInJobs]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[ObjectsInJobs]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_ObjectsInJobs_id]  DEFAULT (newid()),
			[job_id] [uniqueidentifier] NOT NULL,
			[object_id] [uniqueidentifier] NULL,
			[folder_id] [uniqueidentifier] NULL,
			[vss_options] [xml] NOT NULL CONSTRAINT [DF__ObjectsIn__vss_o__00200768]  DEFAULT ('<CVssOptions/>'),
			[approx_size] [bigint] NOT NULL CONSTRAINT [DF__ObjectsIn__appro__0E6E26BF]  DEFAULT ((0)),
			[location] [nvarchar](1024) NOT NULL CONSTRAINT [DF__ObjectsIn__locat__0F624AF8]  DEFAULT (''),
			[type] [int] NOT NULL CONSTRAINT [DF__ObjectsInJ__type__2A164134]  DEFAULT ((0)),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			CONSTRAINT [PK_ObjectsInJobs] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		) 
		ON [PRIMARY]
	END
GO

/********* Soap_creds **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Soap_creds]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Soap_creds]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Soap_creds_id]  DEFAULT (newid()),
			[host_id] [uniqueidentifier] NOT NULL,
			[port] [int] NOT NULL,
			[user] [nvarchar](255) NOT NULL,
			[password] [nvarchar](1024) NULL,
			[savepassword] [bit] NOT NULL,
			[useproxy] [bit] NOT NULL,
			[proxyip] [nvarchar](50) NULL,
			[proxyport] [int] NULL,
			[enabled] [bit] NOT NULL DEFAULT ((1)),
			[db_instance_id] [uniqueidentifier] NULL,
			CONSTRAINT [PK_Soap_creds] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		) 
		ON [PRIMARY]
	END
GO

/********* BJobs **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BJobs]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[BJobs]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_BJobs_id]  DEFAULT (newid()),
			[type] [int] NOT NULL,
			[name] [nvarchar](255) NOT NULL,
			[target_host_id] [uniqueidentifier] NOT NULL,
			[target_dir] [nvarchar](2000) NULL,
			[target_file] [nvarchar](2000) NULL,
			[options] [xml] NULL,
			[schedule] [xml] NULL,
			[is_deleted] [bit] NOT NULL CONSTRAINT [DF__BJobs__is_delete__0EA330E9]  DEFAULT ((0)),
			[latest_result] [int] NOT NULL CONSTRAINT [DF__BJobs__latest_re__0F975522]  DEFAULT ((-1)),
			[post_command_run_count] [int] NOT NULL CONSTRAINT [DF__BJobs__post_comm__6B24EA82]  DEFAULT ((0)),
			[control] [int] NOT NULL CONSTRAINT [DF__BJobs__control__7E37BEF6]  DEFAULT ((0)),
			[vss_options] [xml] NOT NULL CONSTRAINT [DF__BJobs__vss_optio__7F2BE32F]  DEFAULT ('<CVssOptions/>'),
			[vcb_host_id] [uniqueidentifier] NOT NULL CONSTRAINT [DF__BJobs__vcb_host___03F0984C]  DEFAULT ('6745a759-2205-4cd2-b172-8ec8f7e60ef8'),
			[target_type] [int] NOT NULL CONSTRAINT [DF__BJobs__target_ty__08B54D69]  DEFAULT ((0)),
			[description] [nvarchar](1024) NOT NULL CONSTRAINT [DF__BJobs__descripti__09A971A2]  DEFAULT (''),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[next_run_time] [datetime],
			[schedule_enabled] bit NOT NULL,
			CONSTRAINT [PK_BJobs] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		)
		ON [PRIMARY]
	END
GO

/********* BObjects **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BObjects]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[BObjects]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_BObjects_ID]  DEFAULT (newid()),
			[type] [int] NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[object_name] [nvarchar](2000) NULL,
			[object_id] [nvarchar](434) NULL,
			[viobject_type] [nvarchar](50) NULL,
			[guest_os] [xml] NOT NULL CONSTRAINT [DF__BObjects__guest___10566F31]  DEFAULT (''),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[mb_size] [bigint] NULL,
			CONSTRAINT [PK_BObjects] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		) 
		ON [PRIMARY]
	END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BObjects]') AND name = N'IX_BObjects')
	CREATE UNIQUE NONCLUSTERED INDEX [IX_BObjects] ON [dbo].[BObjects] 
	(
		[host_id] ASC,
		[object_id] ASC,
		[db_instance_id] ASC
	)
	WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
GO

/********* Backups **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backups]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Backups_ID]  DEFAULT (newid()),
			[creation_time] [datetime] NOT NULL,
			[is_rollback] [bit] NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[linked_rollback] [uniqueidentifier] NULL,
			[job_name] [nvarchar](255) NOT NULL,
			[job_id] [uniqueidentifier] NULL,
			[job_type] [int] NOT NULL CONSTRAINT [DF__Backups__job_typ__164452B1]  DEFAULT ((0)),
			[is_retry] [bit] NOT NULL CONSTRAINT [DF__Backups__is_retr__173876EA]  DEFAULT ((0)),
			[file_name] [nvarchar](255) NULL,
			[stats] [xml] NULL,
			[version] [int] NOT NULL CONSTRAINT [DF__Backups__version__02084FDA]  DEFAULT ((0)),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[full_size] [bigint] NOT NULL,
			[is_last] bit NOT NULL,
			CONSTRAINT [PK_Backups] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		) 
		ON [PRIMARY]
	END
GO

/********* Ssh_creds **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Ssh_creds]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Ssh_creds_id]  DEFAULT (newid()),
			[host_id] [uniqueidentifier] NOT NULL,
			[user] [nvarchar](255) NOT NULL,
			[password] [nvarchar](1024) NULL,
			[savepassword] [bit] NOT NULL,
			[elevatetoroot] [bit] NOT NULL,
			[rootpassword] [nvarchar](1024) NULL,
			[port] [int] NOT NULL,
			[startftport] [int] NOT NULL,
			[endftport] [int] NOT NULL,
			[buffersize] [int] NOT NULL,
			[isftserver] [bit] NOT NULL,
			[timeout] [int] NOT NULL,
			[adjust_firewall] [bit] NOT NULL DEFAULT ((0)),
			[auto_sudo] [bit] NOT NULL DEFAULT ((1)),
			[enabled] [bit] NOT NULL DEFAULT ((1)),
			[db_instance_id] [uniqueidentifier] NULL,
			CONSTRAINT [PK_Ssh_creds] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		)
		ON [PRIMARY]
	END
GO

/********* BSessions **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BSessions]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[BSessions]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_BSessions_id]  DEFAULT (newid()),
			[creation_time] [datetime] NOT NULL,
			[job_id] [uniqueidentifier] NULL,
			[job_name] [nvarchar](255) NOT NULL,
			[overall_status] [int] NOT NULL CONSTRAINT [DF_BSessions_overall_status]  DEFAULT ((-1)),
			[progress] [int] NOT NULL CONSTRAINT [DF__BSessions__progr__1FCDBCEB]  DEFAULT ((0)),
			[description] [text] NULL CONSTRAINT [DF__BSessions__descr__20C1E124]  DEFAULT (NULL),
			[job_type] [int] NOT NULL CONSTRAINT [DF__BSessions__job_t__21B6055D]  DEFAULT ((0)),
			[is_retry] [bit] NOT NULL CONSTRAINT [DF__BSessions__is_re__22AA2996]  DEFAULT ((0)),
			[end_time] [datetime] NOT NULL CONSTRAINT [DF__BSessions__end_t__6D0D32F4]  DEFAULT ('01.01.1900'),
			[operation] [nvarchar](400) NOT NULL CONSTRAINT [DF__BSessions__opera__74AE54BC]  DEFAULT (''),
			[total_objects] [int] NOT NULL CONSTRAINT [DF__BSessions__total__75A278F5]  DEFAULT ((0)),
			[processed_objects] [int] NOT NULL CONSTRAINT [DF__BSessions__proce__76969D2E]  DEFAULT ((0)),
			[total_size] [bigint] NOT NULL CONSTRAINT [DF__BSessions__total__778AC167]  DEFAULT ((0)),
			[processed_size] [bigint] NOT NULL CONSTRAINT [DF__BSessions__proce__787EE5A0]  DEFAULT ((0)),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[usn] [bigint] NOT NULL,
			[job_source_type] [int] NOT NULL,
			[avg_speed] [bigint] NOT NULL,
			[is_startfull] bit NOT NULL,
			CONSTRAINT [PK_BSessions] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		)
		ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	END
GO

/********* ObjectsInBackups **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ObjectsInBackups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[ObjectsInBackups]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_ObjectsInBackups_id]  DEFAULT (newid()),
			[object_id] [uniqueidentifier] NOT NULL,
			[backup_id] [uniqueidentifier] NOT NULL,
			[filename] [nvarchar](1000) NULL,
			[is_corrupted] [bit] NOT NULL CONSTRAINT [DF__ObjectsIn__is_co__276EDEB3]  DEFAULT ((0)),
			[state] [int] NOT NULL CONSTRAINT [DF__ObjectsIn__state__267ABA7A]  DEFAULT ((0)),
			[inside_dir] [nvarchar](400) NOT NULL CONSTRAINT [DF__ObjectsIn__insid__6E01572D]  DEFAULT ('empty'),
			[is_full] [bit] NOT NULL CONSTRAINT [DF__ObjectsIn__is_fu__0B91BA14]  DEFAULT ((1)),
			[creation_time] [datetime] NOT NULL CONSTRAINT [DF__ObjectsIn__creat__1332DBDC]  DEFAULT ('01.01.1900'),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[approx_size] bigint NOT NULL
			CONSTRAINT [PK_ObjectsInBackups_1] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		) 
		ON [PRIMARY]
	END
GO

/********* BSessionInfo **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BSessionInfo]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[BSessionInfo]
		(
			[id] [uniqueidentifier] NOT NULL,
			[session_id] [uniqueidentifier] NOT NULL,
			[creation_time] [datetime] NOT NULL,
			[object_name] [nvarchar](2000) NULL,
			[status] [int] NOT NULL CONSTRAINT [DF_BSessionInfo_status]  DEFAULT ((-1)),
			[reason] [ntext] NULL,
			[backup_id] [uniqueidentifier] NULL,
			[object_id] [uniqueidentifier] NULL,
			[end_time] [datetime] NOT NULL CONSTRAINT [DF__BSessionI__end_t__6C190EBB]  DEFAULT ('01.01.1900'),
			[operation] [nvarchar](400) NOT NULL CONSTRAINT [DF__BSessionI__opera__797309D9]  DEFAULT (''),
			[total_objects] [int] NOT NULL CONSTRAINT [DF__BSessionI__total__7A672E12]  DEFAULT ((0)),
			[processed_objects] [int] NOT NULL CONSTRAINT [DF__BSessionI__proce__7B5B524B]  DEFAULT ((0)),
			[total_size] [bigint] NOT NULL CONSTRAINT [DF__BSessionI__total__7C4F7684]  DEFAULT ((0)),
			[processed_size] [bigint] NOT NULL CONSTRAINT [DF__BSessionI__proce__7D439ABD]  DEFAULT ((0)),
			[mode] [int] NOT NULL CONSTRAINT [DF__BSessionIn__mode__123EB7A3]  DEFAULT ((0)),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[avg_speed] [bigint] NOT NULL,
			[usn] [bigint] NOT NULL,
		    CONSTRAINT [PK_BSessionInfo] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		) 
		ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	END
GO

/********* LicensedHosts **************************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[LicensedHosts]
		(
			[id] [uniqueidentifier] NOT NULL,
			[uuid] [nvarchar](255) NOT NULL,
			[name] [nvarchar](255) NOT NULL,
			[cpu] [int] NOT NULL,
			[type] [int] NOT NULL CONSTRAINT [DF__LicensedHo__type__114A936A]  DEFAULT ((0)),
			[db_instance_id] [uniqueidentifier] NOT NULL,
			CONSTRAINT [PK_LicensedHosts] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
		) 
		ON [PRIMARY]
	END
GO

/*******************************************************************************************
*
*	VIEWS
*
********************************************************************************************/
	CREATE VIEW [dbo].[view.Notification.JobsData]
		AS
			SELECT DISTINCT
				type,
				latest_result,
				COUNT(*) OVER(PARTITION BY type, latest_result)  as count
			FROM [dbo].[BJobs]
GO
/*******************************************************************************************
*
*	HELPER - FUNCTIONS
*
********************************************************************************************/

/********************************************************************************************
*
*	REPLICATION TABLES
*
*********************************************************************************************/

		/********* Repl_Scheme_FieldsBindings **************************************/
		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Scheme.ColumnsBindings]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.Scheme.ColumnsBindings]
				(
					[id] [uniqueidentifier] NOT NULL,
					[tables_binding] [uniqueidentifier] NOT NULL,
					[source_field] [nvarchar](50) NOT NULL,
					[target_field] [nvarchar](50) NOT NULL,
					[column_sql_type] [int] NOT NULL,
					CONSTRAINT [PK_Repl_Scheme_FieldsBindings] PRIMARY KEY CLUSTERED 
					(
						[id] ASC	
					)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
				)
				ON [PRIMARY]
			END
		GO
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Scheme.ComputeColumnsBindings]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.Scheme.ComputeColumnsBindings]
				(
					[id] [uniqueidentifier] NOT NULL,
					[tables_binding] [uniqueidentifier] NOT NULL,
					[compute_field] [nvarchar](50) NOT NULL,
					[target_field] [nvarchar](50) NOT NULL,
					[column_sql_type] [int] NOT NULL,
					CONSTRAINT [PK_Repl_Scheme_ComputeColumnsBindings] PRIMARY KEY CLUSTERED 
					(
						[id] ASC	
					)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
				)
				ON [PRIMARY]
			END
		GO
		/********* Repl.Scheme.TablesBindings**************************************/
		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Scheme.TablesBindings]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.Scheme.TablesBindings]
				(
					[id] [uniqueidentifier] NOT NULL,
					[source_table] [nvarchar](255) NOT NULL,
					[source_id_field] [nvarchar](255) NOT NULL,
					[target_table] [nvarchar](255) NOT NULL,
					[target_id_field] [nvarchar](255) NOT NULL,
					[import_updates_procedure][nvarchar](100) NOT NULL DEFAULT 'usp_Import_StubUpdates',
					[import_dels_procedure][nvarchar](100) NOT NULL DEFAULT 'usp_Import_StubDels',
					CONSTRAINT [PK_Repl.Scheme.TablesBindings] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
				) 
				ON [PRIMARY]
			END
		GO

		/********* Repl.Topology.BackupDbInstances **************************************/
		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Topology.BackupDbInstances]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.Topology.BackupDbInstances]
				(
					[id] [uniqueidentifier] NOT NULL,					
					[last_sync_usn] [bigint] NOT NULL,
					[last_sync_time] [datetime] NOT NULL,
					[update_usn][bigint] NOT NULL,
					CONSTRAINT [PK_Repl.Topology.BackupDbInstances] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
				) 
				ON [PRIMARY]
			END
		GO

		/********* Repl.Topology.BackupServers **************************************/
		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Topology.BackupServers]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.Topology.BackupServers]
				(
					[id] [uniqueidentifier] NOT NULL,
					[display_name] [nvarchar](255) NOT NULL,
					[ip_or_dns_name] [nvarchar](50) NOT NULL,
					[description] [nvarchar](2000) NULL,
					[current_db_id][uniqueidentifier] NULL,					
					[port] [int] NOT NULL,
					CONSTRAINT [PK_Repl.Topology.BackupServers] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
				)
				ON [PRIMARY]
			END

		/********* Repl.Topology.BackupServerCreds **************************************/

		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Topology.BackupServerCreds]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.Topology.BackupServerCreds]
				(
					[id] [uniqueidentifier] NOT NULL,
					[backup_server] [uniqueidentifier] NOT NULL,
					[domain] [nvarchar](255) NOT NULL,
					[login] [nvarchar](255) NOT NULL,
					[pwd] [nvarchar](1024) NOT NULL,
					CONSTRAINT [PK_Repl.Topology.BackupServerCreds] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
				) 
				ON [PRIMARY]
			END

		/********* Repl.Sessions **************************************/
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Sessions]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.Sessions]
				(
					[id] [uniqueidentifier] NOT NULL,
					[request_type] [int] NOT NULL,
					[start_date] [datetime] NOT NULL,
					[status] [int] NOT NULL,
					[end_date] [datetime],
					[details] [nvarchar](max) NOT NULL,
					[ordinal_number] int,
					CONSTRAINT [PK_Repl.Sessions] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
				) 
				ON [PRIMARY]
			END
		GO	
		
		/********* Repl.ServerSessions **************************************/	
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.ServerSessions]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.ServerSessions]
				(
					[id] [uniqueidentifier] NOT NULL,
					[backup_server] [nvarchar] (300) NOT NULL,
					[backup_server_id] [uniqueidentifier] NOT NULL,
					--[sync_type] [int] NOT NULL,
					[start_date] [datetime] NOT NULL,
					[end_date] [datetime] NULL,
					[status] [int] NOT NULL,
					[comment] [nvarchar](max) NOT NULL
					CONSTRAINT [PK_Repl.ServerSessions] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
				) 
				ON [PRIMARY]
			END
		GO
		
		/********* Repl.SessionRelations **************************************/	
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.SessionRelations]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Repl.SessionRelations]
				(
					[id] [uniqueidentifier] NOT NULL,
					[parent_session_id] [uniqueidentifier] NOT NULL,
					[server_session_id] [uniqueidentifier] NOT NULL,
					CONSTRAINT [PK_Repl.SessionRelations] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
				) 
				ON [PRIMARY]
			END
		GO
	
/********************************************************************************************
*
*	RENDERING TABLES
*
*********************************************************************************************/

	/********************* Rendering.Containers ****************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rendering.Containers]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Rendering.Containers]
			(
				[id] [uniqueidentifier] NOT NULL,
				[display_name] [nvarchar](255) NOT NULL,
				[type] [int] NOT NULL,
				[is_history_bar_required][bit] NOT NULL,
				CONSTRAINT [PK_Rendering.Containers] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
			)
			ON [PRIMARY]
		END
	GO


	/********************* Rendering.HyperlinkTransitions ****************************/		
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rendering.HyperlinkTransitions]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Rendering.HyperlinkTransitions]
			(
				[id] [uniqueidentifier] NOT NULL,
				[source_container_id] [uniqueidentifier] NOT NULL,
				[hyperlink_id] [uniqueidentifier] NOT NULL,
				[target_container_id] [uniqueidentifier] NOT NULL,
				CONSTRAINT [PK_Rendering.HyperlinkTransitions] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
								
			)
			ON [PRIMARY]
		END	
	GO
	

	/****************************** Rendering.ImageFolders   ******/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rendering.ImageFolders]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Rendering.ImageFolders]
			(
				[id] [uniqueidentifier] NOT NULL,
				[folder_name] [nvarchar](255) NOT NULL
				CONSTRAINT [PK_Rendering.ImageFolders] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
			) 
			ON [PRIMARY]
		END
	GO
	
	
	


	/****************************** Rendering.ImageFiles   ******/
	
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rendering.ImageFiles]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Rendering.ImageFiles]
			(
				[id] [uniqueidentifier] NOT NULL,
				[folder_id] [uniqueidentifier] NOT NULL,
				[file_name] [nvarchar](255) NOT NULL,
				CONSTRAINT [PK_Rendering.ImageFiles] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]			
			)
			ON [PRIMARY]
		END
	GO

/*************************************************************************************************************
*
*	REPORT TABLES
*
**************************************************************************************************************/

	/****************************** Report.GridReport.Columns   ******/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Columns]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.Columns]
			(
				[id] [uniqueidentifier] NOT NULL,
				[grid_report_id] [uniqueidentifier] NOT NULL,
				[display_name] [nvarchar](100) NOT NULL,
				[unique_name] [nvarchar](100) NOT NULL,
				[ordinal_number] [int] NOT NULL,
				[relative_width] [int] NOT NULL,
				[is_sortable] [bit] NOT NULL,
				[order_id] [uniqueidentifier] NULL,
				[icon_binding_id] [uniqueidentifier] NULL,
				[text_binding_id] [uniqueidentifier] NULL,
				[href_binding_id] [uniqueidentifier] NULL,				
				CONSTRAINT [PK_Report.GridReport.Columns] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
			)
			ON [PRIMARY]
		END
	GO
	
	/****************************** Report.GridReport.Columns   ******/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.HiddenColumns]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.HiddenColumns]
			(
				[id] [uniqueidentifier] NOT NULL,
				[grid_report_id] [uniqueidentifier] NOT NULL,
				[unique_name] [nvarchar](100) NOT NULL,
				[binding_id] [uniqueidentifier] NULL,
				CONSTRAINT [PK_Report.GridReport.HiddenColumns] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
			)
			ON [PRIMARY]
		END
	GO	
		
	/******************************** Report.GridReport.DetailsPanels ***************************************/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.DetailsPanels]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.DetailsPanels]
			(
				[id] [uniqueidentifier] NOT NULL,
				[panel_width] [int] NOT NULL,
				[text_binding_id] [uniqueidentifier] NOT NULL,
				[title] [nvarchar](100) NOT NULL,
				[default_text] nvarchar(max) NOT NULL,
				CONSTRAINT [PK_Report.GridReport.DetailsPanels] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]			
			)
			ON [PRIMARY]
		END
	GO

	
	/*********************** Report.GridReport.Filters ********************************************************/		
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Filters]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.GridReport.Filters]
			(
				[id] [uniqueidentifier] NOT NULL,
				[grid_report_id] [uniqueidentifier] NOT NULL,
				[filter_type_id] [uniqueidentifier] NOT NULL,
				[display_name] [nvarchar](255) NOT NULL,
				[unique_name][nvarchar](100) NOT NULL,
				[ordinal_number] [int] NOT NULL,
				[width] [int] NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Filters] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					
			)
			ON [PRIMARY]
		END
	GO
	
	
	/*********************** Report.GridReport.Orders ********************************************************/		
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Orders]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.GridReport.Orders]
			(
				[id] [uniqueidentifier] NOT NULL,
				[grid_report_id] [uniqueidentifier] NOT NULL,
				[column_name] [nvarchar](50) NOT NULL,
				[sort_direction] int NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Orders] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					
			)
			ON [PRIMARY]
		END
	GO	

	/*********************** Report.GridReport.Tasks ********************************************************/	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Tasks]') AND type in (N'U'))
		BEGIN			
			CREATE TABLE [dbo].[Report.GridReport.Tasks]
			(
				[id] [uniqueidentifier] NOT NULL,
				[grid_id] [uniqueidentifier] NOT NULL,
				[task_type_id] [uniqueidentifier] NOT NULL,
				[ordinal_number][int] NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Tasks] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
								
			)
			ON [PRIMARY]
		END
	GO


	/********************** Report.GridReport.HrefColBindingDynAttrs *******************************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]
			(
				[id] [uniqueidentifier] NOT NULL,
				[href_binding_id] [uniqueidentifier] NOT NULL,
				[attr_name] [nvarchar](100) NOT NULL,
				[datasrc_column] [nvarchar](100) NOT NULL,
				[is_mandatory_attr][Bit] NOT NULL,
				CONSTRAINT [PK_Report.GridReport.HrefColBindingDynAttrs] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					 
			)
			ON [PRIMARY]
		END
	GO
	
	/********************** Report.GridReport.HrefColBindingStatAttrs *******************************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.HrefColBindingStatAttrs]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.GridReport.Binding.HrefColBindingStatAttrs]
			(
				[id] [uniqueidentifier] NOT NULL,
				[href_binding_id] [uniqueidentifier] NOT NULL,
				[attr_name] [nvarchar](100) NOT NULL,
				[attr_value] [nvarchar](255) NOT NULL,				
				CONSTRAINT [PK_Report.GridReport.Binding.HrefColBindingStatAttrs] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					 				
			) 
			ON [PRIMARY]
		END
	GO
	
	
	/********************** Report.GridReport.HrefColBindings *************************************************/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.HrefColBindings]') AND type in (N'U'))
		BEGIN			
			CREATE TABLE [dbo].[Report.GridReport.Binding.HrefColBindings]
			(
				[id] [uniqueidentifier] NOT NULL,
				[target_report_id] [uniqueidentifier] NOT NULL,
				[hyperlink_id][uniqueidentifier] NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Binding.HrefColBindings] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
			) 
			ON [PRIMARY]
		END
	GO
	
	/********************** Report.GridReport.DynHrefColBindings *************************************************/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.DynHrefColBindings]') AND type in (N'U'))
		BEGIN			
			CREATE TABLE [dbo].[Report.GridReport.Binding.DynHrefColBindings]
			(
				[id] [uniqueidentifier] NOT NULL,
				[href_binding1_id] [uniqueidentifier] NOT NULL,
				[href_binding2_id] [uniqueidentifier] NOT NULL,
				[resolve_proc] [nvarchar](255) NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Binding.DynHrefColBindings] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
			) 
			ON [PRIMARY]
		END
	GO	
		
	/******************************** Report.GridReport.Bindings.IconColBindings *******************************************************/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.IconColBindings]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.GridReport.Binding.IconColBindings]
			(
				[id] [uniqueidentifier] NOT NULL,
				[datasrc_column] [nvarchar](100) NOT NULL,
				[enumeration_id] [uniqueidentifier] NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Binding.IconColBindings] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
			) 
			ON [PRIMARY]
		END		
	GO
	

	/****************** Report.GridReport.Bindings.TextColBindings *******************************************************/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.TextColBindings]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.Binding.TextColBindings]
			(
				[id] [uniqueidentifier] NOT NULL,
				[datasrc_column] [nvarchar](100) NOT NULL,				
				CONSTRAINT [PK_Report.GridReport.Binding.TextColBindings] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
			) 
			ON [PRIMARY]
					
		END
	GO
	
	/****************** Report.GridReport.Bindings.DirectTextColBindings *******************************************************/	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.DirectTextColBindings]') AND type in (N'U'))
		BEGIN			
			CREATE TABLE [dbo].[Report.GridReport.Binding.DirectTextColBindings]
			(
				[id] [uniqueidentifier] NOT NULL,
				[sqldb_type] [int] NULL,
				[format] [int] NULL,
				[default_value_column] [nvarchar](100),
				CONSTRAINT [PK_Report.GridReport.Binding.DirectTextColBindings] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]						
			)
			ON [PRIMARY]
		END
	GO
	
	/****************** Report.GridReport.Bindings.EnumTextColBindings *******************************************************/	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.EnumTextColBindings]') AND type in (N'U'))
		BEGIN			
			CREATE TABLE [dbo].[Report.GridReport.Binding.EnumTextColBindings]
			(
				[id] [uniqueidentifier] NOT NULL,
				[enum_id] [uniqueidentifier] NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Binding.EnumTextColBindings] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]									
			)
			ON [PRIMARY]
		END
	GO
	/****************** Report.GridReport.Bindings.HiddenColBindings *******************************************************/	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.Binding.HiddenColBindings]') AND type in (N'U'))
		BEGIN			
			CREATE TABLE [dbo].[Report.GridReport.Binding.HiddenColBindings]
			(
				[id] [uniqueidentifier] NOT NULL,
				[datasrc_column] [nvarchar](100) NOT NULL,
				CONSTRAINT [PK_Report.GridReport.Binding.HiddenColBindings] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
			)
			ON [PRIMARY]
		END
	GO	
	
	
	
	/************************** Reports *********************************************************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Reports]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Reports]
			(
				[id]				[uniqueidentifier]	NOT NULL,
				[unique_name]		[nvarchar](100)		NOT NULL,
				[display_name]		[nvarchar](255)		NOT NULL,
				[naviname_builder_id] [uniqueidentifier]	NOT NULL,
				CONSTRAINT [PK_Reports] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					    				
			)
			ON [PRIMARY]
		END
	GO
	/****************************  Report.GridReports *******************************************************/
	
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReports]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReports]
			(
				[id] [uniqueidentifier] NOT NULL,
				[view_type] int NOT NULL,
				[report_id] [uniqueidentifier] NOT NULL,
				[datasrc_proc] [nvarchar](100) NOT NULL,
				[updates_check_proc] [nvarchar](100) NOT NULL DEFAULT N'usp.GridReport.DataSrc.DefaultCheckUpdatesProc',
				CONSTRAINT [PK_Report.GridReports] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					    								
			)
			ON [PRIMARY]
		END
	GO
	
	
	/************************* Report.GridReport.FilterType.DynScopeFilterTypes  **************************************/ 
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.FilterType.DynScopeFilterTypes]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.FilterType.DynScopeFilterTypes]
			(
				[id] [uniqueidentifier] NOT NULL,
				[filter_type_id] [uniqueidentifier] NOT NULL,
				[scope_procedure_name] [nvarchar](100) NOT NULL,
				CONSTRAINT [PK_Report.GridReport.FilterType.DynScopeFilterTypes] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
			) 
			ON [PRIMARY]
		END
	GO

	/************************************ Report.Shared.Filter.TextFilters ********************************************************/	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.FilterType.TextFilterTypes]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.FilterType.TextFilterTypes]
			(
				[id] [uniqueidentifier] NOT NULL,
				[filter_type_id] [uniqueidentifier] NOT NULL,
				CONSTRAINT [PK_Report.GridReport.FilterType.TextFilterTypes] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]				
			)
			ON [PRIMARY]
		END
	GO
	
	/************************************ Report.GridReport.FilterType.RangeFilterTypes ********************************************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.FilterType.RangeFilterTypes]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.FilterType.RangeFilterTypes]
			(
				[id] [uniqueidentifier] NOT NULL,
				[filter_type_id] [uniqueidentifier] NOT NULL,
				[range_id][uniqueidentifier] NOT NULL,				
				CONSTRAINT [PK_Report.Shared.Filter.Ranges] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					   				
			)
			ON [PRIMARY]
		END
	GO

	/**************************************************** Report.GridReport.FilterType.StatScopeFilterTypes ***********************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.FilterType.StatScopeFilterTypes]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.FilterType.StatScopeFilterTypes]
			(			
				[id] [uniqueidentifier] NOT NULL,
				[filter_type_id][uniqueidentifier] NOT NULL,
				[enumeration_id][uniqueidentifier] NOT NULL,				
				[is_icon_required]Bit NOT NULL,
				[is_text_required]Bit NOT NULL,				
				CONSTRAINT [PK_Report.Shared.Filter.ScopeValues] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]		
			) 
			ON [PRIMARY]
		END
	GO

	/***************************************************** Report.GridReport.FilterTypes ******************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.GridReport.FilterTypes]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.GridReport.FilterTypes]
			(
				[id][uniqueidentifier] NOT NULL,
				[unique_name][nvarchar](100) NOT NULL,				
				CONSTRAINT [PK_Report.GridReport.FilterTypes] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]										
			)
			ON [PRIMARY]
		END
	GO

	/**********************************************************************************************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.Hyperlinks]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.Shared.Hyperlinks]
			(
				[id] [uniqueidentifier] NOT NULL,
				[name_id] [nvarchar](100) NOT NULL,
				CONSTRAINT [PK_Report.Shared.Hyperlinks] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]														
			) 
			ON [PRIMARY]
		END
	GO
	
		/**************** Report.Shared.Enumerations *************************************************************/			
		SET ANSI_NULLS ON
		GO		
		SET QUOTED_IDENTIFIER ON
		GO
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.Enumerations]') AND type in (N'U'))
			BEGIN		
				CREATE TABLE [dbo].[Report.Shared.Enumerations]
				(
					[id] [uniqueidentifier] NOT NULL,
					[unique_name] [nvarchar](50) NOT NULL
					CONSTRAINT [PK_Report.Shared.Enumerations] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
				) ON [PRIMARY]
			END
		GO

	/**************** Report.Shared.EnumerationValues *************************************************************/	
	SET ANSI_NULLS ON
	GO
	
	SET QUOTED_IDENTIFIER ON
	GO
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.EnumerationValues]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.Shared.EnumerationValues]
			(
				[id] [uniqueidentifier] NOT NULL,
				[enumeration_id] [uniqueidentifier] NOT NULL,
				[text_value] [nvarchar](255) NOT NULL,
				[small_image_id][uniqueidentifier] NULL,
				[large_image_id][uniqueidentifier] NULL,
				[ordinal_number]int NOT NULL,
				CONSTRAINT [PK_Report.Shared.EnumerationValues] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																		
			)
			ON [PRIMARY]
		END
	GO
	
	
	/**************** Report.Shared.Ranges  ******************************************************************/
	
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.Ranges]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.Shared.Ranges]
			(
				[id] [uniqueidentifier] NOT NULL,
				[unique_name] [nvarchar](50) NOT NULL,
				CONSTRAINT [PK_Report.Shared.Ranges] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																		
			) 
			ON [PRIMARY]
		END
	GO	
	
	/************** Report.Shared.RangeValues ****************************************************************/	
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.RangeValues]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.Shared.RangeValues]
			(
				[id] [uniqueidentifier] NOT NULL,
				[range_id] [uniqueidentifier] NOT NULL,
				[text_value] [nvarchar](50) NOT NULL,
				[ordinal_number] [int] NOT NULL,
				[min_value] [int] NOT NULL,
				[max_value] [int] NOT NULL,
				CONSTRAINT [PK_Report.Shared.RangeValues] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																						
			)
			ON [PRIMARY]
		END
	GO	
	
	
	/**************** Report.Shared.Builders.NaviName *************************************************************/			
	SET ANSI_NULLS ON
	GO		
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.Builders.NaviName]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.Shared.Builders.NaviName]
			(
				[id] [uniqueidentifier] NOT NULL,
				[format] [nvarchar](50) NOT NULL
				CONSTRAINT [PK_Report.Shared.Builders.NaviName] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
			) ON [PRIMARY]
		END
	GO
	
	/**************** Report.Shared.Builders.NaviName.QueryAttributes *************************************************************/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.Builders.NaviName.QueryAttributes]') AND type in (N'U'))
		BEGIN
			CREATE TABLE [dbo].[Report.Shared.Builders.NaviName.QueryAttributes]
			(
				[id] [uniqueidentifier] NOT NULL,
				[builder_id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](50) NOT NULL,
				[ordinal] [int] NOT NULL
				CONSTRAINT [PK_Report.Shared.Builders.NaviName.QueryAttributes] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]	
			) ON [PRIMARY]
		END
	GO	
	
	/**************** Report.Shared.TaskTypes *************************************************************/
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.TaskTypes]') AND type in (N'U'))
		BEGIN			
			CREATE TABLE [dbo].[Report.Shared.TaskTypes]
			(
				[id] [uniqueidentifier] NOT NULL,
				[image_id] [uniqueidentifier] NOT NULL,
				[display_name] [nvarchar](100) NOT NULL,
				[invoke_type] [int] NOT NULL,
				[req_lines_selection][bit] NOT NULL
			    CONSTRAINT [PK_Report.Shared.TaskTypes] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					
			) 
			ON [PRIMARY]
		END
	GO
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Headers]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Report.Headers]
			(
				[id] [uniqueidentifier] NOT NULL,
				[unique_name] nvarchar(100) NOT NULL,
				[datasrc_proc] nvarchar(255) NOT NULL,
				[report_id] [uniqueidentifier] NOT NULL,
  			    CONSTRAINT [PK_Report.Headers] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																										
			)
			ON [PRIMARY]		
		END
	GO			


	
/*************************************************************************************************************
*
*	STARTUP STATE TABLES
*
**************************************************************************************************************/
	/************************************** Startup.InitialReportPages **********************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Startup.InitialReportPages]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Startup.InitialReportPages]
			(
				[id] [uniqueidentifier] NOT NULL,
				[container_id] [uniqueidentifier] NOT NULL,
				[report_id] [uniqueidentifier] NOT NULL,
				[page_ordinal_number] [int] NOT NULL				
				CONSTRAINT [PK_Startup.InitialReportPages] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																						
			)
			ON [PRIMARY]
		END
	GO	
	
	/************************************** Startup.InitialReportAttrs **********************************/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Startup.InitialReportAttrs]') AND type in (N'U'))
		BEGIN		
			CREATE TABLE [dbo].[Startup.InitialReportAttrs]
			(
				[id] [uniqueidentifier] NOT NULL,
				[initial_page_id][uniqueidentifier] NOT NULL,
				[attr_name] [nvarchar](100) NOT NULL,
				[attr_value] [nvarchar](255) NOT NULL,
  			    CONSTRAINT [PK_Startup.InitialReportAttrs] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				)
				WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																										
			)
			ON [PRIMARY]		
		END
	GO		
	
	
	
/*************************************************************************************************************
*
*	UPDATE TABLES
*
**************************************************************************************************************/
		/************************************** Update.Counters **********************************/
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Update.Counters]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Update.Counters]
				(
					[highestUsn] [bigint] NOT NULL
				)
				ON [PRIMARY]

				INSERT INTO [dbo].[Update.Counters]( [highestUsn] )
				VALUES( 0 )
			END
		GO

		/************************************** Update.TombstoneTypes **********************************/
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Update.TombstoneTypes]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Update.TombstoneTypes]
				(
					[id] [uniqueidentifier] NOT NULL,
					[type_name] [nvarchar](100) NOT NULL,
					[highest_tombstone_usn][BigInt] NOT NULL,
					CONSTRAINT [PK_Update.TombstoneTypes] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],			
				)
				ON [PRIMARY]
			END
		GO
/*************************************************************************************************************
*
*	CONFIG TABLES
*
**************************************************************************************************************/
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Config.Scheduler.Options]') AND type in (N'U'))
			BEGIN		
				CREATE TABLE [dbo].[Config.Scheduler.Options]
				(
					[id] [uniqueidentifier] NOT NULL,
					[schedule_type] int NOT NULL,
					[period_sec] int NOT NULL,
					[period_type] int NOT NULL,
					[start_time] datetime NOT NULL,
  					CONSTRAINT [PK_Config.Scheduler.Options] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																										
				)
				ON [PRIMARY]
			END
		GO		

/*************************************************************************************************************
*
*	NOTIFICATION TABLES
*
**************************************************************************************************************/
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Notification.MailSettings]
				(
					[smtp_server] [nvarchar](255) NOT NULL,
					[smtp_server_port] [int] NOT NULL,
					[authentication] [bit] NOT NULL,
					[domain] [nvarchar](100) NULL,
					[username] [nvarchar](100) NULL,
					[password] [nvarchar](1024) NULL,
					[to] [nvarchar](max) NOT NULL,
					[from] [nvarchar](max) NOT NULL,
					[send_enabled] [bit] NOT NULL,
					[subject] [nvarchar](max) NULL,
					[body] TEXT NULL,
					[notif_period] [int] NULL,
					[web_site_url] nvarchar(255) NOT NULL
				) ON [PRIMARY]
			END
		GO
			
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Notification.Sessions]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Notification.Sessions]
				(
					[id] [uniqueidentifier] NOT NULL,
					[start_time] datetime NOT NULL,
					[end_time] datetime NULL,
					[status] int NOT NULL,
  					CONSTRAINT [PK_Notification.Sessions] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
				)
				ON [PRIMARY]
			END
		GO
				
/**********************************************************
*
*	SECURITY TABLES
*
***********************************************************/
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.Roles]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Security.Roles]
				(
					[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Security_Roles_id]  DEFAULT (newid()),
					[name] [nvarchar](50) NOT NULL,
					[number] [int] NOT NULL
					
					CONSTRAINT [PK_Security_Roles] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
				)
				ON [PRIMARY]
			END
		GO
		
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.RoleAccounts]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Security.RoleAccounts]
				(
					[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Security_RoleAccounts_id]  DEFAULT (newid()),
					[role_id] [uniqueidentifier] NOT NULL,
					[account_id] [uniqueidentifier] NOT NULL
					
					CONSTRAINT [PK_Security_RoleAccounts] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
				)
				ON [PRIMARY]
			END
		GO	
			
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.Accounts]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Security.Accounts]
				(
					[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Security_Accounts_id]  DEFAULT (newid()),
					[name] [nvarchar](100) NOT NULL,
					[sid] [nvarchar](100) NOT NULL,
					[nt4_name] [nvarchar](255) NOT NULL,
					[type] [int] NOT NULL
					
					CONSTRAINT [PK_Security_Accounts] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
				)
				ON [PRIMARY]
			END	
		GO	
	
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.RolePermissions]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[Security.RolePermissions]
				(
					[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Security_RolePermissions_id]  DEFAULT (newid()),
					[role_id] [uniqueidentifier] NOT NULL,
					[permission] [int] NOT NULL
					
					CONSTRAINT [PK_Security_RolePermissions] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
				)
				ON [PRIMARY]
			END
		GO
/**********************************************************
*
*	TEMPORARY TABLES
*
***********************************************************/
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BJobs.Markers]') AND type in (N'U'))
			BEGIN
				CREATE TABLE [dbo].[BJobs.Markers]
				(
					[id] [uniqueidentifier] NOT NULL,
					[job_id] [uniqueidentifier] NOT NULL,
					[latest_result] [int] NOT NULL,
					[mark_time] [datetime] NOT NULL
					CONSTRAINT [PK_BJobs_Markers] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
				)
				ON [PRIMARY]
			END
		GO
/**********************************************************/



-----------------------------------------------------
--
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DashboardSettings]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[DashboardSettings]
	(
	[id] [uniqueidentifier]	NOT NULL CONSTRAINT [DF_DashboardSettings_id]  DEFAULT (newid()),
	[show_backup_window] [bit] NOT NULL,
	[backup_window_from_min] [int]		NOT NULL,
	[backup_window_length_min] 	[int]		NOT NULL,
	[activity_graph_scale] [int] NOT NULL,
	CONSTRAINT [PK_DashboardSettings] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]					    				
	)
	ON [PRIMARY]
END
GO
-----------------------------------------------------



/**********************************************************
*
*	FILL DATA STORED PROCEDURES
*
***********************************************************/

-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegGridReport]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegGridReport]
GO
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegGridReport]
	@report_id uniqueidentifier,
	@unique_name nvarchar(100),
	@display_name nvarchar( 255 ),
	@datasrc_proc nvarchar( 100 ),
	@grid_report_id uniqueidentifier,
	@naviname_builder_id uniqueidentifier,
	@view_type int = 0
AS
BEGIN	
	SET NOCOUNT ON;
						
	
	INSERT INTO [dbo].[Reports]([id],[unique_name],[display_name], [naviname_builder_id])
	VALUES( @report_id, @unique_name, @display_name, @naviname_builder_id)

	INSERT INTO [dbo].[Report.GridReports]( [id],[report_id], [datasrc_proc], [view_type])
	VALUES( @grid_report_id, @report_id, @datasrc_proc, @view_type )
END
GO	
-----------------------------------------------------


-----------------------------------------------------
--		
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegDirectTextColBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegDirectTextColBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegDirectTextColBinding]					
	@datasrc_col_name nvarchar( 100 ),										
	@datasrc_col_type int,
	@binding_id uniqueidentifier OUTPUT,					
	@format int,
	@default_value_column nvarchar(100) = null
AS
BEGIN
	SELECT @binding_id = NEWID()
		
	INSERT INTO [dbo].[Report.GridReport.Binding.TextColBindings]( [id], [datasrc_column] )
	VALUES( @binding_id, @datasrc_col_name)
	
	INSERT INTO [dbo].[Report.GridReport.Binding.DirectTextColBindings]( [id], [sqldb_type], [format], [default_value_column] )
	VALUES( @binding_id, @datasrc_col_type, @format, @default_value_column )
	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegColWithHrefDBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegColWithHrefDBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegColWithHrefDBinding]
	@grid_report_id uniqueidentifier,
	@col_display_name nvarchar(100),
	@col_unique_name  nvarchar(100),
	@col_width  int,
	@col_number int,
	@is_sortable Bit,
	@trg_report_id uniqueidentifier,
	@href_id uniqueidentifier,
	@datasrc_textcol_name nvarchar( 100 ),
	@datasrc_textcol_type int,
	@dyn_attr1_name nvarchar( 100 ),
	@datasrc_dynattr1_colname nvarchar( 100 ),
	@format int,
	@order_id uniqueidentifier = null
AS
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @column_id as uniqueidentifier
	SELECT @column_id = NEWID()
	
	-- REGISTER TEXT BINDING
	DECLARE @text_binding_id as uniqueidentifier
	EXEC [dbo].[usp.GridReport.Config.RegDirectTextColBinding] @datasrc_textcol_name, @datasrc_textcol_type, @text_binding_id OUTPUT, @format
	
																																	
	-- REGISTER HREF BINDING					
	DECLARE @href_binding_id uniqueidentifier 							
	SELECT @href_binding_id = NEWID()
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindings]( [id],  [target_report_id], [hyperlink_id] )
	VALUES( @href_binding_id,  @trg_report_id, @href_id )
	
	-- REGISTER DYNAMIC ATTRIBUTES
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr1_name, @datasrc_dynattr1_colname, 1 ) 										
											
	
	-- REGISTER  COLUMN
	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [href_binding_id], [text_binding_id], [order_id])
	VALUES( @column_id, @grid_report_id, @col_display_name, @col_unique_name, @col_number, @col_width, @is_sortable, @href_binding_id, @text_binding_id, @order_id )

END
GO		
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id uniqueidentifier,
	@col_display_name nvarchar(100),
	@col_unique_name  nvarchar(100),
	@col_width  int,
	@col_number int,
	@is_sortable Bit,
	@datasrc_col_name nvarchar( 100 ),
	@datasrc_col_type int,
	@format int,	
	@default_value_column nvarchar(100) = null,
	@order_id uniqueidentifier = null
AS
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @column_id as uniqueidentifier
	SELECT @column_id = NEWID()
	
	DECLARE @binding_id as uniqueidentifier
	EXEC [dbo].[usp.GridReport.Config.RegDirectTextColBinding] @datasrc_col_name, @datasrc_col_type, @binding_id OUTPUT, @format, @default_value_column

	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [text_binding_id], [order_id])
	VALUES( @column_id, @grid_report_id,@col_display_name, @col_unique_name, @col_number, @col_width, @is_sortable, @binding_id, @order_id )
				
END
GO	
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegEnumTextColBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegEnumTextColBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegEnumTextColBinding]					
	@datasrc_col_name nvarchar( 100 ),										
	@enum_id uniqueidentifier,
	@binding_id uniqueidentifier OUTPUT
AS
BEGIN
	SELECT @binding_id = NEWID()
		
	INSERT INTO [dbo].[Report.GridReport.Binding.TextColBindings]( [id], [datasrc_column] )
	VALUES( @binding_id, @datasrc_col_name)
	
	INSERT INTO [dbo].[Report.GridReport.Binding.EnumTextColBindings]( [id], [enum_id] )
	VALUES( @binding_id, @enum_id )																
END
GO			
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Report.Shared.RegisterNaviNameBuilder]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
GO	
CREATE PROCEDURE [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
	@builder_id uniqueidentifier,
	@format_str  nvarchar(50) 		
AS
BEGIN
	
	SET NOCOUNT ON;

	INSERT INTO [dbo].[Report.Shared.Builders.NaviName]( [id], [format])
	VALUES (@builder_id, @format_str)
    
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
GO																		
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]	
	@grid_report_id uniqueidentifier,
	@col_display_name nvarchar(100),
	@col_unique_name  nvarchar(100),
	@col_width  int,
	@col_number int,
	@is_sortable Bit,
	@datasrc_col_name nvarchar( 100 ),
	@enumeration_id uniqueidentifier,
	@order_id uniqueidentifier = null
AS
BEGIN
	SET NOCOUNT ON;
	
	-- REGISTER BINDING					
	DECLARE @binding_id as uniqueidentifier
	EXEC [dbo].[usp.GridReport.Config.RegEnumTextColBinding]  @datasrc_col_name, @enumeration_id, @binding_id OUTPUT 
						
	-- REGISTER COLUMN																				
	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [text_binding_id], [order_id])
	VALUES( NEWID(), @grid_report_id,@col_display_name, @col_unique_name, @col_number, @col_width, @is_sortable, @binding_id, @order_id  )
						
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegHiddenColBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegHiddenColBinding]
GO
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegHiddenColBinding]
	@datasrc_col_name nvarchar( 100 ),
	@datasrc_col_type int,
	@binding_id uniqueidentifier OUTPUT,
	@default_value_column nvarchar(100) = null
AS
BEGIN
	SELECT @binding_id = NEWID()
		
	INSERT INTO [dbo].[Report.GridReport.Binding.HiddenColBindings]( [id], [datasrc_column] )
	VALUES( @binding_id, @datasrc_col_name)
	
	INSERT INTO [dbo].[Report.GridReport.Binding.DirectTextColBindings]( [id], [sqldb_type], [format], [default_value_column] )
	VALUES( @binding_id, @datasrc_col_type, 0, @default_value_column)
	
END
GO			
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegHiddenCol]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegHiddenCol]
GO																		
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegHiddenCol]
	@grid_report_id uniqueidentifier,
	@col_unique_name  nvarchar(100),
	@datasrc_col_name nvarchar(100),
	@datasrc_col_type int
AS
BEGIN
	SET NOCOUNT ON;		

	DECLARE @column_id as uniqueidentifier
	SELECT @column_id = NEWID()
	
	DECLARE @binding_id as uniqueidentifier
	EXEC [dbo].[usp.GridReport.Config.RegHiddenColBinding] @datasrc_col_name, @datasrc_col_type, @binding_id OUTPUT

	INSERT INTO [dbo].[Report.GridReport.HiddenColumns]( [id], [grid_report_id], [unique_name], [binding_id])
	VALUES( @column_id, @grid_report_id, @col_unique_name, @binding_id )
	
END
GO		
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegLogReport]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegLogReport]
GO
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegLogReport]
	@report_id uniqueidentifier,
	@unique_name nvarchar(50),
	@datasrc_proc nvarchar(255)
AS
BEGIN
	SET NOCOUNT ON;					
	
	DECLARE @grid_repid uniqueidentifier, @naviname_builder_id uniqueidentifier
	SELECT @grid_repid = NEWID(), @naviname_builder_id = NEWID()
			
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'Log'

	EXEC  [dbo].[usp.GridReport.Config.RegGridReport]  
				@report_id = @report_id,
				@unique_name = @unique_name,
				@display_name = N'Log',
				@datasrc_proc = @datasrc_proc,
				@grid_report_id = @grid_repid,
				@naviname_builder_id = @naviname_builder_id,
				@view_type = 1

	/**********************************  COLUMNS  *******************************************/
	--  TIME
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
				@grid_report_id = @grid_repid,
				@col_display_name = N'Time',
				@col_unique_name = N'time',
				@col_width = 70,
				@col_number = 0,
				@is_sortable = 0,
				@datasrc_col_name = N'time',
				@datasrc_col_type = 4,  --Sql DB type - datetime
				@format = 1 --datetime
				
	--  TYPE
	DECLARE @severity_enum_id as uniqueidentifier		
	SELECT  @severity_enum_id = '8BD74F79-3B66-401c-9ADC-B872DB08D1B1'

	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = 'Type',
		@col_unique_name = N'severity',
		@col_width = 50,
		@col_number  = 1,
		@is_sortable = 0,
		@datasrc_col_name = N'severity',
		@enumeration_id = @severity_enum_id
		
	--  TEXT			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Information',
		@col_unique_name = N'text',
		@col_width = 300,
		@col_number = 2,
		@is_sortable = 0,
		@datasrc_col_name = N'text',
		@datasrc_col_type = 12,
		@format = 0--text

	EXEC [dbo].[usp.GridReport.Config.RegHiddenCol]
		@grid_report_id = @grid_repid,
		@col_unique_name = N'color',
		@datasrc_col_name = N'color',
		@datasrc_col_type = 12
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.AttachOrder2Rep]') AND type in (N'P'))										
DROP PROCEDURE [dbo].[usp.GridReport.Config.AttachOrder2Rep]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.AttachOrder2Rep]
	@order_id uniqueidentifier,
	@grid_report_id uniqueidentifier,
	@column_name nvarchar(100),
	@sort_direction int	= 0 -- NONE
AS
BEGIN	
	SET NOCOUNT ON;
						
	INSERT INTO [dbo].[Report.GridReport.Orders]( [id], [grid_report_id], [column_name], [sort_direction])
	VALUES( @order_id, @grid_report_id, @column_name, @sort_direction )
END
GO					
-----------------------------------------------------




-----------------------------------------------------
--		
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Rendering.FindOrCreateImage]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Rendering.FindOrCreateImage]
GO												
CREATE PROCEDURE [dbo].[usp.Rendering.FindOrCreateImage]
	@image_folder_id as uniqueidentifier,
	@image_name as nvarchar( 255 ),
	@image_id as uniqueidentifier OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT @image_id = [dbo].[Rendering.ImageFiles].[id]
	FROM [dbo].[Rendering.ImageFiles]
	WHERE [dbo].[Rendering.ImageFiles].[folder_id] = @image_folder_id AND [dbo].[Rendering.ImageFiles].[file_name] = @image_name

	IF ( @image_id IS NULL )
	BEGIN
		SELECT @image_id = NEWID()

		INSERT INTO [dbo].[Rendering.ImageFiles]( [id], [folder_id], [file_name])
		VALUES( @image_id, @image_folder_id, @image_name )
	END
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Report.Shared.RegisterEnumValue]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Report.Shared.RegisterEnumValue]
GO										
CREATE PROCEDURE [dbo].[usp.Report.Shared.RegisterEnumValue]
	@enum_id as uniqueidentifier,
	@image_folder_id as uniqueidentifier,					
	@int_value as int,
	@display_value  as nvarchar(255),
	@small_icon_name as nvarchar(255),
	@large_icon_name as nvarchar(255 )			
AS
BEGIN	
	SET NOCOUNT ON;

	DECLARE @small_icon_id as uniqueidentifier
	if ( @small_icon_name is NOT NULL )
		EXEC [dbo].[usp.Rendering.FindOrCreateImage] @image_folder_id, @small_icon_name, @small_icon_id OUTPUT
																	
	DECLARE @large_icon_id as uniqueidentifier
	if ( @large_icon_name is NOT NULL )
		EXEC [dbo].[usp.Rendering.FindOrCreateImage] @image_folder_id, @large_icon_name, @large_icon_id OUTPUT

	INSERT INTO [dbo].[Report.Shared.EnumerationValues]( [id], [enumeration_id], [text_value], [small_image_id], [large_image_id], [ordinal_number] )
	VALUES( NEWID(), @enum_id, @display_value, @small_icon_id, @large_icon_id, @int_value)
END
GO		
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Report.Shared.RegisterTaskType]') AND type in (N'P'))
DROP PROCEDURE [dbo].[Report.Shared.RegisterTaskType]	
GO			   
CREATE PROCEDURE [dbo].[Report.Shared.RegisterTaskType] 
	@task_id uniqueidentifier,
	@img_folder_id uniqueidentifier,
	@img_name nvarchar(255),
	@description nvarchar( 100 ),
	@req_lines_selection bit,
	@invoke_type int
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @icon_id uniqueidentifier							
	
	EXEC  [dbo].[usp.Rendering.FindOrCreateImage] 
		@image_folder_id = @img_folder_id, 
		@image_name = @img_name,
		@image_id = @icon_id OUTPUT
							
    					
	INSERT INTO [dbo].[Report.Shared.TaskTypes]( [id], [image_id],[display_name], [invoke_type], [req_lines_selection])
	VALUES( @task_id, @icon_id, @description, @invoke_type, @req_lines_selection )
END
GO						
-----------------------------------------------------


-----------------------------------------------------
--			
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegHyperlink]') AND type in (N'P'))										
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegHyperlink]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegHyperlink]
	@hyperlink_id uniqueidentifier,
	@hyperlink_unique_name nvarchar(100)									
AS
BEGIN	
	SET NOCOUNT ON;
	
	INSERT INTO [dbo].[Report.Shared.Hyperlinks] ([id],[name_id])
	VALUES( @hyperlink_id, @hyperlink_unique_name )															
END
GO							
-----------------------------------------------------

		

-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.AttachTextFilter2Rep]') AND type in (N'P'))										
DROP PROCEDURE [dbo].[usp.GridReport.Config.AttachTextFilter2Rep]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.AttachTextFilter2Rep]
	@grid_report_id uniqueidentifier,
	@filter_unique_name nvarchar(100),
	@filter_display_name nvarchar(255),
	@filter_number int					
AS
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @text_filter_type_id as uniqueidentifier
	SELECT @text_filter_type_id = 'D7F9A519-3782-48d1-833F-68868B7E61C9'
						
	
	INSERT INTO [dbo].[Report.GridReport.Filters]( [id], [grid_report_id], [filter_type_id], [display_name], [unique_name], [ordinal_number], [width])
	VALUES( NEWID(), @grid_report_id, @text_filter_type_id, @filter_display_name,@filter_unique_name, @filter_number, 100 )
END
GO
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id uniqueidentifier,
	@col_display_name nvarchar(100),
	@col_unique_name  nvarchar(100),
	@col_width  int,
	@col_number int,
	@is_sortable Bit,
	@trg_report_id uniqueidentifier,
	@href_id uniqueidentifier,
	@datasrc_textcol_name nvarchar( 100 ),
	@datasrc_textcol_type int,
	@dyn_attr1_name nvarchar( 100 ),
	@datasrc_dynattr1_colname nvarchar( 100 ),
	@dyn_attr2_name nvarchar( 100 ),
	@datasrc_dynattr2_colname nvarchar( 100 ),
	@format int,
	@order_id uniqueidentifier = null
AS
BEGIN											
	SET NOCOUNT ON;
	
	DECLARE @column_id as uniqueidentifier
	SELECT @column_id = NEWID()
	
	-- REGISTER TEXT BINDING
	DECLARE @text_binding_id as uniqueidentifier					
	EXEC [dbo].[usp.GridReport.Config.RegDirectTextColBinding] @datasrc_textcol_name, @datasrc_textcol_type, @text_binding_id OUTPUT, @format
	
																																	
	-- REGISTER HREF BINDING					
	DECLARE @href_binding_id uniqueidentifier 							
	SELECT @href_binding_id = NEWID()
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindings]( [id],  [target_report_id], [hyperlink_id] )
	VALUES( @href_binding_id,  @trg_report_id, @href_id )
	
	-- REGISTER DYNAMIC ATTRIBUTES
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr1_name, @datasrc_dynattr1_colname, 1 ) 
	
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr2_name, @datasrc_dynattr2_colname, 1 ) 																				
											
	
	-- REGISTER  COLUMN
	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [href_binding_id], [text_binding_id], [order_id])
	VALUES( @column_id, @grid_report_id, @col_display_name, @col_unique_name, @col_number, @col_width, @is_sortable, @href_binding_id, @text_binding_id, @order_id )
														
END
GO							
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegColWithHrefDDDBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegColWithHrefDDDBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegColWithHrefDDDBinding]
	@grid_report_id uniqueidentifier,
	@col_display_name nvarchar(100),
	@col_unique_name  nvarchar(100),
	@col_width  int,
	@col_number int,
	@is_sortable Bit,
	@trg_report_id uniqueidentifier,
	@href_id uniqueidentifier,
	@datasrc_textcol_name nvarchar( 100 ),
	@datasrc_textcol_type int,
	@dyn_attr1_name nvarchar( 100 ),
	@datasrc_dynattr1_colname nvarchar( 100 ),
	@dyn_attr2_name nvarchar( 100 ),
	@datasrc_dynattr2_colname nvarchar( 100 ),
	@dyn_attr3_name nvarchar( 100 ),
	@datasrc_dynattr3_colname nvarchar( 100 ),
	@format int,
	@order_id uniqueidentifier = null
AS
BEGIN	
	SET NOCOUNT ON;

	DECLARE @column_id as uniqueidentifier
	SELECT @column_id = NEWID()
	
	-- REGISTER TEXT BINDING
	DECLARE @text_binding_id as uniqueidentifier
	EXEC [dbo].[usp.GridReport.Config.RegDirectTextColBinding] @datasrc_textcol_name, @datasrc_textcol_type, @text_binding_id OUTPUT, @format
	
																																	
	-- REGISTER HREF BINDING					
	DECLARE @href_binding_id uniqueidentifier							
	SELECT @href_binding_id = NEWID()
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindings]( [id],  [target_report_id], [hyperlink_id] )
	VALUES( @href_binding_id,  @trg_report_id, @href_id )
	
	-- REGISTER DYNAMIC ATTRIBUTES
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column],[is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr1_name, @datasrc_dynattr1_colname, 1 )
	
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column],[is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr2_name, @datasrc_dynattr2_colname, 1 )
	
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr3_name, @datasrc_dynattr3_colname, 1 )
	
	
	-- REGISTER  COLUMN
	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [href_binding_id], [text_binding_id], [order_id])
	VALUES( @column_id, @grid_report_id, @col_display_name, @col_unique_name, @col_number, @col_width, @is_sortable, @href_binding_id, @text_binding_id, @order_id )
															
END
GO							
-----------------------------------------------------


		
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegIconCol]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegIconCol]
GO																		
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegIconCol]	
	@grid_report_id uniqueidentifier,
	@col_unique_name  nvarchar(100),					
	@col_number int,					
	@datasrc_col_name nvarchar(100),
	@enumeration_id uniqueidentifier,
	@order_id uniqueidentifier = null
AS
BEGIN
	SET NOCOUNT ON;
	
	-- REGISTER BINDING
	DECLARE @binding_id as uniqueidentifier
	SELECT @binding_id = NEWID()
	
	INSERT INTO [dbo].[Report.GridReport.Binding.IconColBindings]( [id], [datasrc_column], [enumeration_id])
	VALUES( @binding_id, @datasrc_col_name, @enumeration_id )
						
	-- REGISTER COLUMN																				
	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [icon_binding_id], [order_id])
	VALUES( NEWID(), @grid_report_id,'', @col_unique_name, @col_number, 0, 0, @binding_id, @order_id )
						
END
GO			
-----------------------------------------------------





-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegColWithEnumHrefDynBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegColWithEnumHrefDynBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegColWithEnumHrefDynBinding]
	@grid_report_id uniqueidentifier,
	@col_display_name nvarchar(100),
	@col_unique_name  nvarchar(100),
	@col_width  int,
	@col_number int,
	@is_sortable Bit,
	@trg_report_id uniqueidentifier,
	@href_id uniqueidentifier,
	@datasrc_enumcol_name nvarchar( 100 ),
	@datasrc_enum_type uniqueidentifier,
	@dyn_attr1_name nvarchar( 100 ),
	@datasrc_dynattr1_colname nvarchar( 100 ),
	@dyn_attr2_name nvarchar( 100 ) = null,
	@datasrc_dynattr2_colname nvarchar( 100 ) = null,
	@dyn_attr3_name nvarchar( 100 ) = null,
	@datasrc_dynattr3_colname nvarchar( 100 ) = null,
	@order_id uniqueidentifier = null
AS
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @column_id as uniqueidentifier
	SELECT @column_id = NEWID()
	
	-- REGISTER TEXT BINDING
	DECLARE @text_binding_id as uniqueidentifier					
	EXEC [dbo].[usp.GridReport.Config.RegEnumTextColBinding] @datasrc_enumcol_name, @datasrc_enum_type, @text_binding_id OUTPUT
																																	
	-- REGISTER HREF BINDING					
	DECLARE @href_binding_id uniqueidentifier 							
	SELECT @href_binding_id = NEWID()
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindings]( [id],  [target_report_id], [hyperlink_id] )
	VALUES( @href_binding_id,  @trg_report_id, @href_id )
	
	-- REGISTER DYNAMIC ATTRIBUTES
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr1_name, @datasrc_dynattr1_colname, 1 )
	
	IF @dyn_attr2_name IS NOT NULL
		INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
		VALUES( NEWID(), @href_binding_id, @dyn_attr2_name, @datasrc_dynattr2_colname, 1 )
	
	IF @dyn_attr3_name IS NOT NULL
		INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
		VALUES( NEWID(), @href_binding_id, @dyn_attr3_name, @datasrc_dynattr3_colname, 1 )
	
	-- REGISTER  COLUMN
	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [href_binding_id], [text_binding_id], [order_id])
	VALUES( @column_id, @grid_report_id, @col_display_name, @col_unique_name, @col_number, @col_width, @is_sortable, @href_binding_id, @text_binding_id, @order_id )

END
GO		
-----------------------------------------------------


	
	
			

-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
GO	
CREATE PROCEDURE [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
	@builder_id uniqueidentifier,
	@format_str  nvarchar(50),
	@query_attr_name nvarchar(50)
AS
BEGIN
	
	SET NOCOUNT ON;

	INSERT INTO [dbo].[Report.Shared.Builders.NaviName]( [id], [format])
	VALUES (@builder_id, @format_str)
	
	INSERT INTO [dbo].[Report.Shared.Builders.NaviName.QueryAttributes]([id], [builder_id], [name], [ordinal])
	VALUES( NEWID(), @builder_id, @query_attr_name, 0 )					    
END
GO				
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Report.Shared.RegisterNaviNameBuilder2]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Report.Shared.RegisterNaviNameBuilder2]
GO	
CREATE PROCEDURE [dbo].[usp.Report.Shared.RegisterNaviNameBuilder2]
	@builder_id uniqueidentifier,
	@format_str  nvarchar(50),
	@query_attr1_name nvarchar(50),
	@query_attr2_name nvarchar(50)
AS
BEGIN
	
	SET NOCOUNT ON;

	INSERT INTO [dbo].[Report.Shared.Builders.NaviName]( [id], [format])
	VALUES (@builder_id, @format_str)
	
	INSERT INTO [dbo].[Report.Shared.Builders.NaviName.QueryAttributes]([id], [builder_id], [name], [ordinal])
	VALUES( NEWID(), @builder_id, @query_attr1_name, 0 )					    
	
	INSERT INTO [dbo].[Report.Shared.Builders.NaviName.QueryAttributes]([id], [builder_id], [name], [ordinal])
	VALUES( NEWID(), @builder_id, @query_attr2_name, 1 )					    
END
GO								
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegDetailsPanelWithDirectColBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegDetailsPanelWithDirectColBinding]
GO																
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegDetailsPanelWithDirectColBinding]
	@grid_report_id uniqueidentifier,
	@src_col_name nvarchar( 100 ),
	@panel_width int,
	@title nvarchar( 100 ),
	@format int,
	@default_text nvarchar(max) = N''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @text_binding_id uniqueidentifier

	 EXEC [dbo].[usp.GridReport.Config.RegDirectTextColBinding]
		 @src_col_name,
		 12, -- nvarchar
		 @text_binding_id OUTPUT,
		 @format

	INSERT INTO [dbo].[Report.GridReport.DetailsPanels]( [id],[panel_width],[text_binding_id], [title], [default_text])
	VALUES(  @grid_report_id, @panel_width, @text_binding_id, @title, @default_text)
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegTask]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegTask]
GO																				
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegTask]
			@grid_id uniqueidentifier,
			@task_type_id uniqueidentifier,
			@ordinal_number int
AS
BEGIN	
	SET NOCOUNT ON;

	INSERT INTO [dbo].[Report.GridReport.Tasks]( [id], [grid_id], [task_type_id], [ordinal_number])
	VALUES( NEWID(), @grid_id, @task_type_id, @ordinal_number )
END
GO
-----------------------------------------------------
				

-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegHrefBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegHrefBinding]
GO
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegHrefBinding]
	@trg_report_id uniqueidentifier,
	@href_id uniqueidentifier,
	@href_binding_id uniqueidentifier OUTPUT,
	@dyn_attr1_name nvarchar( 100 ),
	@datasrc_dynattr1_colname nvarchar( 100 ),
	@dyn_attr2_name nvarchar( 100 ) = null,
	@datasrc_dynattr2_colname nvarchar( 100 ) = null,
	@dyn_attr3_name nvarchar( 100 ) = null,
	@datasrc_dynattr3_colname nvarchar( 100 ) = null
AS
BEGIN	
	SET NOCOUNT ON;
	
	-- REGISTER HREF BINDING
	SET @href_binding_id = NEWID()
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindings]( [id],  [target_report_id], [hyperlink_id] )
	VALUES( @href_binding_id,  @trg_report_id, @href_id )
	
	-- REGISTER DYNAMIC ATTRIBUTES
	INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
	VALUES( NEWID(), @href_binding_id, @dyn_attr1_name, @datasrc_dynattr1_colname, 1 )
	
	IF @dyn_attr2_name IS NOT NULL
		INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
		VALUES( NEWID(), @href_binding_id, @dyn_attr2_name, @datasrc_dynattr2_colname, 1 )
		
	IF @dyn_attr3_name IS NOT NULL
		INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
		VALUES( NEWID(), @href_binding_id, @dyn_attr3_name, @datasrc_dynattr3_colname, 1 )
		
END
GO
-----------------------------------------------------







-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegDynHrefBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegDynHrefBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegDynHrefBinding]
	@href_binding1_id uniqueidentifier,
	@href_binding2_id uniqueidentifier,
	@resolve_proc nvarchar(255),
	@dyn_href_binding_id uniqueidentifier OUTPUT,
	@dyn_attr1_name nvarchar(100) = null,
	@datasrc_dynattr1_colname nvarchar(100) = null
AS
BEGIN	
	SET NOCOUNT ON;
	
	SET @dyn_href_binding_id = NEWID()
	INSERT INTO [dbo].[Report.GridReport.Binding.DynHrefColBindings]( [id], [href_binding1_id], [href_binding2_id], [resolve_proc] )
	VALUES( @dyn_href_binding_id, @href_binding1_id, @href_binding2_id, @resolve_proc )
	
	IF @dyn_attr1_name IS NOT NULL
		INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
		VALUES( NEWID(), @dyn_href_binding_id, @dyn_attr1_name, @datasrc_dynattr1_colname, 1 )
END	
GO	
-----------------------------------------------------
				
				
				
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.GridReport.Config.RegColWithEnumDynHrefBinding]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.GridReport.Config.RegColWithEnumDynHrefBinding]
GO													
CREATE PROCEDURE [dbo].[usp.GridReport.Config.RegColWithEnumDynHrefBinding]
	@grid_report_id uniqueidentifier,
	@col_display_name nvarchar(100),
	@col_unique_name  nvarchar(100),
	@col_width  int,
	@col_number int,
	@is_sortable Bit,
	@dyn_href_binding_id uniqueidentifier,
	@datasrc_enumcol_name nvarchar( 100 ),
	@datasrc_enum_type uniqueidentifier,
	@order_id uniqueidentifier = null
AS
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @column_id as uniqueidentifier
	SELECT @column_id = NEWID()
	
	-- REGISTER TEXT BINDING
	DECLARE @text_binding_id as uniqueidentifier					
	EXEC [dbo].[usp.GridReport.Config.RegEnumTextColBinding] @datasrc_enumcol_name, @datasrc_enum_type, @text_binding_id OUTPUT
	
	-- REGISTER  COLUMN
	INSERT INTO [dbo].[Report.GridReport.Columns]( [id], [grid_report_id], [display_name], [unique_name], [ordinal_number], [relative_width],[is_sortable], [href_binding_id], [text_binding_id], [order_id])
	VALUES( @column_id, @grid_report_id, @col_display_name, @col_unique_name, @col_number, @col_width, @is_sortable, @dyn_href_binding_id, @text_binding_id, @order_id )

END
GO	
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Startup.RegInitialReportPageWithAttr]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Startup.RegInitialReportPageWithAttr]
GO
CREATE PROCEDURE [dbo].[usp.Startup.RegInitialReportPageWithAttr]	
	@page_id uniqueidentifier,
	@report_id uniqueidentifier,
	@ordinal_number int,
	@attr_name nvarchar(100),
	@attr_value nvarchar( 255 )
AS
BEGIN			
	SET NOCOUNT ON;
	
	DECLARE @initialPageId as uniqueidentifier
	SELECT @initialPageId = NEWID()
	
	INSERT INTO	[dbo].[Startup.InitialReportPages]([id],[container_id],[report_id], [page_ordinal_number])
	VALUES( @initialPageId, @page_id, @report_id , @ordinal_number )				
	
	INSERT INTO [dbo].[Startup.InitialReportAttrs]([id],[initial_page_id],[attr_name],[attr_value])
	VALUES( NEWID(), @initialPageId, @attr_name, @attr_value )
       
END
GO
-----------------------------------------------------


-----------------------------------------------------
--		
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Startup.RegInitialReportPage]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Startup.RegInitialReportPage]
GO
CREATE PROCEDURE [dbo].[usp.Startup.RegInitialReportPage]	
	@page_id uniqueidentifier,
	@report_id uniqueidentifier,
	@ordinal_number int
AS
BEGIN			
	SET NOCOUNT ON;
	
	INSERT INTO	[dbo].[Startup.InitialReportPages]([id],[container_id],[report_id], [page_ordinal_number])
	VALUES( NEWID(), @page_id, @report_id , @ordinal_number )				
       
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Config.Scheduler.CreateSettings]') AND type in (N'P'))
DROP PROCEDURE [dbo].[usp.Config.Scheduler.CreateSettings]
GO
CREATE PROCEDURE [dbo].[usp.Config.Scheduler.CreateSettings]
	@settings_id uniqueidentifier,
	@schedule_type int,
	@period_sec int,
	@period_type int				
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [dbo].[Config.Scheduler.Options] ([id], [schedule_type], [period_sec], [period_type], [start_time])
	VALUES (@settings_id, @schedule_type, @period_sec, @period_type, GETUTCDATE() )
END
GO		
-----------------------------------------------------



/**********************************************************
*
*	FILL DATA
*
***********************************************************/


-----------------------------------------------------
--
BEGIN
	--  Permission types
	DECLARE @perm_view int, @perm_config int, @perm_collect int
	SELECT @perm_view = 1, @perm_config = 2, @perm_collect = 4

	--  Roles
	DECLARE @viewer_role_id uniqueidentifier, @admin_role_id uniqueidentifier
	SELECT 
		@viewer_role_id = 'D19A3D33-CB77-4ffe-94E6-001432483A4E',
		@admin_role_id = '5F37A46B-9CE2-40f4-8A62-B45B079257FC'
	
	INSERT INTO [dbo].[Security.Roles]( [id], [number], [name] )
		SELECT @admin_role_id, 1, 'Portal Administrator'
		UNION ALL
		SELECT @viewer_role_id, 2, 'Portal Viewer'

	-- Permissions
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @viewer_role_id, @perm_view

	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @admin_role_id, @perm_view
	UNION ALL
	SELECT NEWID(), @admin_role_id, @perm_config
	UNION ALL
	SELECT NEWID(), @admin_role_id, @perm_collect
			
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
BEGIN
	DECLARE @grid_repid uniqueidentifier, @naviname_builder_id uniqueidentifier
	SELECT @grid_repid = NEWID(), @naviname_builder_id = NEWID()
			
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'Restore Points'

	EXEC  [dbo].[usp.GridReport.Config.RegGridReport]  
				@report_id = 'BD1667AC-2454-4968-B137-60110D8EA205',
				@unique_name = N'vm_restore_points',
				@display_name = N'Restore Points',
				@datasrc_proc = N'usp.GridReport.DataSrc.VmRestorePoints',
				@grid_report_id = @grid_repid,
				@naviname_builder_id = @naviname_builder_id
							
	/************************* ORDERS ****************************************************/
	DECLARE 
		@order_restore_point uniqueidentifier,
		@order_type uniqueidentifier
	SELECT
		@order_restore_point = NEWID(),
		@order_type = NEWID()
		
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_restore_point, @grid_repid, 'restore_point'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_type, @grid_repid, 'type'
	
	/**********************************  COLUMNS  *******************************************/

	/*  RESTORE POINT    */
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]					
				@grid_report_id = @grid_repid,
				@col_display_name = N'Restore Point',
				@col_unique_name = N'restore_point',
				@col_width = 70,
				@col_number = 0,
				@is_sortable = 1,
				@datasrc_col_name = N'restore_point',
				@datasrc_col_type = 4,  --Sql DB type - datetime
				@format = 1, --datetime
				@order_id = @order_restore_point
				
	/*  TYPE   */
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]					
				@grid_report_id = @grid_repid,
				@col_display_name = N'Type',
				@col_unique_name = N'type',
				@col_width = 70,
				@col_number = 1,
				@is_sortable = 1,
				@datasrc_col_name = N'type',
				@datasrc_col_type = 12, --nvarchar
				@format = 0, --text
				@order_id = @order_type
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
BEGIN
	DECLARE @backupsrv_filter_type_id as uniqueidentifier			        
	SELECT @backupsrv_filter_type_id = '59835D5B-353D-4e50-8ABA-50BD52ABFD8F'
	       
	       
	INSERT INTO [dbo].[Report.GridReport.FilterTypes]( [id], [unique_name] )
	VALUES( @backupsrv_filter_type_id, 'backupsrv_filter')						
	
	INSERT INTO [dbo].[Report.GridReport.FilterType.DynScopeFilterTypes] ( [id], [filter_type_id], [scope_procedure_name])
	VALUES( NEWID(), @backupsrv_filter_type_id, 'usp.GridReport.DynScopeFilter.EnumBackupServers' )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--JOB TYPE FILTER
BEGIN
	DECLARE @job_type_filter_type_id as uniqueidentifier			        
	SELECT @job_type_filter_type_id = 'AF3CD010-1F6E-4df5-88EA-DF63DC54A57E'

	DECLARE @job_type_enum_id as uniqueidentifier			
	SELECT  @job_type_enum_id = '2ED2AF5B-041A-4e8b-B467-F960B894EF7F'
											
	INSERT INTO [dbo].[Report.GridReport.FilterTypes]( [id], [unique_name] )
	VALUES( @job_type_filter_type_id, 'job_type_filter')
	INSERT INTO [dbo].[Report.GridReport.FilterType.StatScopeFilterTypes]( [id], [filter_type_id],[enumeration_id],[is_icon_required], [is_text_required])
	VALUES( NEWID(), @job_type_filter_type_id, @job_type_enum_id, 0, 1 )
	       
END
GO		
-----------------------------------------------------


-----------------------------------------------------
--LAST JOB RESULT FILTER
BEGIN
	DECLARE @job_status_filter_type_id as uniqueidentifier
	SELECT  @job_status_filter_type_id = '4731913E-EB45-42ad-B3A3-0D0BEA8E1C3D'
	
	DECLARE @joblastres_enum_id as uniqueidentifier		
	SELECT  @joblastres_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3'
											
	INSERT INTO [dbo].[Report.GridReport.FilterTypes]( [id], [unique_name] )
	VALUES( @job_status_filter_type_id, 'job_status_filter')							
	INSERT INTO [dbo].[Report.GridReport.FilterType.StatScopeFilterTypes]( [id], [filter_type_id],[enumeration_id],[is_icon_required], [is_text_required])
	VALUES( NEWID(), @job_status_filter_type_id, @joblastres_enum_id, 0, 1 )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--TEXT FILTER
BEGIN
	DECLARE @text_filter_type_id as uniqueidentifier
	SELECT @text_filter_type_id = 'D7F9A519-3782-48d1-833F-68868B7E61C9'
	
	INSERT INTO [dbo].[Report.GridReport.FilterTypes]( [id], [unique_name] )
	VALUES( @text_filter_type_id, 'text_filter')				
	
	INSERT INTO [dbo].[Report.GridReport.FilterType.TextFilterTypes]( [id], [filter_type_id])
	VALUES( NEWID(), @text_filter_type_id )
END
GO
-----------------------------------------------------


-----------------------------------------------------
--BACKUP  JOB STATUSES
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @jobstatuses_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E'
   
	-- Register images folder
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END			
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @jobstatuses_enum_id, 'JobStatuses')
												
	-- Register enumeration values									
	--  None 
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, -1, 'Never started', null, null 
	--  Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 0, 'Success', 'SuccessSmall', null 
	--  Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 1, 'Warning', 'WarningSmall', null 
	--  Failed
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 2, 'Failed', 'FailedSmall', null 
	--  Starting
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 3, 'Starting', 'RunSmall', null
	--  Stopping
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 4, 'Stopping', 'RunSmall', null 
	--  Running
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 5, 'Running', 'RunSmall', null 
END
GO
-----------------------------------------------------



------------------------------------------------------------------
/*   BACKUP  JOB LAST RESULT									*/
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @joblastres_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @joblastres_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3'
	
	-- Register images folder			
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @joblastres_enum_id, 'JobLastRes')
												
	-- Register enumeration values
	--  None 
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @joblastres_enum_id, @statuses_img_folder_id, -1, 'Never started', null, null 
	--  Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @joblastres_enum_id, @statuses_img_folder_id, 0, 'Success', 'SuccessSmall', null 
	--  Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @joblastres_enum_id, @statuses_img_folder_id, 1, 'Warning', 'WarningSmall', null
	--  Failed
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @joblastres_enum_id, @statuses_img_folder_id, 2, 'Error', 'FailedSmall', null
END
GO

------------------------------------------------------------------
/*    BACKUP SERVER STATUSES                                     */
BEGIN
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @backupsrv_statuses_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @backupsrv_statuses_enum_id = '2741B14C-F923-4175-8154-2F8F5E26AD65'
		   
	-- Register images folder			
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END
		
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @backupsrv_statuses_enum_id, 'BackupSrvStatuses')
												
	-- Register enumeration values
	--  Never collected
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @backupsrv_statuses_enum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = -1,
			@display_value  = N'Never processed',
			@small_icon_name = null,
			@large_icon_name = null
												
	--  Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @backupsrv_statuses_enum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 0,
			@display_value  = N'OK',
			@small_icon_name = N'SuccessSmall',
			@large_icon_name = null			
	
	--  Error
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @backupsrv_statuses_enum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 1,
			@display_value  = N'Error',
			@small_icon_name = N'FailedSmall',
			@large_icon_name = null			
					
	--  Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @backupsrv_statuses_enum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 2,
			@display_value  = N'Warning',
			@small_icon_name = N'WarningSmall',
			@large_icon_name = null											
END
GO

------------------------------------------------------------------
/*   COLLECTING STATUSES 									*/
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @collect_statuses_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @collect_statuses_enum_id = '5E3149C0-3BC9-4395-9F04-035EE85B1F55'
	
	-- Register images folder			
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @collect_statuses_enum_id, 'CollectSessionStatuses')
												
	-- Register enumeration values
	--  Collecting
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @collect_statuses_enum_id, @statuses_img_folder_id, 0, 'Collecting', 'SuccessSmall', null
	--  Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @collect_statuses_enum_id, @statuses_img_folder_id, 1, 'Success', 'SuccessSmall', null 
	--  Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @collect_statuses_enum_id, @statuses_img_folder_id, 2, 'Warning', 'WarningSmall', null
	--  Error
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @collect_statuses_enum_id, @statuses_img_folder_id, 3, 'Error', 'FailedSmall', null
END
GO

------------------------------------------------------------------
/*   JOB TYPES 									*/
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @job_types_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @job_types_enum_id = '2ED2AF5B-041A-4e8b-B467-F960B894EF7F'
	
	-- Register images folder			
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @job_types_enum_id, 'JobTypes')
												
	-- Register enumeration values
	--  Backup
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @job_types_enum_id, @statuses_img_folder_id, 0, 'Backup', null, null
	--  Replica
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @job_types_enum_id, @statuses_img_folder_id, 1, 'Replica', null, null 
	--  Copy
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @job_types_enum_id, @statuses_img_folder_id, 2, 'Copy', null, null
END
GO

------------------------------------------------------------------
/*   SESSION INFO STATUSES 									*/
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @si_statuses_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @si_statuses_enum_id = '806747C3-873B-4027-B053-223B6A4BE1ED'
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @si_statuses_enum_id, 'ObjectStatuses')
												
	-- Register enumeration values
	--  Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @si_statuses_enum_id, @statuses_img_folder_id, 0, 'Success', 'SuccessSmall', null
	--  Error
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @si_statuses_enum_id, @statuses_img_folder_id, 2, 'Failed', 'FailedSmall', null
	--  Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @si_statuses_enum_id, @statuses_img_folder_id, 3, 'Warning', 'WarningSmall', null 
	--  In Progress
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @si_statuses_enum_id, @statuses_img_folder_id, 5, 'In progress...', 'SuccessSmall', null 
END
GO




------------------------------------------------------------------
/*   SEVERETIES 									*/
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @severity_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @severity_enum_id = '8BD74F79-3B66-401c-9ADC-B872DB08D1B1'
	
	-- Register images folder			
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @severity_enum_id, 'Severity')

	-- Register enumeration values
	--  Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @severity_enum_id, @statuses_img_folder_id, 1, 'Success', 'SuccessSmall', null 
	--  Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @severity_enum_id, @statuses_img_folder_id, 2, 'Warning', 'WarningSmall', null
	--  Error
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @severity_enum_id, @statuses_img_folder_id, 3, 'Error', 'FailedSmall', null
END
GO


------------------------------------------------------------------
/*   ACCOUNT TYPES 									*/
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier,
		@account_type_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @account_type_enum_id = '4820EFFD-8A8E-44b1-9CBD-85234E8251E8'
	
	-- Register images folder			
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @account_type_enum_id, 'Account Types')

	-- Register enumeration values
	--  User
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @account_type_enum_id, @statuses_img_folder_id, 2, 'Users', 'UserSmall', null 
	--  Group
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @account_type_enum_id, @statuses_img_folder_id, 1, 'Groups', 'GroupSmall', null
END
GO		

------------------------------------------------------------------
/*   ROLES 									*/
BEGIN			
	DECLARE @roles_enum_id as uniqueidentifier
	SELECT @roles_enum_id = '795239D9-EE07-4c7c-A4BD-AD17D4F2478C'
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @roles_enum_id, 'Roles')

	-- Register enumeration values
	--  Administrator
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @roles_enum_id, null, 1, 'Portal Administrator', null, null
	--  Viewer
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @roles_enum_id, null, 2, 'Portal Viewer', null, null 
END
GO					
			
			
			
	
	
				
/*************************************************  REGISTER WELL-KNOWN TASKS ************************************************/						
BEGIN
	--	Register TASKS image folder
	DECLARE @tasks_img_folder_id as uniqueidentifier						
	SELECT  @tasks_img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D'
	
	INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
	VALUES( @tasks_img_folder_id, 'Tasks')
		   
		   
	-- 'START JOB' TASK
	DECLARE @startjob_task_id uniqueidentifier
	SELECT @startjob_task_id = '132A630E-8B8A-472c-9EAE-752B6B23BDFD'		
	
	
	EXEC [dbo].[Report.Shared.RegisterTaskType]							
		@task_id = @startjob_task_id,
		@img_folder_id = @tasks_img_folder_id,
		@img_name = N'StartJob',
		@description = N'Start job',
		@req_lines_selection = true,
		@invoke_type = 1
	
		
	--	'STOP JOB' TASK
	DECLARE @stopjob_task_id uniqueidentifier
	SELECT @stopjob_task_id = 'CC8A624D-3E7A-47ba-AB22-0D2D37FABA5F'						
											
	EXEC [dbo].[Report.Shared.RegisterTaskType]							
		@task_id = @stopjob_task_id,
		@img_folder_id = @tasks_img_folder_id,
		@img_name = N'StopJob',
		@description = N'Stop job',
		@req_lines_selection = true,
		@invoke_type = 1
		
	--	'RETRY JOB' TASK
	DECLARE @retryjob_task_id uniqueidentifier
	SELECT @retryjob_task_id = '2C4D1976-432F-45ad-9B9C-1D0338BC1FB8'

	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @retryjob_task_id,
		@img_folder_id = @tasks_img_folder_id,
		@img_name = N'RetryJob',
		@description = N'Retry job',
		@req_lines_selection = true,
		@invoke_type = 1
END
GO


/********************************************************************************************************
*
*	DASHBOARD
*
*********************************************************************************************************/
BEGIN

	DECLARE @repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier
	SELECT @repid = 'F3749311-9C91-4d89-8BF7-2F53EC171374', @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
	@builder_id = @naviname_builder_id,
	@format_str = N'Dashboard'

	INSERT INTO [dbo].[Reports]([id],[unique_name],[display_name], [naviname_builder_id])
	VALUES( @repid, 'dashboard', 'Dashboard', @naviname_builder_id)

END
GO
/********************************************************************************************************
*
*	VMs REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @grid_repid uniqueidentifier, @naviname_builder_id uniqueidentifier
	SELECT @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'VMs'

	EXEC  [dbo].[usp.GridReport.Config.RegGridReport]  
				@report_id = 'A672891E-C13C-481a-A7AE-C22E54E1D4E2',
				@unique_name = N'vm_in_backups',
				@display_name = N'VMs',
				@datasrc_proc = N'usp.GridReport.DataSrc.VmInBackups',
				@grid_report_id = @grid_repid,
				@naviname_builder_id = @naviname_builder_id
				
	/******************  HYPERLINKS *****************************************************/
	DECLARE
		@vm_2_restorepoint_hrefid uniqueidentifier,
		@vms_2_vmsessions_hyperlink_id uniqueidentifier
	SELECT 
		@vm_2_restorepoint_hrefid = '8FED9947-E958-410c-A859-79EABC73A8E9',
		@vms_2_vmsessions_hyperlink_id = '453D47EA-3255-443b-A8AF-B2142A2492DC'

	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
		  @hyperlink_id = @vm_2_restorepoint_hrefid,
		  @hyperlink_unique_name = 'vm2restorepoints'
		  
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
		  @hyperlink_id = @vms_2_vmsessions_hyperlink_id,
		  @hyperlink_unique_name = 'vms2vmsessions'
							
	/************************* ORDERS ****************************************************/
	DECLARE	
		@order_vm_name uniqueidentifier,
		@order_last_backup_file uniqueidentifier,
		@order_restore_points_count uniqueidentifier,
		@order_backup_server_name uniqueidentifier,
		@order_job_name uniqueidentifier,
		@order_latest_success_dt uniqueidentifier,
		@order_tgt_server uniqueidentifier

	SELECT 
		@order_vm_name = NEWID(),
		@order_last_backup_file = NEWID(),
		@order_restore_points_count = NEWID(),
		@order_backup_server_name = NEWID(),
		@order_job_name = NEWID(),
		@order_latest_success_dt = NEWID(),
		@order_tgt_server = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_name, @grid_repid, 'vm_name'		
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_last_backup_file, @grid_repid, 'last_backup_file'		
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_restore_points_count, @grid_repid, 'restore_points_count'		
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_backup_server_name, @grid_repid, 'backup_server_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_name, @grid_repid, 'job_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_latest_success_dt, @grid_repid, 'latest_success_dt'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_tgt_server, @grid_repid, 'tgt_server'

	/**********************************  COLUMNS  *******************************************/
	/*  VM NAME    */
	DECLARE @vm_sessions_repid uniqueidentifier		
	SELECT @vm_sessions_repid = '3644428A-D5DD-410d-976C-34C13A76F047'

	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'VM',
		@col_unique_name = N'vms_2_vmsessions_href',
		@col_width  = 100,
		@col_number = 0,
		@is_sortable = 1,
		@trg_report_id = @vm_sessions_repid,  /*SESSIONS HISTORY*/
		@href_id = @vms_2_vmsessions_hyperlink_id,
		@datasrc_textcol_name = N'vm_name',
		@datasrc_textcol_type = 12, -- nvarchar
		@dyn_attr1_name = 'id',
		@datasrc_dynattr1_colname = 'vm_id',
		@dyn_attr2_name = 'vm_name',
		@datasrc_dynattr2_colname = 'vm_name',
		@format = 0, --text
		@order_id = @order_vm_name

	--  Backup server
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]					
		@grid_report_id = @grid_repid,
		@col_display_name = N'Backup Server',
		@col_unique_name = N'backup_server_name',
		@col_width = 70,
		@col_number = 1,
		@is_sortable = 1,
		@datasrc_col_name = N'backup_server_name',
		@datasrc_col_type = 12,
		@format = 0,--text
		@order_id = @order_backup_server_name

	--  Job name
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]					
		@grid_report_id = @grid_repid,
		@col_display_name = N'Job Name',
		@col_unique_name = N'job_name',
		@col_width = 100,
		@col_number = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'job_name',
		@datasrc_col_type = 12,
		@format = 0,--text
		@order_id = @order_job_name
				
	--   RESTORE POINTS
	DECLARE @restore_points_repid uniqueidentifier		
	SELECT @restore_points_repid = 'BD1667AC-2454-4968-B137-60110D8EA205'

	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDDBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Restore Points',
		@col_unique_name = N'restore_points_href',
		@col_width  = 60,
		@col_number = 3,
		@is_sortable = 1,
		@trg_report_id = @restore_points_repid,
		@href_id = @vm_2_restorepoint_hrefid,
		@datasrc_textcol_name = N'restore_points_linkname',
		@datasrc_textcol_type = 12, -- nvarchar --8, -- Int
		@dyn_attr1_name = N'vm_id',
		@datasrc_dynattr1_colname = N'vm_id',
		@dyn_attr2_name = N'point_id',
		@datasrc_dynattr2_colname = N'point_id',
		@dyn_attr3_name = N'vb_db_id',
		@datasrc_dynattr3_colname = N'vb_db_id',
		@format = 0,--text
		@order_id = @order_restore_points_count

	--  LOCATION (TARGET SERVER NAME)	
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Location',
		@col_unique_name = N'tgt_server',
		@col_width = 70,
		@col_number = 4,
		@is_sortable = 1,
		@datasrc_col_name = N'tgt_server',
		@datasrc_col_type = 12,
		@format = 0, --text
		@order_id = @order_tgt_server

	--  FILE PATH
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]					
		@grid_report_id = @grid_repid,
		@col_display_name = N'File Path',
		@col_unique_name = N'last_backup_file',
		@col_width = 200,
		@col_number = 5,
		@is_sortable = 1,
		@datasrc_col_name = N'last_backup_file',
		@datasrc_col_type = 12,
		@format = 0,--text
		@order_id = @order_last_backup_file

	/*  Latest success */
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Latest Success',
		@col_unique_name = N'latest_success_dt',
		@col_width = 80,
		@col_number = 6,
		@is_sortable = 1,
		@datasrc_col_name = N'latest_success_dt',
		@datasrc_col_type = 4, --SqlDbType - DateTime
		@format = 1, --datetime
		@order_id = @order_latest_success_dt
				
	/***************************  FILTERS ***************************************************/		
	/*  VM NAME FILTER */

	EXEC [dbo].[usp.GridReport.Config.AttachTextFilter2Rep]
				@grid_report_id = @grid_repid,
				@filter_unique_name = 'vm_name',
				@filter_display_name = N'Name',
				@filter_number = 0
			    
END
GO




/********************************************************************************************************
*
*	JOB LOG REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @report_id uniqueidentifier
	SELECT @report_id = '1D8D40AB-6A41-490e-AFBB-55085BADFBF2'

	EXEC [dbo].[usp.GridReport.Config.RegLogReport] 
		@report_id, N'job_log', N'usp.GridReport.DataSrc.JobLog'
END
GO


/********************************************************************************************************
*
*	COLLECT LOG REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @report_id uniqueidentifier
	SELECT @report_id = '68ACF7B6-A35B-4d12-86D7-7A8C1F075EBE'

	EXEC [dbo].[usp.GridReport.Config.RegLogReport] 
		@report_id, N'collect_log', N'usp.GridReport.DataSrc.CollectLog'
END
GO
/*********************************************** DATASRC PROCEDURE **********************************************/



/********************************************************************************************************
*
*	JOBS
*
*********************************************************************************************************/
BEGIN		
	DECLARE @grid_repid as uniqueidentifier 
	DECLARE @naviname_builder_id as uniqueidentifier 

	SELECT @grid_repid = NEWID(),
	@naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
	@builder_id = @naviname_builder_id,
	@format_str = N'Jobs'

	/************* REGISTER REPORT ***********************************************/	

	EXEC  [dbo].[usp.GridReport.Config.RegGridReport]  
	@report_id = '923FA20C-E6F7-4de7-AB69-BA006707AF78',
	@unique_name = N'current_jobs',
	@display_name = N'Jobs',					
	@datasrc_proc = N'usp.GridReport.DataSrc.CurrentJobs',
	@grid_report_id = @grid_repid,
	@naviname_builder_id = @naviname_builder_id


	/******************  HYPERLINKS *****************************************************/
	DECLARE 
	@bjob_2_last_completesession_hrefid uniqueidentifier,
	@bjob_2_joblog_hrefid uniqueidentifier,
	@curjobs_2_all_sessions_hrefid uniqueidentifier
	SELECT 
	@bjob_2_last_completesession_hrefid = '153B2A2B-6BBD-4080-B203-6B96A6605BFB',
	@bjob_2_joblog_hrefid = '27686973-22FF-4875-8023-F591A19DC6EA',
	@curjobs_2_all_sessions_hrefid = 'DDA425A3-B6C0-4cde-B7D9-D167DE0BD031'

	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	@hyperlink_id = @bjob_2_last_completesession_hrefid,
	@hyperlink_unique_name = 'bjob2last_complete_session'
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	@hyperlink_id = @bjob_2_joblog_hrefid,
	@hyperlink_unique_name = 'bjob2log'
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	@hyperlink_id = @curjobs_2_all_sessions_hrefid,
	@hyperlink_unique_name = N'current_job_2_all_sessions'


	/************************* ORDERS ****************************************************/
	DECLARE @order_name uniqueidentifier,
	@order_status uniqueidentifier,
	@order_backup_server uniqueidentifier,
	@order_type uniqueidentifier,
	@order_latest_run uniqueidentifier,
	@order_next_run uniqueidentifier

	SELECT @order_name = NEWID(),
	@order_status = NEWID(),
	@order_backup_server = NEWID(),
	@order_type = NEWID(),
	@order_latest_run = NEWID(),
	@order_next_run = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_name, @grid_repid, 'name' 
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_status, @grid_repid, 'status' 
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_backup_server, @grid_repid, 'backup_server' 
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_type, @grid_repid, 'type'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_latest_run, @grid_repid, 'latest_run'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_next_run, @grid_repid, 'next_run'		


	/******* COLUMNS *************************************************************/
	DECLARE 
	@jobstatuses_enum_id as uniqueidentifier, 
	@job_last_res_enum_id as uniqueidentifier,
	@jobtypes_enum_id as uniqueidentifier
	SELECT 
	@jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E',
	@job_last_res_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3',
	@jobtypes_enum_id = '2ED2AF5B-041A-4e8b-B467-F960B894EF7F'

	/*  JOB STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,
	@col_unique_name = 'job_status_icon',
	@col_number  = 0,
	@datasrc_col_name = 'status',
	@enumeration_id = @job_last_res_enum_id

	/* JOB NAME */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Name',
	@col_unique_name = N'job_name',
	@col_width  = 100,
	@col_number = 1,
	@is_sortable = 1,
	@trg_report_id = '56D6E095-69A1-403f-BF77-422E303FE31A',  /*Job's sessions*/
	@href_id = @curjobs_2_all_sessions_hrefid,
	@datasrc_textcol_name = N'name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'id',
	@dyn_attr2_name = 'job_name',
	@datasrc_dynattr2_colname = 'name',
	@format = 0, --text
	@order_id = @order_name

	/*  JOB TYPE */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Type',
	@col_unique_name = 'job_type',
	@col_width = 40,
	@col_number  = 2,
	@is_sortable = 1,
	@datasrc_col_name = 'type',
	@enumeration_id = @jobtypes_enum_id,
	@order_id = @order_type
		
	/*  BACKUP SERVER */
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Backup Server',
	@col_unique_name = N'backup_server',
	@col_width = 80,
	@col_number = 3,
	@is_sortable = 1,
	@datasrc_col_name = N'backup_server',
	@datasrc_col_type = 12,  /*Sql DB type - nvarchar*/
	@format = 0, --text
	@order_id = @order_backup_server

	/*  STATUS */
	DECLARE 
	@session_details_repid uniqueidentifier,
	@job_log_repid uniqueidentifier	
	SELECT 
	@session_details_repid  = '0F8FDA6D-25D6-4f03-835E-A6EC971BE62F',
	@job_log_repid  = '1D8D40AB-6A41-490e-AFBB-55085BADFBF2'

	DECLARE			
	@href_binding1_id uniqueidentifier, 
	@href_binding2_id uniqueidentifier,
	@dyn_href_binding_id uniqueidentifier			

	EXEC [dbo].[usp.GridReport.Config.RegHrefBinding]
	@trg_report_id				= @session_details_repid,
	@href_id					= @bjob_2_last_completesession_hrefid,
	@href_binding_id			= @href_binding1_id OUTPUT,
	@dyn_attr1_name				= N'id',
	@datasrc_dynattr1_colname	= N'last_completed_session_id',
	@dyn_attr2_name				= 'navi_name_attr',
	@datasrc_dynattr2_colname	= 'session_creation_time',
	@dyn_attr3_name				= 'navi_name_attr2',
	@datasrc_dynattr3_colname	= 'retry_text'

	EXEC [dbo].[usp.GridReport.Config.RegHrefBinding]
	@trg_report_id				= @job_log_repid,
	@href_id					= @bjob_2_joblog_hrefid,
	@href_binding_id			= @href_binding2_id OUTPUT,
	@dyn_attr1_name				= 'session_id',
	@datasrc_dynattr1_colname	= 'started_session_id'
	EXEC [dbo].[usp.GridReport.Config.RegDynHrefBinding]
	@href_binding1_id,
	@href_binding2_id,
	N'[usp.GridReport.HrefResolveProc.Jobs_CurrentState]',
	@dyn_href_binding_id OUTPUT,
	@dyn_attr1_name				= 'session_id',
	@datasrc_dynattr1_colname	= 'started_session_id'
		
	EXEC [dbo].[usp.GridReport.Config.RegColWithEnumDynHrefBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Current State',
	@col_unique_name = N'job_status',
	@col_width  = 50,
	@col_number = 4,
	@is_sortable = 1,
	@dyn_href_binding_id = @dyn_href_binding_id,
	@datasrc_enumcol_name = N'status',
	@datasrc_enum_type = @jobstatuses_enum_id,
	@order_id = @order_status

	/*  LATEST RUN */
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Latest Run',
	@col_unique_name = N'latest_run',
	@col_width = 70,
	@col_number = 5,
	@is_sortable = 1,
	@datasrc_col_name = N'latest_run',
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_latest_run

	/*  NEXT RUN */
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Next Run',
	@col_unique_name = N'next_run',
	@col_width = 70,
	@col_number = 6,
	@is_sortable = 1,
	@datasrc_col_name = N'next_run',
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@default_value_column = 'next_run_def_value',
	@order_id = @order_next_run


	/*  JOB DESCRIPTION */
	EXEC  [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]					
	@grid_report_id = @grid_repid,
	@col_display_name = N'Description',
	@col_unique_name = N'job_description',
	@col_width = 200,
	@col_number = 7,
	@is_sortable = 0,
	@datasrc_col_name = N'description',
	@datasrc_col_type = 12,  /*Sql DB type - datetime*/
	@format = 0--text

	/******* FILTERS *******************************************************************************/				
	/*  BACKUP SERVER FILTER */
	DECLARE @backupsrv_filter_type_id as uniqueidentifier
	SELECT @backupsrv_filter_type_id = '59835D5B-353D-4e50-8ABA-50BD52ABFD8F'
	INSERT INTO [dbo].[Report.GridReport.Filters]( [id], [grid_report_id], [filter_type_id], [display_name], [unique_name], [ordinal_number], [width])
	VALUES( NEWID(), @grid_repid, @backupsrv_filter_type_id, 'Backup server', 'backup_srv', 0, 150 )

	/*  LAST RESULT  FILTER */
	DECLARE @backupjob_lastres_filter_type_id as uniqueidentifier
	SELECT @backupjob_lastres_filter_type_id = '4731913E-EB45-42ad-B3A3-0D0BEA8E1C3D'
	INSERT INTO [dbo].[Report.GridReport.Filters]( [id], [grid_report_id], [filter_type_id], [display_name], [unique_name], [ordinal_number], [width])
	VALUES( NEWID(), @grid_repid, @backupjob_lastres_filter_type_id, 'Last result', 'last_res', 2, 100 )

	/*  JOB NAME FILTER */
	DECLARE @jobname_filter_type_id as uniqueidentifier
	SELECT @jobname_filter_type_id = 'D7F9A519-3782-48d1-833F-68868B7E61C9'
	INSERT INTO [dbo].[Report.GridReport.Filters]( [id], [grid_report_id], [filter_type_id], [display_name], [unique_name], [ordinal_number], [width])
	VALUES( NEWID(), @grid_repid, @jobname_filter_type_id, 'Job name','job_name', 2, 100 )

	/************************* TASKS ****************************************************/
	/*   START JOB  */
	DECLARE @startjob_task_id uniqueidentifier
	SELECT @startjob_task_id = '132A630E-8B8A-472c-9EAE-752B6B23BDFD'		

	EXEC [usp.GridReport.Config.RegTask]
	@grid_id = @grid_repid,
	@task_type_id = @startjob_task_id,
	@ordinal_number = 0
			
	/*   STOP JOB  */
	DECLARE @stopjob_task_id uniqueidentifier
	SELECT @stopjob_task_id = 'CC8A624D-3E7A-47ba-AB22-0D2D37FABA5F'						
								
	EXEC [usp.GridReport.Config.RegTask]
	@grid_id = @grid_repid,
	@task_type_id = @stopjob_task_id,
	@ordinal_number = 1

	/*   RETRY JOB  */
	DECLARE @retryjob_task_id uniqueidentifier
	SELECT @retryjob_task_id = '2C4D1976-432F-45ad-9B9C-1D0338BC1FB8'						
								
	EXEC [usp.GridReport.Config.RegTask]
	@grid_id = @grid_repid,
	@task_type_id = @retryjob_task_id,
	@ordinal_number = 2
END		
GO
							


/********************************************************************************************************
*
*	BACKUP SERVERS
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid uniqueidentifier, @grid_repid uniqueidentifier, @naviname_builder_id uniqueidentifier
	SELECT @repid = 'ED83A1E2-632E-4d81-B112-7FFE60336F10', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
	@builder_id = @naviname_builder_id,
	@format_str = N'All Servers'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
	@report_id = @repid,
	@unique_name = N'backup_servers',				
	@display_name = N'Backup servers',
	@datasrc_proc = N'usp.GridReport.DataSrc.BackupServers',
	@grid_report_id = @grid_repid,
	@naviname_builder_id = @naviname_builder_id		

	/******************  HYPERLINKS *****************************************************/
	DECLARE @srv2jobs_hyperlink_id as uniqueidentifier
	SELECT @srv2jobs_hyperlink_id = 'CB7499CE-DD2A-4e25-9F8B-3FCB4B8DE0D7'

	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	@hyperlink_id = @srv2jobs_hyperlink_id,
	@hyperlink_unique_name = N'srv2jobs'		

	/************************* ORDERS ****************************************************/
	DECLARE @order_display_name uniqueidentifier,
	@order_description uniqueidentifier,
	@order_backupsrv_status uniqueidentifier,
	@order_jobs_count uniqueidentifier,
	@order_vms_count uniqueidentifier,
	@order_vms_total_size uniqueidentifier
	SELECT
	@order_display_name = NEWID(),
	@order_description = NEWID(),
	@order_backupsrv_status = NEWID(),
	@order_jobs_count = NEWID(),
	@order_vms_count = NEWID(),
	@order_vms_total_size = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_display_name, @grid_repid, 'display_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_description, @grid_repid, 'description'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_backupsrv_status, @grid_repid, 'backupsrv_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_jobs_count, @grid_repid, 'jobs_count'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vms_count, @grid_repid, 'vms_count'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vms_total_size, @grid_repid, 'vms_total_size'

	/******************  COLUMNS ********************************************************/		
	DECLARE @backupsrv_statuses_enum_id as uniqueidentifier
	SELECT  @backupsrv_statuses_enum_id = '2741B14C-F923-4175-8154-2F8F5E26AD65'

	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,			
	@col_unique_name = 'backupsrv_status_icon',			
	@col_number  = 0,			
	@datasrc_col_name = 'backupsrv_status',
	@enumeration_id = @backupsrv_statuses_enum_id


	/* SERVERS */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Backup Server',
	@col_unique_name = N'backup_server',
	@col_width  = 80,
	@col_number = 1,
	@is_sortable = 1,
	@trg_report_id = 'E3FB504E-DCBD-4d26-993E-E1A1D62095B1',  /*JobsPerServer*/
	@href_id = @srv2jobs_hyperlink_id,
	@datasrc_textcol_name = 'display_name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'id',
	@dyn_attr2_name = 'srv_display_name',
	@datasrc_dynattr2_colname = 'display_name',
	@format = 0, --text
	@order_id = @order_display_name
						
	/* STATUS */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Server Status',
	@col_unique_name = 'backupsrv_status_text',
	@col_width = 50,
	@col_number  = 2,
	@is_sortable = 1,
	@datasrc_col_name = 'backupsrv_status',
	@enumeration_id = @backupsrv_statuses_enum_id,
	@order_id = @order_backupsrv_status			

	/* JOBS NUMBER */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Jobs Count',
	@col_unique_name = N'jobs_count',
	@col_width  = 40,
	@col_number = 3,
	@is_sortable = 1,
	@datasrc_col_name = N'jobs_count',
	@datasrc_col_type = 8,  /*SqlDbType.Int*/
	@format = 0, --text
	@order_id = @order_jobs_count

	/* VMS NUMBER */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'VM Count',
	@col_unique_name = N'vms_count',
	@col_width  = 40,
	@col_number = 4,
	@is_sortable = 1,
	@datasrc_col_name = N'vms_count',
	@datasrc_col_type = 8,  /*SqlDbType.Int*/
	@format = 0, --text
	@order_id = @order_vms_count

	/* SOURCE DATA SIZE */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Source Data Size',
	@col_unique_name = N'vms_total_size',
	@col_width  = 70,
	@col_number = 5,
	@is_sortable = 1,
	@datasrc_col_name = N'vms_total_size',
	@datasrc_col_type = 0,  /*SqlDbType.BigInt*/
	@format = 2, --size
	@order_id = @order_vms_total_size

	/* DESCRIPTION */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Server Description',
	@col_unique_name = N'description',
	@col_width  = 300,
	@col_number = 6,
	@is_sortable = 0,
	@datasrc_col_name = N'description',
	@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
	@format = 0, --text
	@order_id = @order_description			  
END
GO
/******************************************* DATASRC PROCEDURE ******************************************/	



/********************************************************************************************************
*
*	JOBS PER SERVER - REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = 'E3FB504E-DCBD-4d26-993E-E1A1D62095B1', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	/******************* NAVINAME BUILDER **********************************************/
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
	@builder_id = @naviname_builder_id,
	@format_str = N'{0}',
	@query_attr_name = N'srv_display_name'

		
	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
		@report_id = @repid,
		@unique_name = N'jobs_per_server',				
		@display_name = N'Jobs',
		@datasrc_proc = N'usp.GridReport.DataSrc.JobsPerServer',
		@grid_report_id = @grid_repid,
		@naviname_builder_id = @naviname_builder_id			

	/******************  HYPERLINKS *****************************************************/
	/*   JOB -> LAST SESSION  */
	DECLARE @bjob_2_last_completesession_hrefid as uniqueidentifier
	SELECT @bjob_2_last_completesession_hrefid = '510B2668-9394-4f86-AB67-34B4C62D2FF8'
		
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @bjob_2_last_completesession_hrefid,
	 @hyperlink_unique_name = N'job2last_session'
	 
	/*   JOB -> ALL SESSIONS  */				 
	DECLARE @job2all_sessions_hyperlink_id as uniqueidentifier
	SELECT @job2all_sessions_hyperlink_id = 'DF3ACC9E-348D-453f-AB4A-22C4B15A15B5'

	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @job2all_sessions_hyperlink_id,
	 @hyperlink_unique_name = N'job2all_sessions'

	/************************* ORDERS ****************************************************/
	DECLARE @order_job_name uniqueidentifier,
	@order_vms_count uniqueidentifier,
	@order_total_size uniqueidentifier,
	@order_job_status uniqueidentifier,
	@order_last_success uniqueidentifier,
	@order_job_type uniqueidentifier,
	@order_last_result uniqueidentifier

	SELECT @order_job_name = NEWID(),
	@order_vms_count = NEWID(),
	@order_total_size = NEWID(),
	@order_job_status = NEWID(),
	@order_last_success = NEWID(),
	@order_job_type = NEWID(),
	@order_last_result = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_name, @grid_repid, 'job_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vms_count, @grid_repid, 'vms_count'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_total_size, @grid_repid, 'total_size'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_status, @grid_repid, 'job_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_last_success, @grid_repid, 'last_success'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_type, @grid_repid, 'job_type'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_last_result, @grid_repid, 'last_result'

	/******************  COLUMNS ********************************************************/					
	DECLARE 
	@jobstatuses_enum_id as uniqueidentifier,
	@joblastres_enum_id as uniqueidentifier,
	@jobtypes_enum_id as uniqueidentifier
		
	SELECT  
	@jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E',
	@joblastres_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3',
	@jobtypes_enum_id = '2ED2AF5B-041A-4e8b-B467-F960B894EF7F'

	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,				
	@col_unique_name = 'job_status_icon',				
	@col_number  = 0,				
	@datasrc_col_name = 'job_status',
	@enumeration_id = @joblastres_enum_id

	/* JOB NAME */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Job Name',
	@col_unique_name = N'job_name',
	@col_width  = 100,
	@col_number = 1,
	@is_sortable = 1,
	@trg_report_id = '56D6E095-69A1-403f-BF77-422E303FE31A',  /*Job's sessions*/
	@href_id = @job2all_sessions_hyperlink_id,
	@datasrc_textcol_name = N'job_name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'id',
	@dyn_attr2_name = 'job_name',
	@datasrc_dynattr2_colname = 'job_name',
	@format = 0, --text
	@order_id = @order_job_name			

	/*  JOB TYPE */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Type',
	@col_unique_name = 'job_type',
	@col_width = 60,
	@col_number  = 2,
	@is_sortable = 1,
	@datasrc_col_name = 'job_type',
	@enumeration_id = @jobtypes_enum_id,
	@order_id = @order_job_type

	/* VM COUNT */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'VM Count',
	@col_unique_name = N'vms_count',
	@col_width  = 40,
	@col_number = 3,
	@is_sortable = 1,
	@datasrc_col_name = N'vms_count',
	@datasrc_col_type = 8,  /*SqlDbType - int*/
	@format = 0, --text
	@order_id = @order_vms_count

	/* Total size */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Total Size',
	@col_unique_name = N'total_size',
	@col_width  = 60,
	@col_number = 4,
	@is_sortable = 1,
	@datasrc_col_name = N'total_size',
	@datasrc_col_type = 0,  /*SqlDbType.BigInt*/
	@format = 2, --size
	@order_id = @order_total_size

	/* CURRENT STATE */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Current State',
	@col_unique_name = 'job_cur_state',
	@col_width = 50,
	@col_number  = 5,
	@is_sortable = 1,
	@datasrc_col_name = 'job_status',
	@enumeration_id = @jobstatuses_enum_id,
	@order_id = @order_job_status			
		

	/* LAST RESULT */
	EXEC [dbo].[usp.GridReport.Config.RegColWithEnumHrefDynBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Last Result',
	@col_unique_name = N'last_result_href',
	@col_width  = 50,
	@col_number = 6,
	@is_sortable = 1,
	@trg_report_id = '0F8FDA6D-25D6-4f03-835E-A6EC971BE62F',  /*Session details*/
	@href_id = @bjob_2_last_completesession_hrefid,
	@datasrc_enumcol_name = N'last_result',
	@datasrc_enum_type = @joblastres_enum_id, 
	@dyn_attr1_name = N'id',
	@datasrc_dynattr1_colname = N'job_last_session_id',
	@dyn_attr2_name = 'navi_name_attr',
	@datasrc_dynattr2_colname = 'session_creation_time',
	@dyn_attr3_name = 'navi_name_attr2',
	@datasrc_dynattr3_colname = 'retry_text',
	@order_id = @order_last_result

	/* LAST SUCCESS */							
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Last Success',
	@col_unique_name = 'last_success_time',
	@col_width = 70,
	@col_number  = 7,
	@is_sortable = 1,
	@datasrc_col_name = 'last_success',
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_last_success

	/* DESCRIPTION */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Job Description',
	@col_unique_name = N'job_description',
	@col_width  = 200,
	@col_number = 8,
	@is_sortable = 0,
	@datasrc_col_name = N'job_description',
	@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
	@format = 0 --text		
END
GO


/****************************************************************************************
*
*		SESSIONS PER JOB REPORT
*
*****************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier
	SELECT @repid = '56D6E095-69A1-403f-BF77-422E303FE31A', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
	@builder_id = @naviname_builder_id,
	@format_str = N'{0}',--Sessions of job
	@query_attr_name = N'job_name'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
		@report_id = @repid,
		@unique_name = N'sessions_per_job',				
		@display_name = N'Sessions',
		@datasrc_proc = N'usp.GridReport.DataSrc.SessionsPerJob',
		@grid_report_id = @grid_repid,
		@naviname_builder_id = @naviname_builder_id			

	/******************  HYPERLINKS *****************************************************/
	/*   SESSIONS -> VM SESSION  */
	DECLARE @jobsession_2_vmsession_hyperlink_id as uniqueidentifier
	SELECT @jobsession_2_vmsession_hyperlink_id = '4EBB8F5F-3FFC-41c4-B740-83BE73640D0A'
		
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @jobsession_2_vmsession_hyperlink_id,
	 @hyperlink_unique_name = N'jobsession_2_vmsession'		
	 					
	/************************* ORDERS ****************************************************/
	DECLARE @order_job_start_time uniqueidentifier,
	@order_job_end_time uniqueidentifier,
	@order_job_status uniqueidentifier,
	@order_perf_rate uniqueidentifier,
	@order_data_transferred uniqueidentifier
	SELECT @order_job_start_time = NEWID(),
	@order_job_end_time = NEWID(),
	@order_job_status = NEWID(),
	@order_perf_rate = NEWID(),
	@order_data_transferred = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_start_time, @grid_repid, 'job_start_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_end_time, @grid_repid, 'job_end_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_status, @grid_repid, 'job_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_perf_rate, @grid_repid, 'perf_rate'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_data_transferred, @grid_repid, 'data_transferred'

	/******************  COLUMNS ********************************************************/					
	DECLARE @jobstatuses_enum_id as uniqueidentifier
	SELECT  @jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E'

	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,				
	@col_unique_name = 'job_status_icon',				
	@col_number  = 0,				
	@datasrc_col_name = 'job_status',
	@enumeration_id = @jobstatuses_enum_id


													
	/* START TIME */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Start Time',
	@col_unique_name = N'job_start_time',
	@col_width  = 70,
	@col_number = 1,
	@is_sortable = 1,
	@datasrc_col_name = N'job_start_time',
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_job_start_time

	/* END TIME */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'End Time',
	@col_unique_name = N'job_end_time',
	@col_width  = 70,
	@col_number = 2,
	@is_sortable = 1,
	@datasrc_col_name = N'job_end_time',
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_job_end_time

	/* RESULT */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Result',
	@col_unique_name = N'session_href',
	@col_width  = 50,
	@col_number = 3,
	@is_sortable = 1,
	@trg_report_id = '0F8FDA6D-25D6-4f03-835E-A6EC971BE62F',  /*Session details*/
	@href_id = @jobsession_2_vmsession_hyperlink_id,
	@datasrc_textcol_name = N'job_status_text',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'id',
	@dyn_attr2_name = 'navi_name_attr',
	@datasrc_dynattr2_colname = 'job_start_time',
	@dyn_attr3_name = 'navi_name_attr2',
	@datasrc_dynattr3_colname = 'retry_text',
	@format = 0, --text
	@order_id = @order_job_status

	/* Performance rate */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Performance Rate',
	@col_unique_name = N'perf_rate',
	@col_width  = 50,
	@col_number = 4,
	@is_sortable = 1,
	@datasrc_col_name = N'perf_rate',
	@datasrc_col_type = 0,  /*SqlDbType - BigInt*/
	@format = 3, --speed
	@order_id = @order_perf_rate

	/* DATA TRANSFERERD */					
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Data Transferred',
	@col_unique_name = N'data_transferred',
	@col_width  = 50,
	@col_number = 5,
	@is_sortable = 1,
	@datasrc_col_name = N'data_transferred',
	@datasrc_col_type = 0,  /*SqlDbType - BigInt*/
	@format = 2, --size
	@order_id = @order_data_transferred
END
GO


/********************************************************************************************************
*
*	SESSION DETAILS REPORT
*
*********************************************************************************************************/		
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '0F8FDA6D-25D6-4f03-835E-A6EC971BE62F', @grid_repid = NEWID(), @naviname_builder_id = NEWID()
		
	/******************* NAVINAME BUILDER **********************************************/
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder2]
	@builder_id = @naviname_builder_id,
	@format_str = N'Session {0}{1}',--VMs per Job				
	@query_attr1_name = N'navi_name_attr',
	@query_attr2_name = N'navi_name_attr2'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
		@report_id = @repid,
		@unique_name = N'session_details',
		@display_name = N'Session details',
		@datasrc_proc = N'usp.GridReport.DataSrc.SessionDetails',
		@grid_report_id = @grid_repid,
		@naviname_builder_id = @naviname_builder_id
		
	INSERT INTO [dbo].[Report.Headers] ([id], [unique_name], [report_id], [datasrc_proc])
	VALUES('DEBF40EC-2AA5-4d63-9F07-7595D1C27866', N'JobSessions', @repid, N'usp.GridReport.DataSrc.JobSessionsHeader')

	/******************  HYPERLINKS *****************************************************/
	/*   VM -> ALL VM SESSIONS  */
	DECLARE @vm_2_vmsessions_hyperlink_id as uniqueidentifier
	SELECT @vm_2_vmsessions_hyperlink_id = 'DB20115E-2743-4756-9137-13AECBF7ACC8'
		
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @vm_2_vmsessions_hyperlink_id,
	 @hyperlink_unique_name = N'vm_2_vmsessions'		
	 					
	/************************* ORDERS ****************************************************/
	DECLARE @order_vm_name uniqueidentifier,
	@order_vm_processing_start_time uniqueidentifier,
	@order_vm_processing_end_time uniqueidentifier,
	@order_vm_processing_status uniqueidentifier,
	@order_vm_processing_rate uniqueidentifier,
	@order_vm_processed_size uniqueidentifier			
	SELECT @order_vm_name = NEWID(),
	@order_vm_processing_start_time = NEWID(),
	@order_vm_processing_end_time = NEWID(),
	@order_vm_processing_status = NEWID(),
	@order_vm_processing_rate = NEWID(),
	@order_vm_processed_size = NEWID()		

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_name, @grid_repid, 'vm_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_start_time, @grid_repid, 'vm_processing_start_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_end_time, @grid_repid, 'vm_processing_end_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_status, @grid_repid, 'vm_processing_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_rate, @grid_repid, 'vm_processing_rate'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processed_size, @grid_repid, 'vm_processed_size'

	/******************  COLUMNS ********************************************************/					
	DECLARE @si_statuses_enum_id as uniqueidentifier
	SELECT @si_statuses_enum_id = '806747C3-873B-4027-B053-223B6A4BE1ED'
			
	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,				
	@col_unique_name = 'vm_processing_status_icon',				
	@col_number  = 0,				
	@datasrc_col_name = 'vm_processing_status',
	@enumeration_id = @si_statuses_enum_id

	/* VMS HYPERLINK   */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'VM',
	@col_unique_name = N'vm_2_vmsessions_href',
	@col_width  = 100,
	@col_number = 1,
	@is_sortable = 1,
	@trg_report_id = '3644428A-D5DD-410d-976C-34C13A76F047',  /*SESSIONS HISTORY*/
	@href_id = @vm_2_vmsessions_hyperlink_id,
	@datasrc_textcol_name = N'vm_name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'vm_id',
	@dyn_attr2_name = 'vm_name',
	@datasrc_dynattr2_colname = 'vm_name',
	@format = 0, --text
	@order_id = @order_vm_name

	/* START TIME */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Start Time',
	@col_unique_name = N'vm_processing_start_time',
	@col_width  = 100,
	@col_number = 2,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processing_start_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_vm_processing_start_time

	/* END TIME */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'End Time',
	@col_unique_name = N'vm_processing_end_time',
	@col_width  = 100,
	@col_number = 3,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processing_end_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/	
	@format = 1, --datetime
	@order_id = @order_vm_processing_end_time

	/* RESULT */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Result',
	@col_unique_name = 'vm_processing_status_text',
	@col_width = 80,
	@col_number  = 4,
	@is_sortable = 1,
	@datasrc_col_name = 'vm_processing_status',
	@enumeration_id = @si_statuses_enum_id,
	@order_id = @order_vm_processing_status											

	/* PROCESSING RATE */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Performance Rate',
	@col_unique_name = N'vm_processing_rate',
	@col_width  = 80,
	@col_number = 5,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processing_rate',
	@datasrc_col_type = 0,  /*SqlDbType - BigInt*/
	@format = 3, --speed
	@order_id = @order_vm_processing_rate
			
	/* DATA TRANSFERRED */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Data Transferred',
	@col_unique_name = N'vm_processed_size',
	@col_width  = 100,
	@col_number = 6,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processed_size',				
	@datasrc_col_type = 0,  /*SqlDbType - BigInt*/
	@format = 2, --size
	@order_id = @order_vm_processed_size

	/*  ERROR DETAILS  */
	EXEC [dbo].[usp.GridReport.Config.RegDetailsPanelWithDirectColBinding]
	@grid_report_id = @grid_repid,
	@src_col_name = N'vm_processing_details',
	@panel_width = 200,
	@title = N'Details',
	@format = 0, --text
	@default_text = N'Select VM to view details'
END
GO	


/********************************************************************************************************
*
*	VMs SESSIONS HISTORY
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '3644428A-D5DD-410d-976C-34C13A76F047', @grid_repid = NEWID(), @naviname_builder_id = NEWID()
		
		
	/******************  VM backup history ***************************************************/					
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
	@builder_id = @naviname_builder_id,
	@format_str = N'{0}',--VM [{0}] backup history
	@query_attr_name = N'vm_name'
		

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
		@report_id = @repid,
		@unique_name = N'vm_sessions_history',				
		@display_name = N'VM backup history',
		@datasrc_proc = N'usp.GridReport.DataSrc.VmSessionsHistory',
		@grid_report_id = @grid_repid,
		@naviname_builder_id = @naviname_builder_id			

	/******************  HYPERLINKS *****************************************************/
	/*   VM -> ALL VM SESSIONS  */
	DECLARE @vmsession_2_jobsessions_hyperlink_id as uniqueidentifier
	SELECT @vmsession_2_jobsessions_hyperlink_id = 'DF63AD74-63E0-4026-8A0A-64D2CDD73222'
		
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @vmsession_2_jobsessions_hyperlink_id,
	 @hyperlink_unique_name = N'vmsession_2_jobsession'		
	 					
	/************************* ORDERS ****************************************************/
	DECLARE @order_vm_processing_start_time uniqueidentifier,
	@order_vm_processing_end_time uniqueidentifier,
	@order_vm_processing_status uniqueidentifier,
	@order_transferred_data uniqueidentifier,
	@order_vm_perf_rate uniqueidentifier,
	@order_session_owner_name uniqueidentifier
	SELECT @order_vm_processing_start_time = NEWID(),
	@order_vm_processing_end_time = NEWID(),
	@order_vm_processing_status = NEWID(),
	@order_transferred_data = NEWID(),
	@order_vm_perf_rate = NEWID(),
	@order_session_owner_name = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_start_time, @grid_repid, 'vm_processing_start_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_end_time, @grid_repid, 'vm_processing_end_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_status, @grid_repid, 'vm_processing_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_transferred_data, @grid_repid, 'transferred_data'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_perf_rate, @grid_repid, 'vm_perf_rate'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_session_owner_name, @grid_repid, 'session_owner_name'

	/******************  COLUMNS ********************************************************/					
	DECLARE @si_statuses_enum_id as uniqueidentifier
	SELECT  @si_statuses_enum_id = '806747C3-873B-4027-B053-223B6A4BE1ED'
			
	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,				
	@col_unique_name = 'vm_processing_status_icon',				
	@col_number  = 0,				
	@datasrc_col_name = 'vm_processing_status',
	@enumeration_id = @si_statuses_enum_id


	/* START TIME */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Start Time',
	@col_unique_name = N'vm_processing_start_time',
	@col_width  = 100,
	@col_number = 1,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processing_start_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_vm_processing_start_time

	/* END TIME */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'End Time',
	@col_unique_name = N'vm_processing_end_time',
	@col_width  = 100,
	@col_number = 2,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processing_end_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_vm_processing_end_time


	/* JOB SESSION   */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Job Session',
	@col_unique_name = N'vmsession_owner',
	@col_width  = 100,
	@col_number = 3,
	@is_sortable = 1,
	@trg_report_id = '0F8FDA6D-25D6-4f03-835E-A6EC971BE62F',  /*SESSION DETAILS*/
	@href_id = @vmsession_2_jobsessions_hyperlink_id,
	@datasrc_textcol_name = N'session_owner_name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'session_owner_id',
	@dyn_attr2_name = 'navi_name_attr',
	@datasrc_dynattr2_colname = 'session_creation_time',
	@dyn_attr3_name = 'navi_name_attr2',
	@datasrc_dynattr3_colname = 'retry_text',
	@format = 0, --text
	@order_id = @order_session_owner_name

	/* PERFORMANCE RATE */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Performance Rate',
	@col_unique_name = N'vm_perf_rate',
	@col_width  = 80,
	@col_number = 4,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_perf_rate',
	@datasrc_col_type = 0,  /*SqlDbType - BigInt*/
	@format = 3, --speed
	@order_id = @order_vm_perf_rate

	/* TRANSFERRED DATA */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Transferred Data',
	@col_unique_name = N'transferred_data',
	@col_width  = 80,
	@col_number = 5,
	@is_sortable = 1,
	@datasrc_col_name = N'transferred_data',
	@datasrc_col_type = 0,  /*SqlDbType - BigInt*/
	@format = 2, --size
	@order_id = @order_transferred_data			

	/* STATUS TEXT */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Status',
	@col_unique_name = 'vm_processing_status_text',
	@col_width = 100,
	@col_number  = 6,
	@is_sortable = 1,
	@datasrc_col_name = 'vm_processing_status',
	@enumeration_id = @si_statuses_enum_id,
	@order_id = @order_vm_processing_status

	/* DETAILS */
	EXEC [dbo].[usp.GridReport.Config.RegDetailsPanelWithDirectColBinding]
	@grid_report_id = @grid_repid,
	@src_col_name = N'vm_processing_details',
	@panel_width = 200,
	@title = N'Details',
	@format = 0, --text
	@default_text = N'Select Session to view details'
END
GO
/**************************************************** DATASRC PROCEDURE  **********************************/



/********************************************************************************************************
*
*	SESSIONS FOR PERIOD
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '67601441-55B6-4372-B2F4-31FF529C42D5', @grid_repid = NEWID(), @naviname_builder_id = NEWID()
		
		
	/******************  VM backup history ***************************************************/					
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
	@builder_id = @naviname_builder_id,
	@format_str = N'Last {0} days',--Backup sessions for the last {0} days
	@query_attr_name = N'days_count'
		

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
		@report_id = @repid,
		@unique_name = N'bsessions_for_period',				
		@display_name = N'Backup session for the period',
		@datasrc_proc = N'usp.GridReport.DataSrc.BSessionsForPeriod',
		@grid_report_id = @grid_repid,
		@naviname_builder_id = @naviname_builder_id			

	/******************  HYPERLINKS *****************************************************/
	/*   SESSION TO JOB  */

	-- BSESSION -> ALL JOB SESSIONS
	DECLARE @bsession_2_allbsessions_hyperlink_id as uniqueidentifier
	SELECT @bsession_2_allbsessions_hyperlink_id = 'A41D0A9C-DEC3-49f5-B66B-323DD968FC7E'
		
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @bsession_2_allbsessions_hyperlink_id,
	 @hyperlink_unique_name = N'bsession_2_job'		
	 

	-- BSESSION -> BACKUP SERVER
	DECLARE @bsession_2_bserver_hyperlink_id as uniqueidentifier
	SELECT @bsession_2_bserver_hyperlink_id = '127F901F-318E-401d-A824-E36508E6917E'
		
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @bsession_2_bserver_hyperlink_id,
	 @hyperlink_unique_name = N'bsession_2_bserver'						 
	 										 				 				 
	 					
	/************************* ORDERS ****************************************************/
	DECLARE  @order_job_name uniqueidentifier,
	@order_backup_srv uniqueidentifier,
	@order_session_starttime uniqueidentifier,
	@order_session_endtime uniqueidentifier,
	@order_status uniqueidentifier


	SELECT  @order_job_name = NEWID(),
		@order_backup_srv = NEWID(),
		@order_session_starttime = NEWID(),
		@order_session_endtime = NEWID(),
		@order_status = NEWID()
					

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_name, @grid_repid, 'job_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_backup_srv, @grid_repid, 'backup_srv_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_session_starttime, @grid_repid, 'bsession_start_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_session_endtime, @grid_repid, 'bsession_end_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_status, @grid_repid, 'bsession_status_text'

	/******************  COLUMNS ********************************************************/					
	DECLARE @jobstatuses_enum_id as uniqueidentifier
	SELECT  @jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E'
			
	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,				
	@col_unique_name = 'bsession_status_icon',
	@col_number  = 0,				
	@datasrc_col_name = 'bsession_status',
	@enumeration_id = @jobstatuses_enum_id


	/* JOB NAME   */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Job Name',
	@col_unique_name = N'job_name',
	@col_width  = 100,
	@col_number = 1,
	@is_sortable = 1,
	@trg_report_id = '56D6E095-69A1-403f-BF77-422E303FE31A',  /*Job's sessions*/
	@href_id = @bsession_2_allbsessions_hyperlink_id,
	@datasrc_textcol_name = N'job_name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'id',
	@dyn_attr2_name = 'job_name',
	@datasrc_dynattr2_colname = 'job_name',
	@format = 0, --text				
	@order_id = @order_job_name


	/* BACKUP SERVER */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	 @grid_report_id = @grid_repid,
	 @col_display_name = N'Backup Server',
	 @col_unique_name = N'backup_server_name',
	 @col_width  = 100,
	 @col_number = 2,
	 @is_sortable = 1,
	 @trg_report_id = 'E3FB504E-DCBD-4d26-993E-E1A1D62095B1',  /*JobsPerServer*/
	 @href_id = @bsession_2_bserver_hyperlink_id,
	 @datasrc_textcol_name = N'backup_srv_name',
	 @datasrc_textcol_type = 12, -- nvarchar
	 @dyn_attr1_name = 'id',
	 @datasrc_dynattr1_colname = 'backup_srv_id',
	 @dyn_attr2_name = 'srv_display_name',--'backup_srv_name',
	 @datasrc_dynattr2_colname = 'backup_srv_name',
	 @format = 0, --text				
	 @order_id = @order_backup_srv


	/* START TIME */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Start Time',
	@col_unique_name = N'bsession_start_time',
	@col_width  = 100,
	@col_number = 3,
	@is_sortable = 1,
	@datasrc_col_name = N'bsession_start_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_session_starttime

	/* END TIME */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'End Time',
	@col_unique_name = N'bsession_end_time',
	@col_width  = 100,
	@col_number = 4,
	@is_sortable = 1,
	@datasrc_col_name = N'bsession_end_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_session_endtime


	/* STATUS TEXT */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Status',
	@col_unique_name = 'bsession_status_text',
	@col_width = 100,
	@col_number  = 5,
	@is_sortable = 1,
	@datasrc_col_name = 'bsession_status',
	@enumeration_id = @jobstatuses_enum_id,
	@order_id = @order_status


END
GO

/**************************************************** DATASRC PROCEDURE  **********************************/


/********************************************************************************************************
*
*	CONFIGURATION - BACKUP SERVERS REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '955DF1AA-2501-451d-A4FE-FE877731D192', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'Backup Servers'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
			@report_id = @repid,
			@unique_name = N'cfg_backup_servers',
			@display_name = N'Backup Servers',
			@datasrc_proc = N'usp.GridReport.DataSrc.Cfg.BackupServers',
			@grid_report_id = @grid_repid,
			@naviname_builder_id = @naviname_builder_id

	/****************** ORDERS ********************************************************/					
	DECLARE @order_cfg_bs_name uniqueidentifier,
		@order_cfg_bs_user uniqueidentifier
	SELECT @order_cfg_bs_name = NEWID(),
		@order_cfg_bs_user = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_bs_name, @grid_repid, 'cfg_bs_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_bs_user, @grid_repid, 'cfg_bs_user'

	/******************  COLUMNS ********************************************************/					
	/* Name */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Name',
		@col_unique_name = N'cfg_bs_name',
		@col_width  = 100,
		@col_number = 1,
		@is_sortable = 1,
		@datasrc_col_name = N'cfg_bs_name',
		@datasrc_col_type = 12,  --SqlDbType - nvarchar
		@format = 0, --text
		@order_id = @order_cfg_bs_name
		
	/* LOGIN */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Login',
		@col_unique_name = N'cfg_bs_user',
		@col_width  = 100,
		@col_number = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'cfg_bs_user',
		@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
		@format = 0, --text
		@order_id = @order_cfg_bs_user
		
	/* DESCRIPTION */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Server Description',
		@col_unique_name = N'cfg_bs_desc',
		@col_width  = 200,
		@col_number = 6,
		@is_sortable = 0,
		@datasrc_col_name = N'cfg_bs_desc',
		@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
		@format = 0 --text
		
	/************************* TASKS ****************************************************/
	/*   ADD SERVER  */
	DECLARE @add_server_task_id uniqueidentifier
	SELECT @add_server_task_id = '352817F8-856F-444a-AE5B-599DDC6506A4'
		
	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @add_server_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'AddServer',
		@description = N'Add...',
		@req_lines_selection = false,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @add_server_task_id,
		@ordinal_number = 0
		
	/*   EDIT SERVER  */
	DECLARE @edit_server_task_id uniqueidentifier
	SELECT @edit_server_task_id = '18556C5D-4AC1-4eda-A106-0EB23FE0E8AF'
		
	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @edit_server_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'EditServer',
		@description = N'Edit...',
		@req_lines_selection = true,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @edit_server_task_id,
		@ordinal_number = 1

	/*   REMOVE SERVER  */
	DECLARE @remove_server_task_id uniqueidentifier
	SELECT @remove_server_task_id = '381B46DA-1E9D-48da-A431-3FD0219C40F8'
		
	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @remove_server_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'RemoveServer',
		@description = N'Remove',
		@req_lines_selection = true,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @remove_server_task_id,
		@ordinal_number = 2
							
	/*   COLLECT SCHEDULE  */
	DECLARE @collect_schedule_task_id uniqueidentifier
	SELECT @collect_schedule_task_id = 'FFA5E7D7-7FB4-4507-824C-29925ABC8AFF'
		
	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @collect_schedule_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'CollectSchedule',
		@description = N'Schedule...',
		@req_lines_selection = false,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @collect_schedule_task_id,
		@ordinal_number = 3
		
	/*   START COLLECTING  */
	DECLARE @collect_now_task_id uniqueidentifier
	SELECT @collect_now_task_id = 'A2D73F23-7DC8-4ccf-AF82-CDDFDE41B86C'
		
	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @collect_now_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'CollectNow',
		@description = N'Start Collecting',
		@req_lines_selection = false,
		@invoke_type = 1
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @collect_now_task_id,
		@ordinal_number = 4
END
GO


/**************************************************** DATASRC PROCEDURE  **********************************/

/********************************************************************************************************
*
*	CONFIGURATION - ROLES REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '21323399-F396-4c85-B62D-92827B107FC1', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'Roles'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
			@report_id = @repid,
			@unique_name = N'cfg_roles',
			@display_name = N'Roles',
			@datasrc_proc = N'usp.GridReport.DataSrc.Cfg.Roles',
			@grid_report_id = @grid_repid,
			@naviname_builder_id = @naviname_builder_id

	/******************  COLUMNS ********************************************************/
	DECLARE @account_type_enum_id as uniqueidentifier
	SELECT  @account_type_enum_id = '4820EFFD-8A8E-44b1-9CBD-85234E8251E8'
			
	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
		@grid_report_id = @grid_repid,				
		@col_unique_name = 'roles_acctype_icon',
		@col_number  = 0,				
		@datasrc_col_name = 'roles_acctype',
		@enumeration_id = @account_type_enum_id

	/* ACCOUNT */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Account',
		@col_unique_name = N'roles_account',
		@col_width  = 100,
		@col_number = 1,
		@is_sortable = 1,
		@datasrc_col_name = N'roles_account',
		@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
		@format = 0 --text
		
	/* ROLE */
	DECLARE @roles_enum_id as uniqueidentifier
	SELECT @roles_enum_id = '795239D9-EE07-4c7c-A4BD-AD17D4F2478C'

	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Role',
		@col_unique_name = N'roles_name',
		@col_width  = 100,
		@col_number  = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'roles_number',
		@enumeration_id = @roles_enum_id/*,
		@order_id = @order_cfg_sessions_status		*/
		
	/************************* TASKS ****************************************************/
	/*   ADD TO ROLE  */
	DECLARE @add_to_role_task_id uniqueidentifier
	SELECT @add_to_role_task_id = '0D7F01EB-5FF1-443e-A488-80BACB4CEA28'

	EXEC [dbo].[Report.Shared.RegisterTaskType]							
		@task_id = @add_to_role_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'AddToRole',
		@description = N'Add...',
		@req_lines_selection = true,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @add_to_role_task_id,
		@ordinal_number = 0
				
	/*   EDIT ROLE  */
	DECLARE @edit_role_task_id uniqueidentifier
	SELECT @edit_role_task_id = 'BE6FB8D6-3048-450b-ADF2-0E0DA27FFF90'

	EXEC [dbo].[Report.Shared.RegisterTaskType]							
		@task_id = @edit_role_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'EditRole',
		@description = N'Edit...',
		@req_lines_selection = true,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @edit_role_task_id,
		@ordinal_number = 1
		
	/*   REMOVE FROM ROLE  */
	DECLARE @remove_from_role_task_id uniqueidentifier
	SELECT @remove_from_role_task_id = '3A30D363-824E-46c3-9739-9A319AA1E774'

	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @remove_from_role_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'RemoveFromRole',
		@description = N'Remove...',
		@req_lines_selection = true,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @remove_from_role_task_id,
		@ordinal_number = 2
END
GO	
/**************************************************** DATASRC REPORT PROCEDURE  **********************************/



/********************************************************************************************************
*
*	CONFIGURATION - COLLECT SESSIONS REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = 'D6FB5F10-D723-414d-8674-122DDD4D66C1', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'All Collect Sessions'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
			@report_id = @repid,
			@unique_name = N'cfg_collect_sessions',
			@display_name = N'Sessions',
			@datasrc_proc = N'usp.GridReport.DataSrc.Cfg.CollectSessions',
			@grid_report_id = @grid_repid,
			@naviname_builder_id = @naviname_builder_id
	/******************  HYPERLINKS *****************************************************/
	DECLARE 
		@sessions2srv_sessions_hyperlink_id as uniqueidentifier,
		@collect_sessions_2_log_hrefid as uniqueidentifier
	SELECT 
		@sessions2srv_sessions_hyperlink_id = 'CBE8B587-A965-4d3b-AAC2-EFFF66513FC8',
		@collect_sessions_2_log_hrefid = 'C517669B-B21E-43a2-81DC-520C5D134AAE'
			
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
		 @hyperlink_id = @sessions2srv_sessions_hyperlink_id,
		 @hyperlink_unique_name = N'collect_sessions2server_collect_sessions'

	/****************** ORDERS ********************************************************/					
	DECLARE @order_cfg_sessions_start_date uniqueidentifier,
		@order_cfg_sessions_status uniqueidentifier,
		@order_cfg_sessions_initiated_by uniqueidentifier
	SELECT @order_cfg_sessions_start_date = NEWID(),
		@order_cfg_sessions_status = NEWID(),
		@order_cfg_sessions_initiated_by = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_sessions_start_date, @grid_repid, 'cfg_sessions_start_date'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_sessions_status, @grid_repid, 'cfg_sessions_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_sessions_initiated_by, @grid_repid, 'cfg_sessions_initiated_by'
			
	/******************  COLUMNS ********************************************************/
	DECLARE @collect_statuses_enum_id as uniqueidentifier			
	SELECT  @collect_statuses_enum_id = '5E3149C0-3BC9-4395-9F04-035EE85B1F55'

	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
		@grid_report_id = @grid_repid,				
		@col_unique_name = 'cfg_sessions_status_icon',
		@col_number  = 0,				
		@datasrc_col_name = 'cfg_sessions_status',
		@enumeration_id = @collect_statuses_enum_id

	/* DATE TIME */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Start Time',
		@col_unique_name = N'cfg_sessions_start_date',
		@col_width  = 70,
		@col_number = 1,
		@is_sortable = 1,
		@trg_report_id = '41955354-DD43-4302-8797-3D894790C35C',  --CollectServerSessions
		@href_id = @sessions2srv_sessions_hyperlink_id,
		@datasrc_textcol_name = 'cfg_sessions_start_date',
		@datasrc_textcol_type = 4,  --SqlDbType - DateTime
		@dyn_attr1_name = 'id',
		@datasrc_dynattr1_colname = 'id',
		@format = 1, --datetime
		@order_id = @order_cfg_sessions_start_date
		
	/* STATUS */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = 'Status',
		@col_unique_name = 'cfg_sessions_status_text',
		@col_width = 80,
		@col_number  = 2,
		@is_sortable = 1,
		@datasrc_col_name = 'cfg_sessions_status',
		@enumeration_id = @collect_statuses_enum_id,
		@order_id = @order_cfg_sessions_status					
									
	/* INITIATED BY */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Initiated By',
		@col_unique_name = N'cfg_sessions_initiated_by',
		@col_width  = 80,
		@col_number = 3,
		@is_sortable = 1,
		@datasrc_col_name = N'cfg_sessions_initiated_by',
		@datasrc_col_type = 12,  --SqlDbType - nvarchar
		@format = 0, --text
		@order_id = @order_cfg_sessions_initiated_by

	-- LOG				
	DECLARE @collect_log_repid uniqueidentifier
	SELECT @collect_log_repid  = '68ACF7B6-A35B-4d12-86D7-7A8C1F075EBE'

	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Log',
		@col_unique_name = N'collect_log',
		@col_width  = 70,
		@col_number = 6,
		@is_sortable = 0,
		@trg_report_id = @collect_log_repid,
		@href_id = @collect_sessions_2_log_hrefid,
		@datasrc_textcol_name = 'log',
		@datasrc_textcol_type = 12, -- nvarchar
		@dyn_attr1_name = 'session_id',
		@datasrc_dynattr1_colname = 'id',
		@format = 0 --text
		
	/************************* TASKS ****************************************************/
	/*   START COLLECTING  */
	DECLARE @start_collecting_task_id uniqueidentifier
	SELECT @start_collecting_task_id = 'A2D73F23-7DC8-4ccf-AF82-CDDFDE41B86C'

	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @start_collecting_task_id,
		@ordinal_number = 0
END
GO						
/**************************************************** DATASRC REPORT PROCEDURE  **********************************/


/********************************************************************************************************
*
*	CONFIGURATION - COLLECT SERVER SESSIONS REPORT
*
*********************************************************************************************************/
BEGIN
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '41955354-DD43-4302-8797-3D894790C35C', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
		@builder_id = @naviname_builder_id,
		@format_str = N'Session {0}',
		@query_attr_name = N'cfg_sessions_start_date'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
			@report_id = @repid,
			@unique_name = N'cfg_srv_collect_sessions',
			@display_name = N'Server Sessions',
			@datasrc_proc = N'usp.GridReport.DataSrc.Cfg.CollectServerSessions',
			@grid_report_id = @grid_repid,
			@naviname_builder_id = @naviname_builder_id

	/******************  COLUMNS ********************************************************/
	DECLARE @collect_statuses_enum_id as uniqueidentifier
	SELECT  @collect_statuses_enum_id = '5E3149C0-3BC9-4395-9F04-035EE85B1F55'

	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
		@grid_report_id = @grid_repid,				
		@col_unique_name = 'cfg_srv_sessions_status_icon',
		@col_number  = 0,				
		@datasrc_col_name = 'cfg_srv_sessions_status',
		@enumeration_id = @collect_statuses_enum_id

	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Backup Server',
		@col_unique_name = N'cfg_srv_sessions_backup_server',
		@col_width  = 100,
		@col_number = 1,
		@is_sortable = 1,
		@datasrc_col_name = N'cfg_srv_sessions_backup_server',
		@datasrc_col_type = 12,  --SqlDbType - nvarchar
		@format = 0 --text

	/* DATE TIME */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Start Time',
		@col_unique_name = N'cfg_srv_sessions_start_date',
		@col_width  = 80,
		@col_number = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'cfg_srv_sessions_start_date',
		@datasrc_col_type = 4,  --SqlDbType - DateTime
		@format = 1 --datetime

	/* STATUS */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = 'Status',
		@col_unique_name = 'cfg_srv_sessions_status_text',
		@col_width = 80,
		@col_number  = 3,
		@is_sortable = 1,
		@datasrc_col_name = 'cfg_srv_sessions_status',
		@enumeration_id = @collect_statuses_enum_id	
END
GO						
/**************************************************** DATASRC REPORT PROCEDURE  **********************************/



/********************************************************************************************************
*
*	CONTAINERS
*
*********************************************************************************************************/
BEGIN
	DECLARE @WindowContainerType as int
	DECLARE @TabContainerType as int
	DECLARE @SameContainerType as int

	SELECT  @SameContainerType = 0,
	@WindowContainerType = 1,
	@TabContainerType = 2

	/* DASHBOARD TAB (ONE DAY ) */			
	DECLARE @dashboard_day_tab_id as uniqueidentifier
	SELECT @dashboard_day_tab_id = 'EDF4009A-A72B-4a9d-A59D-2B7CF30952D0'
	       
	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @dashboard_day_tab_id, 'Last 24 hours', @TabContainerType, 0 )


	/* DASHBOARD TAB (ONE WEEK ) */							
	DECLARE @dashboard_week_tab_id as uniqueidentifier
	SELECT @dashboard_week_tab_id = '4D9F0A2A-AE17-4da6-BA59-94422EF57E58'
	       
	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @dashboard_week_tab_id, 'Last 7 days', @TabContainerType, 0 )

	/*  FIND VM TAB */
	DECLARE @findvm_tab_id as uniqueidentifier
	SELECT @findvm_tab_id = '2B556014-A0BB-4320-ADB8-1472C7BAEB59'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @findvm_tab_id, 'VMs', @TabContainerType, 0 )

	/* JOBS TAB */
	DECLARE @jobs_tab_id as uniqueidentifier
	SELECT @jobs_tab_id = '7FFD1688-B14C-4692-8EFB-45A3E9F1E45A'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required] )
	VALUES( @jobs_tab_id, 'Jobs', @TabContainerType, 0 )

	/* REPORTS */
	DECLARE @reports_tab_id as uniqueidentifier
	SELECT @reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @reports_tab_id, 'Reports', @TabContainerType, 1 )

	/* RESTORE POINTS */
	DECLARE @restore_points_wnd_id as uniqueidentifier
	SELECT @restore_points_wnd_id = 'B7B57B32-58BB-42ce-8006-4E5EDF9699D5'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @restore_points_wnd_id, 'Restore points', @WindowContainerType, 0 )

	/*  COLLECT SESSIONS */
	DECLARE @collect_sessions_tab_id as uniqueidentifier
	SELECT @collect_sessions_tab_id = 'DCD3DD62-681F-4bd2-B44C-B44A534745C2'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @collect_sessions_tab_id, 'Sessions', @TabContainerType, 0 )

	/* JOB LOG */
	DECLARE @joblog_wnd_id as uniqueidentifier
	SELECT @joblog_wnd_id = 'EAB67EF6-66D7-41a3-87E8-060FE3C8B59A'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @joblog_wnd_id, 'Job Activity', @WindowContainerType, 0 )

	/* COLLECT LOG */
	DECLARE @collectlog_wnd_id as uniqueidentifier
	SELECT @collectlog_wnd_id = '279A43A6-C1B8-4bd3-822F-22C676329DE8'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @collectlog_wnd_id, 'Log', @WindowContainerType, 0 )

END	
GO

/********************************************************************************************************
*
*	TRANSITIONS
*
*********************************************************************************************************/
BEGIN	
	DECLARE @dashboard_tab_id as uniqueidentifier
	SELECT @dashboard_tab_id = 'EDF4009A-A72B-4a9d-A59D-2B7CF30952D0'
	DECLARE @findvm_tab_id as uniqueidentifier
	SELECT @findvm_tab_id = '2B556014-A0BB-4320-ADB8-1472C7BAEB59'
	DECLARE @jobs_tab_id as uniqueidentifier
	SELECT @jobs_tab_id = '7FFD1688-B14C-4692-8EFB-45A3E9F1E45A'
	DECLARE @reports_tab_id as uniqueidentifier
	SELECT @reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'
	DECLARE @restore_points_wnd_id as uniqueidentifier
	SELECT @restore_points_wnd_id = 'B7B57B32-58BB-42ce-8006-4E5EDF9699D5'
	DECLARE @joblog_wnd_id as uniqueidentifier
	SELECT @joblog_wnd_id = 'EAB67EF6-66D7-41a3-87E8-060FE3C8B59A'
	DECLARE @collectlog_wnd_id as uniqueidentifier
	SELECT @collectlog_wnd_id = '279A43A6-C1B8-4bd3-822F-22C676329DE8'

	/*   BSESSION -> ALL BSESSIONS  */
	DECLARE @bsession_2_allbsessions_hyperlink_id  uniqueidentifier
	SELECT  @bsession_2_allbsessions_hyperlink_id = 'A41D0A9C-DEC3-49f5-B66B-323DD968FC7E'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @bsession_2_allbsessions_hyperlink_id, @reports_tab_id )

	/*   BSESSION -> BACKUP SERVER  */
	DECLARE @bsession_2_bserver_hyperlink_id as uniqueidentifier
	SELECT  @bsession_2_bserver_hyperlink_id = '127F901F-318E-401d-A824-E36508E6917E'


	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @bsession_2_bserver_hyperlink_id, @reports_tab_id )


	/*    JOBS MGMT -> LAST COMPLETED SESSION */
	DECLARE @bjob_2_last_completesession_hrefid uniqueidentifier		
	SELECT @bjob_2_last_completesession_hrefid = '153B2A2B-6BBD-4080-B203-6B96A6605BFB'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @jobs_tab_id, @bjob_2_last_completesession_hrefid, @reports_tab_id )

	/*    SERVERS -> JOBS */
	DECLARE @srv2jobs_hyperlink_id as uniqueidentifier
	SELECT @srv2jobs_hyperlink_id = 'CB7499CE-DD2A-4e25-9F8B-3FCB4B8DE0D7'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @srv2jobs_hyperlink_id, @reports_tab_id )


	/*    VM -> RESTORE POINTS */
	DECLARE @vm_2_restorepoint_hrefid uniqueidentifier		
	SELECT @vm_2_restorepoint_hrefid = '8FED9947-E958-410c-A859-79EABC73A8E9'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @findvm_tab_id, @vm_2_restorepoint_hrefid, @restore_points_wnd_id )			


	/*    JOBS -> ALL SESSIONS*/
	DECLARE @job2all_sessions_hyperlink_id as uniqueidentifier
	SELECT @job2all_sessions_hyperlink_id = 'DF3ACC9E-348D-453f-AB4A-22C4B15A15B5'
			
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @job2all_sessions_hyperlink_id, @reports_tab_id )


	/*    JOBS -> LAST SESSION*/
	DECLARE @job2last_session_hyperlink_id as uniqueidentifier
	SELECT @job2last_session_hyperlink_id = '510B2668-9394-4f86-AB67-34B4C62D2FF8'


	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @job2last_session_hyperlink_id, @reports_tab_id )

	/*   JOBS SESSIONS -> CONCRETE SESSION */
	DECLARE @jobsession_2_vmsession_hyperlink_id as uniqueidentifier
	SELECT @jobsession_2_vmsession_hyperlink_id = '4EBB8F5F-3FFC-41c4-B740-83BE73640D0A'
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @jobsession_2_vmsession_hyperlink_id, @reports_tab_id )

	/*  VM -> ALL VM SESSIONS */
	DECLARE @vm_2_vmsessions_hyperlink_id as uniqueidentifier
	SELECT @vm_2_vmsessions_hyperlink_id = 'DB20115E-2743-4756-9137-13AECBF7ACC8'
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @vm_2_vmsessions_hyperlink_id, @reports_tab_id )

	/*  VM SESSION -> JOB SESSION */
	DECLARE @vmsession_2_jobsessions_hyperlink_id as uniqueidentifier
	SELECT @vmsession_2_jobsessions_hyperlink_id = 'DF63AD74-63E0-4026-8A0A-64D2CDD73222'
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @vmsession_2_jobsessions_hyperlink_id, @reports_tab_id )

	/*    COLLECT SESSIONS -> SERVER COLLECT SESSIONS */
	DECLARE @sessions2srv_sessions_hyperlink_id as uniqueidentifier
	SELECT @sessions2srv_sessions_hyperlink_id = 'CBE8B587-A965-4d3b-AAC2-EFFF66513FC8'	

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	--VALUES( NEWID(), @reports_tab_id, @sessions2srv_sessions_hyperlink_id, @reports_tab_id )	
	VALUES( NEWID(), 'DCD3DD62-681F-4bd2-B44C-B44A534745C2', @sessions2srv_sessions_hyperlink_id, 'DCD3DD62-681F-4bd2-B44C-B44A534745C2' )

	/*    JOBS MGMT -> JOB LOG */
	DECLARE @bjob_2_joblog_hrefid uniqueidentifier
	SELECT @bjob_2_joblog_hrefid = '27686973-22FF-4875-8023-F591A19DC6EA'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @jobs_tab_id, @bjob_2_joblog_hrefid, @joblog_wnd_id )

	--    COLLECT SESSIONS -> LOG
	DECLARE @collect_sessions_2_log_hrefid uniqueidentifier
	SELECT @collect_sessions_2_log_hrefid = 'C517669B-B21E-43a2-81DC-520C5D134AAE'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), 'DCD3DD62-681F-4bd2-B44C-B44A534745C2', @collect_sessions_2_log_hrefid, @collectlog_wnd_id )

	/*    CURRENT JOBS -> ALL SESSIONS*/
	DECLARE @curjobs_2_all_sessions_hrefid as uniqueidentifier
	SELECT @curjobs_2_all_sessions_hrefid = 'DDA425A3-B6C0-4cde-B7D9-D167DE0BD031'
			
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @jobs_tab_id, @curjobs_2_all_sessions_hrefid, @reports_tab_id )

	--  VMs -> ALL VM SESSIONS
	DECLARE @vms_2_vmsessions_hyperlink_id as uniqueidentifier
	SELECT @vms_2_vmsessions_hyperlink_id = '453D47EA-3255-443b-A8AF-B2142A2492DC'
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @findvm_tab_id, @vms_2_vmsessions_hyperlink_id, @reports_tab_id )

END
GO
-----------------------------------------------------










-----------------------------------------------------
--
BEGIN	
	/*   PAGES  */
	DECLARE @dashboard_day_tab_id as uniqueidentifier
	SELECT @dashboard_day_tab_id = 'EDF4009A-A72B-4a9d-A59D-2B7CF30952D0'			
	DECLARE @dashboard_week_tab_id as uniqueidentifier
	SELECT @dashboard_week_tab_id = '4D9F0A2A-AE17-4da6-BA59-94422EF57E58'

	DECLARE @findvm_tab_id as uniqueidentifier
	SELECT @findvm_tab_id = '2B556014-A0BB-4320-ADB8-1472C7BAEB59'		
	DECLARE @jobs_tab_id as uniqueidentifier
	SELECT @jobs_tab_id = '7FFD1688-B14C-4692-8EFB-45A3E9F1E45A'
	DECLARE @reports_tab_id as uniqueidentifier
	SELECT @reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'

	/* REPORTS */
	DECLARE @dashboard_report_id as uniqueidentifier
	SELECT @dashboard_report_id = 'F3749311-9C91-4d89-8BF7-2F53EC171374'
	DECLARE @currentjobs_report_id as uniqueidentifier
	SELECT @currentjobs_report_id = '923FA20C-E6F7-4de7-AB69-BA006707AF78'
	DECLARE @findvm_report_id as uniqueidentifier 
	SELECT @findvm_report_id = 'A672891E-C13C-481a-A7AE-C22E54E1D4E2'
	DECLARE @backupsrv_report_id as uniqueidentifier
	SELECT @backupsrv_report_id = 'ED83A1E2-632E-4d81-B112-7FFE60336F10'


	/* DASHBOARD PAGE (ONE DAY)  */	
	EXEC [dbo].[usp.Startup.RegInitialReportPageWithAttr]
	@page_id = @dashboard_day_tab_id,
	@report_id = @dashboard_report_id,
	@ordinal_number = 1,
	@attr_name = N'period',
	@attr_value = 24

	/* DASHBOARD PAGE  ( ONE WEEK)*/	
	EXEC [dbo].[usp.Startup.RegInitialReportPageWithAttr]
	@page_id = @dashboard_week_tab_id,
	@report_id = @dashboard_report_id,
	@ordinal_number = 2,
	@attr_name = N'period',
	@attr_value = 168

	/* JOBS PAGE  */	
	EXEC [dbo].[usp.Startup.RegInitialReportPage]
	@page_id = @jobs_tab_id,
	@report_id = @currentjobs_report_id,
	@ordinal_number = 3			
			
	/* FIND VM PAGE */
	EXEC [dbo].[usp.Startup.RegInitialReportPage]
		@page_id = @findvm_tab_id,
		@report_id = @findvm_report_id,
		@ordinal_number = 4
						
	/* REPORTS PAGE */
	EXEC [dbo].[usp.Startup.RegInitialReportPage]
		@page_id = @reports_tab_id,
		@report_id = @backupsrv_report_id,
		@ordinal_number = 5
														
END
GO
-----------------------------------------------------



-----------------------------------------------------
--
EXEC [dbo].[usp.Config.Scheduler.CreateSettings] 'D87CDAF7-483E-4128-B7C6-2C4A11CFE4EF', 1, 900, 0
GO
-----------------------------------------------------



-----------------------------------------------------
--
INSERT INTO [dbo].[Version] ([current_version]) VALUES( 64 )
GO
-----------------------------------------------------

