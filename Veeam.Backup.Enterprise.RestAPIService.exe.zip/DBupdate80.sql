IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1205 AND current_version < 1251)
BEGIN
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_tape_medium_from_catalogue]') AND type in (N'P', N'PC'))
	BEGIN
		DECLARE @id uniqueidentifier

		DECLARE c CURSOR FOR
			SELECT
				t.id
			FROM
				[Tape.tape_mediums] t
				INNER JOIN [Tape.media_pools] m ON t.media_pool_id = m.id
			WHERE
				NOT EXISTS(SELECT * FROM [Tape.libraries] l WHERE l.id = m.library_id)

		OPEN c

		WHILE 1 = 1
		BEGIN
			FETCH NEXT FROM c INTO @id
			IF (@@FETCH_STATUS <> 0)
				BREAK

			PRINT 'Deleting tape medium ' + cast(@id as nvarchar(max)) + ' from catalogue'
			EXEC [Tape.delete_tape_medium_from_catalogue] @tape_medium_id = @id
			DELETE FROM [Tape.tape_mediums] WHERE id = @id
		END

		CLOSE c
		DEALLOCATE c
	END

	BEGIN TRY
		DELETE FROM [dbo].[Tape.media_pools]
		WHERE
		NOT EXISTS(SELECT 1 FROM [dbo].[Tape.libraries] l WHERE l.id = library_id)
	END TRY

	BEGIN CATCH
		DECLARE @error_message nvarchar(4000)
		DECLARE @error_severity int
		DECLARE @error_state int

		SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY(), @error_state = ERROR_STATE()

		SET @error_message = 'Invalid configuration of tape infrastructure. Please contact Veeam Support. ' + @error_message

		RAISERROR (@error_message, @error_severity, @error_state)
	END CATCH

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1251; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1251)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeLUNs]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.SanVolumeLUNs](
			 [id] [uniqueidentifier] NOT NULL,
			 [volume_id] [uniqueidentifier] NOT NULL,
			 [name] [nvarchar](255) NOT NULL,
			 [internal_id] [nvarchar](255) NOT NULL,
			 [size] bigint NOT NULL,		 
			 [aux_data] xml		 
			 CONSTRAINT [PK_Backup.SanVolumeLUNs] PRIMARY KEY CLUSTERED 
			(
			 [id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		
			print 'Table [dbo].[Backup.Model.SanVolumeLUNs] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1252; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1252)
BEGIN
	exec sp_executesql @statement = N'
		DECLARE 
			@volume_id uniqueidentifier, 
			@volume_name [nvarchar](255), 
			@volume_size bigint,
			@volume_internal_id [nvarchar](255)
 
		DECLARE sanvolumes_cursor CURSOR FOR
		SELECT DISTINCT [id] FROM [dbo].[Backup.Model.SanVolumes]	
	
		OPEN sanvolumes_cursor
		FETCH NEXT FROM sanvolumes_cursor INTO @volume_id
	
		WHILE @@FETCH_STATUS = 0
		BEGIN
		   SELECT @volume_name  = [name], @volume_size = [size], @volume_internal_id = [internal_id] FROM [dbo].[Backup.Model.SanVolumes] WHERE [id] = @volume_id	
		   		   
		   INSERT INTO
				[dbo].[Backup.Model.SanVolumeLUNs]		   
				([id], [volume_id], [name], [internal_id], [size], [aux_data] )
			VALUES
				(NEWID(), @volume_id, @volume_name, @volume_internal_id, @volume_size, null);
	   
		   FETCH NEXT FROM sanvolumes_cursor INTO @volume_id
		END

		CLOSE sanvolumes_cursor
		DEALLOCATE sanvolumes_cursor
		print ''Filling dbo.Backup.Model.SanVolumeLUNs for existing volumes has been successfully completed''
		'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1253; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1253)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotLUNs]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.SanSnapshotLUNs](
			 [id] [uniqueidentifier] NOT NULL,
			 [snapshot_id] [uniqueidentifier] NOT NULL,
			 [volume_lun_id] [uniqueidentifier],
			 [name] [nvarchar](255) NOT NULL,
			 [internal_id] [nvarchar](255) NOT NULL,
			 [indexed] int NOT NULL,		 
			 [vmfs_version] int NOT NULL,		 
			 [aux_data] xml		 
			 CONSTRAINT [PK_Backup.SanSnapshotLUNs] PRIMARY KEY CLUSTERED 
			(
			 [id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		
			print 'Table [dbo].[Backup.Model.SanSnapshotLUNs] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1254; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1254)
BEGIN
	exec sp_executesql @statement = N'
		DECLARE 
			@snapshot_id uniqueidentifier, 
			@snapshot_name [nvarchar](255), 			
			@snapshot_internal_id [nvarchar](255),
			@snapshot_indexed int,
			@snapshot_vmfs_version int,
			@volume_id uniqueidentifier,
			@volume_lun_id uniqueidentifier
 
		DECLARE sansnapshots_cursor CURSOR FOR
		SELECT DISTINCT [id] FROM [dbo].[Backup.Model.SanSnapshots]	
	
		OPEN sansnapshots_cursor
		FETCH NEXT FROM sansnapshots_cursor INTO @snapshot_id
	
		WHILE @@FETCH_STATUS = 0
		BEGIN
		   SELECT @snapshot_name  = [name], @snapshot_internal_id = [internal_id], @snapshot_indexed = [indexed], @snapshot_vmfs_version = [vmfs_version], @volume_id = [volume_id]
				FROM [dbo].[Backup.Model.SanSnapshots] WHERE [id] = @snapshot_id
				
		   SELECT @volume_lun_id = [id] 
				FROM [dbo].[Backup.Model.SanVolumeLUNs] WHERE [volume_id] = @volume_id
		   		   
		   INSERT INTO
				[dbo].[Backup.Model.SanSnapshotLUNs]		   
				([id], [snapshot_id], [volume_lun_id], [name], [internal_id], [indexed], [vmfs_version], [aux_data] )
			VALUES
				(NEWID(), @snapshot_id, @volume_lun_id, @snapshot_name, @snapshot_internal_id, @snapshot_indexed, @snapshot_vmfs_version, null);
	   
		   FETCH NEXT FROM sansnapshots_cursor INTO @snapshot_id
		END

		CLOSE sansnapshots_cursor
		DEALLOCATE sansnapshots_cursor
		print ''Filling dbo.Backup.Model.SanSnapshotLUNs for existing snapshots has been successfully completed''	
		'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1255; END
END
GO
		
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1255)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeExportInfos]') AND [name] = 'volume_lun_id')
	BEGIN		
		alter table [dbo].[Backup.Model.SanVolumeExportInfos] add volume_lun_id uniqueidentifier
		print 'New column {volume_lun_id} has been successfully added to [dbo].[Backup.Model.SanVolumeExportInfos] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1256; END
END
GO

	
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1256)
BEGIN	
	exec sp_executesql @statement = N'	
		UPDATE 
			[dbo].[Backup.Model.SanVolumeExportInfos]
		SET 
			[volume_lun_id] = LUNs.id
		FROM (
				SELECT [id], [volume_id] 
				FROM [dbo].[Backup.Model.SanVolumeLUNs]
			) AS LUNs
		WHERE 
			[dbo].[Backup.Model.SanVolumeExportInfos].volume_id = LUNs.volume_id
	
		print ''Updating volume_lun_id on table [dbo].[Backup.Model.SanVolumeExportInfos]''
		'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1257; END
END
GO
	
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1257)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotStorages]') AND [name] = 'snapshot_lun_id')
	BEGIN		
		alter table [dbo].[Backup.Model.SanSnapshotStorages] add snapshot_lun_id uniqueidentifier
		print 'New column {snapshot_lun_id} has been successfully added to [dbo].[Backup.Model.SanSnapshotStorages] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1258; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1258)
BEGIN	

	exec sp_executesql @statement = N'	
		UPDATE 
			[dbo].[Backup.Model.SanSnapshotStorages] 
		SET 
			[snapshot_lun_id] = LUNs.id
		FROM (
				SELECT [id], [snapshot_id] 
				FROM [dbo].[Backup.Model.SanSnapshotLUNs]
			) AS LUNs
		WHERE 
			[dbo].[Backup.Model.SanSnapshotStorages].snapshot_id = LUNs.snapshot_id
	
		print ''Updating snapshot_lun_id on table [dbo].[Backup.Model.SanSnapshotStorages]''
		'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1259; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1259 and current_version < 1261)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1261; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1261 and current_version < 1262)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReplicaDiskTransferState]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[ReplicaDiskTransferState](
			[id] UNIQUEIDENTIFIER NOT NULL,
			[job_id] UNIQUEIDENTIFIER NOT NULL,
			[obj_id] UNIQUEIDENTIFIER NOT NULL,
			[disk_id] NVARCHAR(512) NOT NULL,
			[snap_ref] NVARCHAR(512) NOT NULL,
			[source_wan] NVARCHAR(512) NULL,
			[target_wan] NVARCHAR(512) NULL,
			[disk_info] XML
			CONSTRAINT [PK_ReplicaDiskTransferState] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		print 'Table [dbo].[ReplicaDiskTransferState] has been successfully created'

	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1262; END	
END		
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1262 and current_version < 1264)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1264; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1264 and current_version < 1265)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReplicaDiskTransferState]') AND [name] = 'num')
	BEGIN		
		alter table [dbo].[ReplicaDiskTransferState] add num bigint IDENTITY(1,1) NOT NULL
		print 'New column {num} has been successfully added to [dbo].[ReplicaDiskTransferState] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1265; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1265)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobVssCredentials]') AND [name] = 'ssh_creds_id')
	BEGIN
		ALTER TABLE [dbo].[JobVssCredentials] ADD [ssh_creds_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {ssh_creds_id} has been successfully added to [dbo].[JobVssCredentials] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1266; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1266 and current_version < 1268)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1268; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1268)
BEGIN

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobVssCredentials]') AND [name] = 'credentials_id')
	BEGIN
		exec sp_rename '[dbo].[JobVssCredentials].[credentials_id]', 'win_creds_id', 'COLUMN'
		PRINT 'Column [dbo].[JobVssCredentials].[credentials_id] has been successfully rename to [dbo].[JobVssCredentials].[win_creds_id]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobVssCredentials]') AND [name] = 'ssh_creds_id')
	BEGIN
		exec sp_rename '[dbo].[JobVssCredentials].[ssh_creds_id]', 'lin_creds_id', 'COLUMN'
		PRINT 'Column [dbo].[JobVssCredentials].[ssh_creds_id] has been successfully rename to [JobVssCredentials].[lin_creds_id]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1269; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1269)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.devices]') AND [name] = 'tape_server_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.devices] ADD [tape_server_id] uniqueidentifier NULL
		print 'New column {tape_server_id} has been successfully added to [dbo].[Tape.devices] table'		
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.libraries]') AND [name] = 'tape_server_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.libraries] ADD [tape_server_id] uniqueidentifier NULL
		print 'New column {tape_server_id} has been successfully added to [dbo].[Tape.libraries] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1270; END
END
GO

-- Adding storage_crypto_key and meta_crypto_key fields for storage
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1270 AND current_version < 1277)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1277; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1277)
BEGIN

	DECLARE @constr sysname	;
		
	SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.SanVolumes]') and [name] = 'san_type')
	IF (@constr IS NOT NULL)
	BEGIN		
		DECLARE @statement NVARCHAR(255);					
		SET @statement = N'ALTER TABLE [dbo].[Backup.Model.SanVolumes] DROP CONSTRAINT [' + @constr + ']'		
		exec sp_executesql @statement
		PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.SanVolumes]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumes]') AND ([name] = 'san_type'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumes]
		DROP COLUMN [san_type]
		PRINT 'Columns [san_type] was successfully removed from [dbo].[Backup.Model.SanVolumes]'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1278; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1278)
BEGIN
		
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumes]') AND ([name] = 'iqn_or_wwn'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumes]
		DROP COLUMN [iqn_or_wwn]
		PRINT 'Columns [iqn_or_wwn] was successfully removed from [dbo].[Backup.Model.SanVolumes]'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1279; END
END
GO

-- Alter incorrect trigger
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1279)
BEGIN
	exec sp_executesql @stat = N'ALTER trigger [dbo].[d_Backup_Model_BackupTaskSessions] on [dbo].[Backup.Model.BackupTaskSessions] for delete 
	as 	begin  
		declare @id uniqueidentifier
		declare delEnumerator cursor
			for select id from deleted
			
		open delEnumerator
		fetch next from delEnumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''Backup.Model.BackupTaskSessions'', @id, 2
		  fetch next from delEnumerator into @id
		end
			
		close delEnumerator
		deallocate delEnumerator
	end'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1280; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1280)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeLUNs]') AND [name] = 'type')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumeLUNs] ADD [type] int DEFAULT 0 NOT NULL
		print 'New column {type} has been successfully added to [dbo].[Backup.Model.SanVolumeLUNs] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1281; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1281 and current_version < 1282)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1282; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1282)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HostCreds]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[HostCreds] 
		(
			[id] uniqueidentifier NOT NULL CONSTRAINT [DF_HostCreds_id]  DEFAULT (newid()),
			[host_id] uniqueidentifier NOT NULL,
			[lin_creds_id] uniqueidentifier NULL,
			[ssh_enabled] bit NULL,
			[ssh_startftport] int NULL,
			[ssh_endftport] int NULL,
			[ssh_buffersize] int NULL,
			[ssh_isftserver] bit NULL,
			[ssh_timeout] int NULL,
			[ssh_adjust_firewall] bit NULL,
			[usn] bigint NOT NULL DEFAULT 0
			
			CONSTRAINT [PK_HostCreds] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		
		) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1283; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1283)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[HostCreds]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''HostCreds''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1284; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1284)
BEGIN	
	exec sp_executesql @stat = N'
	PRINT N''Starting moving information about SSH creds for hosts''
	DECLARE @host_id uniqueidentifier
	DECLARE @ssh_enabled bit
	DECLARE @lin_creds_id uniqueidentifier
	DECLARE @ssh_startftport int
    DECLARE @ssh_endftport int
    DECLARE @ssh_buffersize int
    DECLARE @ssh_isftserver bit
    DECLARE @ssh_timeout int
	DECLARE @ssh_adjust_firewall bit
	
	DECLARE ssh_cursor CURSOR FOR
	SELECT 
		sshCreds.[host_id],
		sshCreds.[creds],
		sshCreds.[enabled],
		sshCreds.[startftport],
		sshCreds.[endftport],
		sshCreds.[buffersize],
		sshCreds.[isftserver],
		sshCreds.[timeout],
		sshCreds.[adjust_firewall]
	FROM
		[dbo].[Ssh_creds] sshCreds
	WHERE
		sshCreds.[host_id] <> N''00000000-0000-0000-0000-000000000000'' AND sshCreds.[creds] <> N''00000000-0000-0000-0000-000000000000''
		
	OPEN ssh_cursor
	FETCH NEXT FROM ssh_cursor INTO @host_id, @lin_creds_id, @ssh_enabled, @ssh_startftport, @ssh_endftport, @ssh_buffersize, @ssh_isftserver, @ssh_timeout, @ssh_adjust_firewall
	WHILE @@FETCH_STATUS = 0
	BEGIN
		PRINT N''Starting moving information about SSH creds for host '' + convert(nvarchar(50), @host_id)
   		INSERT INTO	[dbo].[HostCreds] 
			([host_id]
			,[lin_creds_id]
			,[ssh_enabled] 
			,[ssh_startftport]
			,[ssh_endftport]
			,[ssh_buffersize]
			,[ssh_isftserver]
			,[ssh_timeout]
			,[ssh_adjust_firewall])
		VALUES
			(@host_id
			,@lin_creds_id
			,@ssh_enabled
			,@ssh_startftport
			,@ssh_endftport
			,@ssh_buffersize
			,@ssh_isftserver
			,@ssh_timeout
			,@ssh_adjust_firewall)

		FETCH NEXT FROM ssh_cursor INTO @host_id, @lin_creds_id, @ssh_enabled, @ssh_startftport, @ssh_endftport, @ssh_buffersize, @ssh_isftserver, @ssh_timeout, @ssh_adjust_firewall
	END

	CLOSE ssh_cursor;
	DEALLOCATE ssh_cursor;
	'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1285; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1285)
BEGIN

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND [name] = 'host_id')
	BEGIN
		ALTER TABLE [dbo].[Ssh_creds]
		DROP COLUMN [host_id]
		print 'Column {host_id} has been successfully removed to [dbo].[Ssh_creds] table'	
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND [name] = 'savepassword')
	BEGIN
		ALTER TABLE [dbo].[Ssh_creds]
		DROP COLUMN [savepassword]
		print 'Column {savepassword} has been successfully removed to [dbo].[Ssh_creds] table'	
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1286; END
END
GO
		
-- Drop uuid from HostsByJobs & LicensedHosts
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1286 and current_version < 1289)
BEGIN

	-- Clearing LicensedHosts
	delete from [dbo].[LicensedHosts]
	print 'All entries has been successfully removed from [dbo].[LicensedHosts] table'

	-- Drop uuid from HostsByJobs
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostsByJobs]') AND [name] = 'uuid')
	BEGIN		
		alter table [dbo].[HostsByJobs] drop column uuid
		print 'Column {uuid} has been successfully removed from [dbo].[HostsByJobs] table'
	END

	-- Drop uuid from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND [name] = 'uuid')
	BEGIN		
		alter table [dbo].[LicensedHosts] drop column uuid
		print 'Column {uuid} has been successfully removed from [dbo].[LicensedHosts] table'
	END

	-- Drop name from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND [name] = 'name')
	BEGIN		
		alter table [dbo].[LicensedHosts] drop column name
		print 'Column {name} has been successfully removed from [dbo].[LicensedHosts] table'
	END

	-- Drop cpu from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND [name] = 'cpu')
	BEGIN		
		alter table [dbo].[LicensedHosts] drop column cpu
		print 'Column {cpu} has been successfully removed from [dbo].[LicensedHosts] table'
	END

	-- Drop cores constraint from LicensedHosts
	DECLARE @constr sysname;
	SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[LicensedHosts]') and [name] = 'cores')
	IF (@constr IS NOT NULL)
	BEGIN		
		DECLARE @statement NVARCHAR(255);					
		SET @statement = N'ALTER TABLE [dbo].[LicensedHosts] DROP CONSTRAINT [' + @constr + ']'		
		exec sp_executesql @statement
		PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[LicensedHosts]'
	END

	-- Drop cores from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND [name] = 'cores')
	BEGIN
		alter table [dbo].[LicensedHosts] drop column cores
		print 'Column {cores} has been successfully removed from [dbo].[LicensedHosts] table'
	END

	-- Add physical_host_id to LicensedHosts
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND [name] = 'physical_host_id')
	BEGIN		
		alter table [dbo].[LicensedHosts] add physical_host_id uniqueidentifier NOT NULL
		print 'New column {physical_host_id} has been successfully added to [dbo].[LicensedHosts] table'
	END
	
	-- Add physical_host_id index to Hosts
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Hosts_PhysicalHostId' AND object_id = OBJECT_ID('Hosts'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Hosts_PhysicalHostId] ON [dbo].[Hosts]
		(
			[physical_host_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_Hosts_PhysicalHostId} has been successfully added to [dbo].[Hosts] table'
	END
	
	-- Add physical_host_id index to LicensedHosts
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_LicensedHosts_PhysicalHostId' AND object_id = OBJECT_ID('LicensedHosts'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_LicensedHosts_PhysicalHostId] ON [dbo].[LicensedHosts]
		(
			[physical_host_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_LicensedHosts_PhysicalHostId} has been successfully added to [dbo].[LicensedHosts] table'
	END
	
	-- Add host_id index to HostsByJobs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_HostsByJobs_HostId' AND object_id = OBJECT_ID('HostsByJobs'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_HostsByJobs_HostId] ON [dbo].[HostsByJobs]
		(
			[host_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_HostsByJobs_HostId} has been successfully added to [dbo].[HostsByJobs] table'
	END
	
	-- Alter LicensedHosts insert trigger
	exec sp_executesql @stat = N'ALTER trigger [dbo].[i_LicensedHosts] on [dbo].[LicensedHosts] for insert 
	as 	begin  
		declare @id uniqueidentifier
		declare enumerator cursor LOCAL
			for select id from inserted
			
		open enumerator
		fetch next from enumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''LicensedHosts'', @id, 0
		  fetch next from enumerator into @id
		end
			
		close enumerator
		deallocate enumerator
	end'
	print 'Trigger [dbo].[LicensedHosts].{i_LicensedHosts} has been successfully changed'

	-- Alter LicensedHosts update trigger
	exec sp_executesql @stat = N'ALTER trigger [dbo].[u_LicensedHosts] on [dbo].[LicensedHosts] for update 
	as 	begin  
		declare @id uniqueidentifier
		declare enumerator cursor LOCAL
			for select id from inserted
			
		open enumerator
		fetch next from enumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''LicensedHosts'', @id, 1
		  fetch next from enumerator into @id
		end
			
		close enumerator
		deallocate enumerator
	end'
	print 'Trigger [dbo].[LicensedHosts].{u_LicensedHosts} has been successfully changed'

	-- Alter LicensedHosts delete trigger
	exec sp_executesql @stat = N'ALTER trigger [dbo].[d_LicensedHosts] on [dbo].[LicensedHosts] for delete 
	as 	begin
		declare @id uniqueidentifier
		declare enumerator cursor LOCAL
			for select id from deleted
			
		open enumerator
		fetch next from enumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''LicensedHosts'', @id, 2
		  fetch next from enumerator into @id
		end
		
		if exists (select 1 from deleted)
		BEGIN
			delete hostsByJobs from [dbo].[HostsByJobs] 
				left join [dbo].[Hosts] hosts on hosts.id = HostsByJobs.host_id
				left join [dbo].[PhysicalHosts] physicalHosts on physicalHosts.id = hosts.physical_host_id
				right join [dbo].[LicensedHosts] licensedHosts on licensedHosts.physical_host_id = physicalHosts.id
				right join deleted del on del.id = licensedHosts.id
		END
			
		close enumerator
		deallocate enumerator
	end'
	print 'Trigger [dbo].[LicensedHosts].{d_LicensedHosts} has been successfully changed'

	-- Alter HostsByJobs insert trigger
	exec sp_executesql @stat = N'ALTER trigger [dbo].[i_HostsByJobs] on [dbo].[HostsByJobs] for insert 
	as 	begin  
		declare @id uniqueidentifier
		declare enumerator cursor LOCAL
			for select id from inserted
			
		open enumerator
		fetch next from enumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''HostsByJobs'', @id, 0
		  fetch next from enumerator into @id
		end
			
		close enumerator
		deallocate enumerator
	end'
	print 'Trigger [dbo].[LicensedHosts].{i_HostsByJobs} has been successfully changed'

	-- Alter HostsByJobs update trigger
	exec sp_executesql @stat = N'ALTER trigger [dbo].[u_HostsByJobs] on [dbo].[HostsByJobs] for update 
	as 	begin  
		declare @id uniqueidentifier
		declare enumerator cursor LOCAL
			for select id from inserted
			
		open enumerator
		fetch next from enumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''HostsByJobs'', @id, 1
		  fetch next from enumerator into @id
		end
			
		close enumerator
		deallocate enumerator
	end'
	print 'Trigger [dbo].[LicensedHosts].{u_HostsByJobs} has been successfully changed'

	-- Alter HostsByJobs delete trigger
	exec sp_executesql @stat = N'ALTER trigger [dbo].[d_HostsByJobs] on [dbo].[HostsByJobs] for delete 
	as 	begin  
		declare @id uniqueidentifier
		declare enumerator cursor LOCAL
			for select id from deleted
			
		open enumerator
		fetch next from enumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''HostsByJobs'', @id, 2
		  fetch next from enumerator into @id
		end

		if exists (select 1 from deleted)
BEGIN
			delete licensedHosts from [dbo].[LicensedHosts] 
				left join [dbo].[PhysicalHosts] physicalHosts on physicalHosts.id = licensedHosts.physical_host_id
				left join [dbo].[Hosts] hosts on hosts.physical_host_id = physicalHosts.id
				right join deleted on deleted.[host_id] = hosts.id
				where hosts.id not in (select host_id from [dbo].[HostsByJobs])
		END

		close enumerator
		deallocate enumerator
	end'
	print 'Trigger [dbo].[LicensedHosts].{d_HostsByJobs} has been successfully changed'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1289; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1289 and current_version < 1290)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1290; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1290)
BEGIN
	PRINT 'Deleting duplicates and invalid records from Ssh_creds'
	DELETE FROM [dbo].[Ssh_creds] WHERE [creds] = '00000000-0000-0000-0000-000000000000' OR [creds] IS NULL
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1291; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1291 and current_version < 1292)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1292; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1292)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CryptoKeys]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[CryptoKeys](
				[id] [uniqueidentifier] NOT NULL,
				[key_set_id] [varbinary](20) NOT NULL,
				[key_type] [int] NOT NULL,
				[key_value] [varbinary](max) NOT NULL,
				[hint] [nvarchar](max) NULL,
			 CONSTRAINT [PK_CryptoKeys] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [IX_CryptoKeys_key_set_id] ON [dbo].[CryptoKeys] 
		(
			[key_set_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]


	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1293; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1293)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'pwd_key_id')
	BEGIN		
		alter table [dbo].[BJobs] add pwd_key_id uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {pwd_key_id} has been successfully added to [dbo].[BJobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1294; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1294)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'storage_key_id')
	BEGIN		
		alter table [dbo].[Backup.Model.Storages] add storage_key_id uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {storage_key_id} has been successfully added to [dbo].[Backup.Model.Storages] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'meta_key_id')
	BEGIN		
		alter table [dbo].[Backup.Model.Storages] add meta_key_id uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {meta_key_id} has been successfully added to [dbo].[Backup.Model.Storages] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1295; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1295)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[CryptoKeys]') AND [name] = 'date')
	BEGIN		
		alter table [dbo].[CryptoKeys] add [date] datetime not null DEFAULT (GETUTCDATE())
		print 'New column {[date]} has been successfully added to [dbo].[CryptoKeys] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1296; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1296)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.GuestDatabase](
				[id] [uniqueidentifier] NOT NULL,
				[obj_id] [uniqueidentifier] NOT NULL,
				[server_name] [nvarchar](1000) NOT NULL,
				[db_instance] [nvarchar](max) NOT NULL,
				[db_name] [nvarchar](max) NOT NULL
			 CONSTRAINT [PK_GuestDatabase] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.SqlOIBs](
				[id] [uniqueidentifier] NOT NULL,
				[guest_db_id] [uniqueidentifier] NOT NULL,
				[oib_id] [uniqueidentifier] NOT NULL,
				[stg_id] [uniqueidentifier] NOT NULL,				
				[inside_dir] [nvarchar](400) default 'empty' NOT NULL,
				[creation_time] [datetime] DEFAULT (GETDATE()) NOT NULL,
				[guest_creation_time] [datetime] DEFAULT (GETDATE()) NOT NULL,
				[first_LSN] [nvarchar](25) NOT NULL,
				[last_LSN] [nvarchar](25) NOT NULL
			 CONSTRAINT [PK_SqlOIBs] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			ALTER TABLE [dbo].[Backup.Model.SqlOIBs] WITH CHECK ADD CONSTRAINT [FK_SqlOIBs.guest_db_id] FOREIGN KEY([guest_db_id])
			REFERENCES [dbo].[Backup.Model.GuestDatabase] ([id])

			ALTER TABLE [dbo].[Backup.Model.SqlOIBs] WITH CHECK ADD CONSTRAINT [FK_SqlOIBs.stg_id] FOREIGN KEY([stg_id])
			REFERENCES [dbo].[Backup.Model.Storages] ([id])

	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1297; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1297 and current_version < 1298)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1298; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1298)
BEGIN
		IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'table')
		BEGIN
			EXEC sp_rename
			@objname = '[dbo].[Backup.Model.GuestDatabase].table',
			@newname = 'db_name',
			@objtype = 'COLUMN' 
		END

		IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'vm_name')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.SqlOIBs] DROP COLUMN vm_name 
		END
		
		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1299; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1299)
BEGIN

	IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_SqlOIBs.oib_id]') AND parent_object_id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]'))
	BEGIN
		ALTER TABLE [Backup.Model.SqlOIBs] DROP CONSTRAINT [FK_SqlOIBs.oib_id]

		PRINT 'Old foreign key [FK_SqlOIBs.oib_id] has been successfully dropped in [Backup.Model.SqlOIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1300; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1300)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[CryptoKeys]') AND [name] = 'crypto_alg')
	BEGIN		
		alter table [dbo].[CryptoKeys] add [crypto_alg] int not null DEFAULT (1)
		print 'New column {[crypto_alg]} has been successfully added to [dbo].[CryptoKeys] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1301; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1301)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_pools]') AND [name] = 'crypto_key_id')
	BEGIN		
		ALTER TABLE [dbo].[Tape.media_pools] ADD [crypto_key_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {crypto_key_id} has been successfully added to [dbo].[Tape.media_pools] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1302; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1302)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'creation_time')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.GuestDatabase] ADD [creation_time] DATETIME not null DEFAULT (getdate())
		PRINT 'New column {[creation_time]} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1303; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1303 and current_version < 1304)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1304; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1304)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'crypto_key_id')
	BEGIN		
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [crypto_key_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {crypto_key_id} has been successfully added to [dbo].[Tape.backup_sets] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'encrypted')
	BEGIN		
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [encrypted] bit not null DEFAULT (0)
		PRINT 'New column {encrypted} has been successfully added to [dbo].[Tape.backup_sets] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1305; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1305)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.libraries]') AND [name] = 'name')
	BEGIN		
		ALTER TABLE [dbo].[Tape.libraries] ADD [name] nvarchar(MAX) null
		PRINT 'New column {name} has been successfully added to [dbo].[Tape.libraries] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1306; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1306)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = N'first_LSN' AND [xtype] = 127 )
	BEGIN 
		DECLARE 
			@constname	SYSNAME,
			@cmd		VARCHAR(1024)

		DECLARE curs_constraints CURSOR FOR
			SELECT 	name
			FROM 	sysobjects 
			WHERE 	parent_obj = object_ID('[dbo].[Backup.Model.SqlOIBs]') AND xtype in ('D')

		OPEN curs_constraints

		FETCH NEXT FROM curs_constraints INTO @constname
		WHILE (@@fetch_status = 0)
			BEGIN
				SELECT @cmd = 'ALTER TABLE [dbo].[Backup.Model.SqlOIBs] DROP CONSTRAINT [' + @constname + ']'
				EXEC(@cmd)
				FETCH NEXT FROM curs_constraints INTO @constname
			END
		
		CLOSE curs_constraints
		DEALLOCATE curs_constraints
	
		ALTER TABLE [dbo].[Backup.Model.SqlOIBs] ALTER COLUMN [first_LSN] NVARCHAR(25)
		ALTER TABLE [dbo].[Backup.Model.SqlOIBs] ALTER COLUMN [last_LSN]  NVARCHAR(25)
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1307; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1307)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') AND [name] = 'fqdn')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [fqdn] nvarchar(255) NOT NULL DEFAULT('')
		PRINT 'New column {fqdn} has been successfully added to [dbo].[Backup.Model.OIBs] table'
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_OIBs_Fqdn' AND object_id = OBJECT_ID('Backup.Model.OIBs'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_OIBs_Fqdn] ON [dbo].[Backup.Model.OIBs]
		(
			[fqdn] ASC
		) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		PRINT 'New index {IX_OIBs_Fqdn} has been successfully added to [dbo].[Backup.Model.OIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1308; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1308)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = N'oib_id' )
	BEGIN
		exec sp_rename '[dbo].[Backup.Model.SqlOIBs].[oib_id]', 'obj_id', 'COLUMN'
		PRINT 'Column {oib_id} has been successfully renamed to {obj_id} in [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1309; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1309)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeByProxyInitiators]') AND [name] = 'volume_lun_id')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.SanVolumeByProxyInitiators] add [volume_lun_id] uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {[volume_lun_id]} has been successfully added to [dbo].[Backup.Model.SanVolumeByProxyInitiators] table'
		EXEC sp_executesql @statement = N'	
			UPDATE 
				[dbo].[Backup.Model.SanVolumeByProxyInitiators] 
			SET 
				[volume_lun_id] = LUNs.id
			FROM (
					SELECT [id], [volume_id] 
					FROM [dbo].[Backup.Model.SanVolumeLUNs]
				) AS LUNs
			WHERE 
				[dbo].[Backup.Model.SanVolumeByProxyInitiators].volume_id = LUNs.volume_id
	
			print ''Updating volume_lun_id on table [dbo].[Backup.Model.SanVolumeByProxyInitiators]''
			'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1310; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1310 and current_version < 1315)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1315; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1315)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.EncryptedImportBackups]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.EncryptedImportBackups](
				[id] [uniqueidentifier] NOT NULL,
				[backup_path] [nvarchar](max) NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL,
				[backup_name] [nvarchar](255) NOT NULL,
				[cryptogram_id] [uniqueidentifier] NULL,
			 CONSTRAINT [PK_Backup.Model.EncryptedImportBackups] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	
			print 'Table [dbo].[Backup.Model.EncryptedImportBackups] has been successfully created'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ImportKeySets]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.ImportKeySets](
				[id] [uniqueidentifier] NOT NULL,
				[backup_id] [uniqueidentifier] NOT NULL,
				[key_set_id] [varbinary](20) NOT NULL,
				[cryptogram] [varbinary](max) NOT NULL,
				[key_set] [varbinary](max) NULL,
			 CONSTRAINT [PK_Backup.Model.ImportKeySets] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

			CREATE NONCLUSTERED INDEX [IX_ImportKeySets_key_set_id] ON [dbo].[Backup.Model.ImportKeySets] 
				(
					[key_set_id] ASC
				)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

			CREATE NONCLUSTERED INDEX [IX_ImportKeySets_backup_id] ON [dbo].[Backup.Model.ImportKeySets] 
				(
					[backup_id] ASC
				)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]


			print 'Table [dbo].[Backup.Model.ImportKeySets] has been successfully created'
	END


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1316; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1316 and current_version < 1317)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1317; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1317)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ImportKeySets]') AND [name] = 'key_chain_id')
	BEGIN		
		DELETE FROM [dbo].[Backup.Model.ImportKeySets]

		ALTER TABLE [dbo].[Backup.Model.ImportKeySets] ADD [key_chain_id] UNIQUEIDENTIFIER not null
		ALTER TABLE [dbo].[Backup.Model.ImportKeySets] ADD [key_type] INT not null
		PRINT 'New columns {[key_chain_id], [key_type]} has been successfully added to [dbo].[Backup.Model.ImportKeySets] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1318; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1318 and current_version < 1319)
BEGIN

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1319; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1319)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') AND [name] = 'last_used_key_set')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD [last_used_key_set] VARBINARY(MAX) null
		PRINT 'New column {[last_used_key_set]} has been successfully added to [dbo].[Backup.Model.Backups] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1320; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1320)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.tape_medium_backup_sets]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.tape_medium_backup_sets](
			[tape_medium_id] [uniqueidentifier] NOT NULL,
			[backup_set_id] [uniqueidentifier] NOT NULL,
		 CONSTRAINT [PK_Tape.tape_medium_backup_sets] PRIMARY KEY CLUSTERED 
		(
			[tape_medium_id] ASC,
			[backup_set_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Tape.tape_medium_backup_sets] has been successfully created'

		EXEC('
			INSERT INTO [Tape.tape_medium_backup_sets] (tape_medium_id, backup_set_id)
			SELECT DISTINCT tmf.id, bsf.id
			FROM 
				[Tape.file_parts] fp 
				INNER JOIN [Tape.backup_sets] bsf ON fp.backup_set_id = bsf.id 
				INNER JOIN [Tape.tape_mediums] tmf ON bsf.media_family_id = tmf.media_family_id AND fp.media_sequence_number = tmf.media_sequence_number
			UNION
			SELECT DISTINCT tmd.id, bsd.id
			FROM 
				[Tape.directory_versions] dv 
				INNER JOIN [Tape.backup_sets] bsd ON dv.backup_set_id = bsd.id
				INNER JOIN [Tape.tape_mediums] tmd ON bsd.media_family_id = tmd.media_family_id AND dv.media_sequence_number = tmd.media_sequence_number
		')
	
		PRINT '[dbo].[Tape.tape_medium_backup_sets] table data has been successfully updated'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1321; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1321 and current_version < 1322)
BEGIN
	ALTER TABLE [dbo].[Tape.tape_medium_backup_sets]  WITH NOCHECK ADD  CONSTRAINT [FK_Tape.tape_medium_backup_sets_Tape.backup_sets] FOREIGN KEY([backup_set_id])
	REFERENCES [dbo].[Tape.backup_sets] ([id])
	ON UPDATE CASCADE
	ON DELETE CASCADE

	ALTER TABLE [dbo].[Tape.tape_medium_backup_sets] CHECK CONSTRAINT [FK_Tape.tape_medium_backup_sets_Tape.backup_sets]

	ALTER TABLE [dbo].[Tape.tape_medium_backup_sets]  WITH CHECK ADD  CONSTRAINT [FK_Tape.tape_medium_backup_sets_Tape.tape_mediums] FOREIGN KEY([tape_medium_id])
	REFERENCES [dbo].[Tape.tape_mediums] ([id])
	ON UPDATE CASCADE
	ON DELETE CASCADE

	ALTER TABLE [dbo].[Tape.tape_medium_backup_sets] CHECK CONSTRAINT [FK_Tape.tape_medium_backup_sets_Tape.tape_mediums]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1322; END
END

GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1322)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.EncryptedImportBackups]') AND [name] = 'usn')
	BEGIN		
		alter table [dbo].[Backup.Model.EncryptedImportBackups] add [usn] bigint not null
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.EncryptedImportBackups] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1323; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1323)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1324; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1324)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.EncryptedImportBackups]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.EncryptedImportBackups''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1325; END	
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1324 and current_version < 1326)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1326; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1326)
BEGIN	
	
	ALTER TABLE dbo.[Backup.Model.EncryptedImportBackups] ADD CONSTRAINT
		[DF_Backup.Model.EncryptedImportBackups_usn] DEFAULT 0 FOR usn

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1327; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1327)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'catalog_session')
	BEGIN		
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [catalog_session] [nvarchar](max) NULL
		PRINT 'New column {catalog_session} has been successfully added to [dbo].[Tape.backup_sets] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1328; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1328 and current_version < 1330)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1330; END
END

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1330)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.EncryptedImportBackups]') AND [name] = 'import_guest_file_index')
	BEGIN		
		DELETE FROM [dbo].[Backup.Model.ImportKeySets]
		DELETE FROM [dbo].[Backup.Model.EncryptedImportBackups]

		ALTER TABLE [dbo].[Backup.Model.EncryptedImportBackups] ADD [import_guest_file_index] BIT NOT NULL
		PRINT 'New column {import_guest_file_index} has been successfully added to [dbo].[Backup.Model.EncryptedImportBackups] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1331; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1331 and current_version < 1338)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1338; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1338)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'sql_enabled')
	BEGIN		
		alter table [dbo].[BJobs] add sql_enabled bit DEFAULT 0 not null
		print 'New column {sql_enabled} has been successfully added to [dbo].[BJobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1339; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1339)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.media_vaults]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.media_vaults](
			[id] [uniqueidentifier] NOT NULL,
			[name] [nvarchar](255) NOT NULL,
			[location] [nvarchar](255) NOT NULL,
			[description] [nvarchar](max) NOT NULL,
			[usn] [bigint] NOT NULL DEFAULT ((0)),
		 CONSTRAINT [PK_Tape.media_vaults] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1340; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1340)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.media_in_vaults]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.media_in_vaults](
			[id] [uniqueidentifier] NOT NULL,
			[vault_id] [uniqueidentifier] NOT NULL,
			[media_id] [uniqueidentifier] NOT NULL,
			[usn] [bigint] NOT NULL DEFAULT ((0)),
		CONSTRAINT [PK_Tape.media_in_vaults] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1341; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1341)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Tape.media_vaults]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Tape.media_vaults''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1342; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1342)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Tape.media_in_vaults]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Tape.media_in_vaults''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1343; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1343)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'parent_job_id')
	BEGIN		
		alter table [dbo].[BJobs] add parent_job_id uniqueidentifier DEFAULT null
		print 'New column {parent_job_id} has been successfully added to [dbo].[BJobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1344; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1344 and current_version < 1345)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1345; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1345)
BEGIN	
	IF EXISTS (SELECT * FROM sys.columns WHERE Name = N'is_startfull' AND object_id = OBJECT_ID(N'dbo.[Backup.Model.BackupJobSessions]'))
    BEGIN
		EXEC sp_rename 'dbo.[Backup.Model.BackupJobSessions].[is_startfull]', 'is_full', 'COLUMN'
	END
	
	IF NOT EXISTS (SELECT * FROM sys.columns WHERE Name = N'is_active_full' AND object_id = OBJECT_ID(N'dbo.[Backup.Model.BackupJobSessions]'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions]
		ADD [is_active_full] BIT NOT NULL
		CONSTRAINT [Backup.Model.BackupJobSessions_is_active_full_nn] DEFAULT 0
	END

	declare @table_name nvarchar(256)
	set @table_name = N'Backup.Model.BackupJobSessions'
	declare @col_name nvarchar(256)
	set @col_name = N'session_algorithm'
	declare @Command nvarchar(max)
	declare @constraint_name nvarchar(256)
	set @constraint_name = (select d.name from sys.tables t
		join
		sys.default_constraints d
			on d.parent_object_id = t.object_id
		join
		sys.columns c
			on c.object_id = t.object_id
			and c.column_id = d.parent_column_id
	where t.name = @table_name
	and c.name = @col_name)

	if (@constraint_name IS NOT NULL)
	begin
		set @Command = 'ALTER TABLE [' + @table_name + '] DROP CONSTRAINT [' + @constraint_name + ']'
		print @Command
		execute (@Command)
		ALTER TABLE [Backup.Model.BackupJobSessions] ADD CONSTRAINT
		[DF__Backup.Mo__sessi_alg_default] DEFAULT ((-1)) FOR session_algorithm /*Unknown*/
	end
	
	set @col_name = N'job_algorithm'
	set @constraint_name  = (select d.name from sys.tables t
		join
		sys.default_constraints d
			on d.parent_object_id = t.object_id
		join
		sys.columns c
			on c.object_id = t.object_id
			and c.column_id = d.parent_column_id
	where t.name = @table_name
	and c.name = @col_name)
	
	if (@constraint_name IS NOT NULL)
	begin
		set @Command = 'ALTER TABLE [' + @table_name + '] DROP CONSTRAINT [' + @constraint_name + ']'
		print @Command
		execute (@Command)
		ALTER TABLE [Backup.Model.BackupJobSessions] ADD CONSTRAINT
		[DF__Backup.Mo__job_alg_default] DEFAULT ((-1)) FOR job_algorithm /*Unknown*/
	end

	/* Take it easy, no data is lost - earlier 'job_algorithm' was always 2 */
	UPDATE [Backup.Model.BackupJobSessions] SET job_algorithm = -1 

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1346; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1346)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.VeeamZIPRetention]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.VeeamZIPRetention](
			[id] [uniqueidentifier] NOT NULL,
			[backup_info] [XML] NOT NULL,
			[creation_time] [datetime] NOT NULL,
			[retain_days] [int] NOT NULL,
			[repository_id] [uniqueidentifier] NULL,
			[target_file] [nvarchar](2048) NOT NULL
		 CONSTRAINT [PK_Backup.Model.VeeamZIPRetention] PRIMARY KEY CLUSTERED 
		([id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.VeeamZIPRetention] ADD  CONSTRAINT [DF_Backup.Model.VeeamZIPRetention_id]  DEFAULT (newid()) FOR [id]
		ALTER TABLE [dbo].[Backup.Model.VeeamZIPRetention] ADD  CONSTRAINT [FK_Backup.Model.VeeamZIPRetention_BackupRepositories] FOREIGN KEY([repository_id])
			REFERENCES [dbo].[BackupRepositories] ([id])
			ON UPDATE CASCADE
		ON DELETE CASCADE

		PRINT 'Table [dbo].[Backup.Model.VeeamZIPRetention] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1347; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1347 and current_version < 1350)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1350; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1350)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'file_name')
	BEGIN		
		alter table [dbo].[Backup.Model.SqlOIBs] add file_name nvarchar(400) not null DEFAULT ('')
		print 'New column {[file_name]} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1351; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1351)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'is_system')
	BEGIN		
		alter table [dbo].[Backup.Model.GuestDatabase] add is_system bit not null DEFAULT 0
		print 'New column {[is_system]} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1352; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1352)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.encrypted_imported_backups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.encrypted_imported_backups](
			[id] [uniqueidentifier] NOT NULL,
			[library_id] [uniqueidentifier] NOT NULL,
			[meta] [nvarchar](max) NOT NULL,
		 CONSTRAINT [PK_Tape.encrypted_imported_backups] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		ALTER TABLE [dbo].[Tape.encrypted_imported_backups]  WITH CHECK ADD  CONSTRAINT [FK_Tape.encrypted_imported_backups_Backup.Model.EncryptedImportBackups] FOREIGN KEY([id])
		REFERENCES [dbo].[Backup.Model.EncryptedImportBackups] ([id])
		ON DELETE CASCADE

		PRINT 'Table [dbo].[Tape.encrypted_imported_backups] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1353; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1353)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_pools]') AND [name] = 'vault_id')
	BEGIN		
		ALTER TABLE [Tape.media_pools] add vault_id uniqueidentifier
		print 'New column {vault_id} has been successfully added to [dbo].[Tape.media_pools] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1354; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1354 AND current_version < 1356)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Events.JobSessionEvents]') AND [name] = 'usn')
	BEGIN
		ALTER TABLE [dbo].[Events.JobSessionEvents] ADD [usn] BIGINT NOT NULL DEFAULT(0)
		PRINT 'New column {usn} has been successfully added to [dbo].[Events.JobSessionEvents] table'
	END
		
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Events.TaskSessionEvents]') AND [name] = 'usn')
	BEGIN
		ALTER TABLE [dbo].[Events.TaskSessionEvents] ADD [usn] BIGINT NOT NULL DEFAULT(0)
		PRINT 'New column {usn} has been successfully added to [dbo].[Events.TaskSessionEvents] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1356; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1356 AND current_version < 1357)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.encrypted_imported_backups]') AND [name] = 'original_id')
	BEGIN		
		ALTER TABLE [dbo].[Tape.encrypted_imported_backups] ADD [original_id] uniqueidentifier null

		CREATE NONCLUSTERED INDEX [Tape.encrypted_imported_backups.original_id] ON [dbo].[Tape.encrypted_imported_backups]
		(
			[original_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		PRINT 'New column [original_id] has been successfully added to [dbo].[Tape.encrypted_imported_backups] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1357; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1357 and current_version < 1367)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1367; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1367)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessions]') AND [name] = 'advanced_stat')
	BEGIN		
		alter table [dbo].[Backup.Model.BackupTaskSessions] add advanced_stat xml
		print 'New column {advanced_stat} has been successfully added to [dbo].[Backup.Model.BackupTaskSessions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1368; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1368 and current_version < 1369)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1369; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1369)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1370; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1370)
BEGIN
	IF EXISTS(SELECT *  FROM [dbo].[Tape.jobs])
	BEGIN	
		DECLARE @local_tape_server_id as uniqueidentifier;
		SET @local_tape_server_id = N'211506cf-960f-40a0-832e-6550a14c8c9e';
		INSERT INTO [dbo].[BackupProxies] ([id], [name], [description], [type], [host_id], [options], [usn], [disabled], [is_busy], [is_unavailable], [unique_id]) VALUES (@local_tape_server_id, N'Local Tape Server', N'Created during db update from 7.0', 3, N'6745a759-2205-4cd2-b172-8ec8f7e60ef8', CONVERT(xml,N'<TapeServerOptions/>',1), 112, 0, 0, 0, N'59248bfd-4e7c-47e5-83ce-0e2c06a888bd')
		INSERT INTO [dbo].[HostComponents] ([id], [physical_host_id], [type], [version], [options], [usn], [is_up_to_date]) VALUES (N'a468bf20-a041-465e-b342-1a2c1131b381', N'd7c4ff97-b99b-4d1f-884d-283b7b6b9ee3', 6, N'7.5.0.97', CONVERT(xml,N'<TapeClientOptions/>',1), 122, 1)
		UPDATE [dbo].[Tape.devices] SET [tape_server_id] = @local_tape_server_id;
		UPDATE [dbo].[Tape.libraries] SET [tape_server_id] = @local_tape_server_id;
	END
	ELSE IF EXISTS(SELECT * FROM [dbo].[Tape.devices])	
	BEGIN
		UPDATE [dbo].[Tape.devices] SET [state] = 1
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1371; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1371)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1372; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1372)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'advanced_stat')
	BEGIN		
		alter table [dbo].[Backup.Model.BackupJobSessions] add advanced_stat xml
		print 'New column {advanced_stat} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1373; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1373)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SqlBackupIntervalSess]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.SqlBackupIntervalSess](
			 [id]			 uniqueidentifier NOT NULL,
			 [task_sess_id]	 uniqueidentifier NOT NULL,
			 [databases]	 xml NOT NULL default '<dbs/>',
			 [start_time]	 datetime NOT NULL,
			 [duration]		 bigint NOT NULL,
			 [interval]		 bigint NOT NULL,
			 [read_size]     bigint NOT NULL,
			 [missed]		 bit NOT NULL,
			 [successes]	 int NOT NULL,
			 [warnings]		 int NOT NULL,
			 [errors]		 int NOT NULL
			 CONSTRAINT [PK_SqlBackupIntervalSess] PRIMARY KEY CLUSTERED 
				(
					[id] ASC
				) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
		
			print 'Table [dbo].[Backup.Model.SqlBackupIntervalSess] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1374; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1374)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1375; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1375)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1376; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1376)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1377; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1377)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlBackupIntervalSess]') AND [name] = 'result')
	BEGIN		
		alter table  [dbo].[Backup.Model.SqlBackupIntervalSess] add result int not null default 0
		print 'New column {result} has been successfully added to  [dbo].[Backup.Model.SqlBackupIntervalSess] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1378; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1378 and current_version < 1382)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1382; END
END
GO

-----------------------------------------------------
--
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1382)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OijProxies]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[OijProxies](
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_OijProxies_id]  DEFAULT (newid()),
			[oij_id] [uniqueidentifier] NOT NULL,
			[proxy_id] [uniqueidentifier] NOT NULL,
			[type] [int] NOT NULL,
			[usn] [bigint] NOT NULL DEFAULT 0
		 CONSTRAINT [PK_OijProxies] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		) ON [PRIMARY]
	END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1383; END	
END		
GO
--
-----------------------------------------------------
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1383)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[OijProxies]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''OijProxies''
	end
	'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1384; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1384 and current_version < 1388)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudProviders]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudProviders](
			id uniqueidentifier NOT NULL,
			name nvarchar(MAX) NOT NULL,
			description nvarchar(MAX) NOT NULL,
			port int NOT NULL,
			creds_id uniqueidentifier NOT NULL,
			flags bigint NOT NULL,
			options xml NOT NULL,
			usn bigint NOT NULL,
		CONSTRAINT [PK_Backup.Model.CloudProviders] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
		ALTER TABLE [dbo].[Backup.Model.CloudProviders] ADD  CONSTRAINT [DF_Backup.Model.CloudProviders_id]  DEFAULT (newid()) FOR [id]

		PRINT 'Table [dbo].[Backup.Model.CloudProviders] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1388; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1388)
BEGIN
	IF OBJECT_ID('tempdb..#tempObjectsInJobs') IS NOT NULL DROP TABLE #tempObjectsInJobs

	SELECT
		[oijs].*
	INTO
		#tempObjectsInJobs
	FROM 
		[dbo].[ObjectsInJobs] [oijs],
		[dbo].[BJobs] [jobs]
	WHERE
		[oijs].[type] = 2 AND [oijs].[job_id] = jobs.[id] AND [jobs].[target_type] = 0 AND
		NOT EXISTS (SELECT * FROM [dbo].[ObjectsInJobs] WHERE [job_id] = [oijs].[job_id] AND [object_id] = [oijs].[object_id] AND ([type] = 5 OR [type] = 6))

	UPDATE [dbo].[ObjectsInJobs] SET [type] = 6 WHERE [id] IN (SELECT [id] FROM #tempObjectsInJobs)

	UPDATE #tempObjectsInJobs SET [id] = newid(), [type] = 2
	INSERT INTO [dbo].[ObjectsInJobs] SELECT * FROM #tempObjectsInJobs

	UPDATE #tempObjectsInJobs SET [id] = newid(), [type] = 5
	INSERT INTO [dbo].[ObjectsInJobs] SELECT * FROM #tempObjectsInJobs

	IF OBJECT_ID('tempdb..#tempObjectsInJobs') IS NOT NULL DROP TABLE #tempObjectsInJobs

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1389; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1389 AND current_version < 1390)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'protection_date')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [protection_date] DATETIME NULL
		PRINT 'New column {protection_date} has been successfully added to [dbo].[Tape.tape_mediums] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1390; END
END
GO
 
 
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1390 and current_version < 1392)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1392; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1392 and current_version < 1393)
BEGIN
	IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'Tenants'))
	BEGIN
	   CREATE TABLE [dbo].[Tenants]
	   (id uniqueidentifier PRIMARY KEY,
	   name nvarchar(MAX) not null,
	   password nvarchar(MAX) not null,
	   description nvarchar(MAX)not null,
	   usn bigint not null)
	   PRINT 'New table [dbo].[Tenants] has been successfully added'
	END

	IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'TenantsResourcesQuota'))
	BEGIN
		CREATE TABLE [dbo].[TenantsResourcesQuota]
		(id uniqueidentifier PRIMARY KEY,
		tenant_id uniqueidentifier not null,
		repository_id uniqueidentifier not null,
		folder nvarchar(MAX),
		wan_id uniqueidentifier,
		quota_mb int default 0,
		quota_unit int default 1,
		usn bigint not null)
		PRINT 'New table [dbo].[TenantsResourcesQuota] has been successfully added'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1393; END
END
GO
 
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1393 and current_version < 1395)
BEGIN
	-- Delete AddTrackChangeTriggers
	PRINT N'Creating [dbo].[AddTrackChangeTriggers]'
	IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddTrackChangeTriggers]') AND type in (N'P', N'PC'))
	BEGIN
		DROP PROCEDURE [dbo].[AddTrackChangeTriggers]
	END

	-- Update AddTrackChangeTriggers	
	exec sp_executesql @stat = N'
	CREATE PROCEDURE [dbo].[AddTrackChangeTriggers]
		@tablename nvarchar(1000),
		@include_insert bit = 1,
		@include_update bit = 1,
		@include_delete bit = 1
	AS
	BEGIN
		SET NOCOUNT ON;	
		declare @tables table (prefix nvarchar(255), owner nvarchar(255), tname nvarchar(255), ttype nvarchar(255), rem nvarchar(255))
		insert into @tables exec sp_tables null, ''dbo''

		declare @cur_tables cursor
		set @cur_tables = cursor local for select tname from @tables where tname = @tablename
		open @cur_tables

		declare @tname nvarchar(255)
		fetch next from @cur_tables into @tname

		declare @triggername nvarchar(255)
		select @triggername = replace (@tname, ''.'', ''_'')
	
		
				
		while @@fetch_status = 0
		begin
			if not (@tname = ''Version'' OR 
						@tname = ''sysdiagrams'' OR 
						@tname = ''log'')
			begin
			
	
				declare @text nvarchar(1024)
				declare @script nvarchar (1024)
				select @text = N''
				create trigger !!?? on [dbo].[##] for ^^ 
				as
				begin
					declare @id uniqueidentifier
					declare enumerator cursor LOCAL
						for select id from $$
						
					open enumerator
					fetch next from enumerator into @id
				
					while @@FETCH_STATUS = 0
					begin
						exec dbo.TrackChange ''''##'''', @id, %%
						fetch next from enumerator into @id
					end
						
					close enumerator
					deallocate enumerator
				end
				''
				
				if @include_insert = 1				
				IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[i_'' + @triggername + '']''))
				begin
					select @script = replace (@text, ''??'', @triggername)
					select @script = replace (@script, ''##'', @tname)
					select @script = replace (@script, ''!!'', ''i_'')
					select @script = replace (@script, ''^^'', ''insert'')
					select @script = replace (@script, ''$$'', ''inserted'')
					select @script = replace (@script, ''%%'', ''0'')
					print @script

					EXEC dbo.sp_executesql @statement = @script
					print ''Trigger after insert added '' + @tname
				end
		               
		        if @include_update = 1
				IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[u_'' + @triggername + '']''))
				begin
					select @script = replace (@text, ''??'', @triggername)
					select @script = replace (@script, ''##'', @tname)
					select @script = replace (@script, ''!!'', ''u_'')
					select @script = replace (@script, ''^^'', ''update'')
					select @script = replace (@script, ''$$'', ''inserted'')
					select @script = replace (@script, ''%%'', ''1'')
					print @script

					EXEC dbo.sp_executesql @statement = @script
					print ''Trigger after update added '' + @tname
				end
		        
		        if @include_delete = 1
				IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[d_'' + @triggername + '']''))
				begin
					select @script = replace (@text, ''??'', @triggername)
					select @script = replace (@script, ''##'', @tname)
					select @script = replace (@script, ''!!'', ''d_'')
					select @script = replace (@script, ''^^'', ''delete'')
					select @script = replace (@script, ''$$'', ''deleted'')
					select @script = replace (@script, ''%%'', ''2'')
					print @script

					EXEC dbo.sp_executesql @statement = @script
					print ''Trigger after delete added '' + @tname
				end
			end
			fetch next from @cur_tables into @tname
		end
	END'

	-- Create table CloudGates
	IF OBJECT_ID(N'[dbo].[Backup.Model.CloudGates]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudGates](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.CloudGates] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.CloudGates_id] DEFAULT (newid()),
			host_id uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.CloudGates_Hosts] FOREIGN KEY REFERENCES [dbo].[Hosts] (id) ON DELETE CASCADE,
			name nvarchar(MAX) NOT NULL,
			description nvarchar(MAX) NOT NULL,
			creds_id uniqueidentifier NOT NULL,
			options xml NOT NULL,
			usn bigint NOT NULL,
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.CloudGates] has been successfully created'
	END
	
	-- Create triggers for CloudGates
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudGates'
	
	-- Create triggers for CloudProviders
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudProviders'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1395; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1395)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'db_backup_LSN')
	BEGIN		
		alter table [dbo].[Backup.Model.SqlOIBs] add db_backup_LSN nvarchar(25) not null DEFAULT ('')
		print 'New column {[db_backup_LSN]} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1396; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1396 and current_version < 1400)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'protection_date')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] DROP COLUMN [protection_date]
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'expiration_date')
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [expiration_date] [datetime] NULL

		PRINT 'New column {expiration_date} has been successfully added to [dbo].[Tape.backup_sets] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1400; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1400 and current_version < 1405)
BEGIN
	IF COL_LENGTH('[dbo].[Backup.Model.CloudGates]', 'host_id') IS NULL
	BEGIN
		alter table [dbo].[Backup.Model.CloudGates] add host_id uniqueidentifier not null
			CONSTRAINT [FK_Backup.Model.CloudGates_Hosts] FOREIGN KEY REFERENCES [dbo].[Hosts] (id) ON DELETE CASCADE
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1405; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1405)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') AND [name] = 'parent_backup_id')
	BEGIN		
		alter table [dbo].[Backup.Model.Backups] add parent_backup_id uniqueidentifier DEFAULT null
		print 'New column {parent_backup_id} has been successfully added to [dbo].[Backup.Model.Backups] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1406; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1406)
BEGIN
	IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = 'OibAdminAccounts'))
	BEGIN
	   CREATE TABLE [dbo].[OibAdminAccounts]
	   (
			[id] [uniqueidentifier] NOT NULL,
			[sid] [nvarchar](184) NOT NULL,
			[oib_id] [uniqueidentifier] NOT NULL,
			[account_type] [int] NOT NULL,
			[usn] [bigint] NOT NULL	
	   )
	   PRINT 'New table [dbo].[OibAdminAccounts] has been successfully added'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1407; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1407)
BEGIN
	UPDATE 
		bs
	SET
		bs.expiration_date = 
		CASE mp.options.query('/MediaPoolOptions/OverwriteRetention').value('.', 'nvarchar(8)') 
			WHEN N'None' THEN CAST('1753-01-01T00:00:00.000' AS datetime)
			WHEN N'Period' THEN 
				CASE mp.options.query('/MediaPoolOptions/OverwritePeriod/Type').value('.', 'nvarchar(6)')
					WHEN N'None' THEN bs.write_time
					WHEN N'Days' THEN DATEADD(day, mp.options.query('/MediaPoolOptions/OverwritePeriod/Value').value('.', 'int'), bs.write_time)
					WHEN N'Weeks' THEN DATEADD(week, mp.options.query('/MediaPoolOptions/OverwritePeriod/Value').value('.', 'int'), bs.write_time)
					WHEN N'Months' THEN DATEADD(month, mp.options.query('/MediaPoolOptions/OverwritePeriod/Value').value('.', 'int'), bs.write_time)
				END
			WHEN N'Infinite' THEN CAST('9999-12-31T23:59:59.997' AS datetime)
		END
	FROM 
		[Tape.backup_sets] bs
		INNER JOIN [Tape.tape_medium_backup_sets] tmbs ON bs.id = tmbs.backup_set_id
		INNER JOIN [Tape.tape_mediums] tm ON tmbs.tape_medium_id = tm.id
		INNER JOIN [Tape.media_pools] mp ON tm.media_pool_id = mp.id
	WHERE 
		bs.expiration_date IS NULL AND
		mp.type = 4

	PRINT '[dbo].[Tape.backup_sets] table data has been successfully updated'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1408; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1408)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = N'has_ad')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [has_ad] bit NOT NULL DEFAULT 0
		PRINT 'New column {has_ad} has been successfully added to dbo.[Backup.Model.OIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1409; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1409 and current_version < 1412)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1412; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1412 and current_version < 1413)
BEGIN
	IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'quota_unit' AND OBJECT_ID = OBJECT_ID(N'[dbo].[TenantsResourcesQuota]'))         
		BEGIN
			DECLARE @constr sysname; 
			SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[TenantsResourcesQuota]') and [name] = 'quota_unit')
			IF (@constr IS NOT NULL)
			BEGIN		
				DECLARE @statement NVARCHAR(255);					
				SET @statement = N'ALTER TABLE [dbo].[TenantsResourcesQuota] DROP CONSTRAINT [' + @constr + ']'		
				exec sp_executesql @statement
			END

			ALTER TABLE [dbo].[TenantsResourcesQuota]
			DROP COLUMN [quota_unit]
			PRINT 'Column quota_unit has been successfully removed from [dbo].[TenantsResourcesQuota]'
		END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1413; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1413 and current_version < 1417)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1417; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1417 and current_version < 1419)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1419; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1419)
BEGIN
	IF OBJECT_ID(N'[dbo].[Backup.Model.DataDomainRepositoryServers]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.DataDomainRepositoryServers](
			[id] [uniqueidentifier] NOT NULL,
			[repository_id] [uniqueidentifier] NOT NULL,
			[dd_server_name] [nvarchar](255) NOT NULL,		
			[dd_creds_id] [uniqueidentifier] NOT NULL
		CONSTRAINT [PK_Backup.DataDomainRepositoryServers] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
			
		PRINT 'Create table [dbo].[Backup.Model.DataDomainRepositoryServers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1420; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1420)
BEGIN	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[OibAdminAccounts]') and [name] = N'insert_time')
	BEGIN
		ALTER TABLE [OibAdminAccounts] ADD insert_time datetime DEFAULT GETDATE()
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1421; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1421)
BEGIN
	IF OBJECT_ID(N'[dbo].[Backup.Model.CloudRepositories]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudRepositories](
			[repository_id] [uniqueidentifier] NOT NULL,
			[provider_id] [uniqueidentifier] NOT NULL,
			[cloud_repository_id] [uniqueidentifier] NOT NULL,
			[is_available] [bit] NOT NULL
		) ON [PRIMARY]
			
		PRINT 'Create table [dbo].[Backup.Model.CloudRepositories]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1422; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1422 and current_version < 1424)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1424; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1424 and current_version < 1425)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'protected')
	BEGIN	
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [protected] [bit] NOT NULL DEFAULT 0

		PRINT 'New column {protected} has been successfully added to [dbo].[Tape.tape_mediums] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1425; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1425 and current_version < 1427)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1427; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1427 and current_version < 1428)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.catalog_usn]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Tape.catalog_usn]([usn] [bigint] NOT NULL) ON [PRIMARY]
		INSERT INTO [Tape.catalog_usn] (usn) VALUES (0)
		PRINT 'Table [dbo].[Tape.catalog_usn] has been successfully created'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_delete_file_versions]') AND type in (N'TR'))
	BEGIN
		exec sp_executesql @stat = N'
			CREATE TRIGGER [dbo].[Tape.after_insert_delete_file_versions]
				ON [dbo].[Tape.file_versions]
				AFTER INSERT, DELETE
			AS 
			BEGIN
				SET NOCOUNT ON;

				UPDATE [dbo].[Tape.catalog_usn] SET usn = usn + 1
			END'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_delete_directory_versions]') AND type in (N'TR'))
	BEGIN
		exec sp_executesql @stat = N'
			CREATE TRIGGER [dbo].[Tape.after_insert_delete_directory_versions]
				ON [dbo].[Tape.directory_versions]
				AFTER INSERT, DELETE
			AS 
			BEGIN
				SET NOCOUNT ON;

				UPDATE [dbo].[Tape.catalog_usn] SET usn = usn + 1
			END'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1428; END
END
GO
 
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1428 and current_version < 1430)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1430; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1430 and current_version < 1432)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1432; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1432)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlBackupIntervalSess]') AND [name] = 'stored_size')
	BEGIN		
		alter table [dbo].[Backup.Model.SqlBackupIntervalSess] add stored_size bigint not null default 0
		print 'New column {stored_size} has been successfully added to [dbo].[Backup.Model.SqlBackupIntervalSess] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1433; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1433 and current_version < 1435)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1435; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1435 and current_version < 1436)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[VeeamProductVersion]') and [name] = N'VeeamProductVersion')
	BEGIN
		ALTER TABLE [dbo].[VeeamProductVersion] DROP COLUMN [VeeamProductVersion]
		PRINT 'Column [VeeamProductVersion] has been successfully droppped from [dbo].[VeeamProductVersion]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1436; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1436 and current_version < 1437)
BEGIN
	IF OBJECT_ID(N'[dbo].[Product]', N'U') IS NOT NULL
	BEGIN
		DROP TABLE [dbo].[Product]
		PRINT 'Table [dbo].[Product] has been successfully dropped'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1437; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1437)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[WanGlobalCacheCorruptedDiskRoles]') AND [name] = 'src_wan_guid')
	BEGIN		
		alter table [dbo].[WanGlobalCacheCorruptedDiskRoles] add src_wan_guid varchar(255) NULL, tgt_wan_guid varchar(255) NULL
		print 'New columns {src_wan_guid, tgt_wan_guid} has been successfully added to [dbo].[WanGlobalCacheCorruptedDiskRoles] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1438; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1438 and current_version < 1439)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1439; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1439 and current_version < 1440)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1440; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1440)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudRepositories]') AND [name] = 'is_wan_accelerator_enabled')
	BEGIN		
		alter table [dbo].[Backup.Model.CloudRepositories] add is_wan_accelerator_enabled bit NOT NULL DEFAULT(0)
		print 'New column {is_wan_accelerator_enabled} has been successfully added to [dbo].[Backup.Model.CloudRepositories] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1441; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1441 and current_version < 1442)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1442; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1442)
BEGIN
	
	IF OBJECT_ID(N'[dbo].[Backup.Model.Updates]', N'U') IS NULL
	BEGIN
		CREATE TABLE dbo.[Backup.Model.Updates]
		(
			id uniqueidentifier NOT NULL,
			kb_no nvarchar(255) NOT NULL,
			[description] nvarchar(MAX) NULL,
			info nvarchar(MAX) NOT NULL,
			url nvarchar(MAX) NULL

			CONSTRAINT PK_Backup_Model_Updates PRIMARY KEY CLUSTERED ( id ) 
			WITH ( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON ) ON [PRIMARY]
		)  ON [PRIMARY]
		TEXTIMAGE_ON [PRIMARY]
	END

	IF OBJECT_ID(N'[dbo].[Backup.Model.HostUpdates]', N'U') IS NULL
	BEGIN
		CREATE TABLE [Backup.Model.HostUpdates]
		(
			[host_id] uniqueidentifier NOT NULL,
			update_id uniqueidentifier NOT NULL,
			dismiss bit NOT NULL default (0)

			CONSTRAINT PK_Backup_Model_HostUpdates PRIMARY KEY CLUSTERED ( host_id, update_id ) 
			WITH ( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON ) ON [PRIMARY]
		)  ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1443; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1443 and current_version < 1446)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.EncryptedImportBackups]') AND [name] = 'repository_id')
	BEGIN		
		alter table [dbo].[Backup.Model.EncryptedImportBackups] add repository_id UniqueIdentifier NOT NULL DEFAULT('00000000-0000-0000-0000-000000000000')
		print 'New column {repository_id} has been successfully added to [dbo].[Backup.Model.EncryptedImportBackups] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1446; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1446)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'db_id')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.GuestDatabase] ADD [db_id] int not null DEFAULT(0)
		PRINT 'New column {[db_id]} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1447; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1447)
BEGIN
	-- Alter table CloudProviders
	IF COL_LENGTH(N'[dbo].[Backup.Model.CloudProviders]', N'cert_id') IS NULL
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudProviders] ADD cert_id uniqueidentifier
		print 'New column {cert_id} has been successfully added to [dbo].[Backup.Model.CloudProviders] table'
	END
	
	-- Create table TrustedCertificates
	IF OBJECT_ID(N'[dbo].[Backup.Model.TrustedCertificates]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.TrustedCertificates](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.TrustedCertificates] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.TrustedCertificates_id] DEFAULT (newid()),
			description nvarchar(max) not null,
			flags bigint NOT NULL,
			raw_data varbinary(max) NOT NULL
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.TrustedCertificates] has been successfully created'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1448; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1448 and current_version < 1452)
BEGIN

	IF OBJECT_ID(N'[dbo].[FlrApplianceConfigurations]', N'U') IS NOT NULL
	BEGIN
		DROP TABLE [dbo].[FlrApplianceConfigurations]
		PRINT 'Table [dbo].[FlrApplianceConfigurations] has been successfully dropped'
	END

	IF OBJECT_ID(N'[dbo].[FlrApplianceConfigurations]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[FlrApplianceConfigurations](
			[id] [uniqueidentifier] NOT NULL,
			[username] [nvarchar](255) NOT NULL,
			[sid] [nvarchar](255) NOT NULL,
			[mode] [int] NOT NULL,
			[common_options] [xml],
			[vi_options] [xml]
		)
		
		PRINT 'Table [dbo].[FlrApplianceConfigurations] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1452; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1452 and current_version < 1458)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1458; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1458 )
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Updates]') AND [name] = N'type')
	BEGIN
		exec sp_executesql @stat = N'ALTER TABLE [dbo].[Backup.Model.Updates] ADD [type] int NOT NULL DEFAULT(0)'
		print 'New column {type} has been successfully added to [dbo].[Backup.Model.Updates] table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1459; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1459)
BEGIN
	INSERT INTO [dbo].[Ssh_creds]
           ([elevatetoroot]
           ,[rootpassword]
           ,[port]
           ,[startftport]
           ,[endftport]
           ,[buffersize]
           ,[isftserver]
           ,[timeout]
           ,[adjust_firewall]
           ,[auto_sudo]
           ,[enabled]
           ,[creds])
	  VALUES
           ('False'
           ,''
           ,22
           ,2500
           ,5000
           ,64
           ,'False'
           ,20000
           ,'False'
           ,'False'
           ,'True'
           ,'70275B03-E805-49E1-9535-1867C62371E2')
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1460; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1460)
BEGIN
	DECLARE @retain_opt_id uniqueidentifier
	DECLARE @retain_opt xml
	DECLARE @retain_days int

	SET @retain_opt_id  ='326EE145-E5E9-40B6-9B2B-7CB8ACF93164'

	SET @retain_opt = (SELECT TOP(1) [value] FROM [dbo].[Options] WHERE [id] = @retain_opt_id)

	SET @retain_days = @retain_opt.query('CSessionKeep/Keep').value('.', 'int')

	IF @retain_days = 364
	BEGIN
		SET @retain_days = 53 * 7
		--������, ��� �� ������� ������ ���� �� 52 ������, � 53 (371 ����)

		SET @retain_opt.modify('
			replace value of (CSessionKeep/Keep[1]/text())[1]
			with sql:variable("@retain_days")
			')

		UPDATE [dbo].[Options] SET
			[value] = @retain_opt
		WHERE
			[id] = @retain_opt_id
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1461; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1461 and current_version < 1463)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'link_id')
	BEGIN		
		alter table [dbo].[Backup.Model.Storages] add link_id UniqueIdentifier NULL
		print 'New column {link_id} has been successfully added to [dbo].[Backup.Model.Storages] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1463; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1463 and current_version < 1466)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1466; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1466 and current_version < 1468)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BackupRepositories]') AND [name] = 'on_rotated_drive')
	BEGIN		
		alter table [dbo].[BackupRepositories] add on_rotated_drive bit NOT NULL DEFAULT 0
		print 'New column {on_rotated_drive} has been successfully added to [dbo].[BackupRepositories] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1468; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1468 and current_version < 1469)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1469; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1469 and current_version < 1470)
BEGIN
	IF OBJECT_ID(N'[dbo].[Backup.Model.CloudSessions]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudSessions](
			[id] [uniqueidentifier] NOT NULL,
			[tenant_id] [uniqueidentifier] NOT NULL,
			[data_sent_to_client] [bigint] NOT NULL,
			[data_received_from_client] [bigint] NOT NULL,
			[session_type] [int] NOT NULL,
			[usn] [bigint] NOT NULL
		 CONSTRAINT [PK_Backup.Model.CloudSessions] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.CloudSessions] has been successfully created'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1470; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1470 and current_version < 1472)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1472; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1472 and current_version < 1473)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[after_delete_san_volume_luns]') AND type in (N'TR'))
	BEGIN
	exec sp_executesql @stat = N'
		CREATE TRIGGER [dbo].[after_delete_san_volume_luns]
		   ON  [dbo].[Backup.Model.SanVolumeLUNs]
		   AFTER DELETE
		AS 
		BEGIN
			SET NOCOUNT ON;
		
			DELETE FROM [dbo].[Backup.Model.SanVolumeByProxyInitiators] WHERE volume_lun_id IN (SELECT id FROM deleted)
			DELETE FROM [dbo].[Backup.Model.SanVolumeExportInfos] WHERE volume_lun_id IN (SELECT id FROM deleted)
		END'
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1473; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1473 and current_version < 1476)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1476; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1476)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'usn')
	BEGIN		
		alter table [dbo].[Backup.Model.SqlOIBs] add usn bigint NOT NULL DEFAULT 0
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.SqlOIBs]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.SqlOIBs''
	end
	'

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_SqlOIBs_usn' AND object_id = OBJECT_ID('Backup.Model.SqlOIBs'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_SqlOIBs_usn] ON [dbo].[Backup.Model.SqlOIBs]
		(
			[usn] ASC
		) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		PRINT 'New index {IX_SqlOIBs_usn} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1477; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1477)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.AwayStorages]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.AwayStorages](
			[id] [uniqueidentifier] NOT NULL,
			[repository_id] [uniqueidentifier] NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[job_id] [uniqueidentifier] NOT NULL,
			[backup_id] [uniqueidentifier] NOT NULL,
			[file_path] [nvarchar](1000) NOT NULL,
			[creation_time] [datetime] NOT NULL,
			[link_id] [uniqueidentifier] NULL,
			[storage_key_id] [uniqueidentifier] NOT NULL,
			[meta_key_id] [uniqueidentifier] NOT NULL,
		 CONSTRAINT [PK_Backup.Model.AwayStorages] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
			print 'Table [dbo].[Backup.Model.AwayStorages] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1478; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1478)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1479; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1479)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.SqlOIBs]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.SqlOIBs''
	end
	'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1480; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1480)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1481; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1481)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ProxyAgents]') AND [name] = 'host_id')
	BEGIN
		ALTER TABLE dbo.ProxyAgents ADD
			host_id uniqueidentifier NOT NULL CONSTRAINT DF_ProxyAgents_host_id DEFAULT '00000000-0000-0000-0000-000000000000'
		print 'New column {host_id} has been successfully added to [dbo].[ProxyAgents] table'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1482; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1482)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1483; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1483)
BEGIN
	PRINT 'Deleting duplicates from Soap_creds'
	DELETE FROM [dbo].[Soap_creds] WHERE [creds] = '00000000-0000-0000-0000-000000000000' OR [creds] IS NULL
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1484; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1484)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudRules]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudRules](
			[rule_id] [uniqueidentifier] NOT NULL,
			[gate_id] [uniqueidentifier] NOT NULL,
			[session_id] [uniqueidentifier] NOT NULL
		) ON [PRIMARY]
		
		print 'Table [dbo].[Backup.Model.CloudRules] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1485; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1485 and current_version < 1486)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tenants]') AND [name] = 'expire_time')
	BEGIN		
		alter table [dbo].[Tenants] add expire_time datetime
		print 'New column {expire_time} has been successfully added to [dbo].[Tenants] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1486; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1486 and current_version < 1489)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1489; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1489)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[TenantsResourcesQuota]') AND [name] = 'used_quota_gb')
	BEGIN
		ALTER TABLE [dbo].[TenantsResourcesQuota] ADD
			 [used_quota_gb] [int] NOT NULL DEFAULT 0;
		print 'New column {used_quota_gb} has been successfully added to [dbo].[TenantsResourcesQuota] table'		
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1490; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1490)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Tenants]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Tenants''
	end
	'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1491; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1491)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[TenantsResourcesQuota]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''TenantsResourcesQuota''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1492; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1492)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudGates]') AND [name] = 'disabled')
	BEGIN
		ALTER TABLE dbo.[Backup.Model.CloudGates] ADD
			[disabled] bit NOT NULL CONSTRAINT [DF_Backup.Model.CloudGates_disabled] DEFAULT 0
		print 'New column {disabled} has been successfully added to [dbo].[Backup.Model.CloudGates] table'		
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1493; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1493)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1494; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1494 and current_version < 1495)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1495; END
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1495)
BEGIN	

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[TenantsResourcesQuota]') AND [name] = 'friendly_name')
	BEGIN
		ALTER TABLE [dbo].[TenantsResourcesQuota] ADD
			 [friendly_name] nvarchar(MAX) NOT NULL DEFAULT 'Cloud quota';
		print 'New column {friendly_name} has been successfully added to [dbo].[TenantsResourcesQuota] table'		
    END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1496; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1496)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'partial_increment')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [partial_increment] bit not null DEFAULT 0
		print 'New column {partial_increment} has been successfully added to [dbo].[Backup.Model.Storages] table'		
	END		

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.AwayStorages]') AND [name] = 'partial_increment')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.AwayStorages] ADD [partial_increment] bit not null
		print 'New column {partial_increment} has been successfully added to [dbo].[Backup.Model.AwayStorages] table'		
	END		


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1497; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1497 and current_version < 1499)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1499; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1499)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'dbo.[Backup.Model.HostUpdates]') AND [name] = 'usn')
	BEGIN		
		ALTER TABLE dbo.[Backup.Model.HostUpdates] ADD 	usn bigint NOT NULL CONSTRAINT [DF_Backup.Model.HostUpdates_usn] DEFAULT 0
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.HostUpdates] table'
	END

	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'PK_Backup_Model_HostUpdates'))
	BEGIN
		ALTER TABLE dbo.[Backup.Model.HostUpdates] DROP CONSTRAINT PK_Backup_Model_HostUpdates
		PRINT 'Old PK key [PK_Backup_Model_HostUpdates] has been successfully dropped in [Backup.Model.HostUpdates]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HostUpdates]') AND [name] = 'id')
	BEGIN
		ALTER TABLE dbo.[Backup.Model.HostUpdates] ADD id uniqueidentifier NOT NULL DEFAULT newid()
			CONSTRAINT [PK_Backup.Model.HostUpdates] PRIMARY KEY CLUSTERED 
			(
				id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HostUpdates]'))
	BEGIN
		exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.HostUpdates'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1500; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1500)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tenants]') AND [name] = 'disabled')
	BEGIN
		ALTER TABLE [dbo].[Tenants] ADD [disabled] bit not null DEFAULT 0
		print 'New column {disabled} has been successfully added to [dbo].[Tenants] table'		
	END		

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudGates]') AND [name] = 'is_available')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudGates] ADD [is_available] bit not null DEFAULT 1
		print 'New column {is_available} has been successfully added to [dbo].[Backup.Model.CloudGates] table'		
	END		

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudGates]') AND ([name] = 'internal_port'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudGates]
		DROP COLUMN [internal_port]
		PRINT 'Column [internal_port] was successfully removed from [dbo].[Backup.Model.CloudGates]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudGates]') AND ([name] = 'external_port'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudGates]
		DROP COLUMN [external_port]
		PRINT 'Column [external_port] was successfully removed from [dbo].[Backup.Model.CloudGates]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudGates]') AND ([name] = 'flags'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudGates]
		DROP COLUMN [flags]
		PRINT 'Column [flags] was successfully removed from [dbo].[Backup.Model.CloudGates]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1501; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1501 and current_version < 1503)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1504; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1504)
BEGIN
	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 23 or [job_type] = 31)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = 'D2F0F072-1CA9-40C0-AFD1-56B3DE9AA366'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1505; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1505)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1506; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1506)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'dbo.[Backup.Model.GuestDatabase]') AND [name] = 'usn')
	BEGIN		
		ALTER TABLE dbo.[Backup.Model.GuestDatabase] ADD usn bigint NOT NULL DEFAULT 0
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1507; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1507 and current_version < 1508)
BEGIN
	DECLARE @sql NVARCHAR(MAX), @table NVARCHAR(512);
	SELECT @table = N'[Backup.Model.JobSessions]';
	SELECT @sql = 'ALTER TABLE ' + @table 
		+ ' DROP CONSTRAINT [' + name + '];'
		FROM sys.key_constraints
		WHERE [type] = 'PK'
		AND [parent_object_id] = OBJECT_ID(@table);
	EXEC sp_executeSQL @sql
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1508; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1508 and current_version < 1509)
BEGIN
	ALTER TABLE dbo.[Backup.Model.JobSessions] ADD CONSTRAINT
		[PK__Backup.Model.JobSessions_Id] PRIMARY KEY NONCLUSTERED 
		(
		id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1509; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1509 and current_version < 1510)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.JobSessions]') AND name = N'IX_Backup.Model.JobSessions_CreationTime')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Backup.Model.JobSessions_CreationTime] ON dbo.[Backup.Model.JobSessions]
		(
			creation_time
		) WITH( PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1510; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1510 and current_version < 1511)
BEGIN
	DECLARE @sql NVARCHAR(MAX), @table NVARCHAR(512);
	SELECT @table = N'[Backup.Model.BackupJobSessions]';
	SELECT @sql = 'ALTER TABLE ' + @table 
		+ ' DROP CONSTRAINT [' + name + '];'
		FROM sys.key_constraints
		WHERE [type] = 'PK'
		AND [parent_object_id] = OBJECT_ID(@table);
	EXEC sp_executeSQL @sql
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1511; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1511 and current_version < 1512)
BEGIN
	ALTER TABLE dbo.[Backup.Model.BackupJobSessions] ADD CONSTRAINT
		[PK__Backup.Model.BackupJobSessions_Id] PRIMARY KEY NONCLUSTERED 
		(
		id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1512; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1512 and current_version < 1513)
BEGIN
	DECLARE @sql NVARCHAR(MAX), @table NVARCHAR(512);
	SELECT @table = N'[Backup.Model.BackupTaskSessions]';
	SELECT @sql = 'ALTER TABLE ' + @table 
		+ ' DROP CONSTRAINT [' + name + '];'
		FROM sys.key_constraints
		WHERE [type] = 'PK'
		AND [parent_object_id] = OBJECT_ID(@table);
	EXEC sp_executeSQL @sql
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1513; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1513 and current_version < 1514)
BEGIN
	ALTER TABLE dbo.[Backup.Model.BackupTaskSessions] ADD CONSTRAINT
		[PK__Backup.Model.BackupTaskSessions_Id] PRIMARY KEY NONCLUSTERED 
		(
		id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1514; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1514 and current_version < 1515)
BEGIN
	ALTER TABLE dbo.[Backup.Model.OIBs] DROP CONSTRAINT FK_OIBs_OIBs
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1515; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1515 and current_version < 1516)
BEGIN
	DECLARE @sql NVARCHAR(MAX), @table NVARCHAR(512);
	SELECT @table = N'[Backup.Model.OIBs]';
	SELECT @sql = 'ALTER TABLE ' + @table 
		+ ' DROP CONSTRAINT [' + name + '];'
		FROM sys.key_constraints
		WHERE [type] = 'PK'
		AND [parent_object_id] = OBJECT_ID(@table);
	EXEC sp_executeSQL @sql
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1516; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1516 and current_version < 1517)
BEGIN
	ALTER TABLE dbo.[Backup.Model.OIBs] ADD CONSTRAINT
		[PK__Backup.Model.OIBs_Id] PRIMARY KEY NONCLUSTERED 
		(
		id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1517; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1517 and current_version < 1518)
BEGIN
	ALTER TABLE dbo.[Backup.Model.OIBs] ADD CONSTRAINT
	FK_OIBs_OIBs FOREIGN KEY
	(
	link_id
	) REFERENCES dbo.[Backup.Model.OIBs]
	(
	id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1518; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1518 and current_version < 1519)
BEGIN
	ALTER TABLE dbo.[Backup.Model.OIBs] DROP CONSTRAINT FK_OIBs_Points
	ALTER TABLE dbo.[Backup.Model.Points] DROP CONSTRAINT FK_Points_Points
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1519; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1519 and current_version < 1520)
BEGIN
	DECLARE @sql NVARCHAR(MAX), @table NVARCHAR(512);
	SELECT @table = N'[Backup.Model.Points]';
	SELECT @sql = 'ALTER TABLE ' + @table 
		+ ' DROP CONSTRAINT [' + name + '];'
		FROM sys.key_constraints
		WHERE [type] = 'PK'
		AND [parent_object_id] = OBJECT_ID(@table);
	EXEC sp_executeSQL @sql
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1520; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1520 and current_version < 1521)
BEGIN
	ALTER TABLE dbo.[Backup.Model.Points] ADD CONSTRAINT
		[PK__Backup.Model.Points_Id] PRIMARY KEY NONCLUSTERED 
		(
		id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1521; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1521 and current_version < 1522)
BEGIN
	ALTER TABLE dbo.[Backup.Model.OIBs] ADD CONSTRAINT
	FK_OIBs_Points FOREIGN KEY
	(
	point_id
	) REFERENCES dbo.[Backup.Model.Points]
	(
	id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1522; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1522 and current_version < 1523)
BEGIN
	ALTER TABLE dbo.[Backup.Model.Points] ADD CONSTRAINT
	FK_Points_Points FOREIGN KEY
	(
	link_id
	) REFERENCES dbo.[Backup.Model.Points]
	(
	id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1523; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1523 and current_version < 1524)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1524; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1524 and current_version < 1525)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'backup_meta')
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [backup_meta] [nvarchar](max) NULL
		print 'New column {backup_meta} has been successfully added to [dbo].[Tape.backup_sets] table'		
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1525; END
END	
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1525 and current_version < 1528)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1528; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1528 and current_version < 1530)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1530; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1530)
BEGIN

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[TenantsResourcesQuota]') AND [name] = 'quota_gb')
	BEGIN
		exec sp_rename '[dbo].[TenantsResourcesQuota].[quota_gb]', 'quota_mb', 'COLUMN'
		print 'Column {quota_gb} has been successfully renamed to {quota_mb} in [dbo].[TenantsResourcesQuota] table'	
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[TenantsResourcesQuota]') AND [name] = 'used_quota_gb')
	BEGIN
		exec sp_rename '[dbo].[TenantsResourcesQuota].[used_quota_gb]', 'used_quota_mb', 'COLUMN'
		print 'Column {used_quota_gb} has been successfully renamed to {used_quota_mb} in [dbo].[TenantsResourcesQuota] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1531; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1531)
BEGIN

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.VeeamZIPRetention]') AND [name] = 'retain_days')
	BEGIN
		ALTER TABLE dbo.[Backup.Model.VeeamZIPRetention] DROP COLUMN retain_days
		print 'Column {retain_days} has been successfully dropped from [dbo].[Backup.Model.VeeamZIPRetention] table'	
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.VeeamZIPRetention]') AND [name] = 'backup_info')
	BEGIN
		ALTER TABLE dbo.[Backup.Model.VeeamZIPRetention] DROP COLUMN backup_info
		print 'Column {backup_info} has been successfully dropped from [dbo].[Backup.Model.VeeamZIPRetention] table'	
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.VeeamZIPRetention]') AND [name] = 'creation_time')
	BEGIN
		ALTER TABLE dbo.[Backup.Model.VeeamZIPRetention] DROP COLUMN creation_time
		print 'Column {creation_time} has been successfully dropped from [dbo].[Backup.Model.VeeamZIPRetention] table'	
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.VeeamZIPRetention]') AND [name] = 'retain_datetime')
	BEGIN
		ALTER TABLE dbo.[Backup.Model.VeeamZIPRetention] ADD retain_datetime datetime NULL
		print 'Column {retain_datetime} has been successfully added to [dbo].[Backup.Model.VeeamZIPRetention] table'	
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1532; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1532)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1533; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1533 and current_version < 1538)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1538; END
	END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1538)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1539; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1539 and current_version < 1541)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1541; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1541)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'compatibility')
	BEGIN		
		alter table [dbo].[Backup.Model.GuestDatabase] add compatibility int not null default(0)
		print 'New column {compatibility} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1542; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1542 and current_version < 1547)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'modified_by')
	BEGIN		
		alter table [dbo].[BJobs] add modified_by [nvarchar](512) NOT NULL DEFAULT ''
		print 'New column {modified_by} has been successfully added to [dbo].[BJobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1547; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1547 and current_version < 1548)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'parent_session_id')
	BEGIN		
		alter table [dbo].[Backup.Model.RestoreJobSessions] add 
			parent_session_id [uniqueidentifier] DEFAULT NULL
		print 'New column {parent_session_id} has been successfully added to [dbo].[Backup.Model.RestoreJobSessions]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1548; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1548 and current_version < 1549)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1549; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1548 and current_version < 1549)
BEGIN
IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'parent_session_id')
	BEGIN
		update 	[dbo].[Backup.Model.RestoreJobSessions]
		set parent_session_id = N'00000000-0000-0000-0000-000000000000'
		where parent_session_id = NULL
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1549; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1549 and current_version < 1551)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1551; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1551)
BEGIN
	IF OBJECT_ID(N'[dbo].[Backup.Model.ForeignRepositories]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ForeignRepositories](
			[id] [uniqueidentifier] NOT NULL,
			[provider_id] [uniqueidentifier] NOT NULL,
			[foreign_repository_id] [uniqueidentifier] NOT NULL,
			[relative_path] NVARCHAR(MAX) NOT NULL DEFAULT '',
			[is_available] [bit] NOT NULL,
			[usn] bigint NOT NULL
		) 
		PRINT 'Create table [dbo].[Backup.Model.ForeignRepositories]'
	END

	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ForeignRepositoryProviders]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ForeignRepositoryProviders](
			id uniqueidentifier NOT NULL,
			name nvarchar(MAX) NOT NULL,
			port int NOT NULL,
			creds_id uniqueidentifier NOT NULL,
			flags bigint NOT NULL,
			options xml NOT NULL,
			usn bigint NOT NULL,
		CONSTRAINT [PK_Backup.Model.ForeignRepositoryProviders] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
		ALTER TABLE [dbo].[Backup.Model.ForeignRepositoryProviders] ADD  CONSTRAINT [DF_Backup.Model.ForeignRepositoryProviders_id]  DEFAULT (newid()) FOR [id]

		PRINT 'Table [dbo].[Backup.Model.ForeignRepositoryProviders] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1552; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1552 and current_version < 1556)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1556; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1556 and current_version < 1558)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessions]') AND [name] = 'tenant_name')
	BEGIN		
		alter table [dbo].[Backup.Model.CloudSessions] add tenant_name [nvarchar](MAX) NOT NULL DEFAULT ''
		print 'New column {tenant_name} has been successfully added to [dbo].[Backup.Model.CloudSessions] table'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessions]') AND [name] = 'tenant_id')
	BEGIN
		ALTER TABLE dbo.[Backup.Model.CloudSessions] DROP COLUMN tenant_id
		print 'Column {tenant_id} has been successfully dropped from [dbo].[Backup.Model.CloudSessions] table'	
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1558; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1558 and current_version < 1559)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1559; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1559 and current_version < 1560)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudRepositories]') AND [name] = 'real_path')
	BEGIN
		
		declare @default sysname
		declare @sql nvarchar(max)

		set @sql = N'alter table [Backup.Model.CloudRepositories] drop constraint [' + (select name 
		from sys.default_constraints
		where parent_object_id = object_id('[dbo].[Backup.Model.CloudRepositories]')
		AND type = 'D'
		AND parent_column_id = (
			select column_id 
			from sys.columns 
			where object_id = object_id('[dbo].[Backup.Model.CloudRepositories]')
			and name = 'real_path'
		)) + ']'

		exec sp_executesql @sql
		
		ALTER TABLE dbo.[Backup.Model.CloudRepositories] DROP COLUMN real_path
		print 'Column {real_path} has been successfully dropped from [dbo].[Backup.Model.CloudRepositories] table'	
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1560; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1560 and current_version < 1562)
BEGIN

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1562; END
END
GO

--
-----------------------------------------------------
-- 8.0.0.266
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1562)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.DataDomainRepositoryServers]') AND [name] = 'connection_type')
	BEGIN		
		alter table [dbo].[Backup.Model.DataDomainRepositoryServers] add connection_type int NOT NULL DEFAULT 0
		print 'New column {connection_type} has been successfully added to [dbo].[Backup.Model.DataDomainRepositoryServers] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1563; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1563)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_versions]') AND [name] = 'corrupted')
	BEGIN		
		ALTER TABLE [dbo].[Tape.file_versions] ADD corrupted [bit] NOT NULL DEFAULT 0
		PRINT 'New column {corrupted} has been successfully added to [dbo].[Tape.file_versions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1564; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1564 and current_version < 1572)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1572; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1572)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'size')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.SqlOIBs] ADD size [bigint] NOT NULL DEFAULT 0
		PRINT 'New column {size} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1573; END
END
GO
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1573 and current_version < 1574)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1574; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1574)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Backup.Model.SanSnapshots]') AND [name] = 'is_removed')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanSnapshots] add is_removed [bit] NOT NULL DEFAULT 0
		PRINT 'New column {is_removed} has been successfully added to [dbo].[Backup.Model.SanSnapshots] table'
	END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1575; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1575)
BEGIN
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	INSERT INTO [dbo].[Backup.Model.Session.Filters] ([id],[name],[data],[usn])
	VALUES('DB758D28-2900-4E98-BB89-2CAFE799F0A3',
		   'Cloud',
		   '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 300 OR [job_type] = 5000)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
		   ,@usn)

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1576; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1576 AND current_version < 1582)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.OibMounts]') AND type in (N'U'))
	BEGIN

		CREATE TABLE [dbo].[Backup.OibMounts](
		[id] [uniqueidentifier] NOT NULL,	
		[state] [int] NOT NULL,
		[oib_id] [uniqueidentifier] NOT NULL,
		 CONSTRAINT [PK_Backup.OibMounts] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END	


	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.OibMountsPerLeases]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.OibMountsPerLeases](
		[id] [uniqueidentifier] NOT NULL,	
		[mount_id] [uniqueidentifier] NOT NULL,
		[lease_id] [uniqueidentifier] NOT NULL,
		 CONSTRAINT [PK_Backup.OibMountsPerLeases] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END	
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1582; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1582 and current_version < 1583)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1583; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1583 and current_version < 1585)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1585; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1585 and current_version < 1589)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1589; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1589)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Ssh_creds]') AND [name] = 'auth_type')
	BEGIN
		ALTER TABLE [dbo].[Ssh_creds] add auth_type [int] NOT NULL DEFAULT 0
		PRINT 'New column {auth_type} has been successfully added to [dbo].[Ssh_creds] table'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Ssh_creds]') AND [name] = 'private_key')
	BEGIN
		ALTER TABLE [dbo].[Ssh_creds] add private_key nvarchar(max)
		PRINT 'New column {private_key} has been successfully added to [dbo].[Ssh_creds] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1590; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1590 and current_version < 1592)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1592; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1592)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Tape.tape_mediums]') AND [name] = 'original_library_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [original_library_id] [uniqueidentifier] DEFAULT NULL
		PRINT 'New column {original_library_id} has been successfully added to [dbo].[Tape.tape_mediums] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[Tape.tape_mediums]') AND [name] = 'original_media_pool_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [original_media_pool_id] [uniqueidentifier] DEFAULT NULL
		PRINT 'New column {original_media_pool_id} has been successfully added to [dbo].[Tape.tape_mediums] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1593; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1593 and current_version < 1595)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1595; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1595)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'backup_set_id_media_sequence_number' AND object_id = OBJECT_ID('[dbo].[Tape.directory_versions]'))
	BEGIN
		CREATE NONCLUSTERED INDEX backup_set_id_media_sequence_number ON [dbo].[Tape.directory_versions] ([backup_set_id],[media_sequence_number]) INCLUDE ([directory_id],[creation_time],[last_write_time],[attributes],[format_logical_address])
		PRINT 'New index {backup_set_id_media_sequence_number} has been successfully added to [dbo].[Tape.directory_versions] table'
	END

	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'backup_set_id_media_sequence_number' AND object_id = OBJECT_ID('[dbo].[Tape.file_parts]'))
	BEGIN
		CREATE NONCLUSTERED INDEX backup_set_id_media_sequence_number ON [dbo].[Tape.file_parts] ([backup_set_id],[media_sequence_number]) INCLUDE ([file_id])
		PRINT 'New index {backup_set_id_media_sequence_number} has been successfully added to [dbo].[Tape.file_parts] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1596; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1596 and current_version < 1598)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1598; END
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1598)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVms]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudVms](
			[id] [bigint] IDENTITY(1,1) NOT NULL,
			[resource_quota_id] [uniqueidentifier] NOT NULL,
			[vm_uuid] [nvarchar](256) NOT NULL,
		 CONSTRAINT [PK_Backup.Model.CloudVms] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.CloudVms]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudVms_TenantsResourcesQuota] FOREIGN KEY([resource_quota_id])
		REFERENCES [dbo].[TenantsResourcesQuota] ([id])
		ON DELETE CASCADE
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1599; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1599 and current_version < 1602)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1602; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1602)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'creation_usn')
	BEGIN
		alter table [dbo].[Backup.Model.SqlOIBs] add creation_usn bigint default 0 not null
	END
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1603; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1603)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'is_corrupted')
	BEGIN
		alter table [dbo].[Backup.Model.SqlOIBs] add is_corrupted bit default 0 not null
	END
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1604; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1604 and current_version < 1608)
BEGIN
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1608; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1608)
BEGIN
	-- Add creation_usn index to SqlOIBs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SqlOIBs_creation_usn' AND object_id = OBJECT_ID('[Backup.Model.SqlOIBs]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_SqlOIBs_creation_usn] ON [dbo].[Backup.Model.SqlOIBs]
		(
			[creation_usn] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_SqlOIBs_creation_usn} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	-- Add guest_db_id index to SqlOIBs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SqlOIBs_guest_db_id' AND object_id = OBJECT_ID('[Backup.Model.SqlOIBs]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_SqlOIBs_guest_db_id] ON [dbo].[Backup.Model.SqlOIBs]
		(
			[guest_db_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_SqlOIBs_guest_db_id} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	-- Add obj_id index to SqlOIBs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SqlOIBs_obj_id' AND object_id = OBJECT_ID('[Backup.Model.SqlOIBs]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_SqlOIBs_obj_id] ON [dbo].[Backup.Model.SqlOIBs]
		(
			[obj_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_SqlOIBs_obj_id} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1609; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1609 and current_version < 1612)
BEGIN
	-- Create table Backup.Security.Repositories.AcountLinks
	IF OBJECT_ID(N'[dbo].[Backup.Security.Repositories.AcountLinks]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Security.Repositories.AcountLinks](
			repository_id uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Security.Repositories.AcountLinks_BackupRepositories] FOREIGN KEY REFERENCES [dbo].[BackupRepositories] (id) ON DELETE CASCADE,
			account_id uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Security.Repositories.AcountLinks_Backup.Security.Accounts] FOREIGN KEY REFERENCES [dbo].[Backup.Security.Accounts] (id) ON DELETE CASCADE,
			flags bigint NOT NULL,
			CONSTRAINT [PK_Backup.Security.Repositories.AcountLinks] PRIMARY KEY CLUSTERED (repository_id, account_id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Security.Repositories.AcountLinks] has been successfully created'
	END

	-- Create table Backup.Security.Backups.AcountLinks
	IF OBJECT_ID(N'[dbo].[Backup.Security.Backups.Ownerships]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Security.Backups.Ownerships](
			backup_id uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Security.Backups.Ownerships_Backup.Model.Backups] FOREIGN KEY REFERENCES [dbo].[Backup.Model.Backups] (id) ON DELETE CASCADE,
			account_id uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Security.Backups.Ownerships_Backup.Security.Accounts] FOREIGN KEY REFERENCES [dbo].[Backup.Security.Accounts] (id) ON DELETE CASCADE,
			flags bigint NOT NULL,
			CONSTRAINT [PK_Backup.Security.Backups.Ownerships] PRIMARY KEY CLUSTERED (backup_id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Security.Backups.Ownerships] has been successfully created'
	END

	--IF TYPE_ID(N'[dbo].[GuidTableType]') IS NULL -- NotSupported(SQLServer2008+)
	--BEGIN
	--	CREATE TYPE [dbo].[GuidTableType] AS TABLE
	--		(Value uniqueidentifier)
	--END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1612; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1612)
BEGIN
	DECLARE @viPlatform int
	DECLARE @vcdPlatform int
	DECLARE @allIdeDisks nvarchar(max) 
	DECLARE @systemOnlyDiskFilter_afterUpd2Patch nvarchar(max) 
	DECLARE @systemOnlyDiskFilter_createdInPatch nvarchar(max) 
	SET @viPlatform = 0
	SET @vcdPlatform = 4
	SET @allIdeDisks = ';3000;3001;3002;3003'
	SET @systemOnlyDiskFilter_afterUpd2Patch = '2000;16000;16001;16002;16003;16004;16005;16006;16008;16009;16010;16011;16012;16013;16014;16015;16016;16017;16018;16019;16020;16021;16022;16023;16024;16025;16026;16027;16028;16029;16030;16031;16032;16033;16034;16035;16036;16038;16039;16040;16041;16042;16043;16044;16045;16046;16047;16048;16049;16050;16051;16052;16053;16054;16055;16056;16057;16058;16059;16060;16061;16062;16063;16064;16065;16066;16068;16069;16070;16071;16072;16073;16074;16075;16076;16077;16078;16079;16080;16081;16082;16083;16084;16085;16086;16087;16088;16089;16090;16091;16092;16093;16094;16095;16096;16098;16099;16100;16101;16102;16103;16104;16105;16106;16107;16108;16109;16110;16111;16112;16113;16114;16115;16116;16117;16118;16119'
								--^after sql upgrade from db version 1195
	SET @systemOnlyDiskFilter_createdInPatch = '2000'
	
	UPDATE 
		[dbo].[ObjectsInJobs] 
	SET 
		[disk_filter] = [disk_filter] + @allIdeDisks 
	WHERE 
		[disk_filter] <> @systemOnlyDiskFilter_afterUpd2Patch
		AND [disk_filter] <> @systemOnlyDiskFilter_createdInPatch
		AND [platform] IN (@viPlatform, @vcdPlatform)
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1613; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1613)
BEGIN
	alter table [Tape.media_vaults] add constraint UQ_name unique (name)
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1614; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1614)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1615; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1615)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.AwayStorages]') AND [name] = 'rotated_drive_id')
	BEGIN
		alter table [dbo].[Backup.Model.AwayStorages] add rotated_drive_id uniqueidentifier DEFAULT ('00000000-0000-0000-0000-000000000000') NOT NULL
	END

	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.RotatedDrives]') AND type in (N'U'))
		CREATE TABLE [dbo].[Backup.Model.RotatedDrives]
		(
		id uniqueidentifier NOT NULL,
		repository_id uniqueidentifier NOT NULL,
		volume_guid nvarchar(100) NOT NULL
		)  ON [PRIMARY]		

		ALTER TABLE dbo.[Backup.Model.RotatedDrives] ADD CONSTRAINT
			[PK_Backup.Model.RotatedDrives] PRIMARY KEY CLUSTERED 
			(
				id
			) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		
		CREATE NONCLUSTERED INDEX [IX_Backup.Model.RotatedDrives] ON dbo.[Backup.Model.RotatedDrives]
		(
		repository_id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1616; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1616)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RotatedDrives]') AND [name] = 'volume_name')
	BEGIN
		alter table [dbo].[Backup.Model.RotatedDrives] add volume_name nvarchar(255) 
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RotatedDrives]') AND [name] = 'is_current')
	BEGIN
		alter table [dbo].[Backup.Model.RotatedDrives] add is_current bit not null 
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1617; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1617)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlBackupIntervalSess]') AND [name] = 'end_time')
	BEGIN		
		alter table [dbo].[Backup.Model.SqlBackupIntervalSess] add end_time datetime not null default ''
		print 'New column {end_time} has been successfully added to [dbo].[Backup.Model.SqlBackupIntervalSess] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1618; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1618)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1619; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1619)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'encryption_type')
	BEGIN		
		alter table [dbo].[Tape.backup_sets] add encryption_type tinyint not null default ((0))
		print 'New column {encryption_type} has been successfully added to [dbo].[Tape.backup_sets] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1620; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1620)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BackupRepositories]') AND [name] = 'end_point_key_id')
	BEGIN		
		ALTER TABLE [dbo].[BackupRepositories] ADD end_point_key_id uniqueidentifier NOT NULL CONSTRAINT DF_BackupRepositories_end_point_key_id DEFAULT '00000000-0000-0000-0000-000000000000'

		print 'New column {end_point_key_id} has been successfully added to [dbo].[BackupRepositories] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1621; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1621 AND current_version < 1623)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1623; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1623)
BEGIN
	UPDATE [dbo].[Tape.tape_mediums] SET block_size = 0

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1624; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1624 AND current_version < 1627)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1627; END
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1627)
BEGIN
	EXEC dbo.sp_executesql
		N'ALTER TRIGGER u_Backup_Model_OIBs ON [dbo].[Backup.Model.OIBs] FOR UPDATE
		AS
		BEGIN
			DECLARE @id uniqueidentifier
			SELECT @id = id FROM INSERTED
			IF NOT @id IS NULL
			BEGIN
				UPDATE [dbo].[ReplicationInfo] SET usn = usn + 1
			END
		END'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1628; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1628 AND current_version < 1639)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1639; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1629 AND current_version < 1640)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1640; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1640)
BEGIN
	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 0 OR [job_type] = 40 OR [job_type] = 52)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = '83B702D1-2C19-4EC1-BB5E-CB701CD77273'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1641; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1641)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1642; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1642)
BEGIN

    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.AlwaysOnGroups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.AlwaysOnGroups](
			[id] [uniqueidentifier] NOT NULL,
			[group_id] [uniqueidentifier] NOT NULL,
			[group_name] [nvarchar](max) NOT NULL
	    CONSTRAINT [PK_AlwaysOnGroups] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		print 'Table [dbo].[Backup.Model.AlwaysOnGroups] has been successfully created'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.OibsWithAlwaysOnGroups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.OibsWithAlwaysOnGroups](
			[oib_id] [uniqueidentifier] NOT NULL,
			[group_id] [uniqueidentifier] NOT NULL,
			[is_primary] [bit] NOT NULL
	    CONSTRAINT [PK_OibsWithAlwaysOnGroups] PRIMARY KEY CLUSTERED 
		(
			[oib_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		print 'Table [dbo].[Backup.Model.OibsWithAlwaysOnGroups] has been successfully created'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.AlwaysOnGuestDatabases]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.AlwaysOnGuestDatabases](
			[db_id] [uniqueidentifier] NOT NULL,
			[group_db_id] [uniqueidentifier] NOT NULL,
			[group_id] [uniqueidentifier] NOT NULL,
			[db_name] [nvarchar](max) NOT NULL
	    CONSTRAINT [PK_AlwaysOnGuestDatabases] PRIMARY KEY CLUSTERED 
		(
			[db_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		print 'Table [dbo].[Backup.Model.AlwaysOnGuestDatabases] has been successfully created'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'group_db_id')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.GuestDatabase] ADD [group_db_id] uniqueidentifier not null default '00000000-0000-0000-0000-0000000000000000'
		PRINT 'New column {[group_db_id]} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1643; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1643 AND current_version < 1646)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1646; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1646)
BEGIN
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.OibsWithAlwaysOnGroups]') AND type in (N'U'))
	BEGIN
		DROP TABLE [dbo].[Backup.Model.OibsWithAlwaysOnGroups]
		print 'Table [dbo].[Backup.Model.OibsWithAlwaysOnGroups] has been dropped'

		CREATE TABLE [dbo].[Backup.Model.OibsWithAlwaysOnGroups](
			[id] [uniqueidentifier] NOT NULL,
			[oib_id] [uniqueidentifier] NOT NULL,
			[group_id] [uniqueidentifier] NOT NULL,
			[is_primary] [bit] NOT NULL
	    CONSTRAINT [PK_OibsWithAlwaysOnGroups] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		print 'Table [dbo].[Backup.Model.OibsWithAlwaysOnGroups] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1647; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1647)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProductUpdates]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[ProductUpdates](
			[id] [uniqueidentifier] NOT NULL,
			[product] [nvarchar](255) NOT NULL,
			[version1] [int] NOT NULL,
			[version2] [int] NOT NULL,
			[version3] [int] NOT NULL,
			[version4] [int] NOT NULL,
			[description] [nvarchar](max) NOT NULL,
			[product_code] [uniqueidentifier] NOT NULL,
			[component_code] [uniqueidentifier] NOT NULL,
			[url] [nvarchar](max) NOT NULL,
			[updatable_from_id] [uniqueidentifier] NOT NULL,
			[state] [smallint] NOT NULL,
			[state_update_date] [datetime] NULL,
			[tries] [smallint] NOT NULL
		) ON [PRIMARY] 		
			
		print 'Table [dbo].[ProductUpdates] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1648; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1648)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'restored_obj_id')
	BEGIN
		alter table [dbo].[Backup.Model.RestoreJobSessions] add restored_obj_id [uniqueidentifier] DEFAULT NULL
		print 'New column {restored_obj_id} has been successfully added to [dbo].[Backup.Model.RestoreJobSessions]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1649; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1649 AND current_version < 1654)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1654; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1654)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'group_db_id')
	BEGIN		
		alter table [dbo].[Backup.Model.SqlOIBs] add group_db_id uniqueidentifier not null DEFAULT '00000000-0000-0000-0000-0000000000000000'
		print 'New column {[group_db_id]} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1655; END
END
GO

--
-----------------------------------------------------
-- 8.0.0.427
-----------------------------------------------------
--
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1655)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[VmssVms]') AND [name] = 'redo_store_ref')
	BEGIN		
		alter table [dbo].[VmssVms] add redo_store_ref NVARCHAR(255) not null DEFAULT ''
		print 'New column {[redo_store_ref]} has been successfully added to [dbo].[Backup.Model.VmssVms] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1656; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1656 AND current_version < 1658)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1658; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1658)
BEGIN
	PRINT 'Upgrading e-mail credentials'

	DECLARE @id uniqueidentifier
	DECLARE @options xml

	SET @id = '91BB166B-E197-48F7-A430-7904E013B30B'

	SELECT
		@options = [value]
	FROM
		[dbo].[Options]
	WHERE
		[id] = @id

	IF (@options IS NOT NULL)
	BEGIN
		PRINT 'Found embedded e-mail options'
		PRINT 'XML: ' + cast(@options as nvarchar(max))

		IF (@options.exist('*/Credentials/UserName') = 1)
		BEGIN
			PRINT 'Upgrade of embedded e-mail credentials is required'

			DECLARE @user_name nvarchar(255)
			DECLARE @password nvarchar(max)

			SELECT
				@user_name = @options.value('(/*/Credentials/UserName)[1]', 'nvarchar(255)'),
				@password = @options.value('(/*/Credentials/Password)[1]', 'nvarchar(max)')
			WHERE
				@options.exist('*/Credentials/UserName') = 1

			PRINT 'Deleting embedded e-mail credentials'
			SET @options.modify('delete /*/Credentials')
			PRINT 'XML: ' + cast(@options as nvarchar(max))

			DECLARE @credentials_id uniqueidentifier

			IF (@user_name IS NULL)
			BEGIN
				SET @credentials_id = (SELECT CAST(CAST(0 AS BINARY) AS UNIQUEIDENTIFIER))
			END
			ELSE
			BEGIN
				SET @credentials_id = NEWID()
			END

			SET @options.modify('insert <CredentialsId>{{{sql:variable("@credentials_id")}}}</CredentialsId> as first into (/*)[1]')
			PRINT 'XML: ' + cast(@options as nvarchar(max))

			PRINT 'Updating e-mail options'
			UPDATE
				[dbo].[Options]
			SET
				[value] = @options
			WHERE
				[id] = @id

			IF (@user_name IS NOT NULL)
			BEGIN
				PRINT 'Found embedded e-mail credentials'
				PRINT 'User name: ' + @user_name
				PRINT 'Password: ' + @password

				PRINT 'Creating credentials'
				INSERT INTO
					[dbo].[Credentials]
				(
					[id],
					[user_name],
					[password],
					[usn],
					[description],
					[visible]
				)
				VALUES
				(
					@credentials_id,
					@user_name,
					@password,
					0,
					'Created by ' + ORIGINAL_LOGIN() + ' at ' + convert(varchar, GETDATE(), 101) + ' ' + convert(varchar, GETDATE(), 108),
					1
				)
			END
		END
		ELSE
		BEGIN
			PRINT 'Upgrade of embedded e-mail credentials is not required'
		END
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1659; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1659)
BEGIN
	DECLARE @supportExpirationNotification nvarchar(10)

	SET @supportExpirationNotification =
	(
		SELECT
			CASE cast([value] AS nvarchar(max))
				WHEN 'True' THEN 'False'
				ELSE 'True'
			END
		FROM
			[dbo].[Options]
		WHERE	
			[id] = '7EE590BF-99CA-4193-A5F2-9B542AD2A628'
	)

	IF (@supportExpirationNotification IS NULL)
	BEGIN
		SET @supportExpirationNotification = 'True'
	END

	DELETE FROM
		[dbo].[Options]
	WHERE id IN ('7EE590BF-99CA-4193-A5F2-9B542AD2A628', '2FD5E0CF-46A1-4822-85AE-CFA0032D0D9A')

	INSERT INTO [dbo].[Options] ([id], [name], [value])
	SELECT '7EE590BF-99CA-4193-A5F2-9B542AD2A628', 'SupportExpirationNotifications', @supportExpirationNotification
	UNION ALL
	SELECT '2FD5E0CF-46A1-4822-85AE-CFA0032D0D9A', 'ProductUpdatesNotifications', 'True'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1660; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1660 AND current_version < 1664)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1664; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1664)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'family_guid')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.GuestDatabase] ADD [family_guid] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {[family_guid]} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1665; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1665 AND current_version < 1666)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1666; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1666 AND current_version < 1668)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JobState]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[JobState](
				[job_id] [uniqueidentifier] NOT NULL,
				[state] [xml] NOT NULL
			 CONSTRAINT [PK_JobState] PRIMARY KEY CLUSTERED 
			(
				[job_id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1668; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1668 AND current_version < 1670)
BEGIN
    IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND ([name] = 'post_command_run_count'))
	BEGIN
		IF NOT EXISTS (SELECT * FROM [dbo].[JobState])
		BEGIN
			PRINT 'Copying non-zero [post_command_run_count] values from [dbo].[BJobs] table to [dbo].[JobState] table'

			declare @copy_statement nvarchar(max)
			set @copy_statement=N'
				INSERT INTO [dbo].[JobState]
					SELECT
						[id] as job_id,
						CAST(''<JobState><ScriptCommandRunCount>''+CONVERT(varchar(20), [post_command_run_count], 0)+''</ScriptCommandRunCount></JobState>'' as xml)
					FROM [dbo].[BJobs]
					WHERE
						[dbo].[BJobs].[post_command_run_count] <> 0
			'
			exec sp_executesql @copy_statement
			PRINT '[post_command_run_count] values successfully copied'
		END

		DECLARE @constr sysname	;
		SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[BJobs]') and [name] = 'post_command_run_count')
		IF (@constr IS NOT NULL)
		BEGIN		
			DECLARE @statement NVARCHAR(255);					
			SET @statement = N'ALTER TABLE [dbo].[BJobs] DROP CONSTRAINT [' + @constr + ']'		
			exec sp_executesql @statement
			PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[BJobs]'
		END

		ALTER TABLE [dbo].[BJobs]
			DROP COLUMN [post_command_run_count]	
		PRINT 'Column [post_command_run_count] was successfully removed from [dbo].[BJobs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1670; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1670 AND current_version < 1674)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1675; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1675)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1676; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1676)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobState]') AND [name] = 'script_command_run_count')
	BEGIN
		ALTER TABLE [dbo].[JobState] ADD [script_command_run_count] int not null DEFAULT (0)
		PRINT 'New column {[script_command_run_count]} has been successfully added to [dbo].[JobState] table'

		IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobState]') AND [name] = 'state')
		BEGIN		
			declare @statement nvarchar(max)
			set @statement = N'
				PRINT ''Copying [script_command_run_count] values from [state] column to [script_command_run_count] column''
				UPDATE [dbo].[JobState]
				SET [script_command_run_count] = 
					REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(CONVERT(VARCHAR(max), [state]), ''<JobState>'', ''''), ''</JobState>'', ''''), ''<ScriptCommandRunCount>'', ''''), ''</ScriptCommandRunCount>'', ''''), ''<JobState/>'', '''')

				ALTER TABLE [dbo].[JobState]
					DROP COLUMN [state]
			'
			exec sp_executesql @statement
			print 'Column {state} has been successfully removed from [dbo].[JobState] table'
		END
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobState]') AND [name] = 'usn')
	BEGIN
		ALTER TABLE [dbo].[JobState] ADD [usn] int not null DEFAULT (0)
		PRINT 'New column {[usn]} has been successfully added to [dbo].[JobState] table'
	END

	-- Add creation_usn index to SqlOIBs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_JobState_usn' AND object_id = OBJECT_ID('[JobState]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_JobState_usn] ON [dbo].[JobState]
		(
			[usn] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_JobState_usn} has been successfully added to [dbo].[JobState] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1677; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1677)
BEGIN

	IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Backup.Model.CloudVms_TenantsResourcesQuota]') AND parent_object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVms]'))
	BEGIN		
		DECLARE @statement NVARCHAR(255);					
		SET @statement = N'ALTER TABLE [dbo].[Backup.Model.CloudVms] DROP CONSTRAINT [FK_Backup.Model.CloudVms_TenantsResourcesQuota]'		
		exec sp_executesql @statement
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVms]') AND ([name] = 'resource_quota_id'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudVms] DROP COLUMN [resource_quota_id] 
		PRINT 'Column [resource_quota_id] was successfully removed from [Backup.Model.CloudVms]'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVmsOnQuotas]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudVmsOnQuotas](
			[vm_id] [bigint] NOT NULL,
			[resource_quota_id] [uniqueidentifier] NOT NULL)

		ALTER TABLE [dbo].[Backup.Model.CloudVmsOnQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudVmsOnQuotas_TenantsResourcesQuota] FOREIGN KEY([resource_quota_id])
		REFERENCES [dbo].[TenantsResourcesQuota] ([id])
		ON DELETE CASCADE

		ALTER TABLE [dbo].[Backup.Model.CloudVmsOnQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudVmsOnQuotas_CloudVms] FOREIGN KEY([vm_id])
		REFERENCES [dbo].[Backup.Model.CloudVms] ([id])
		ON DELETE CASCADE

		CREATE UNIQUE NONCLUSTERED INDEX [IX_Backup.Model.CloudVmsOnQuotas] ON dbo.[Backup.Model.CloudVmsOnQuotas]
		(
			vm_id,
			resource_quota_id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		PRINT 'Table [Backup.Model.CloudVmsOnQuotas] was successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1678; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1678)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1679; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1679)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.JobSessions]') AND [name] = 'stop_details')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.JobSessions] ADD [stop_details] nvarchar(1024) null
		PRINT 'New column {[stop_details]} has been successfully added to [dbo].[Backup.Model.JobSessions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1680; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1680)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanStorageLocks]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.SanStorageLocks](
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[san_host_id] [uniqueidentifier] NOT NULL,
			[job_sess_id] [uniqueidentifier] NOT NULL
		)
		print 'Table [dbo].[Backup.Model.SanSanStorageLocks] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1681; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1681)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1683; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1683)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[DataSources]') AND [name] = 'instance_name')
	BEGIN		
		alter table [dbo].[DataSources] add instance_name nvarchar(max) not null DEFAULT ('')
		print 'New column {instance_name} has been successfully added to [dbo].[DataSources] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1684; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1684)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1685; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1685)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1686; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1686)
BEGIN
	DECLARE @constraint nvarchar(MAX)

	ALTER TABLE [Tape.directory_versions] ADD [id] [bigint] IDENTITY(1,1) NOT NULL
	ALTER TABLE [Tape.file_versions] ADD [id] [bigint] IDENTITY(1,1) NOT NULL
	ALTER TABLE [Tape.file_parts] ADD [id] [bigint] IDENTITY(1,1) NOT NULL
	ALTER TABLE [Tape.file_parts] ADD [file_version_id] [bigint] NOT NULL DEFAULT (0)
	ALTER TABLE [Tape.storages] ADD file_version_id bigint NOT NULL DEFAULT (0)

	EXEC('
		UPDATE
			[Tape.file_parts]
		SET
			[Tape.file_parts].file_version_id = [Tape.file_versions].id
		FROM 
			[Tape.file_versions] 
			INNER JOIN [Tape.file_parts] ON [Tape.file_versions].file_id = [Tape.file_parts].file_id AND [Tape.file_versions].backup_set_id = [Tape.file_parts].backup_set_id 
	')

	EXEC('
		UPDATE 
			[Tape.storages]
		SET 
			[Tape.storages].[file_version_id] = [Tape.file_versions].[id]
		FROM 
			[Tape.storages]
			INNER JOIN [Tape.file_versions] ON [Tape.storages].file_id = [Tape.file_versions].file_id AND [Tape.storages].backup_set_id = [Tape.file_versions].backup_set_id
	')

	SELECT @constraint = name FROM sys.default_constraints WHERE OBJECT_NAME(parent_object_id) = 'Tape.file_parts' AND parent_column_id = (SELECT column_id FROM sys.columns WHERE name = 'file_version_id' AND object_id = sys.default_constraints.parent_object_id)
	EXEC('ALTER TABLE [Tape.file_parts] DROP CONSTRAINT [' + @constraint + ']')

	SELECT @constraint = name FROM sys.default_constraints WHERE OBJECT_NAME(parent_object_id) = 'Tape.storages' AND parent_column_id = (SELECT column_id FROM sys.columns WHERE name = 'file_version_id' AND object_id = sys.default_constraints.parent_object_id)
	EXEC('ALTER TABLE [Tape.storages] DROP CONSTRAINT [' + @constraint + ']')

	ALTER TABLE [Tape.file_parts] ALTER COLUMN [file_version_id] [bigint] NOT NULL
	ALTER TABLE [Tape.storages] ALTER COLUMN file_version_id bigint NOT NULL

	ALTER TABLE [Tape.directory_versions] DROP CONSTRAINT [PK_Tape.directory_versions]
	ALTER TABLE [Tape.file_parts] DROP CONSTRAINT [PK_Tape.file_parts]
	ALTER TABLE [Tape.file_parts] DROP CONSTRAINT [FK_Tape.file_parts_file_versions]
	ALTER TABLE [Tape.storages] DROP CONSTRAINT [FK_Tape.storages_Tape.file_versions]
	ALTER TABLE [Tape.file_versions] DROP CONSTRAINT [PK_Tape.file_versions]

	DROP INDEX [backup_set_id_media_sequence_number] ON [Tape.file_parts]

	ALTER TABLE [Tape.file_parts] DROP COLUMN [file_id]
	ALTER TABLE [Tape.file_parts] DROP COLUMN [backup_set_id]

	ALTER TABLE [Tape.storages] DROP COLUMN [file_id]
	ALTER TABLE [Tape.storages] DROP COLUMN [backup_set_id]

	ALTER TABLE [Tape.directory_versions] ADD  CONSTRAINT [PK_Tape.directory_versions] PRIMARY KEY CLUSTERED ([id] ASC) ON [PRIMARY]

	ALTER TABLE [Tape.file_versions] ADD  CONSTRAINT [PK_Tape.file_versions] PRIMARY KEY CLUSTERED ([id] ASC) ON [PRIMARY]

	ALTER TABLE [Tape.file_parts] ADD  CONSTRAINT [PK_Tape.file_parts] PRIMARY KEY CLUSTERED ([id] ASC) ON [PRIMARY]

	ALTER TABLE [Tape.file_parts] WITH CHECK ADD  CONSTRAINT [FK_Tape.file_parts_file_versions] FOREIGN KEY([file_version_id]) REFERENCES [Tape.file_versions] ([id]) ON DELETE CASCADE
	ALTER TABLE [Tape.file_parts] CHECK CONSTRAINT [FK_Tape.file_parts_file_versions]

	ALTER TABLE [Tape.storages] WITH CHECK ADD CONSTRAINT [FK_Tape.storages_Tape.file_versions] FOREIGN KEY([file_version_id]) REFERENCES [Tape.file_versions] ([id]) ON DELETE CASCADE
	ALTER TABLE [Tape.storages] CHECK CONSTRAINT [FK_Tape.storages_Tape.file_versions]


	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_file_parts]'))
	drop trigger [dbo].[Tape.after_insert_file_parts]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1687; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1687)
BEGIN
	DROP INDEX [host_id] ON [Tape.directories]
	DROP INDEX [name_directories] ON [Tape.directories]
	DROP INDEX [parent_id_name_directories] ON [Tape.directories]

	DROP INDEX [backup_set_id_media_sequence_number] ON [Tape.directory_versions]
	DROP INDEX [last_write_time_directory_versions] ON [Tape.directory_versions]

	DROP INDEX [name_files] ON [Tape.files]

	DROP INDEX [last_write_time_file_versions] ON [Tape.file_versions]

	CREATE NONCLUSTERED INDEX backup_set_id_corrupted ON [dbo].[Tape.file_versions] ([backup_set_id],[corrupted]) -- INCLUDE ([file_id],[last_write_time])
	CREATE NONCLUSTERED INDEX file_id_last_write_time ON [dbo].[Tape.file_versions] ([file_id],[last_write_time]) -- INCLUDE ([backup_set_id],[creation_time],[size],[attributes],[corrupted],[id])

	CREATE NONCLUSTERED INDEX file_version_id ON [dbo].[Tape.file_parts] ([file_version_id])

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1688; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1688)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1689; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1689)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1690; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1690)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'outdated')
	BEGIN	
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [outdated] [bit] NOT NULL DEFAULT 1

		PRINT 'New column {outdated} has been successfully added to [dbo].[Tape.tape_mediums] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1691; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1691)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.Warnings]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.Warnings](
			warning_type int NOT NULL,
			msg_id nvarchar(256) NOT NULL
		)  ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.Warnings] ADD CONSTRAINT
		PK_Warnings_1 PRIMARY KEY CLUSTERED 
		(
			warning_type,
			msg_id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		print 'Table [dbo].[Backup.Model.Warnings] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1692; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1692 and current_version < 1695)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1695; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1695 )
BEGIN
	exec sp_executesql @stat = N'ALTER trigger [dbo].[d_LinkedJobs] on [dbo].[LinkedJobs] for delete 
	as 	begin  
		declare @id uniqueidentifier
		declare delEnumerator cursor
			for select id from deleted
			
		open delEnumerator
		fetch next from delEnumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''LinkedJobs'', @id, 2
		  fetch next from delEnumerator into @id
		end
			
		close delEnumerator
		deallocate delEnumerator
	end'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1696; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1696 and current_version < 1698)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SqlOIBs]') AND [name] = 'checkpoint_LSN')
	BEGIN		
		alter table [dbo].[Backup.Model.SqlOIBs] add checkpoint_LSN [nvarchar](25) DEFAULT NULL
		print 'New column {[checkpoint_LSN]} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1698; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1698)
BEGIN
	declare @options xml
	declare @node xml

	select @options = options from [dbo].[BackupRepositories] where id = '88788F9E-D8F5-4EB4-BC4F-9B3F5403BCEC'
	if @options IS NOT NULL begin
		select @node = @options.query('/BackupRepositoryOptions/RepositoryOptions')
		if DATALENGTH(RTRIM(Convert(nvarchar(max), @node))) = 0 begin
			set @options.modify('insert <RepositoryOptions/> into (/BackupRepositoryOptions)[1]')
		end

		set @options.modify('delete /BackupRepositoryOptions/RepositoryOptions/RemoteAccessLimitation')
		set @options.modify('insert <RemoteAccessLimitation>10</RemoteAccessLimitation> into (/BackupRepositoryOptions/RepositoryOptions)[1]')

		update [dbo].[BackupRepositories]
			set options = @options
			where id = '88788F9E-D8F5-4EB4-BC4F-9B3F5403BCEC'
	end

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1699; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1699 and current_version < 1705)
BEGIN
	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_backup_sets]'))
	drop trigger [dbo].[Tape.after_insert_backup_sets]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_delete_backup_sets]'))
	drop trigger [dbo].[Tape.after_delete_backup_sets]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_update_backup_sets]'))
	drop trigger [dbo].[Tape.after_update_backup_sets]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_delete_tape_mediums]'))
	drop trigger [dbo].[Tape.after_delete_tape_mediums]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_tape_mediums]'))
	drop trigger [dbo].[Tape.after_insert_tape_mediums]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_update_tape_mediums]'))
	drop trigger [dbo].[Tape.after_update_tape_mediums]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1705; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1705 and current_version < 1708)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1708; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1708)
BEGIN
	CREATE NONCLUSTERED INDEX directory_id ON [dbo].[Tape.directory_versions] ([directory_id])

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1710; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1709)
	BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1710; END
	END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1710 and current_version < 1711)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_vaults') AND [name] = 'protect')
	BEGIN
		alter table [dbo].[Tape.media_vaults] add protect bit NOT NULL DEFAULT(0)
		print 'New column {[protect]} has been successfully added to [dbo].[Tape.media_vaults] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1711; END
	END
GO
		
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1711)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DatastoreOptions]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[DatastoreOptions] 
		(
			[id] uniqueidentifier NOT NULL CONSTRAINT [DF_DatastoreOptions_id]  DEFAULT (newid()),
			[conn_host_id] uniqueidentifier NOT NULL,
			[datastore_ref] nvarchar(max) NOT NULL,
			[datastore_name] nvarchar(max) NOT NULL,
			[options] xml NOT NULL,
			[usn] bigint NOT NULL DEFAULT 0
			
			CONSTRAINT [PK_DatastoreOptions] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		
		) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1712; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1712)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[DatastoreOptions]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''DatastoreOptions''
	end
	'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1713; END	
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1713 and current_version < 1717)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1717; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1717)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[DatastoreOptions]') AND [name] = 'datastore_type')
	BEGIN		
		alter table [dbo].[DatastoreOptions] add datastore_type int not null default(0)
		print 'New column {datastore_type} has been successfully added to [dbo].[DatastoreOptions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1718; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1718 and current_version < 1723)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1723; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1723)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Credentials]') AND [name] = 'change_time_utc')
	BEGIN
		ALTER TABLE [dbo].[Credentials] ADD [change_time_utc] datetime NULL
		PRINT 'New column [change_time_utc] has been successfully added to [dbo].[Credentials]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1724; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1724 and current_version < 1726)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1726; END
END
GO

-- don't merge this /\ and this \/. Version 1726 is required for special upgrade

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1726 and current_version < 1729)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1729; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1729)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND ([name] = 'backup_meta'))
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] DROP COLUMN [backup_meta]
		PRINT 'Columns [backup_meta] was successfully removed from [dbo].[Tape.backup_sets]'

		ALTER TABLE [dbo].[Tape.backup_sets] ADD [backup_meta] [varbinary](max) NULL
		PRINT 'New column [backup_meta] has been successfully added to [dbo].[Tape.backup_sets]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND ([name] = 'catalog_session'))
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] DROP COLUMN [catalog_session]
		PRINT 'Columns [catalog_session] was successfully removed from [dbo].[Tape.backup_sets]'

		ALTER TABLE [dbo].[Tape.backup_sets] ADD [catalog_session] [varbinary](max) NULL
		PRINT 'New column [catalog_session] has been successfully added to [dbo].[Tape.backup_sets]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1730; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1730)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_vaults]') AND [name] = 'location')
	BEGIN
		ALTER TABLE [dbo].[Tape.media_vaults] DROP COLUMN [location]
		PRINT 'Column [location] has been successfully dropped from [dbo].[Tape.media_vaults]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1731; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1731)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'name')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ALTER COLUMN [name] nvarchar(255)
		ALTER TABLE [dbo].[Tape.tape_mediums] ALTER COLUMN [description] nvarchar(1024)
		PRINT 'Column [name] has been successfully changed in [dbo].[Tape.tape_mediums]'
		PRINT 'Column [description] has been successfully changed in [dbo].[Tape.tape_mediums]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1732; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1732)
BEGIN
	UPDATE [dbo].[Backup.Model.Session.Filters] SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>(([job_type] = 300 OR [job_type] = 5000) AND [cloud_session_type] != 0)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>' WHERE [id] = 'db758d28-2900-4e98-bb89-2cafe799f0a3'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1733; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1733 and current_version < 1735)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1735; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1735)
BEGIN
	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_delete_directories]'))
	DROP TRIGGER [dbo].[Tape.after_delete_directories]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_delete_directory_versions]'))
	DROP TRIGGER [dbo].[Tape.after_insert_delete_directory_versions]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[Tape.after_insert_directory_versions]'))
	DROP TRIGGER [Tape.after_insert_directory_versions]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_file_parts]'))
	DROP TRIGGER [dbo].[Tape.after_insert_file_parts]

	IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Tape.after_insert_delete_file_versions]'))
	DROP TRIGGER [dbo].[Tape.after_insert_delete_file_versions]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1736; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1736)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HostOperationResult]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[HostOperationResult] 
		(
			[id] uniqueidentifier NOT NULL CONSTRAINT [DF_HostOperationResult_id]  DEFAULT (newid()),
			[host_id] uniqueidentifier NOT NULL,
			[operation_type] int NOT NULL,
			[execution_date] datetime NOT NULL,
			[operation_result] int NOT NULL,
			[supplement] xml NOT NULL,
			[usn] bigint NOT NULL DEFAULT 0
			
			CONSTRAINT [PK_HostOperationResult] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		
		) ON [PRIMARY]
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1737; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1737)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[HostOperationResult]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''HostOperationResult''
	end
	'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1738; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1738)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Tape.Directories_parentId' AND object_id = OBJECT_ID('[dbo].[Tape.directories]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Tape.Directories_parentId] ON [dbo].[Tape.directories](parent_id)
		PRINT 'New index {IX_Tape.Directories_parentId} has been successfully added to [dbo].[Tape.directories] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1739; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1739)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1740; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1740)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'backup_set_id_media_sequence_number' AND object_id = OBJECT_ID('[dbo].[Tape.directory_versions]'))
	BEGIN
		CREATE NONCLUSTERED INDEX backup_set_id_media_sequence_number ON [dbo].[Tape.directory_versions] ([backup_set_id],[media_sequence_number]) -- INCLUDE ([id])
		PRINT 'New index {backup_set_id_media_sequence_number} has been successfully added to [dbo].[Tape.directory_versions] table'
	END

	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'backup_set_id' AND object_id = OBJECT_ID('[dbo].[Tape.file_versions]'))
	BEGIN
		CREATE NONCLUSTERED INDEX backup_set_id ON [dbo].[Tape.file_versions] ([backup_set_id]) -- INCLUDE ([id])
		PRINT 'New index {backup_set_id} has been successfully added to [dbo].[Tape.file_versions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1741; END
END
GO

  
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1741 and current_version < 1745)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1745; END
END
GO
 

-- After v8.0 beta2

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1745 and current_version < 1800)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1800; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1800 and current_version < 1801)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1801; END
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1801)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') AND [name] = 'meta_update_time')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD [meta_update_time] datetime not null default ''
		PRINT 'Column [meta_update_time] has been successfully added to [dbo].[Backup.Model.Backups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1802; END
END
GO
 
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1802 and current_version < 1815)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1815; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1815)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HvVolumeSnapshots]') AND [name] = 'job_id')
	BEGIN
		ALTER TABLE [dbo].[HvVolumeSnapshots] ADD job_id uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'Column [job_id] has been successfully added to [dbo].[HvVolumeSnapshots]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1816; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1816)
BEGIN

	DECLARE @viPlatform int
	DECLARE @vcdPlatform int
	DECLARE @systemOnlyDiskFilterOld_1 nvarchar(max)
	DECLARE @systemOnlyDiskFilterOld_2 nvarchar(max)
	DECLARE @systemOnlyDiskFilterNew nvarchar(max)
	SET @viPlatform = 0
	SET @vcdPlatform = 4
	SET @systemOnlyDiskFilterOld_1 = '2000;16000;16001;16002;16003;16004;16005;16006;16008;16009;16010;16011;16012;16013;16014;16015;16016;16017;16018;16019;16020;16021;16022;16023;16024;16025;16026;16027;16028;16029;16030;16031;16032;16033;16034;16035;16036;16038;16039;16040;16041;16042;16043;16044;16045;16046;16047;16048;16049;16050;16051;16052;16053;16054;16055;16056;16057;16058;16059;16060;16061;16062;16063;16064;16065;16066;16068;16069;16070;16071;16072;16073;16074;16075;16076;16077;16078;16079;16080;16081;16082;16083;16084;16085;16086;16087;16088;16089;16090;16091;16092;16093;16094;16095;16096;16098;16099;16100;16101;16102;16103;16104;16105;16106;16107;16108;16109;16110;16111;16112;16113;16114;16115;16116;16117;16118;16119'
	SET @systemOnlyDiskFilterOld_2 = '2000'
	SET @systemOnlyDiskFilterNew = 'Ver8|2000;16000;3000'
	UPDATE 
		[dbo].[ObjectsInJobs] 
	SET 
		[disk_filter] = @systemOnlyDiskFilterNew 
	WHERE 
		([disk_filter] = @systemOnlyDiskFilterOld_1 OR [disk_filter] = @systemOnlyDiskFilterOld_2)
		AND [platform] IN (@viPlatform, @vcdPlatform)
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1817; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1817 and current_version < 1819)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1819; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1819)
BEGIN
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT	
	INSERT INTO [dbo].[Backup.Model.Session.Filters] ([id],[name],[data],[usn])
	VALUES('AC62227D-28BB-4311-B262-F763F2D0BE10',
		   'Endpoint',
		   '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 4000)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
		   ,@usn)

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1820; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1820)
BEGIN
	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<ReportCriteria><Criterions><string>([job_type] = 7 OR [job_type] = 9 OR [job_type] = 206 OR [job_type] &gt; 13 AND [job_type] &lt; 18)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = 'F2323D84-AA8D-4cad-B9BB-D72F022746EF'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1821; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1821)
BEGIN

	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_library]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.delete_library]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1822; END
END	
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1822 and current_version < 1825)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1826; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1826)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') AND [name] = 'incompletion')
	BEGIN		
		ALTER TABLE [Tape.file_parts] ADD [incompletion] tinyint NOT NULL DEFAULT(0)
		print 'New column [incompletion] has been successfully added to [Tape.file_parts] table'
	END

	EXEC sp_executesql @statement = N'UPDATE [Tape.file_parts] SET [incompletion] = 1 WHERE [incomplete] = 1'

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_parts]') AND ([name] = 'incomplete'))
	BEGIN
		ALTER TABLE [Tape.file_parts] DROP COLUMN [incomplete]
		PRINT 'Columns [incomplete] was successfully removed from [Tape.file_parts]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1827; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1827 and current_version < 1832)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1832; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1832 and current_version < 1833)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1833; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1833 AND current_version < 1835)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessionsOnQuotas]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudSessionsOnQuotas] 
		(
			[session_id] [uniqueidentifier] NOT NULL,
			[quota_id] [uniqueidentifier] NOT NULL,
		 CONSTRAINT [PK_Backup.Model.CloudSessionsOnQuotas] PRIMARY KEY CLUSTERED 
		(
			[session_id] ASC,
			[quota_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.CloudSessionsOnQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudSessionsOnQuotas_Backup.Model.CloudSessions] FOREIGN KEY([session_id])
		REFERENCES [dbo].[Backup.Model.CloudSessions] ([id])
		ON DELETE CASCADE

		ALTER TABLE [dbo].[Backup.Model.CloudSessionsOnQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudSessionsOnQuotas_TenantsResourcesQuota] FOREIGN KEY([quota_id])
		REFERENCES [dbo].[TenantsResourcesQuota] ([id])
		ON DELETE CASCADE

		PRINT 'Table [Backup.Model.CloudSessionsOnQuotas] was successfully created'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessions]') AND ([name] = 'resource_quota_id'))
	BEGIN
		ALTER TABLE dbo.[Backup.Model.CloudSessions] DROP CONSTRAINT [FK_Backup.Model.CloudSessions_TenantsResourcesQuota]

		declare @constraint_name sysname, @sql nvarchar(max)
		select @constraint_name = name 
		from sys.default_constraints
		where parent_object_id = object_id('[dbo].[Backup.Model.CloudSessions]')
		AND type = 'D'
		AND parent_column_id = (
			select column_id 
			from sys.columns 
			where object_id = object_id('[dbo].[Backup.Model.CloudSessions]')
			and name = 'resource_quota_id'
			)

		set @sql = N'alter table [Backup.Model.CloudSessions] drop constraint [' + @constraint_name + ']'
		exec sp_executesql @sql

		ALTER TABLE dbo.[Backup.Model.CloudSessions] DROP COLUMN resource_quota_id

		PRINT 'Columns [resource_quota_id] was successfully removed from [Backup.Model.CloudSessions]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1835; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1835 and current_version < 1838)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1838; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1838 AND current_version < 1839)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.UserNotifications]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.UserNotifications](
		[Id] [uniqueidentifier] NOT NULL,
		[text] nvarchar(4000),
		[type] tinyint NOT NULL,
		[enable_date] datetime,
		[set_count] [int] NOT NULL,
		[set_count_trigger] int NOT NULL,
		[dismiss_date] datetime NULL,
		[dissmiss_length] int NULL,
		[usn] bigint NOT NULL,
	 CONSTRAINT [PK_Backup.Model.Notifications] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	
	PRINT 'Table [Backup.Model.UserNotifications] was successfully created'
	END

	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{085B8FC5-AAA6-42A0-B230-00A88732BA3E}', '', 1, 0, 1, NULL, 604800, 0)
    
	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{603D8595-0276-4A10-BC99-8226ABC052D6}','',1, 0, 1, NULL, 604800, 0)

	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{D782F299-8DB6-4DC4-B73C-5EA951C178F4}','',1, 0, 1, NULL, 604800, 0)

	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{66D77FB9-C1B9-4A1E-A804-E800261D6749}','',0, 0, 1, NULL, NULL, 0)

	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{C0F3642D-8E5C-4C2F-9981-A3F0C91EAD33}','',1, 0, 1, NULL, NULL, 0)

	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{59499357-08D7-485C-93F2-A0F69C8D84C9}','',1, 0, 2, NULL, NULL, 0)

	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{BF3685AC-2785-46E5-B2BB-1CC2A8EA85AF}','',1, 0, 1, NULL, NULL, 0)

	INSERT INTO [Backup.Model.UserNotifications]([Id], [text], [type], [set_count],[set_count_trigger],[dismiss_date],[dissmiss_length],[usn])
	VALUES ('{CB318444-46F1-4620-A366-4BA6AEB8BDDF}','',2, 0, 1, NULL, NULL, 0)

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1839; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1839 and current_version < 1843)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1843; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1843)
BEGIN
	PRINT 'Upgrading traffic throttling rule(s)'

	DECLARE @id uniqueidentifier
	SET @id = 'F02AA301-7D80-4D42-AA37-4EEA214CF4CB'

	IF EXISTS (SELECT * FROM [dbo].[options] WHERE [id] = @id)
	BEGIN
		PRINT 'Reading traffic throttling rule(s)'

		DECLARE @count int

		SELECT
			@count = [value].value('count(/TrafficThrottlingRules/TrafficThrottlingRule)', 'int')
		FROM
			[dbo].[options]
		WHERE
			[id] = @id

		PRINT 'Found ' + cast(@count as nvarchar(255)) + ' traffic throttling rule(s)'

		DECLARE @node int
		SET @node = 1

		DECLARE @xml xml

		WHILE @node <= @count
		BEGIN
			PRINT 'Upgrading traffic throttling rule #' + cast(@node as nvarchar(255))

			SELECT @xml = [value] FROM [dbo].[Options] WHERE [id] = @id
			PRINT cast(@xml as nvarchar(max))

			IF EXISTS (SELECT * FROM [dbo].[options] WHERE [id] = @id AND [value].exist('/TrafficThrottlingRules/TrafficThrottlingRule[sql:variable("@node")]/ThrottlingEnabled') = 0)
			BEGIN
				UPDATE
					[dbo].[options]
				SET
					[value].modify('insert <ThrottlingEnabled>True</ThrottlingEnabled> as last into (/TrafficThrottlingRules/TrafficThrottlingRule[sql:variable("@node")])[1]')
				WHERE
					[id] = @id

				PRINT 'Traffic throttling rule #' + cast(@node as nvarchar(255)) + ' is successfully upgraded'

				SELECT @xml = [value] FROM [dbo].[Options] WHERE [id] = @id
				PRINT cast(@xml as nvarchar(max))
			END
			ELSE
			BEGIN
				PRINT 'Throttling is already set for traffic throttling rule #' + cast(@node as nvarchar(255))
			END

			SET @node = @node + 1
		END
	END
	ELSE
	BEGIN
		PRINT 'Upgrade of traffic throttling rule(s) is not required'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1844; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1844 and current_version < 1857)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1857; END
END
GO
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1857)
BEGIN
	update [dbo].[Backup.Model.Session.Filters] SET [name] = 'Application item restore' WHERE [id] = '3c032c4a-d6c3-4c04-921e-55d7ddf9f859'
	update [dbo].[Backup.Model.Session.Filters] SET [name] = 'Failover plan' WHERE [id] = 'be43b98f-f888-4150-bf88-372af0f334ad'
	update [dbo].[Backup.Model.Session.Filters] SET [name] = 'VM and File Copy' WHERE [id] = '225d4c03-0b09-44ce-bb24-7cf8ac34dd6e'
	update [dbo].[Backup.Model.Session.Filters] SET [name] = 'Quick Migration' WHERE [id] = '4508c3e9-6791-4ecf-b502-ff0fda01b1d5'
	update [dbo].[Backup.Model.Session.Filters] SET [name] = 'Cloud Connect' WHERE [id] = 'db758d28-2900-4e98-bb89-2cafe799f0a3'
	update [dbo].[Backup.Model.Session.Filters] SET [name] = 'Storage snapshots' WHERE [id] = 'd2f0f072-1ca9-40c0-afd1-56b3de9aa366'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1858; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1858 and current_version < 1861)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1861; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1861)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.AlwaysOnListeners]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.AlwaysOnListeners](
			[listener_id] [uniqueidentifier] NOT NULL,
			[group_id] [uniqueidentifier] NOT NULL,
			[dns] [nvarchar](max) NOT NULL
	    CONSTRAINT [PK_AlwaysOnListeners] PRIMARY KEY CLUSTERED 
		(
			[listener_id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		print 'Table [dbo].[Backup.Model.AlwaysOnListeners] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1862; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1862 and current_version < 1866)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1866; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1866)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.GuestDatabase]') AND [name] = 'local_creation_time')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.GuestDatabase] ADD [local_creation_time] DATETIME not null DEFAULT (getdate())
		PRINT 'New column {[local_creation_time]} has been successfully added to [dbo].[Backup.Model.GuestDatabase] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1867; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1867 and current_version < 1868)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1868; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1868)
BEGIN
	PRINT 'Upgrading Backup Configuration Job sessions...'

	UPDATE
		[dbo].[Backup.Model.JobSessions]
	SET
		[job_name] = 'Backup Configuration Job',
		[aux_data] = '<ConfigurationBackupAuxData/>'
	WHERE
		[job_id] = '99D1BF3D-E2E0-4BEC-B2B3-820C0B87D212' AND cast([aux_data] as nvarchar(max)) = 'Backup'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1869; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 1869 and current_version < 1870)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1870; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 1870)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1871; END
END
GO

-- 8.0 Patch 1: >=1870

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1871)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostCreds]') AND [name] = 'ssh_fingerprint')
	BEGIN		
		alter table [dbo].[HostCreds] add ssh_fingerprint nvarchar(256)
		print 'New column {ssh_fingerprint} has been successfully added to [dbo].[HostCreds] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1872; END
END
GO

-- 8.0 Patch 2: >=1970

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1872)
BEGIN
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1970; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1970)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SanVolumeRescanPolicy]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[SanVolumeRescanPolicy] 
		(
			[id] uniqueidentifier NOT NULL CONSTRAINT [DF_SanVolumeRescanPolicy_id]  DEFAULT (newid()),
			[host_id] uniqueidentifier NOT NULL,
			[volume_internal_id] nvarchar(255) NOT NULL,
			[volume_name] nvarchar(255) NOT NULL,
			[policy] int NOT NULL,
			[usn] bigint NOT NULL DEFAULT 0
			
			CONSTRAINT [PK_SanVolumeRescanPolicy] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		
		) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1971; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1971)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[SanVolumeRescanPolicy]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''SanVolumeRescanPolicy''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1972; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1972)
BEGIN	

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Soap_creds]') AND [name] = 'certificate_thumbprint')
	BEGIN		
		ALTER TABLE [dbo].[Soap_creds] ADD [certificate_thumbprint] NVARCHAR(1024) not null DEFAULT ('')
		PRINT 'New column {[certificate_thumbprint]} has been successfully added to [dbo].[Soap_creds] table'
	END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1973; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1973)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1974; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1974)
BEGIN	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TenantsWans]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[TenantsWans] 
		(
			[tenant_id] uniqueidentifier NOT NULL,
			[source_wan_id] uniqueidentifier NOT NULL,
			[target_wan_id] uniqueidentifier NOT NULL

			CONSTRAINT [PK_TenantsWans] PRIMARY KEY CLUSTERED 
			(
				[tenant_id] ASC,
				[source_wan_id] ASC,
				[target_wan_id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1975; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1975 and current_version < 1977)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1977; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 1977)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') AND [name] = 'meta_version')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD [meta_version] bigint not null default -1
		PRINT 'Column [meta_version] has been successfully added to [dbo].[Backup.Model.Backups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1978; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1978 and current_version < 1982)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1982; END	
END
GO
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1982 and current_version < 1983)
BEGIN	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	   SET 
		  [data] = '<ReportCriteria>
					  <Criterions>
						<string>([job_type] = 13 OR [job_type] = 6000)</string>
					  </Criterions>
					  <Order>
						<Ascending>false</Ascending>
						<PropertyName>creation_time</PropertyName>
					  </Order>
					</ReportCriteria>'
	 WHERE id = 'A34648B0-1845-462B-9DC4-E42EABE5290D'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1983; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1983 and current_version < 1996)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1996; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1983 and current_version < 1997)
BEGIN
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Backup.Model.BackupTaskSessionsProgress_SessionId_Date' AND object_id = OBJECT_ID(N'[dbo].[Backup.Model.BackupTaskSessionsProgress]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Backup.Model.BackupTaskSessionsProgress_SessionId_Date] ON [dbo].[Backup.Model.BackupTaskSessionsProgress]
		(	[session_id] ASC)
		INCLUDE ([date])
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_Backup.Model.BackupTaskSessionsProgress_SessionId_Date} has been successfully added to [dbo].[Backup.Model.BackupTaskSessionsProgress] table'
		END

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Tape.directory_versions_DirectoryId_BackupSetId' AND object_id = OBJECT_ID(N'[dbo].[Tape.directory_versions]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Tape.directory_versions_DirectoryId_BackupSetId] ON [dbo].[Tape.directory_versions]
		(
			[directory_id] ASC,
			[backup_set_id] ASC)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_Tape.directory_versions_DirectoryId_BackupSetId} has been successfully added to [dbo].[Tape.directory_versions] table'
		END	

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Tape.file_versions_FileId_BackupSetId' AND object_id = OBJECT_ID(N'[dbo].[Tape.file_versions]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Tape.file_versions_FileId_BackupSetId] ON [dbo].[Tape.file_versions]
		(
			[file_id] ASC,
			[backup_set_id] ASC)
			INCLUDE ([id]) 
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_Tape.file_versions_FileId_BackupSetId} has been successfully added to [dbo].[Tape.file_versions] table'
		END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 1997; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 1997 and current_version < 2002)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2002; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2002)
BEGIN	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ForeignIncomeConnections]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ForeignIncomeConnections]
			(
			job_id uniqueidentifier NOT NULL,
			version nvarchar(50) NOT NULL,
			protocol_version int NOT NULL,
			last_touch_utc datetime NOT NULL
			)  ON [PRIMARY]
		
		ALTER TABLE [dbo].[Backup.Model.ForeignIncomeConnections] ADD CONSTRAINT
			[PK_Backup.Model.ForeignIncomeConnections] PRIMARY KEY CLUSTERED 
			(
			job_id
			) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.ForeignIncomeConnections] ADD CONSTRAINT
			[FK_Backup.Model.ForeignIncomeConnections_BJobs] FOREIGN KEY
			(
			job_id
			) REFERENCES dbo.BJobs
			(
			id
			) ON UPDATE  CASCADE 
			 ON DELETE  CASCADE 

		print 'Table [dbo].[Backup.Model.ForeignIncomeConnections] has been successfully created'
		
		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2003; END
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2003 and current_version < 2004)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2004; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2004 and current_version < 2005)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TapeFileParts_MediaSequence_FileVersion' AND object_id = OBJECT_ID('[dbo].[Tape.file_parts]'))
	BEGIN
		CREATE NONCLUSTERED INDEX IX_TapeFileParts_MediaSequence_FileVersion ON [dbo].[Tape.file_parts]
		([media_sequence_number])
		INCLUDE ([file_version_id])
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_TapeFileParts_MediaSequence_FileVersion} has been successfully added to [dbo].[Tape.file_parts] table';
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2005; END

	END
GO	

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2005 and current_version < 2016)
BEGIN
	PRINT 'Upgrading "transform full to syntethic" option...'

	IF (NOT EXISTS (SELECT * FROM [dbo].[BJobs] WHERE [type] = 0) AND 
		NOT EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = 'DAC610E6-751E-462E-A066-5671F461ABF2') AND
		NOT EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = '6D68763E-1A01-4B12-BF64-4C95E03F2BD0') AND
		NOT EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = '161978C6-6114-47DF-ADC9-B45BF68D6E08'))
	BEGIN
		PRINT 'Processing VI/VCD/HV defaults for "transform full to syntethic" option...'

		DECLARE @content as nvarchar(max)

		SET @content = 
			'<PreCommand>
				<CCustomCommand xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
				</CCustomCommand>
			</PreCommand>
			<PostCommand>
				<CCustomCommand xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
				</CCustomCommand>
			</PostCommand>
			<FullBackupMonthlyScheduleOptions>
				<CFullBackupMonthlyScheduleOptions xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
				</CFullBackupMonthlyScheduleOptions>
			</FullBackupMonthlyScheduleOptions>
			<TransformFullToSyntethic>True</TransformFullToSyntethic>
			<EnableFullBackup>False</EnableFullBackup>'

		INSERT INTO [dbo].[Options] (id, name, value)
			SELECT 'DAC610E6-751E-462E-A066-5671F461ABF2', 'vi_backup_adv_opt', '<CViJobAdvancedOptions>' + @content + '</CViJobAdvancedOptions>'
			UNION ALL
			SELECT '6D68763E-1A01-4B12-BF64-4C95E03F2BD0', 'vcd_backup_adv_opt', '<CViJobAdvancedOptions>' + @content + '</CViJobAdvancedOptions>'	
			UNION ALL
			SELECT '161978C6-6114-47DF-ADC9-B45BF68D6E08', 'hv_backup_adv_opt', '<CHvJobAdvancedOptions>' + @content + '</CHvJobAdvancedOptions>'
	END
	ELSE
	BEGIN
		PRINT 'Upgrade is skipped, because there are backup jobs or defaults in database'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2016; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2016 and current_version < 2018)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2018; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2018 and current_version < 2019)
BEGIN	
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Backup.Model.OIBs_is_corrupted_id_object_id_point_id_creation_time_usn_parent_id4' AND object_id = OBJECT_ID('[dbo].[Backup.Model.OIBs]'))
		BEGIN
			CREATE NONCLUSTERED INDEX [IX_Backup.Model.OIBs_is_corrupted_id_object_id_point_id_creation_time_usn_parent_id]
			ON [dbo].[Backup.Model.OIBs] ([is_corrupted])
			INCLUDE ([id],[object_id],[point_id],[creation_time],[usn],[parent_id]);
			PRINT 'New index {IX_Backup.Model.OIBs_is_corrupted_id_object_id_point_id_creation_time_usn_parent_id} has been successfully added to [dbo].[Backup.Model.OIBs] table'
		END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2019; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2019 and current_version < 2022)
BEGIN	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2022; END
END
GO
