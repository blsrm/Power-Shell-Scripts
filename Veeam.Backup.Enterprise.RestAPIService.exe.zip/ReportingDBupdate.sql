﻿---------------------------------------------------
--200
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 200)
BEGIN
	---------------------------------------------------	
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.Points]') AND type in (N'U'))
	BEGIN
		exec sp_executesql @stat = N'
			CREATE TABLE [dbo].[Backup.Model.Points](
				[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Points_id]  DEFAULT (newid()),
				[link_id] [uniqueidentifier] NULL,
				[num] [int] NOT NULL,
				[creation_time] [datetime] NOT NULL,
				[type] [int] NOT NULL,
				[alg]  [int] NOT NULL,
				[group_id] uniqueidentifier NOT NULL,
				[backup_id] [uniqueidentifier] NULL,
				[db_instance_id] [uniqueidentifier] NOT NULL,
			 CONSTRAINT [PK_Points] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		'
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 200; END	
END
GO
--200
---------------------------------------------------
--201
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 200)
BEGIN
	---------------------------------------------------	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') AND type in (N'U'))
	BEGIN
		exec sp_executesql @stat = N'
			CREATE TABLE [dbo].[Backup.Model.OIBs](
				[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_OIBs_id]  DEFAULT (newid()),
				[object_id] [uniqueidentifier] NOT NULL,
				[point_id] [uniqueidentifier] NULL,
				[storage_id] [uniqueidentifier] NULL,
				[link_id] [uniqueidentifier] NULL,
				[is_corrupted] [bit] NOT NULL,
				[is_consistent] [bit] NOT NULL,				
				[state] [int] NOT NULL,
				[type] [int] NOT NULL,
				[alg] [int] NOT NULL,
				[inside_dir] [nvarchar](400) NOT NULL,
				[creation_time] [datetime] NOT NULL,
				[vmname] [nvarchar](1000) NOT NULL,
				[guest_os_info] [xml],
				[memory] [bigint] NOT NULL,
				[approx_size] [bigint] NOT NULL,
				[process_id] [int] NOT NULL,
				[has_index] [bit] NOT NULL,
				[aux_data] [xml] NOT NULL default '''',
				[db_instance_id] [uniqueidentifier] NOT NULL,
			 CONSTRAINT [PK_OIBs] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		'
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 201; END	
END
GO
--201
---------------------------------------------------
--202
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 201)
BEGIN
	---------------------------------------------------	
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') AND type in (N'U'))
	BEGIN
		exec sp_executesql @stat = N'
			ALTER TABLE [dbo].[Backup.Model.OIBs] ADD  DEFAULT ((-1)) FOR [process_id]
			ALTER TABLE [dbo].[Backup.Model.OIBs] ADD  DEFAULT (''empty'') FOR [inside_dir]
			ALTER TABLE [dbo].[Backup.Model.OIBs] ADD  DEFAULT (''01.01.1900'') FOR [creation_time]
		'
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 202; END	
END
GO
--202
---------------------------------------------------
--203
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 202)
BEGIN
	---------------------------------------------------
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Backup.Model.Backups') AND type in (N'U'))
	BEGIN
		exec sp_executesql @stat = N'
			CREATE TABLE [dbo].[Backup.Model.Backups](
				[id] [uniqueidentifier] NOT NULL,
				[job_id] [uniqueidentifier] NULL,
				[job_name] [nvarchar](255) NULL,
				[job_source_type] [int] NULL,
				[job_target_type] [int] NULL,
				[job_target_host_id] [uniqueidentifier] NULL,
				[job_target_host_protocol] [int] NULL,
				[db_instance_id] [uniqueidentifier] NOT NULL,
			 CONSTRAINT [PK_Backup] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		'
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 203; END	
END
GO
--203
-----------------------------------------------------
--206
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 203 AND current_version < 206)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.Storages]'') AND type in (N''U''))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.Storages](
			[id] [uniqueidentifier] NOT NULL,
			[file_path] [nvarchar](1000) NULL,
			[backup_id] [uniqueidentifier] NULL,
			[host_id] [uniqueidentifier] NULL,
			[creation_time] [datetime] NOT NULL,
			[modification_time] [datetime] NOT NULL,			
			[stats] [xml] NULL,
			[version] [int] NOT NULL,
			[block_size] [int] NOT NULL default 1024,		
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[full_size] [bigint] NOT NULL,
		 CONSTRAINT [PK_Storages] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END
	' 
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 206; END	
END
GO
--206
-----------------------------------------------------
--210
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 206 AND current_version < 210)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[usp_Import_Backups_Changes]'') AND type in (N''P''))
	BEGIN
		DROP PROCEDURE [dbo].[usp_Import_Backups_Changes]
	END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 210; END	
END
GO
--210
-----------------------------------------------------
--211
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 210)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[usp_Import_Backups_Dels]'') AND type in (N''P''))
	BEGIN
		DROP PROCEDURE [dbo].[usp_Import_Backups_Dels]
	END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 211; END	
END
GO
--211
-----------------------------------------------------
--212
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 211)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[usp_Import_ObjectsInBackups_Changes]'') AND type in (N''P''))
	BEGIN
		DROP PROCEDURE [dbo].[usp_Import_ObjectsInBackups_Changes]
	END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 212; END	
END
GO
--212
-----------------------------------------------------
--213
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 212)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[usp_Import_ObjectsInBackups_Dels]'') AND type in (N''P''))
	BEGIN
	   DROP PROCEDURE [dbo].[usp_Import_ObjectsInBackups_Dels]
	END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 213; END	
END
GO
--213
-----------------------------------------------------

--215
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 213 AND current_version < 215)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		if exists (select * from syscolumns where id = OBJECT_ID(N''[dbo].[BSessions]'') and [name] = ''overall_status'')
		begin
			ALTER TABLE [BSessions] ADD [state] int not null default -1
			exec sp_rename ''[dbo].[BSessions].[overall_status]'', ''result'', ''COLUMN''
		end
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 215; END	
END
GO
--215
-----------------------------------------------------



-----------------------------------------------------
--216
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 215)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		if exists (select * from syscolumns where id = OBJECT_ID(N''[dbo].[BJobs]'') and [name] = ''control'')
		begin
			declare @constraint nvarchar(100)
			declare @sqlcommand nvarchar(1000) 
			set @constraint = (select [name] from sys.default_constraints where [object_id] = (select cdefault from syscolumns where id = OBJECT_ID(N''[dbo].[BJobs]'') and [name] = ''control''))
			set @sqlcommand = N''Alter table [dbo].[BJobs] drop constraint '' + @constraint
			exec sp_sqlexec @sqlcommand
			alter table [dbo].[BJobs] drop column [control]
		end
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 216; END	
END
GO
--216
-----------------------------------------------------
--217
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 216)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Repl.Sessions]'') AND type in (N''U''))	    
		begin
			EXEC sp_rename ''[dbo].[Repl.Sessions]'', [Enterprise.Sessions]
		end
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 217; END	
END
GO
--217
-----------------------------------------------------
--218	
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 217)
BEGIN
	
	---------------------------------------------------
	exec sp_executesql @stat = N'
		if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N''U'') AND cols.name = N''job_type'' and objs.name = N''Enterprise.Sessions'')		
		BEGIN
			ALTER TABLE [dbo].[Enterprise.Sessions]
			ADD  [job_type] int default 3 NOT NULL
		END		
	'	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 218; END	
END
GO
--218
-----------------------------------------------------
--219
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 218)
BEGIN
	
	---------------------------------------------------
	exec sp_executesql @stat = N'
		if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N''U'') AND cols.name = N''cancel_flag'' and objs.name = N''Enterprise.Sessions'')		
		BEGIN
			ALTER TABLE [dbo].[Enterprise.Sessions]
			ADD  [cancel_flag] int default 0 NOT NULL
		END		
	'	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 219; END	
END
GO
--219
-----------------------------------------------------
--220
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 219)
BEGIN
	
	---------------------------------------------------
	exec sp_executesql @stat = N'
		if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N''U'') AND cols.name = N''config'' and objs.name = N''Enterprise.Sessions'')		
		BEGIN
			ALTER TABLE [dbo].[Enterprise.Sessions]
			ADD  [config] [nvarchar](max)  default N'''' NOT NULL
		END		
	'	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 220; END	
END
GO
--220
-----------------------------------------------------
--221
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 220)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Enterprise.SessionEvents]'') AND type in (N''U''))
	BEGIN
		CREATE TABLE [dbo].[Enterprise.SessionEvents]
		(
			[session_id] [uniqueidentifier] NOT NULL,
			[event_time] [datetime] NOT NULL,
			[severity] [int] NOT NULL,
			[ordinal_num] [int] NOT NULL,
			[text] [nvarchar](max) NOT NULL
		)
		ON [PRIMARY]
	END	
	' 
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 221; END	
END
GO
--221
-----------------------------------------------------
--222
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 221)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Catalog.SearchServers]'') AND type in (N''U''))
	BEGIN
		CREATE TABLE [dbo].[Catalog.SearchServers]
		(
			[id] [uniqueidentifier] NOT NULL,
			[ip_or_dns_name] [nvarchar](255) NOT NULL,
			[port] [int] NOT NULL,
			[description] [nvarchar](2000) NOT NULL,
			[oibs_index_limit] [int] NOT NULL,
			[indexed_oibs_num] [int] NOT NULL,
			[used_sources_num] [int] default 0 NOT NULL, 
			CONSTRAINT [PK_Catalog.SearchServers] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) 
		ON [PRIMARY]		
	END	
	' 
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 222; END	
END
GO
--222
-----------------------------------------------------
--223
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 222)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Catalog.SearchServerCreds]'') AND type in (N''U''))
			BEGIN
				CREATE TABLE [dbo].[Catalog.SearchServerCreds]
				(
					[search_srv_id] [uniqueidentifier] NOT NULL,
					[domain] [nvarchar](255) NOT NULL,
					[login] [nvarchar](255) NOT NULL,
					[pwd] [nvarchar](1024) NOT NULL,
					CONSTRAINT [PK_Catalog.SearchServerCreds] PRIMARY KEY CLUSTERED 
					(
						[search_srv_id] ASC
					)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
				) 
				ON [PRIMARY]
			END	
	' 
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 223; END	
END
GO
--223
-----------------------------------------------------
--224
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 223)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Catalog.SearchServerDelRequests]'') AND type in (N''U''))
			BEGIN
				CREATE TABLE [dbo].[Catalog.SearchServerDelRequests]
				(
					[search_srv_id] [uniqueidentifier] NOT NULL,
					[cleanup_srv_sources] [bit] NOT NULL,
					CONSTRAINT [PK_Catalog.SearchServerDelRequests] PRIMARY KEY CLUSTERED 
					(
						[search_srv_id] ASC
					)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
				) 
				ON [PRIMARY]
			END	
	' 
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 224; END	
END
GO
--224
-----------------------------------------------------
--225
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 224)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'		
		if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N''U'') AND cols.name = N''counter_type'' and objs.name = N''Update.Counters'')		
		BEGIN
			ALTER TABLE [dbo].[Update.Counters]
			ADD  [counter_type] int  default 0 NOT NULL
		END		
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 225; END	
END
GO
--225
-----------------------------------------------------

-----------------------------------------------------
--226
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 225)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Catalog.ScalarSettings]'') AND type in (N''U''))
			BEGIN
				CREATE TABLE [dbo].[Catalog.ScalarSettings]
				(
					[id] [int] NOT NULL,
					[bsessions_retention_period] [int] NOT NULL,
					CONSTRAINT [PK_Catalog.ScalarSettings] PRIMARY KEY CLUSTERED 
					(
						[id] ASC
					)
					WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
				)
				ON [PRIMARY]			
			END	
	' 		
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 226; END	
END
GO
--226
-----------------------------------------------------


-----------------------------------------------------
--227
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 226)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		if NOT EXISTS (SELECT * FROM [dbo].[Catalog.ScalarSettings] )
		BEGIN
			INSERT INTO [dbo].[Catalog.ScalarSettings]( [id], [bsessions_retention_period])			
			VALUES( 0 , 3 )
		END
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 227; END	
END
GO
--227
-----------------------------------------------------
		
		
-----------------------------------------------------
--228
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 227)
BEGIN
	---------------------------------------------------
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Catalog.SearchServerCrawlSessions]') AND type in (N'U'))
	BEGIN
		exec sp_executesql @stat = N'
		CREATE TABLE [dbo].[Catalog.SearchServerCrawlSessions]
		(
			[id] [uniqueidentifier] NOT NULL,
			[ent_session_id] [uniqueidentifier] NOT NULL,
			[search_srv_id] [uniqueidentifier] NOT NULL,
			[status] [int] DEFAULT 0 NOT NULL,
			[status_comment] [ntext] DEFAULT N'''' NOT NULL,
			[changed_sources_num] [int] DEFAULT 0 NOT NULL,
			[new_sources_num] [int] DEFAULT 0 NOT NULL,
			[deleted_sources_num] [int] DEFAULT 0 NOT NULL,
			 CONSTRAINT [PK_Catalog.SearchServerCrawlSessions] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 			
		)
		ON [PRIMARY]
		'	
	END
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 228; END	
END
GO
--228
-----------------------------------------------------


-----------------------------------------------------
--229
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 228)
BEGIN
	---------------------------------------------------
	IF NOT EXISTS (SELECT object_id FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Config.Scheduler.CatSyncSettings]') AND type in (N'U'))
	BEGIN
		exec sp_executesql @stat = N'
		CREATE TABLE [dbo].[Config.Scheduler.CatSyncSettings]
		(
			[id] [uniqueidentifier] NOT NULL,
			[schedule_type] [int] NOT NULL,
			[settings] [xml] NOT NULL
			CONSTRAINT [PK_Config.Scheduler.CatSyncSettings] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]																										
		)	
		ON [PRIMARY]
		'
	END
	---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 229; END	
END
GO
--229
-----------------------------------------------------



-----------------------------------------------------
--230
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 229)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[HostsByJobs]'') AND type in (N''U''))
	BEGIN
		CREATE TABLE [dbo].[HostsByJobs](
			[id] [uniqueidentifier] NOT NULL,
			[host_id] [uniqueidentifier] NULL,
			[job_id] [uniqueidentifier] NULL,
			[uuid] [nvarchar](255) NOT NULL,
			[db_instance_id] [uniqueidentifier]
		 CONSTRAINT [PK_HostsByJobs] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 230; END	
END
GO
--230
-----------------------------------------------------



-----------------------------------------------------
--231
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 230)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N''U'') AND cols.name = N''fill_version'' and objs.name = N''Version'')		
		BEGIN
			ALTER TABLE [dbo].[Version]
			ADD [fill_version] int default 0 NOT NULL
		END		
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 231; END	
END
GO
--231
-----------------------------------------------------


-----------------------------------------------------
--238
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 231 AND current_version < 238)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	if not exists (select * from syscolumns where id = OBJECT_ID(N''[dbo].[LicensedHosts]'') and [name] = ''lic_edition'')
	begin
		alter table dbo.LicensedHosts add lic_edition int DEFAULT 0 NOT null
	end
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 238; END	
END
GO
--238
-----------------------------------------------------



-----------------------------------------------------
--240
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 238 AND current_version < 240)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	if not exists (select * from syscolumns where id = OBJECT_ID(N''[dbo].[LicensedHosts]'') and [name] = ''is_licensed'')
	begin
		alter table dbo.LicensedHosts add is_licensed bit DEFAULT 0 NOT null
	end
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 240; END	
END
GO
--240
-----------------------------------------------------



-----------------------------------------------------
--241
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 240)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[VirtualLabs]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[VirtualLabs] (
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[name] nvarchar(255) NOT NULL,
			[description] nvarchar(255) NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[vm_ref] nvarchar(1024) NOT NULL,
			[usn] bigint not null default 0,
			[db_instance_id] [uniqueidentifier]
			)
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 241; END	
END
GO
--241
-----------------------------------------------------
-----------------------------------------------------
--243
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 243)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.SbTaskSessions]'') AND type in (N''U''))
		BEGIN
		
			CREATE TABLE [dbo].[Backup.Model.SbTaskSessions] (
				[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
				[drsession_id] [uniqueidentifier] NOT NULL,
				[type] int NOT NULL,
				[object_name] nvarchar(max) NOT NULL,
				[object_id] [uniqueidentifier] NOT NULL,
				[oib_id] [uniqueidentifier] NOT NULL,
				[overall_status] int NOT NULL,
				[description] nvarchar(max) NOT NULL,
				[start_time] DateTime NOT NULL,
				[finish_time] DateTime NOT NULL,
				[total_steps] int NOT NULL,
				[processed_steps] int NOT NULL,
				[powerOn_status] int NOT NULL,
				[heartbeat_status] int NOT NULL,
				[ping_status] int NOT NULL,
				[test_script_status] int NOT NULL,
				[powerOff_status] int NOT NULL,
				[test_script_error_code] int NOT NULL,
				
				[vm_ref] nvarchar(max) NOT NULL,
				
				[usn] bigint not null default 0,
				[percent] [int] NOT NULL DEFAULT ((0)),
				
				[appliance_ip] [nvarchar](80) NOT NULL DEFAULT (''''),
				[subnet_ip] [nvarchar](80) NOT NULL DEFAULT (''''),
				[subnet_mask] [nvarchar](80) NOT NULL DEFAULT (''''),
				
				[vm_external_ip] [nvarchar](80) NOT NULL DEFAULT (''''),
				[state] int not null,
				
				[order_num] [int] NOT NULL DEFAULT((0)),
				[control] [int] NOT NULL DEFAULT((0)),
				[leave_powered_on]    [bit] NOT NULL DEFAULT((0)),
				[oiag_id] [uniqueidentifier] NULL,
				[restore_counter] [int] NOT NULL DEFAULT((0)),
				[test_scripts_results] [xml],
				[db_instance_id] [uniqueidentifier]
			)
	
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 243; END	
END
GO
--243
-----------------------------------------------------



-----------------------------------------------------
--244
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 243)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[DRRoles]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[DRRoles] (
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[name] nvarchar(max) NOT NULL,
			[effective_memory] [bigint] NOT NULL,
			[boot_delay] int NOT NULL,
			[test_script_file_full_name] nvarchar(max) NOT NULL,
			[db_instance_id] [uniqueidentifier]
			)
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 244; END	
END
GO
--244
-----------------------------------------------------


-----------------------------------------------------
--248
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 244 AND current_version < 248)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Air.LabRequests]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[Air.LabRequests](
				[id] [uniqueidentifier] NOT NULL,
				[req_vmname] [nvarchar](1000) NOT NULL,
				[req_vmtype] int,
				[req_date] datetime,
				[sid] [nvarchar](184) NOT NULL,
				[user] [nvarchar](1000) NOT NULL,
				[description] [nvarchar](4000) NOT NULL DEFAULT '''',
				[preferred_date] [datetime] NOT NULL,
				[preferred_duration_sec] [bigint] NOT NULL,
				[queue_num] [int] IDENTITY(0,1) NOT NULL,
				[state_id] [uniqueidentifier] NULL,
				[aux_data] [xml] NULL,
			 CONSTRAINT [PK_Air_LabRequests] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 248; END	
END
GO
--248
-----------------------------------------------------



-----------------------------------------------------
--250
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 248 AND current_version < 250)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Air.LabRequestStates]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[Air.LabRequestStates](
				[id] [uniqueidentifier] NOT NULL,
				[request_id] [uniqueidentifier] NULL,
				[date] [datetime] NOT NULL,
				[state] [int] NOT NULL,
				[description] [nvarchar](4000) NOT NULL,
				[aux_data] [xml] NULL,
				[num] [int] IDENTITY(0,1) NOT NULL
			 CONSTRAINT [PK_Air.LabRequestStates] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 250; END	
END
GO
--250
-----------------------------------------------------



-----------------------------------------------------
--251
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 250)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N''[dbo].[FK_Air.LabRequestStates_Air.LabRequests]'') AND parent_object_id = OBJECT_ID(N''[dbo].[Air.LabRequestStates]''))
		BEGIN
			ALTER TABLE [dbo].[Air.LabRequestStates]  WITH CHECK ADD  CONSTRAINT [FK_Air.LabRequestStates_Air.LabRequests] FOREIGN KEY([request_id])
			REFERENCES [dbo].[Air.LabRequests] ([id])
			ON DELETE CASCADE
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 251; END	
END
GO
--251
-----------------------------------------------------


-----------------------------------------------------
--252
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 251)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.JobSessions]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[Backup.Model.JobSessions](
				[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
				[job_id] [uniqueidentifier] NULL,
				[job_name] [nvarchar](255) NOT NULL,
				[job_type] [int] NOT NULL DEFAULT ((0)),
				[creation_time] [datetime] NOT NULL,
				[end_time] [datetime] NOT NULL DEFAULT (''01.01.1900''),
				[state] [int] NOT NULL DEFAULT ((-1)),
				[result] [int] NOT NULL,				
				[control] [int] NOT NULL DEFAULT ((0)),
				[description] [text] NULL DEFAULT (''''),	
				[operation] [nvarchar](400) NOT NULL,	
				[progress] [int] NOT NULL DEFAULT ((0)),				
				[usn] [bigint] NOT NULL DEFAULT ((0)),
				[log_xml] [xml] not null default (''<Root TotalUsn="0" TotalId="0"></Root>''),
				[db_instance_id] [uniqueidentifier]
			)
		END
	
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 252; END	
END
GO
--252
-----------------------------------------------------


-----------------------------------------------------
--254
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 252 AND current_version < 254)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.SbSessions]'') AND type in (N''U''))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.SbSessions](
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[preferred_date] [datetime],		
			[usn] [bigint] NOT NULL DEFAULT ((0)),
			[db_instance_id] [uniqueidentifier]
			)
	END	
	'
	---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 254; END	
END
GO
--254


-----------------------------------------------------
--255
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 254)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[Backup.Model.BackupJobSessions]'') AND type in (N''U''))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.BackupJobSessions](
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[is_retry] [bit] NOT NULL DEFAULT 0,
			[total_objects] [int] NOT NULL  DEFAULT 0,
			[processed_objects] [int] NOT NULL DEFAULT 0,
			[total_size] [bigint] NOT NULL DEFAULT 0,
			[processed_size] [bigint] NOT NULL DEFAULT 0,
			[usn] [bigint] NOT NULL DEFAULT 0,
			[job_source_type] [int] NOT NULL DEFAULT 0,
			[avg_speed] [bigint] NOT NULL DEFAULT 0,
			[is_startfull] [bit] NOT NULL DEFAULT 0,
			[db_instance_id] [uniqueidentifier]
			)
	END
	'
	---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 255; END	
END
GO
--255

-----------------------------------------------------
--256
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 255)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[Backup.Model.BackupTaskSessions]'') AND type in (N''U''))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.BackupTaskSessions](
			[id] [uniqueidentifier] NOT NULL,
			[session_id] [uniqueidentifier] NOT NULL,
			[creation_time] [datetime] NOT NULL,
			[object_name] [nvarchar](2000) NULL,
			[status] [int] NOT NULL,
			[reason] [ntext] NULL,
			[object_id] [uniqueidentifier] NULL,
			[end_time] [datetime] NOT NULL DEFAULT (''01.01.1900''),
			[operation] [nvarchar](400) NOT NULL  DEFAULT (''''),
			[total_objects] [int] NOT NULL DEFAULT 0,
			[processed_objects] [int] NOT NULL  DEFAULT 0,
			[total_size] [bigint] NOT NULL DEFAULT 0,
			[processed_size] [bigint] NOT NULL DEFAULT 0,
			[mode] [int] NOT NULL DEFAULT 0,
			[usn] [bigint] NOT NULL DEFAULT 0,
			[avg_speed] [bigint] NOT NULL DEFAULT 0,
			[change_tracking] [bit] NOT NULL DEFAULT 0,
			[db_instance_id] [uniqueidentifier]
			)
	END
	'
	---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 256; END	
END
GO
--256
-----------------------------------------------------
-----------------------------------------------------
--257
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 256)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[ObjectsInApplicationGroups]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[ObjectsInApplicationGroups] (
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[folder_id] [uniqueidentifier] NOT NULL,
			[object_id] [uniqueidentifier] NOT NULL,
			[order] [int] NOT NULL,
			[guest_os_info] [xml],
			[effective_memory] [bigint] NOT NULL,
			[options] [xml],
			[usn] [bigint] NOT NULL DEFAULT 0,
			[db_instance_id] [uniqueidentifier]
			)
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 257; END	
END
GO
--257
-----------------------------------------------------
-----------------------------------------------------
--258
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 257)
BEGIN
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[SbVerificationRules]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[SbVerificationRules] (
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[job_id] [uniqueidentifier] NOT NULL,
			[object_id] [uniqueidentifier] NOT NULL,
			[object_type] [int] NOT NULL,
			[options] [xml],
			[usn] [bigint] NOT NULL DEFAULT ((0)),
			[db_instance_id] [uniqueidentifier]
			)
		END
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 258; END	
END
GO
-----------------------------------------------------

	
-----------------------------------------------------
--259
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 258)
BEGIN
	exec sp_executesql @stat = N'
		IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Repl.Topology.BackupServers]'') AND type in (N''U''))
		BEGIN
			ALTER TABLE dbo.[Repl.Topology.BackupServers] ALTER COLUMN ip_or_dns_name nvarchar(255) not null			
		END						
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 259; END	
END
GO
-----------------------------------------------------
		
	
-----------------------------------------------------
--260
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version < 260)
BEGIN
	exec sp_executesql @stat = N'
	DECLARE @lrstate_filter_type_id as uniqueidentifier			        
	SELECT @lrstate_filter_type_id = ''839E9CC1-E6A1-41d3-B64F-3C4863509BA9''
	       
	INSERT INTO [dbo].[Report.GridReport.FilterTypes]( [id], [unique_name] )
	VALUES( @lrstate_filter_type_id, ''lr_state_filter'')						
	
	INSERT INTO [dbo].[Report.GridReport.FilterType.DynScopeFilterTypes] ( [id], [filter_type_id], [scope_procedure_name])
	VALUES( NEWID(), @lrstate_filter_type_id, ''usp.GridReport.DynScopeFilter.EnumLabRequestsStates'' )
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 260; END	
END
GO
-----------------------------------------------------



-----------------------------------------------------
--261
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 260)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_from')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_from] nvarchar(1000) default '' NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 261; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--262
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 261)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_to')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_to] nvarchar(1000) default '' NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 262; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--263
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 262)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_subject')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_subject] nvarchar(1000) default '' NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 263; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--264
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 263)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_state_pending')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_state_pending] bit default 0 NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 264; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--265
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 264)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_state_ready')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_state_ready] bit default 0 NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 265; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--266
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 265)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_state_cancelled')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_state_cancelled] bit default 0 NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 266; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--267
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 266)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_state_approved')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_state_approved] bit default 0 NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 267; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--268
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 267)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_state_failed')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_state_failed] bit default 0 NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 268; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--269
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 268)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_state_stopped')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_state_stopped] bit default 0 NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 269; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--270
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 269)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') and [name] = 'lr_send')
	begin
		ALTER TABLE [dbo].[Notification.MailSettings] ADD [lr_send] bit default 0 NOT NULL
	end
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 270; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
--271
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 270)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[LinkedJobs]'') AND type in (N''U''))
		BEGIN
			CREATE TABLE [dbo].[LinkedJobs] (
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[job_id] [uniqueidentifier] NOT NULL,
			[linked_job_id] [uniqueidentifier] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
			)
		END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 271; END	
END
GO
--271
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 271)
BEGIN
	exec sp_executesql @stat = N'IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N''[dbo].[BJobs]'') AND [name] = ''platform'')
	BEGIN
		ALTER TABLE [dbo].[BJobs] ADD platform int NOT NULL DEFAULT(0)
	END'
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 273; END	
END		
GO
--
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 273)
BEGIN
    alter table [dbo].[Backup.Model.JobSessions] add log_text ntext null
    print 'New column {log_text} has been successfully added to [dbo].[Backup.Model.JobSessions] table'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 274; END	
END
GO
--
-----------------------------






/********************************************************/
/*               DATA UPGRADE 40-50						*/



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 274)
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.Backup50Upgrade.GetBackupsChainAsc]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[fn.Backup50Upgrade.GetBackupsChainAsc]
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 287; END	
END		
GO
--
-----------------------------------------------------




-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 287)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	CREATE FUNCTION [dbo].[fn.Backup50Upgrade.GetBackupsChainAsc] ( @id uniqueidentifier )
	RETURNS 
	@Result TABLE 
	(
		id UNIQUEIDENTIFIER, 
		rn int
	)
	AS
	BEGIN
		DECLARE @rn INT
		SET @rn = 1

		DECLARE @ChainAsc TABLE (id UNIQUEIDENTIFIER, parent_id UNIQUEIDENTIFIER, rn int)
		INSERT @ChainAsc(id, parent_id, rn)
		SELECT linked_rollback, id, @rn from Backups where id = @id

		WHILE @@RowCount <> 0
		BEGIN
			set @rn = @rn + 1
			INSERT @ChainAsc(id, parent_id, rn)
			select b.linked_rollback, b.id, @rn from Backups b, @ChainAsc bc
			where b.id = bc.id and bc.id != bc.parent_id AND bc.rn = @rn - 1
		END

		INSERT @Result(id, rn)
		select parent_id , rn from @ChainAsc
			
		RETURN 
	END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 288; END	
END
GO
--
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 288)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	CREATE FUNCTION [dbo].[fn.Backup50Upgrade.GetNextLinkedObjectInBackup] ( @id uniqueidentifier )
	RETURNS uniqueidentifier
	AS
	BEGIN
		declare @linkId uniqueidentifier
		
		SELECT @linkId = oibs.id FROM 
		(SELECT * from [dbo].[fn.Backup50Upgrade.GetBackupsChainAsc]((SELECT TOP 1 b.id FROM backups b, [ObjectsInBackups] o WHERE o.[backup_id] = b.id AND o.id = @id))) backupsChain,
		[ObjectsInBackups] oibs,
		(SELECT * FROM ObjectsInBackups WHERE id = @id) oibs1
		WHERE oibs.[backup_id] = backupsChain.[id] AND
		oibs.object_id = oibs1.object_id and backupsChain.rn = 2
		
		return @linkId
	END
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 289; END	
END
GO
--
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 289)
BEGIN
	---------------------------------------------------

	declare @bid              uniqueidentifier 
	declare @bcreation_time   datetime
	declare @bis_rollback     bit
	declare @bhost_id         uniqueidentifier 
	declare @blinked_rollback uniqueidentifier 
	declare @bjob_name        nvarchar(255) 
	declare @bjob_id          uniqueidentifier 
	declare @bjob_type        int
	declare @bis_retry        bit
	declare @bfile_name       nvarchar(255)
	declare @bstats           xml
	declare @bversion         int
	declare @bjob_source_type int 
	declare @bis_last         bit		
	declare @dbinstance_id    uniqueidentifier


	declare @points_backups as table ([pid] uniqueidentifier, [bid] uniqueidentifier)


	--populate [dbo].[Backup.Model.Backups]
	DECLARE points_cursor CURSOR FOR
	SELECT 
		[id],
		[creation_time],
		[is_rollback],
		[host_id],
		[linked_rollback],
		[job_name],
		[job_id],
		[job_type],
		[is_retry],
		[file_name], 
		[stats],
		[version],
		0,
		[is_last],
		[db_instance_id]
	FROM [dbo].[Backups]
	ORDER BY job_id, creation_time
	OPEN points_cursor
	FETCH NEXT FROM points_cursor into @bid, @bcreation_time, @bis_rollback, @bhost_id, @blinked_rollback, @bjob_name, @bjob_id, @bjob_type, @bis_retry, @bfile_name, @bstats, @bversion, @bjob_source_type, @bis_last, @dbinstance_id
	WHILE @@FETCH_STATUS = 0
	BEGIN

		declare @backup_id uniqueidentifier	
		set @backup_id = null			
		if @bjob_id is not null
			select top 1 @backup_id = id from [dbo].[Backup.Model.Backups] where job_id = @bjob_id
		else
			select top 1 @backup_id = id from [dbo].[Backup.Model.Backups] where job_name = @bjob_name
			
		DECLARE @bhost_protocol int
		set @bhost_protocol = null
		select @bhost_protocol = protocol from [dbo].[Hosts] where id = @bhost_id

		if @backup_id is null
		BEGIN
			set @backup_id = newid()
			
			insert [dbo].[Backup.Model.Backups]
				(id,
				 job_id, 
				 job_name, 
				 job_source_type, 
				 job_target_type, 
				 job_target_host_id,
				 job_target_host_protocol,
				 db_instance_id)
			select
				 @backup_id,
				 @bjob_id, 
				 @bjob_name, 
				 @bjob_source_type,
				 @bjob_type,
				 @bhost_id,
				 @bhost_protocol,
				 @dbinstance_id
		END

		insert 
			@points_backups(pid, bid)
		select
			@bid, @backup_id
		
		FETCH NEXT FROM points_cursor into @bid, @bcreation_time, @bis_rollback, @bhost_id, @blinked_rollback, @bjob_name, @bjob_id, @bjob_type, @bis_retry, @bfile_name, @bstats, @bversion, @bjob_source_type, @bis_last, @dbinstance_id
	END
	CLOSE points_cursor
	DEALLOCATE points_cursor
	--


	declare @bkpid       uniqueidentifier
	declare @bkpjob_id   uniqueidentifier
	declare @bkpjob_name nvarchar(255) 
	declare @bkpjob_source_type int
	declare @bkpjob_target_type int
	declare @bkptarget_host_id  uniqueidentifier

	--run through [dbo].[Backup.Model.Backups]
	DECLARE backups_cursor CURSOR FOR
	SELECT 
		[id],
		[job_id], 
		[job_name], 
		[job_source_type], 
		[job_target_type], 
		[job_target_host_id]
	FROM [dbo].[Backup.Model.Backups]

	OPEN backups_cursor
	FETCH NEXT FROM backups_cursor into @bkpid, @bkpjob_id, @bkpjob_name, @bkpjob_source_type, @bkpjob_target_type, @bkptarget_host_id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		declare @pnum int
		set     @pnum = 1

		declare @pgroup_id uniqueidentifier
		set     @pgroup_id = newid()

		--populate [dbo].[Backup.Model.Points]	
		DECLARE pnt_cursor CURSOR FOR
		SELECT 
			[id],
			[creation_time],
			[is_rollback],
			[host_id],
			[linked_rollback],
			[job_name],
			[job_id],
			[job_type],
			[is_retry],
			[file_name], 
			[stats],
			[version],
			0,
			[is_last],
			[db_instance_id]
		FROM [dbo].[Backups]
		WHERE id in (select pid from @points_backups where bid = @bkpid)
		ORDER BY job_id, creation_time
		OPEN pnt_cursor
		
		FETCH NEXT FROM pnt_cursor into @bid, @bcreation_time, @bis_rollback, @bhost_id, @blinked_rollback, @bjob_name, @bjob_id, @bjob_type, @bis_retry, @bfile_name, @bstats, @bversion, @bjob_source_type, @bis_last, @dbinstance_id
		WHILE @@FETCH_STATUS = 0
		BEGIN
					
			declare @palg  int
			set     @palg  = 1 --synthetic

			declare @ptype int
			set     @ptype = 1 --normal
			
			declare @plink_id uniqueidentifier
			set     @plink_id = @blinked_rollback
			
			declare @chain_finished bit
			set     @chain_finished = 0
		
			if @bid = @blinked_rollback 
			begin
				set @ptype = 0
				set @palg  = 0
				set @plink_id = null
				set @chain_finished = 1
			end


			--
			insert [dbo].[Backup.Model.Points]
				(id, link_id, num, creation_time, type, alg, group_id, backup_id, db_instance_id)
			select
				 @bid, @plink_id, @pnum, @bcreation_time, @ptype, @palg, @pgroup_id, @bkpid, @dbinstance_id
			--

			declare @oib_id            uniqueidentifier
			declare @oib_object_id     uniqueidentifier
			declare @oib_backup_id     uniqueidentifier
			declare @oib_filename      nvarchar(1000)
			declare @oib_is_corrupted  bit
			declare @oib_state         int
			declare @oib_inside_dir    nvarchar(400)
			declare @oib_is_full       bit
			declare @oib_creation_time datetime
			declare @oib_approx_size   bigint
			declare @oib_proccess_id   int
			
			DECLARE oib_cursor CURSOR FOR
			SELECT 
				[id],
				[object_id],
				[backup_id],
				[filename],
				[is_corrupted],
				[state],
				[inside_dir],
				[is_full],
				[creation_time],
				[approx_size],
				-1
			FROM [dbo].[ObjectsInBackups]
			WHERE backup_id = @bid
			OPEN oib_cursor
			
			FETCH NEXT FROM oib_cursor into @oib_id, @oib_object_id, @oib_backup_id, @oib_filename, @oib_is_corrupted, @oib_state, @oib_inside_dir, @oib_is_full, @oib_creation_time, @oib_approx_size, @oib_proccess_id
			WHILE @@FETCH_STATUS = 0
			BEGIN		

				declare @storage_id uniqueidentifier
				set @storage_id = null
				
				
				select top 1 @storage_id = id 
				from
					[dbo].[Backup.Model.Storages]
				where
					backup_id = @bkpid and
					file_path = @oib_filename and
					host_id   = @bhost_id

				--populate [dbo].[Backup.Model.Storages]
				if @storage_id is null
				BEGIN
					set @storage_id = newid()
					
					insert [dbo].[Backup.Model.Storages]		
					   (id,
						file_path,
						backup_id,
						host_id,
						creation_time,
						modification_time,
						stats,
						version,
						full_size,
						db_instance_id
						)
					select 
						@storage_id,
						@oib_filename,
						@bkpid,
						@bhost_id,
						@oib_creation_time,
						@oib_creation_time,
						@bstats,
						@bversion,
						0, -- full_size,
						@dbinstance_id		
				END
				--
				
				 		
				--populate [dbo].[Backup.Model.OIBs]
				insert [dbo].[Backup.Model.OIBs]
					(id, 
					object_id, 
					point_id, 
					storage_id, 
					link_id, 
					is_corrupted, 
					is_consistent, 
					state, 
					type, 
					alg,
					inside_dir,
					creation_time,
					vmname,
					guest_os_info,
					memory,
					approx_size,
					process_id,
					has_index,
					db_instance_id)
				select
					@oib_id, 
					@oib_object_id, 
					@oib_backup_id, 
					@storage_id, 
					[dbo].[fn.Backup50Upgrade.GetNextLinkedObjectInBackup] (@oib_id), --link_id
					@oib_is_corrupted, 
					@oib_is_full, 
					@oib_state, 
					@ptype, 
					@palg,
					@oib_inside_dir,
					@oib_creation_time,
					o.object_name,
					o.guest_os,
					0,
					@oib_approx_size,
					@oib_proccess_id,
					0, -- has_index					
					@dbinstance_id
				from [dbo].[BObjects] o
				where
					o.id = @oib_object_id
				--
				
				FETCH NEXT FROM oib_cursor into @oib_id, @oib_object_id, @oib_backup_id, @oib_filename, @oib_is_corrupted, @oib_state, @oib_inside_dir, @oib_is_full, @oib_creation_time, @oib_approx_size, @oib_proccess_id
			END
			CLOSE oib_cursor
			DEALLOCATE oib_cursor	
			--


			set @pnum = @pnum + 1		
			if @chain_finished = 1 
			begin
				set @pgroup_id = newid()
			end
			
			FETCH NEXT FROM pnt_cursor into @bid, @bcreation_time, @bis_rollback, @bhost_id, @blinked_rollback, @bjob_name, @bjob_id, @bjob_type, @bis_retry, @bfile_name, @bstats, @bversion, @bjob_source_type, @bis_last, @dbinstance_id
		END
		CLOSE pnt_cursor
		DEALLOCATE pnt_cursor	
		--
		
		
		FETCH NEXT FROM backups_cursor into @bkpid, @bkpjob_id, @bkpjob_name, @bkpjob_source_type, @bkpjob_target_type, @bkptarget_host_id
	END
	CLOSE backups_cursor
	DEALLOCATE backups_cursor
	--
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 290; END	
END
GO
--
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 290)
BEGIN
	---------------------------------------------------
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.Backup50Upgrade.GetBackupsChainAsc]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[fn.Backup50Upgrade.GetBackupsChainAsc]
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.Backup50Upgrade.GetNextLinkedObjectInBackup]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[fn.Backup50Upgrade.GetNextLinkedObjectInBackup]	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 291; END	
END
GO
--
-----------------------------------------------------




-----------------------------------------------------
-- Upgrade data: Backup.Model.JobSessions
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 291)
BEGIN

DECLARE bs_cursor CURSOR FOR
select
	bs.id,
	bs.job_id,
	bs.job_name,
	bs.job_type,
	bs.creation_time,
	bs.end_time,
	bs.state,
	bs.result,
	0,
	bs.description,
	bs.operation,
	bs.progress
from
	[dbo].[BSessions] bs

OPEN bs_cursor

declare @id uniqueidentifier
declare @job_id uniqueidentifier
declare @job_name nvarchar(255)
declare @job_type int
declare @creation_time datetime
declare @end_time datetime
declare @state int
declare @result int
declare @control int
declare @description varchar(max)
declare @operation nvarchar(400)
declare @progress int

FETCH NEXT FROM bs_cursor into @id, @job_id, @job_name, @job_type, @creation_time, @end_time, @state, @result, @control, @description, @operation, @progress
WHILE @@FETCH_STATUS = 0
BEGIN	
	insert into 
		[dbo].[Backup.Model.JobSessions]
	(
		[id],
		[job_id],
		[job_name],
		[job_type],
		[creation_time],
		[end_time],
		[state],
		[result] ,
		[control],
		[description],
		[operation],
		[progress]
	)
	select
		@id,
		@job_id,
		@job_name,
		@job_type,
		@creation_time,
		@end_time,
		@state,
		@result,
		@control,
		@description,
		@operation,
		@progress
	FETCH NEXT FROM bs_cursor into @id, @job_id, @job_name, @job_type, @creation_time, @end_time, @state, @result, @control, @description, @operation, @progress
END

CLOSE bs_cursor
DEALLOCATE bs_cursor	
--

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 294; END	
END		
GO
--
-----------------------------------------------------


-----------------------------------------------------
-- Upgrade data: Backup.Model.BackupJobSessions
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 294)
BEGIN

declare @id uniqueidentifier
declare @is_retry bit
declare @total_objects int
declare @processed_objects int
declare @total_size bigint
declare @processed_size bigint
declare @job_source_type int
declare @avg_speed bigint
declare @is_startfull bit


DECLARE bs_cursor CURSOR FOR
select
	bs.id,
	bs.is_retry,
	bs.total_objects,
	bs.processed_objects,
	bs.total_size,
	bs.processed_size,
	bs.job_source_type,
	bs.avg_speed,
	bs.is_startfull
from
	[dbo].[BSessions] bs	

OPEN bs_cursor

FETCH NEXT FROM bs_cursor into @id, @is_retry, @total_objects, @processed_objects, @total_size, @processed_size, @job_source_type, @avg_speed, @is_startfull
WHILE @@FETCH_STATUS = 0
BEGIN	

	insert into
	[dbo].[Backup.Model.BackupJobSessions](
		[id],
		[is_retry],
		[total_objects],
		[processed_objects],
		[total_size],
		[processed_size],
		[job_source_type],
		[avg_speed],
		[is_startfull]
		)
	select
		@id,
		@is_retry,
		@total_objects,
		@processed_objects,
		@total_size,
		@processed_size,
		@job_source_type,
		@avg_speed,
		@is_startfull
		
	FETCH NEXT FROM bs_cursor into @id, @is_retry, @total_objects, @processed_objects, @total_size, @processed_size, @job_source_type, @avg_speed, @is_startfull
END

CLOSE bs_cursor
DEALLOCATE bs_cursor	
--

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 295; END	
END		
GO
--
-----------------------------------------------------



-----------------------------------------------------
-- Upgrade data: Backup.Model.BackupTaskSessions
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 295)
BEGIN

declare @id uniqueidentifier
declare @session_id uniqueidentifier
declare @creation_time datetime
declare @object_name nvarchar(2000)
declare @status int
declare @reason nvarchar(max)
declare @object_id uniqueidentifier
declare @end_time datetime
declare @operation nvarchar(400)
declare @total_objects int
declare @processed_objects int
declare @total_size bigint
declare @processed_size bigint
declare @mode int
declare @avg_speed bigint
declare @change_tracking bit


DECLARE bts_cursor CURSOR FOR
select 
	bts.id,
	bts.session_id,
	bts.creation_time,
	bts.object_name,
	bts.status,
	bts.reason,
	bts.object_id,
	bts.end_time,
	bts.operation,
	bts.total_objects,
	bts.processed_objects,
	bts.total_size,
	bts.processed_size,
	bts.mode,
	bts.avg_speed,
	0 --change_tracking
from
	[dbo].[BSessionInfo] bts

OPEN bts_cursor

FETCH NEXT FROM bts_cursor into @id, @session_id, @creation_time, @object_name, @status, @reason, @object_id, @end_time, @operation, @total_objects, @processed_objects, @total_size, @processed_size, @mode, @avg_speed, @change_tracking
WHILE @@FETCH_STATUS = 0
BEGIN	

	insert into [dbo].[Backup.Model.BackupTaskSessions]
	(
		[id],
		[session_id],
		[creation_time],
		[object_name],
		[status],
		[reason],
		[object_id],
		[end_time],
		[operation],
		[total_objects],
		[processed_objects],
		[total_size],
		[processed_size],
		[mode],
		[avg_speed],
		[change_tracking]
	)
	select 
		@id,
		@session_id, 
		@creation_time, 
		@object_name, 
		@status, 
		@reason, 
		@object_id, 
		@end_time, 
		@operation, 
		@total_objects, 
		@processed_objects, 
		@total_size, 
		@processed_size, 
		@mode, 
		@avg_speed, 
		@change_tracking
		
	FETCH NEXT FROM bts_cursor into @id, @session_id, @creation_time, @object_name, @status, @reason, @object_id, @end_time, @operation, @total_objects, @processed_objects, @total_size, @processed_size, @mode, @avg_speed, @change_tracking
END

CLOSE bts_cursor
DEALLOCATE bts_cursor	
--

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 296; END	
END		
GO
--
-----------------------------------------------------



-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 296)
BEGIN

	delete [dbo].[LicensedHosts]

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 297; END	
END
GO
--
-----------------------------------------------------

-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 297)
BEGIN

	ALTER TABLE [dbo].[Security.Accounts]
	ALTER COLUMN [sid] [nvarchar](184) NOT NULL;

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 298; END	
END
GO
--
-----------------------------------------------------






/*             END OF DATA UPGRADE 				*/
/********************************************************/










-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 298)
BEGIN

	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Report.GridReport.Filters]') and [name] = 'prefval_object_id')
	begin
		alter table [dbo].[Report.GridReport.Filters] add prefval_object_id nvarchar(255) null
		print 'New column {prefval_object_id} has been successfully added to [dbo].[Report.GridReport.Filters] table'
	end

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 310; END	
END
GO
--
-----------------------------------------------------



-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 310)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[VeeamProductVersion]') AND type in (N'U'))
    BEGIN
			CREATE TABLE [dbo].[VeeamProductVersion](
                  [VeeamProductID] NVARCHAR(38) NOT NULL,
                  [VeeamProductVersion] NVARCHAR(16) NOT NULL
            )
	END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 311; END	
END
GO
--
-----------------------------------------------------



--5.0.2
-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 311)
BEGIN

	exec sp_executesql @st = N'
	if not exists (select * from syscolumns where id = OBJECT_ID(N''[dbo].[Backup.Model.Points]'') and [name] = ''num2'')
	begin

		alter table [dbo].[Backup.Model.Points]
		add [num2] numeric(16, 10) not null default(0)

	end
	'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 312; END	
END
GO
--
-----------------------------------------------------


-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 312)
BEGIN
	
	exec sp_executesql @st = N'
	update 
		[dbo].[Backup.Model.Points]
	set 
		[num2] = [num]
	'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 313; END	
END
GO
--
-----------------------------------------------------


-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 313)
BEGIN

	if exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Backup.Model.Points]') and [name] = 'num')
	begin
		declare @defconstraint_name nvarchar(max)
		select @defconstraint_name = object_name(cdefault) from syscolumns
		where [id] = object_id('[dbo].[Backup.Model.Points]')
		and [name] = 'num'

		if @defconstraint_name is not null
		exec ('alter table [dbo].[Backup.Model.Points] drop constraint [' + @defconstraint_name + ']')
		
		alter table [dbo].[Backup.Model.Points] drop column [num]
		
		exec sp_rename '[dbo].[Backup.Model.Points].[num2]', 'num', 'COLUMN'
	end

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 314; END	
END
GO
--
-----------------------------------------------------






-----------------------------------------------------
-- DATA UPGRADE 50-60 
-----------------------------------------------------




--350 - Starting UPGRADE 5.0 - 6.0
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 314)
BEGIN
	UPDATE [dbo].[Version] SET current_version = 350;
END
GO
--
-----------------------------------------------------


-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 350)
BEGIN

	
	IF EXISTS (SELECT * FROM sys.key_constraints WHERE name = 'PK_BObjects')
		ALTER TABLE [dbo].[BObjects] DROP CONSTRAINT [PK_BObjects]
	
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[Backup.Model.JobSessions]', 'usn'
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[Backup.Model.BackupJobSessions]', 'usn'
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[Backup.Model.BackupTaskSessions]', 'usn'
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[Backup.Model.SbSessions]', 'usn'
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[Backup.Model.SbTaskSessions]', 'usn'
	--exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[BSessionInfo]', 'usn'
	--exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[BSessions]', 'usn'
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[ObjectsInApplicationGroups]', 'usn'
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[SbVerificationRules]', 'usn'
	exec [dbo].[usp.Upgrade.Common.DropColumn] '[dbo].[VirtualLabs]', 'usn'

 
	declare @table_name nvarchar(255)
	
	declare tables_cursor cursor for
	select name from [dbo].[fn.Upgrade.56.GetTablesToUpgrade] ()
	
	open tables_cursor
	fetch next from tables_cursor into @table_name

	while @@FETCH_STATUS = 0
	BEGIN
	
		declare @renamed_table nvarchar(255)		
		set @renamed_table = [dbo].[fn.Upgrade.56.GetPreviousTableName] (@table_name)
		
		declare @current_table nvarchar(255)		
		set @current_table = [dbo].[fn.Upgrade.Common.GetCurrentTableName] (@table_name)
		
		if not exists(select * from sys.Tables where name = @renamed_table)
		begin 
		
			exec [dbo].[usp.Upgrade.Common.RenameTable] @renamed_table, @table_name
			exec [dbo].[usp.Upgrade.Common.DuplicateTable] @current_table, @renamed_table 
			
		end
		
		fetch next from tables_cursor into @table_name
	END
	
	close tables_cursor
	deallocate tables_cursor		
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 351; END	
END
GO
-----------------------------------------------------



-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 351)
BEGIN

	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Repl.Scheme.TablesBindings]') and [name] = 'vbsrv_version')
	begin
		ALTER TABLE [dbo].[Repl.Scheme.TablesBindings] ADD [vbsrv_version] int not null default 6
	end
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 352; END	
END
GO
-----------------------------------------------------



-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 352)
BEGIN

	declare dbinst_cursor cursor for
	select id from [dbo].[Repl.Topology.BackupDbInstances]
	
	declare @dbinst uniqueidentifier
	
	open dbinst_cursor
	fetch next from dbinst_cursor into @dbinst
	
	while @@FETCH_STATUS = 0
	begin
		exec [dbo].[usp.Upgrade.56.InternalSync] @dbinst, N'C'
		fetch next from dbinst_cursor into @dbinst
	end	
	
	close dbinst_cursor
	deallocate dbinst_cursor
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 353; END	
END
GO
-----------------------------------------------------




-----------------------------------------------------
-- END DATA UPGRADE 50-60 
-----------------------------------------------------



--400 - Starting version number for 6.0
-----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 353) -- <- set last upgrade 50-60 version
BEGIN
	UPDATE [dbo].[Version] SET current_version = 400;
END
GO
--
-----------------------------------------------------



-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 400)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FLRSessions]') AND type in (N'U'))
    BEGIN
			exec sp_executesql @stat = N'
			CREATE TABLE [dbo].[FLRSessions](
				[session_id] [uniqueidentifier] NOT NULL,
				[start_time] [datetime] NOT NULL,
				[status] [int] NOT NULL,
				[end_time] [datetime] NULL,
				[total_objects] [int] NOT NULL,
				[processed_objects] [int] NOT NULL,
				[details] [text] NULL,
			CONSTRAINT [PK_FLRSessions] PRIMARY KEY CLUSTERED 
			(
				[session_id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
			'
	END
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FLRSessionEvents]') AND type in (N'U'))
    BEGIN
			exec sp_executesql @stat = N'
			CREATE TABLE [dbo].[FLRSessionEvents](
			[session_id] [uniqueidentifier] NOT NULL,
			[event_time] [datetime] NOT NULL,
			[severity] [int] NOT NULL,
			[ordinal_num] [int] NOT NULL,
			[text] [nvarchar](max) NOT NULL
			) ON [PRIMARY]
			'
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 401; END	
END
GO
-----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 401)
BEGIN

	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FLRSessions]') AND type in (N'U'))
		BEGIN
			exec sp_executesql @stat = N'
				ALTER TABLE [dbo].[FLRSessions] ADD [options] xml DEFAULT ('''') NOT NULL 
				ALTER TABLE [dbo].[FLRSessions] ADD [files_log] xml DEFAULT (''<Root TotalUsn="0" TotalId="0"></Root>'') NOT NULL 
				ALTER TABLE [dbo].[FLRSessions] ADD [top_log_num] int DEFAULT (0) NOT NULL
				ALTER TABLE [dbo].[FLRSessions] ADD [initiator_name] nvarchar(300)
				ALTER TABLE [dbo].[FLRSessions] ADD [initiator_sid] nvarchar(100)
			'
		END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 402; END	
END
GO
-----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 402)
BEGIN

	IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FLRSessionFiles]') AND type in (N'U'))
		BEGIN
			exec sp_executesql @stat = N'
				CREATE TABLE [dbo].[FLRSessionFiles](
				[id] [uniqueidentifier] NOT NULL,
				[session_id] [uniqueidentifier] NOT NULL,
				[file_path] [nvarchar](max) NOT NULL,
				[creation_time] [datetime] NOT NULL,
			 CONSTRAINT [PK_FLRSessionFiles] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
			'
		END
		
		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') AND type in (N'U'))
		BEGIN
			exec sp_executesql @stat = N'
			ALTER TABLE [dbo].[Notification.MailSettings] ADD [flr_send] bit DEFAULT (0) NOT NULL
			ALTER TABLE [dbo].[Notification.MailSettings] ADD [flr_from] nvarchar(1000) DEFAULT ('''') NOT NULL
			ALTER TABLE [dbo].[Notification.MailSettings] ADD [flr_to] nvarchar(1000) DEFAULT ('''') NOT NULL
			'
		END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 403; END	
END
GO

-------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 403)
BEGIN
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Catalog.ScalarSettings]') AND type in (N'U'))
	BEGIN
		exec sp_executesql @stat = N'ALTER TABLE dbo.[Catalog.ScalarSettings] ADD allow_search_servers bit NOT NULL CONSTRAINT [DF_Catalog.ScalarSettings_allow_search_servers] DEFAULT 1'
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 404; END	
END
GO

-------------------------------------------------------


-------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 404)
BEGIN
	ALTER TABLE [dbo].[C.Hosts] ALTER COLUMN reference nvarchar(1024) null
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 406; END	
END
GO
-------------------------------------------------------

-------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 406)
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FLRSessions]') AND type in (N'U'))
		BEGIN
			exec sp_executesql @stat = N'ALTER TABLE [dbo].[FLRSessions] ADD [progress] integer DEFAULT (0) NOT NULL'
		END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 407; END	
END
GO

-------------------------------------------------------

-------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 407)
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.BackupTaskSessions]') AND type in (N'U'))
		BEGIN
			exec sp_executesql @stat = N'
				ALTER TABLE [C.Backup.Model.BackupTaskSessions] ADD [log_xml] xml DEFAULT (''<Root TotalUsn="0" TotalId="0"></Root>'') NOT NULL
				ALTER TABLE [C.Backup.Model.BackupTaskSessions] ADD [read_size] [bigint] NOT NULL DEFAULT(0)
				ALTER TABLE [C.Backup.Model.BackupTaskSessions] ADD [stored_size] [bigint] NOT NULL DEFAULT(0)
				'
		END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 408; END	
END
GO
-----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 408)
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DashboardSettings]') AND type in (N'U'))
		BEGIN
			exec sp_executesql @stat = N'
				ALTER TABLE [dbo].[DashboardSettings] ADD [no_file_restore_downloads] [bit] NOT NULL DEFAULT 0
				'
		END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 409; END	
END
GO
-------------------------------------------------------

-----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 409)
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') AND type in (N'U'))
		BEGIN
			exec sp_executesql @stat = N'
				ALTER TABLE [dbo].[Notification.MailSettings] ADD [smtp_server_ssl] [bit] NOT NULL DEFAULT 0
				'
		END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 410; END	
END
GO
-------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 410)
BEGIN
	
	exec sp_executesql @stat = N'
		if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N''U'') AND cols.name = N''keep_index4archived_backups'' and objs.name = N''Catalog.ScalarSettings'')		
		BEGIN
			ALTER TABLE [dbo].[Catalog.ScalarSettings]
			ADD  [keep_index4archived_backups] bit default 1 NOT NULL
		END		
	'
	
	CREATE TABLE [dbo].[Enterprise.ScalarSettings]
	(
		[id] [int] NOT NULL,
		[default_sessions_retention_for_each_bserver_in_months] [int] NOT NULL,
		CONSTRAINT [PK_Enterprise.ScalarSettings] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)
		WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	)
	ON [PRIMARY]
	
	exec sp_executesql @stat = N'
	INSERT INTO [dbo].[Enterprise.ScalarSettings]([id], [default_sessions_retention_for_each_bserver_in_months])
	VALUES(0, 12)'
					
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 411; END	
END
GO
-----------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 411)
BEGIN

	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'flr_restricted_by_ext' and objs.name = N'DashboardSettings')
		BEGIN
			ALTER TABLE [dbo].[DashboardSettings]
			ADD  [flr_restricted_by_ext] bit default 0 NOT NULL
		END

	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'flr_ext_restrictions' and objs.name = N'DashboardSettings')
		BEGIN
			ALTER TABLE [dbo].[DashboardSettings]
			ADD  [flr_ext_restrictions] nvarchar(1024) default N'txt,pdf,doc,docx,xls,xlsx,ppt,pptx' NOT NULL
		END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 412; END	
END
GO
-----------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 412 AND current_version < 414)
BEGIN

	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'version' and objs.name = N'Repl.Topology.BackupServers')
		BEGIN
			ALTER TABLE [dbo].[Repl.Topology.BackupServers]
			ADD  [version] nvarchar(50) default '5.0.2.0' NOT NULL
		END
	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'major_version' and objs.name = N'Repl.Topology.BackupServers')
		BEGIN
			ALTER TABLE [dbo].[Repl.Topology.BackupServers]
			ADD  [major_version] int default 5 NOT NULL
		END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 414; END	
END
GO
-----------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 414)
BEGIN

	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'name_in_catalog' and objs.name = N'Repl.Topology.BackupServers')
		BEGIN
			ALTER TABLE [dbo].[Repl.Topology.BackupServers]
			ADD  [name_in_catalog] nvarchar(256) default NULL
		END
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 415; END	
END
GO
-----------------------------------------------------


-----------------------------------------------------
-- DATA UPGRADE 60-61 
-----------------------------------------------------


--465 - Starting UPGRADE 6.0 - 6.1
-----------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 415)
BEGIN
	UPDATE [dbo].[Version] SET current_version = 465;
END
GO
--
-----------------------------------------------------


-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 465)
BEGIN

	declare @table_name nvarchar(255)
	
	declare tables_cursor cursor for
	select name from [dbo].[fn.Upgrade.v6_to_v61.GetTablesToUpgrade] ()
	
	open tables_cursor
	fetch next from tables_cursor into @table_name

	while @@FETCH_STATUS = 0
	BEGIN
	
		declare @renamed_table nvarchar(255)		
		set @renamed_table = [dbo].[fn.Upgrade.v6_to_v61.GetPreviousTableName] (@table_name)
		
		declare @current_table nvarchar(255)		
		set @current_table = [dbo].[fn.Upgrade.Common.GetCurrentTableName] (@table_name)
		
		if not exists(select * from sys.Tables where name = @renamed_table)
		begin 
			exec [dbo].[usp.Upgrade.Common.RenameTable] @renamed_table, @current_table
			exec [dbo].[usp.Upgrade.Common.DuplicateTable] @current_table, @renamed_table
		end
		
		fetch next from tables_cursor into @table_name
	END
	
	close tables_cursor
	deallocate tables_cursor		

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 466; END	
END
GO
--
-----------------------------------------------------




-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 466)
BEGIN

exec sp_rename '[dbo].[Repl.Scheme.TablesBindings].[vbsrv_version]', 'vbsrv_version_major', 'COLUMN'
ALTER TABLE [dbo].[Repl.Scheme.TablesBindings] ADD [vbsrv_version_minor] int not null default -1
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 467; END	
END
GO
-----------------------------------------------------



-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 467)
BEGIN

	declare dbinst_cursor cursor for
	select id from [dbo].[Repl.Topology.BackupDbInstances]
	
	declare @dbinst uniqueidentifier
	
	open dbinst_cursor
	fetch next from dbinst_cursor into @dbinst
	
	while @@FETCH_STATUS = 0
	begin
		exec [dbo].[usp.Upgrade.v6_to_v61.InternalSync] @dbinst, N'C'
		fetch next from dbinst_cursor into @dbinst
	end	
	
	close dbinst_cursor
	deallocate dbinst_cursor
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 468; END	
END
GO
-----------------------------------------------------


/*             END OF DATA UPGRADE 60-61				*/
/********************************************************/


-----------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 468)
BEGIN
	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'stored_size' 
	and objs.name = N'6.Backup.Model.BackupJobSessions')
			BEGIN
				ALTER TABLE [dbo].[6.Backup.Model.BackupJobSessions]
				ADD  [stored_size] bigint default 0 NOT NULL
			END
	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'stored_size' 
	and objs.name = N'C.Backup.Model.BackupJobSessions')
			BEGIN
				ALTER TABLE [dbo].[C.Backup.Model.BackupJobSessions]
				ADD  [stored_size] bigint default 0 NOT NULL
			END	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 469; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 469)
BEGIN	
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.OIBs]') and [name] = N'[has_exchange]')
	begin
		alter table [dbo].[C.Backup.Model.OIBs] add [has_exchange] bit DEFAULT 0 NOT null
		print 'New column {has_exchange} has been successfully added to dbo.C.Backup.Model.OIBs table'
	end	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 470; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 470)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.LicensedHosts]') and [name] = N'[cores]')
	begin
		alter table [dbo].[C.LicensedHosts] add cores int DEFAULT 0 NOT null
		print 'New column {cores} has been successfully added to [dbo].[C.LicensedHosts] table'
	end	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 471; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 471)
BEGIN	
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.BJobs]') and [name] = N'[parent_schedule_id]')
	begin
		alter table [dbo].[C.BJobs] add [parent_schedule_id] uniqueidentifier DEFAULT NULL
		print 'New column [parent_schedule_id] has been successfully added to dbo.C.BJobs table'
	end	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 472; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 472)
BEGIN	
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Repl.Topology.BackupServers]') and [name] = N'em_name')
	begin
		alter table [dbo].[Repl.Topology.BackupServers] add [em_name] nvarchar(255) DEFAULT NULL
		print 'New column [em_name] has been successfully added to dbo.Repl.Topology.BackupServers table'
	end	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 473; END	
END
GO

/*             END OF DATA UPGRADE 61-65				*/
/********************************************************/

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 473)
BEGIN
	UPDATE [dbo].[Version] SET current_version = 523;
END
GO
-----------------------------------------------------





-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 523)
BEGIN

	declare @table_name nvarchar(255)
	
	declare tables_cursor cursor for
	select name from [dbo].[fn.Upgrade.v65_to_v70.GetTablesToUpgrade] ()
	
	open tables_cursor
	fetch next from tables_cursor into @table_name

	while @@FETCH_STATUS = 0
	BEGIN
	
		declare @renamed_table nvarchar(255)		
		set @renamed_table = [dbo].[fn.Upgrade.v65_to_v70.GetPreviousTableName] (@table_name)
		
		declare @current_table nvarchar(255)		
		set @current_table = [dbo].[fn.Upgrade.Common.GetCurrentTableName] (@table_name)
		
		if not exists(select * from sys.Tables where name = @renamed_table)
		begin 
			exec [dbo].[usp.Upgrade.Common.RenameTable] @renamed_table, @current_table
			exec [dbo].[usp.Upgrade.Common.DuplicateTable] @current_table, @renamed_table
		end
		
		fetch next from tables_cursor into @table_name
	END
	
	close tables_cursor
	deallocate tables_cursor		

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 524; END	
END
GO
--
-----------------------------------------------------



-----------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 524 AND current_version < 526)
BEGIN

	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'parent_id' and objs.name = N'C.Backup.Model.OIBs')
		BEGIN
			ALTER TABLE [dbo].[C.Backup.Model.OIBs]
			ADD  [parent_id] uniqueidentifier DEFAULT NULL
		END
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 526; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 526)
BEGIN
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.RestoreJobSessions](
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[action] [int] NOT NULL DEFAULT ((0)),
			[usn] [bigint] NOT NULL DEFAULT ((0)),
			[options] [xml] NOT NULL DEFAULT ('') ,
			[initiator_sid] [nvarchar](255)  NULL DEFAULT (''),
			[initiator_name] [nvarchar](255) NULL DEFAULT (''),
			[reason] [nvarchar](max) NOT NULL DEFAULT (''),
			[files_log_xml] [xml] NOT NULL DEFAULT ('<Root TotalUsn="0" TotalId="0"></Root>'),
			[platform] [int] NOT NULL DEFAULT ((0)),
			[multi_restore_id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[restore_type] [int] NOT NULL DEFAULT ((0)),
			[oib_id] [uniqueidentifier] NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000') ,
			[db_instance_id] [uniqueidentifier] NULL,

			PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY] 
		
	END
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreTaskSessions]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.RestoreTaskSessions](
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[session_id] [uniqueidentifier] NOT NULL ,
			[object_name] [nvarchar](2000) NULL,
			[object_id] [uniqueidentifier] NULL,
			[status] [int] NOT NULL,
			[reason] [ntext] NULL,
			[creation_time] [datetime] NOT NULL,
			[end_time] [datetime] NOT NULL DEFAULT ('01.01.1900'),
			[operation] [nvarchar](400) NOT NULL DEFAULT (''),
			[usn] [bigint] NOT NULL DEFAULT ((0)), 
			[process] [xml] NOT NULL DEFAULT (''),
			[db_instance_id] [uniqueidentifier] NULL,
		PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 527; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 527)
BEGIN
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.PhysicalHosts]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.PhysicalHosts](
		[id] [uniqueidentifier] NOT NULL,
		[name] [nvarchar](max) NOT NULL,
		[bios_uuid] [nvarchar](255) NOT NULL,
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C_PhysicalHosts] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END
	
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.BObjectsRelations]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.BObjectsRelations](
		[id] [uniqueidentifier] NOT NULL,
		[obj_id] [uniqueidentifier] NOT NULL,
		[parent_id] [uniqueidentifier] NOT NULL,
		[rel_type] [int] NOT NULL,
		[db_instance_id] [uniqueidentifier] NOT NULL
		 CONSTRAINT [PK_BObjectsRelations] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END


	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'physical_host_id' and objs.name = N'C.Hosts')
	BEGIN
		ALTER TABLE [dbo].[C.Hosts]
		ADD  [physical_host_id] uniqueidentifier DEFAULT NULL
	END

	If  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'path' and objs.name = N'C.BObjects')
	BEGIN
		ALTER TABLE [dbo].[C.BObjects]
		ADD 
			[path] nvarchar(400) DEFAULT NULL,
			[platform] int DEFAULT '0',
			[uuid] nvarchar(256) DEFAULT NULL
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 528; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 528)
BEGIN
	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'host_instance_id' 
	and objs.name = N'C.Hosts')
			BEGIN
				ALTER TABLE [dbo].[C.Hosts]
				ADD  [host_instance_id] varchar(255) DEFAULT NULL
			END
	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'unique_key_hash' 
	and objs.name = N'C.BObjects')
			BEGIN
				ALTER TABLE [dbo].[C.BObjects]
				ADD  [unique_key_hash] varbinary(max) DEFAULT NULL
			END	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 529; END	
END
GO

------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 529)
BEGIN
	
	IF NOT EXISTS(select * from syscolumns where id = OBJECT_ID(N'[dbo].[Security.RoleAccounts]') and [name] = 'security_scope_enabled')
	BEGIN
		ALTER TABLE [dbo].[Security.RoleAccounts] ADD  [security_scope_enabled] bit NOT NULL DEFAULT 0;
	END;

	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Security.RoleAccounts]') and [name] = 'role_group_id')
	BEGIN
		ALTER TABLE [dbo].[Security.RoleAccounts] ADD  [role_group_id] uniqueidentifier NOT NULL DEFAULT (newid());
	END;
	

	
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.HierarchyScopes]') AND type in (N'U'))
	BEGIN
		-- Security.HiearchyScope
		CREATE TABLE [dbo].[Security.HierarchyScopes](
			[id] [uniqueidentifier] NOT NULL,
			[role_account_group_id] [uniqueidentifier] NOT NULL,
			[scope_state] [int] NOT NULL,
			[scope_name] [nvarchar](1024) NOT NULL,
			[hierarchy_root_instance_id] [nvarchar](max) NOT NULL,
			[hierarchy_object_ref] [nvarchar](max) NOT NULL,
			[hierarchy_object_keyhash] [varbinary](16) NOT NULL,
			[hierarchy_view_type] [int] not null,
			[hierarchy_object_type] [int] not null
		 CONSTRAINT [PK_Security.HierarchyScopes] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

	END;
	
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.LoggedOnUsers]') AND type in (N'U'))
	BEGIN
		-- Security.LoggedOnUsers
		CREATE TABLE [dbo].[Security.LoggedOnUsers](
			[id] [uniqueidentifier] NOT NULL,
			[name] [nvarchar](max) NOT NULL,
			[sid_string] [nvarchar](max) NOT NULL,
			[sid_binary] [varbinary](max) NOT NULL
		 CONSTRAINT [PK_Security.LoggedOnUsers] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END;

	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.LoggedOnUserAccounts]') AND type in (N'U'))
	BEGIN
		-- Security.LoggedOnUserAccounts
		CREATE TABLE [dbo].[Security.LoggedOnUserAccounts](
			[id] [uniqueidentifier] NOT NULL,
			[account_id][uniqueidentifier] NOT NULL,
			[login_id] [uniqueidentifier] NOT NULL
		 CONSTRAINT [PK_Security.LoggedOnUserAccounts] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
	END;

	
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.VmsRecursiveInclusion]') AND type in (N'U'))
	BEGIN
		-- Security.VmsRecursiveInclusion
		CREATE TABLE [dbo].[Security.VmsRecursiveInclusion](
			[id] as [container_key_hash] + [vm_key_hash] PERSISTED NOT NULL,
			[container_key_hash] [varbinary](16) NOT NULL,
			[vm_key_hash] [varbinary](16) NOT NULL			
			CONSTRAINT [PK_Security.VmsRecursiveInclusion] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	
	END;

	
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 530; END	
END
GO


------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 530 AND current_version < 532)
BEGIN

	CREATE TABLE [dbo].[Enterprise.UserTasks](
		[id] uniqueidentifier NOT NULL,
		[type] int NOT NULL,
		[name] nvarchar(255) NOT NULL,
		[creation_time] datetime NOT NULL,
		[expiration_time] datetime NOT NULL,
		[stage] int NOT NULL,
		[result] int NOT NULL,
		[failure_msg] nvarchar(max) NULL,
		[job_session_id] uniqueidentifier NULL,
		CONSTRAINT [PK_Enterprise.UserTasks] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 532; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 532)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'job_spec' and objs.name = N'Enterprise.Sessions')
		BEGIN
			ALTER TABLE [dbo].[Enterprise.Sessions]
			ADD  [job_spec] xml default '' NOT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 533; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 533)
BEGIN

	CREATE TABLE [dbo].[Enterprise.JobSettings](
		[id] uniqueidentifier NOT NULL,
		[job_type] int NOT NULL,
		[settings] xml NOT NULL,
		[scheduled_first_start_time] datetime NULL,
		[scheduled_period_mins] int NOT NULL,
		[latest_start_time_by_scheduler] datetime NULL,
		CONSTRAINT [PK_Enterprise.JobSettings] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 534; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 534)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'job_spec' and objs.name = N'Security.HierarchyScopes')
		BEGIN
			ALTER TABLE [dbo].[Security.HierarchyScopes]
			ADD  [platform] int default 0 NOT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 535; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 535)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'job_spec' and objs.name = N'Security.LoggedOnUsers')
		BEGIN
			ALTER TABLE [dbo].[Security.LoggedOnUsers]
			ADD  [restrictedByScopes] bit default 1 NOT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 536; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 536)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'display_name' and objs.name = N'C.BObjects')
		BEGIN
			ALTER TABLE [dbo].[C.BObjects]
			ADD [display_name] nvarchar(256) DEFAULT '' NOT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 537; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 537)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'platform' and objs.name = N'C.Backup.Model.Backups')
		BEGIN
			ALTER TABLE [dbo].[C.Backup.Model.Backups]
			ADD platform int DEFAULT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 538; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 538)
BEGIN

CREATE TABLE [dbo].[VCPlugins](
	[id] [uniqueidentifier] NOT NULL,
	[hostname] [varchar](255) NOT NULL,
	[port] [int] NULL,
	[username] [varchar](255) NULL,
	[password] [nvarchar](512) NULL,
	[version] [varchar](50) NOT NULL,
	[status] [int] NOT NULL,
	[plugin_version] [varchar](50) NULL,
	[installed_by] [varchar](255) NULL,
	[plugin_state] [int] NOT NULL default 0
) ON [PRIMARY]

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 539; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 539 AND current_version < 542)
BEGIN
	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.BackupProxies]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.BackupProxies]
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_CBackupProxies_id]  DEFAULT (newid()),
			[name] [nvarchar](max) NOT NULL,
			[description] [nvarchar](max) NOT NULL,
			[type] int NOT NULL,
			[host_id] uniqueidentifier NULL,
			[options] xml NOT NULL,
			[disabled] bit NOT NULL,
			[is_busy] bit NOT NULL,
			[is_unavailable] bit NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL
	
			CONSTRAINT [PK_CBackupProxies] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]

		) ON [PRIMARY]
	END

	IF NOT  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.BackupRepositories]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.BackupRepositories] 
		(
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_CBackupRepositories_id]  DEFAULT (newid()),
			[name] [nvarchar](max) NOT NULL,
			[description] [nvarchar](max) NOT NULL,
			[type] int NOT NULL,
			[host_id] uniqueidentifier NULL,
			[mount_host_id] uniqueidentifier NULL,
			[path] [nvarchar](max) NOT NULL,
			[options] xml NOT NULL,
			[is_busy] bit NOT NULL,
			[is_unavailable] bit NOT NULL,
			[is_full] bit NOT NULL,
			[total_space] bigint NOT NULL,
			[free_space] bigint NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL
	
			CONSTRAINT [PK_CBackupRepositories] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]

		) ON [PRIMARY]
	END

	if  NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'display_name' and objs.name = N'C.Backup.Model.OIBs')
	BEGIN
		alter table [dbo].[C.Backup.Model.OIBs] add [display_name] nvarchar(256) not null default N''
	END
		
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') and [name] = 'is_internal')
	begin
		alter table [dbo].[C.Backup.Model.RestoreJobSessions] add [is_internal] [bit] not null default 0
	end
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 542; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 542)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Credentials]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Credentials](
			[id] [uniqueidentifier] NOT NULL,
			[user_name] [varchar](255) NOT NULL,
			[db_instance_id] [uniqueidentifier] NULL
		)

		IF  NOT EXISTS( SELECT * FROM sys.objects objs  INNER JOIN sys.columns cols ON objs.object_id = cols.object_id
						WHERE objs.type in (N'U') AND cols.name = N'creds' and objs.name = N'C.Soap_creds')
		BEGIN
			ALTER TABLE [dbo].[C.Soap_creds]
			ADD [creds] [uniqueidentifier] DEFAULT NULL
		END
	
		IF  NOT EXISTS( SELECT * FROM sys.objects objs  INNER JOIN sys.columns cols ON objs.object_id = cols.object_id
						WHERE objs.type in (N'U') AND cols.name = N'creds' and objs.name = N'C.Ssh_creds')
		BEGIN
			ALTER TABLE [dbo].[C.Ssh_creds]
			ADD [creds] [uniqueidentifier] DEFAULT NULL
		END

		IF  EXISTS( SELECT * FROM sys.objects objs  INNER JOIN sys.columns cols ON objs.object_id = cols.object_id
			WHERE objs.type in (N'U') AND cols.name = N'user' and objs.name = N'C.Soap_creds')
		BEGIN
			EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
				'[C.Soap_creds]',
				'user'
		END

		IF  EXISTS( SELECT * FROM sys.objects objs  INNER JOIN sys.columns cols ON objs.object_id = cols.object_id
					WHERE objs.type in (N'U') AND cols.name = N'user' and objs.name = N'C.Ssh_creds')
		BEGIN
			EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
				'[C.Ssh_creds]',
				'user'
		END
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 543; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 543 AND current_version < 545)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Security.VmsRecursiveInclusion]') AND [name] = 'vm_real_name')
	BEGIN
		ALTER TABLE [dbo].[Security.VmsRecursiveInclusion] ADD [vm_real_name] nvarchar(256) NOT NULL DEFAULT N''
		print 'New column {vm_real_name} has been successfully added to [dbo].[Security.VmsRecursiveInclusion] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 545; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 545 AND current_version < 546)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') AND [name] = 'oib_display_name')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.RestoreJobSessions] ADD [oib_display_name] nvarchar(256) NOT NULL DEFAULT N''
		print 'New column {oib_display_name} has been successfully added to [dbo].[C.Backup.Model.RestoreJobSessions] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') AND [name] = 'oib_creation_time')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.RestoreJobSessions] ADD [oib_creation_time] datetime NOT NULL default '1900-01-01 00:00:00.000'
		print 'New column {oib_creation_time} has been successfully added to [dbo].[C.Backup.Model.RestoreJobSessions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 546; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 546 AND current_version < 547)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	if not exists (select * from syscolumns where id = OBJECT_ID(N''[dbo].[C.LicensedHosts]'') and [name] = ''lic_tier'')
	begin
		alter table [dbo].[C.LicensedHosts] add lic_tier int DEFAULT 0 NOT null
	end
	'
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 547; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 547)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'repository_id' and objs.name = N'C.Backup.Model.Backups')
		BEGIN
			ALTER TABLE [dbo].[C.Backup.Model.Backups]
			ADD repository_id uniqueidentifier DEFAULT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 548; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 548)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Scheme.Collect]') AND type in (N'U'))
	BEGIN
		CREATE TABLE  [dbo].[Repl.Scheme.Collect](
			[db_instance_id] [uniqueidentifier] NOT NULL,
			[collect_new_columns] [bit] NOT NULL
		)
	END

	IF NOT EXISTS (SELECT * FROM sysobjects objs INNER JOIN syscolumns cols ON objs.id = cols.id WHERE objs.type in (N'U') AND objs.name = N'Repl.Scheme.ColumnsBindings' AND cols.name = N'is_new')
	BEGIN	
		ALTER TABLE [dbo].[Repl.Scheme.ColumnsBindings] ADD is_new bit NOT NULL DEFAULT 0
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 549; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 549)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.JobVssCredentials]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.JobVssCredentials](
			[id] [uniqueidentifier] NOT NULL,
			[job_id] [uniqueidentifier] NOT NULL,
			[oij_id] [uniqueidentifier] NULL,
			[credentials_id] [uniqueidentifier] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
			CONSTRAINT [PK_JobCredentials] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 550; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 550)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Options]') AND type in (N'U'))
	BEGIN
		CREATE TABLE Options (
			[id] [uniqueidentifier] primary key NOT NULL DEFAULT (newid()),
			[value] xml not null default '')
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 551; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 551)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'original_oib_id' and objs.name = N'C.Backup.Model.OIBs')
		BEGIN
			ALTER TABLE [dbo].[C.Backup.Model.OIBs]
			ADD original_oib_id uniqueidentifier DEFAULT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 552; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 552)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') 
		AND cols.name = N'repository_id' and objs.name = N'C.BJobs')
		BEGIN
			ALTER TABLE [dbo].[C.BJobs]
			ADD repository_id uniqueidentifier DEFAULT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 553; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 553)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') 
		AND cols.name = N'order_no' and objs.name = N'C.ObjectsInJobs')
		BEGIN
			ALTER TABLE [dbo].[C.ObjectsInJobs]	ADD order_no int DEFAULT 0 NOT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 554; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 554 AND current_version < 556)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') 
		AND cols.name = N'validation_status' and objs.name = N'C.Backup.Model.SbTaskSessions')
		BEGIN
			ALTER TABLE [dbo].[C.Backup.Model.SbTaskSessions] ADD validation_status int DEFAULT 3 NOT NULL
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 556; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 556)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'unique_id' and objs.name = N'C.BackupRepositories')
	BEGIN
		ALTER TABLE [dbo].[C.BackupRepositories] ADD unique_id uniqueidentifier NOT NULL DEFAULT (newid())
	END
	
	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'unique_id' and objs.name = N'C.BackupProxies')
	BEGIN
		ALTER TABLE [dbo].[C.BackupProxies] ADD unique_id uniqueidentifier NOT NULL DEFAULT (newid())
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 557; END	
END
GO



-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 557)
BEGIN

	declare dbinst_cursor cursor for
	select id from [dbo].[Repl.Topology.BackupDbInstances]
	
	declare @dbinst uniqueidentifier
	
	open dbinst_cursor
	fetch next from dbinst_cursor into @dbinst
	
	while @@FETCH_STATUS = 0
	begin
		exec [dbo].[usp.Upgrade.v65_to_v70.InternalSync] @dbinst, N'C'
		fetch next from dbinst_cursor into @dbinst
	end	
	
	close dbinst_cursor
	deallocate dbinst_cursor
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 559; END	
END
GO

-----------------------------------------------------
-- 

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 559)
BEGIN
	ALTER TABLE [dbo].[C.BackupRepositories] ALTER COLUMN [unique_id] UNIQUEIDENTIFIER NOT NULL	
	ALTER TABLE [dbo].[C.BackupRepositories] DROP CONSTRAINT [PK_CBackupRepositories]			
	ALTER TABLE [dbo].[C.BackupRepositories] ADD CONSTRAINT [PK_CBackupRepositories] PRIMARY KEY CLUSTERED 
	(
		[unique_id] ASC
	)
	WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 560; END	
END
GO

-----------------------------------------------------
-- 

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 560)
BEGIN
	ALTER TABLE [dbo].[C.BackupProxies] ALTER COLUMN [unique_id] UNIQUEIDENTIFIER NOT NULL	
	ALTER TABLE [dbo].[C.BackupProxies] DROP CONSTRAINT [PK_CBackupProxies]			
	ALTER TABLE [dbo].[C.BackupProxies] ADD CONSTRAINT [PK_CBackupProxies] PRIMARY KEY CLUSTERED 
	(
		[unique_id] ASC
	)
	WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 561; END	
END
GO




IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 561)
BEGIN

	IF EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'algorithm' and objs.name = N'C.Backup.Model.BackupJobSessions')
	BEGIN
		exec [usp.RemoveColumnWithDefaultConstraints] '[C.Backup.Model.BackupJobSessions]', 'algorithm'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 562; END	
END
GO

		
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 562)
BEGIN

	IF EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'default_sessions_retention_for_each_bserver_in_months' and objs.name = N'Enterprise.ScalarSettings')
	BEGIN

		exec sp_executesql @stat = N'
		UPDATE [dbo].[Enterprise.ScalarSettings] 
		SET [default_sessions_retention_for_each_bserver_in_months]=
		(
			CASE WHEN [default_sessions_retention_for_each_bserver_in_months]  < 0 
				THEN [default_sessions_retention_for_each_bserver_in_months] 
				ELSE [default_sessions_retention_for_each_bserver_in_months] * 30 
			END
		)'

		exec sp_rename 
		@objname = '[Enterprise.ScalarSettings].[default_sessions_retention_for_each_bserver_in_months]',
		@newname = 'default_sessions_retention_for_each_bserver_in_days',
		@objtype = 'COLUMN'
		
		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 563; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 563)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'disable_support_expiration_notification' and objs.name = N'Enterprise.ScalarSettings')
	BEGIN
		ALTER TABLE [dbo].[Enterprise.ScalarSettings] ADD disable_support_expiration_notification smallint NOT NULL DEFAULT (0)
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 564; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 564)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'sub_type' and objs.name = N'C.Backup.Model.RestoreJobSessions')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.RestoreJobSessions] ADD sub_type int NOT NULL DEFAULT 0
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 565; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 565 AND current_version < 566)
BEGIN
	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'settings' and objs.name = N'Security.RoleAccounts')
	BEGIN
		ALTER TABLE [dbo].[Security.RoleAccounts] ADD settings xml NOT NULL DEFAULT '<RoleAccountSettings/>'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 566; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 566 AND current_version < 567)
BEGIN
	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id = cols.id WHERE objs.type in (N'U') AND cols.name = N'cur_point_id' and objs.name = N'C.Backup.Model.BackupJobSessions')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.BackupJobSessions] ADD cur_point_id uniqueidentifier DEFAULT NULL
	END

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id = cols.id WHERE objs.type in (N'U') AND cols.name = N'cur_point_id' and objs.name = N'65.Backup.Model.BackupJobSessions')
	BEGIN
		ALTER TABLE [dbo].[65.Backup.Model.BackupJobSessions] ADD cur_point_id uniqueidentifier DEFAULT NULL
	END

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id = cols.id WHERE objs.type in (N'U') AND cols.name = N'cur_point_id' and objs.name = N'6.Backup.Model.BackupJobSessions')
	BEGIN
		ALTER TABLE [dbo].[6.Backup.Model.BackupJobSessions] ADD cur_point_id uniqueidentifier DEFAULT NULL
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 567; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 567 AND current_version < 568)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id = cols.id WHERE objs.type in (N'U') AND cols.name = N'reason' and objs.name = N'C.Backup.Model.JobSessions')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.JobSessions] ADD reason NTEXT NULL
	END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 568; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 568 AND current_version < 569)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id = cols.id WHERE objs.type in (N'U') AND cols.name = N'sts_url' and objs.name = N'VCPlugins')
	BEGIN
		ALTER TABLE [dbo].[VCPlugins] ADD sts_url nvarchar(512) DEFAULT NULL
	END

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id = cols.id WHERE objs.type in (N'U') AND cols.name = N'vc_fqdn' and objs.name = N'VCPlugins')
	BEGIN
		ALTER TABLE [dbo].[VCPlugins] ADD vc_fqdn nvarchar(512) DEFAULT NULL
	END

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 569; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 569 AND current_version < 570)
BEGIN

	ALTER TABLE [dbo].[Security.LoggedOnUsers] ADD sessions int DEFAULT 1	

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 570; END
END
GO


-----------------------------------------------------
-- DATA UPGRADE 7.0-8.0
-----------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 570 AND current_version < 618)
BEGIN
	UPDATE [dbo].[Version] SET current_version = 618;
END
GO
--
-----------------------------------------------------

-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 618)
BEGIN
	DECLARE @time nvarchar(113)  
	SELECT @time = convert(nvarchar, CURRENT_TIMESTAMP, 113)
	print @time
	print '[Upgrade] Begin upgrade from v7 to v8'
	
	exec sp_executesql @stat = N'
		ALTER TABLE [dbo].[C.Backup.Model.JobSessions] ADD usn bigint DEFAULT 0 NOT null
      	ALTER TABLE [dbo].[C.Backup.Model.BackupJobSessions] ADD usn bigint DEFAULT 0 NOT null
		ALTER TABLE [dbo].[C.Backup.Model.BackupTaskSessions] ADD usn bigint DEFAULT 0 NOT null
		ALTER TABLE [dbo].[C.Backup.Model.SbTaskSessions] ADD usn bigint DEFAULT 0 NOT null

		ALTER TABLE [dbo].[C.Backup.Model.BackupTaskSessions] ALTER COLUMN db_instance_id uniqueidentifier NOT NULL
		ALTER TABLE [dbo].[C.Backup.Model.JobSessions] ALTER COLUMN db_instance_id uniqueidentifier NOT NULL
		ALTER TABLE [dbo].[C.Backup.Model.BackupJobSessions] ALTER COLUMN db_instance_id uniqueidentifier NOT NULL
		'
	
	exec sp_executesql @stat = N'
		WITH JobSessionsCTE AS(
		   SELECT id, db_instance_id, RN = ROW_NUMBER() OVER (PARTITION BY id, db_instance_id ORDER BY id)
		   FROM [dbo].[C.Backup.Model.JobSessions]
		)
		DELETE FROM JobSessionsCTE WHERE RN > 1'

	exec sp_executesql @stat = N'
		WITH BackupJobSessionsCTE AS(
		   SELECT id, db_instance_id, RN = ROW_NUMBER() OVER (PARTITION BY id, db_instance_id ORDER BY id)
		   FROM [dbo].[C.Backup.Model.BackupJobSessions]
		)
		DELETE FROM BackupJobSessionsCTE WHERE RN > 1'

	exec sp_executesql @stat = N'
		WITH BackupTaskSessionsCTE AS(
		   SELECT id, db_instance_id, RN = ROW_NUMBER() OVER (PARTITION BY id, db_instance_id ORDER BY id)
		   FROM [dbo].[C.Backup.Model.BackupTaskSessions]
		)
		DELETE FROM BackupTaskSessionsCTE WHERE RN > 1'

	exec sp_executesql @stat = N'
		ALTER TABLE [dbo].[C.Backup.Model.BackupTaskSessions] ADD CONSTRAINT PK_70_Backup_Model_BackupTaskSessions
			PRIMARY KEY NONCLUSTERED (db_instance_id, id)
		ALTER TABLE [dbo].[C.Backup.Model.JobSessions] ADD CONSTRAINT PK_70_Backup_Model_JobSessions
			PRIMARY KEY NONCLUSTERED (db_instance_id, id)
		ALTER TABLE [dbo].[C.Backup.Model.BackupJobSessions] ADD CONSTRAINT PK_70_Backup_Model_BackupJobSessions
			PRIMARY KEY NONCLUSTERED (db_instance_id, id)
		'



	declare @table_name nvarchar(255)	
	declare tables_cursor cursor for
	select name from [dbo].[fn.Upgrade.v70_to_v80.GetTablesToUpgrade] ()
	
	open tables_cursor
	fetch next from tables_cursor into @table_name
	
	while @@FETCH_STATUS = 0
	BEGIN
	
		declare @renamed_table nvarchar(255)		
		set @renamed_table = [dbo].[fn.Upgrade.v70_to_v80.GetPreviousTableName] (@table_name)
		
		declare @current_table nvarchar(255)		
		set @current_table = [dbo].[fn.Upgrade.Common.GetCurrentTableName] (@table_name)
		
		if not exists(select * from sys.Tables where name = @renamed_table)
		begin 
			exec [dbo].[usp.Upgrade.Common.RenameTable] @renamed_table, @current_table
			exec [dbo].[usp.Upgrade.Common.DuplicateTable] @current_table, @renamed_table
		end
		
		fetch next from tables_cursor into @table_name
	END
	
	close tables_cursor
	deallocate tables_cursor
	
	exec sp_executesql @stat = N'
		ALTER TABLE [dbo].[C.Backup.Model.BackupTaskSessions] ADD CONSTRAINT PK_80_Backup_Model_BackupTaskSessions
			PRIMARY KEY NONCLUSTERED (db_instance_id, id)
		ALTER TABLE [dbo].[C.Backup.Model.JobSessions] ADD CONSTRAINT PK_80_Backup_Model_JobSessions
			PRIMARY KEY NONCLUSTERED (db_instance_id, id)
		ALTER TABLE [dbo].[C.Backup.Model.BackupJobSessions] ADD CONSTRAINT PK_80_Backup_Model_BackupJobSessions
			PRIMARY KEY NONCLUSTERED (db_instance_id, id)
		'



	exec sp_executesql @stat = N'
		ALTER TABLE [dbo].[C.Backup.Model.SbTaskSessions] ADD log_xml xml NOT NULL DEFAULT ''<Root />''
	';


	declare dbinst_cursor cursor for
	select id from [dbo].[Repl.Topology.BackupDbInstances]
	
	declare @dbinst uniqueidentifier
	declare @dbNum int	
		
	open dbinst_cursor
	fetch next from dbinst_cursor into @dbinst

	SELECT @time = convert(nvarchar, CURRENT_TIMESTAMP, 113)
	print @time
	print '[Upgrade] new tables were created'

	SET @dbNum = 0
	while @@FETCH_STATUS = 0
	begin
		print @time
		SET @dbNum = @dbNum + 1
		print '[Upgrade] Copying content to v8 tables. DB #' + CAST(@dbNum as varchar(20))
		
		exec [dbo].[usp.Upgrade.v70_to_v80.InternalSync] @dbinst, 0, N'C'
		fetch next from dbinst_cursor into @dbinst
	end	
	
	SELECT @time = convert(nvarchar, CURRENT_TIMESTAMP, 113)
	print @time
	print '[Upgrade] v7 content was copied to v8 tables'

	close dbinst_cursor
	deallocate dbinst_cursor		

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 619; END	
END
GO


--
-----------------------------------------------------

/*             END OF DATA UPGRADE 6.5 to 7.0			*/
/********************************************************/


-----------------------------------------------------
-- 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 619)
BEGIN

	declare @table_name nvarchar(255)
	declare @table_version int
	
	declare tables_cursor cursor for
	select name, 5 as version
	from [dbo].[fn.Upgrade.56.GetTablesToUpgrade] ()
	union all
	select name, 6 as version
	from [dbo].[fn.Upgrade.v6_to_v61.GetTablesToUpgrade] ()
	
	open tables_cursor
	fetch next from tables_cursor into @table_name, @table_version

	while @@FETCH_STATUS = 0
	BEGIN
	
		declare @to_delete_table nvarchar(255)
		if @table_version = 5
		begin
			set @to_delete_table = [dbo].[fn.Upgrade.56.GetPreviousTableName] (@table_name)
		end
		else
			set @to_delete_table = [dbo].[fn.Upgrade.v6_to_v61.GetPreviousTableName] (@table_name)			
			
		set @to_delete_table = [dbo].[fn.Upgrade.Common.GetWrappedTableName] (@to_delete_table)
		
		declare @delete_stat nvarchar(255)
		set @delete_stat = N'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @to_delete_table +''') AND type in (N''U''))' + 
		' DROP TABLE ' + @to_delete_table;
		print 'Deleting table ' + @to_delete_table
		exec sp_executesql @stat = @delete_stat
		
		fetch next from tables_cursor into @table_name, @table_version
	END
	
	close tables_cursor
	deallocate tables_cursor		

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 620; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 620)
BEGIN
	
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Ssh_creds]') AND [name] = 'host_id')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.Ssh_creds]',
			'host_id'
		print 'Column {host_id} has been successfully removed from [dbo].[C.Ssh_creds] table'	
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Ssh_creds]') AND [name] = 'savepassword')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.Ssh_creds]',
			'savepassword'
		print 'Column {savepassword} has been successfully removed from [dbo].[C.Ssh_creds] table'	
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 621; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 621)
BEGIN
	
	-- Add physical_host_id to LicensedHosts
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N''[dbo].[C.LicensedHosts]'') AND [name] = ''physical_host_id'')
		BEGIN		
			alter table [dbo].[C.LicensedHosts] add physical_host_id uniqueidentifier NOT NULL DEFAULT (''00000000-0000-0000-0000-000000000000'')
			print ''New column {physical_host_id} has been successfully added to [dbo].[C.LicensedHosts] table''
		END'

	-- Add cpu to PhysicalHosts
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N''[dbo].[C.PhysicalHosts]'') AND [name] = ''cpu'')
		BEGIN		
			alter table [dbo].[C.PhysicalHosts] add cpu int NULL
			print ''New column {cpu} has been successfully added to [dbo].[C.PhysicalHosts] table''
		END'

	-- Add cores to PhysicalHosts
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N''[dbo].[C.PhysicalHosts]'') AND [name] = ''cores'')
		BEGIN		
			alter table [dbo].[C.PhysicalHosts] add cores int NULL
			print ''New column {cores} has been successfully added to [dbo].[C.PhysicalHosts] table''
		END'
/*
	-- Establish data links
	exec sp_executesql @stat = N'update [C.LicensedHosts] set physical_host_id = (select id from [C.PhysicalHosts] where bios_uuid = uuid)'

	-- Move data
	exec sp_executesql @stat = N'
		update [C.PhysicalHosts] set 
			cpu = (select cpu from [C.LicensedHosts] where bios_uuid = uuid),
			cores = (select cores from [C.LicensedHosts] where bios_uuid = uuid)
	'
*/
	-- Drop uuid from HostsByJobs
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.HostsByJobs]') AND [name] = 'uuid')
	BEGIN		
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.HostsByJobs]',
			'uuid'
		print 'Column {uuid} has been successfully removed from [dbo].[C.HostsByJobs] table'
	END

	-- Drop uuid from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.LicensedHosts]') AND [name] = 'uuid')
	BEGIN		
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.LicensedHosts]',
			'uuid'
		print 'Column {uuid} has been successfully removed from [dbo].[C.LicensedHosts] table'
	END

	-- Drop name from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.LicensedHosts]') AND [name] = 'name')
	BEGIN		
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.LicensedHosts]',
			'name'
		print 'Column {name} has been successfully removed from [dbo].[C.LicensedHosts] table'
	END

	-- Drop cpu from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.LicensedHosts]') AND [name] = 'cpu')
	BEGIN		
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.LicensedHosts]',
			'cpu'
		print 'Column {cpu} has been successfully removed from [dbo].[C.LicensedHosts] table'
	END

	-- Drop cores from LicensedHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.LicensedHosts]') AND [name] = 'cores')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.LicensedHosts]',
			'cores'
		print 'Column {cores} has been successfully removed from [dbo].[C.LicensedHosts] table'
	END	
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 622; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 622)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Crypto.MasterKeys]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [Crypto.MasterKeys]
		(
			id [uniqueidentifier] NOT NULL,
			key_set_id [varbinary](max) NOT NULL,
			hint [nvarchar](1024) NULL,
			pem_string_encrypted nvarchar(max) NOT NULL,
			creation_time datetime NOT NULL,
			is_active bit NOT NULL
		)
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 623; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 623)
BEGIN	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Crypto.BsCryptoKeys]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Crypto.BsCryptoKeys]
		(
			[id] [uniqueidentifier] NOT NULL,
			[hint] nvarchar(max) NULL,
			[key_set_id] [varbinary](20) NOT NULL,
			[key_value] [varbinary](max) NOT NULL,
			[date] [datetime] NOT NULL
		)
	END

	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Repl.Topology.BackupDbInstances]') AND [name] = 'crypto_key_id')
	BEGIN		
		ALTER TABLE [dbo].[Repl.Topology.BackupDbInstances] ADD crypto_key_id [uniqueidentifier]
		PRINT 'Column {crypto_key_id} has been successfully added to [dbo].[Repl.Topology.BackupDbInstances] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 624; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 624)
BEGIN
	---------------------------------------------------	
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.OIBs]') AND [name] = 'fqdn')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.OIBs] ADD fqdn nvarchar(255) DEFAULT NULL
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 626; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 626)
BEGIN

	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') AND [name] = 'key_mgnt_send')
	BEGIN
		ALTER TABLE [dbo].[Notification.MailSettings] ADD key_mgnt_send bit DEFAULT (0) NOT NULL
	END

	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') AND [name] = 'key_mgnt_from')
	BEGIN
		ALTER TABLE [dbo].[Notification.MailSettings] ADD key_mgnt_from nvarchar(1000) DEFAULT NULL
	END
	
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') AND [name] = 'key_mgnt_to')
	BEGIN
		ALTER TABLE [dbo].[Notification.MailSettings] ADD key_mgnt_to nvarchar(1000) DEFAULT NULL
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 627; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 627)
BEGIN
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.BJobs]') AND [name] = 'pwd_key_id')
	BEGIN
		ALTER TABLE [dbo].[C.BJobs] ADD [pwd_key_id] uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000');	
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 628; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 628)
BEGIN
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.PhysicalHosts]') AND [name] = 'chassis_type')
	BEGIN
		ALTER TABLE [dbo].[C.PhysicalHosts] ADD [chassis_type] int NOT NULL DEFAULT ((0));	
	END

	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.PhysicalHosts]') AND [name] = 'hardware_info')
	BEGIN
		ALTER TABLE [dbo].[C.PhysicalHosts] ADD [hardware_info] xml NOT NULL DEFAULT ('');	
	END

	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.PhysicalHosts]') AND [name] = 'net_info')
	BEGIN
		ALTER TABLE [dbo].[C.PhysicalHosts] ADD [net_info] xml NOT NULL DEFAULT ('');	
	END
	
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.PhysicalHosts]') AND [name] = 'os_type')
	BEGIN
		ALTER TABLE [dbo].[C.PhysicalHosts] ADD [os_type] int NOT NULL DEFAULT (0);	
	END

	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.PhysicalHosts]') AND [name] = 'os_platform')
	BEGIN
		ALTER TABLE [dbo].[C.PhysicalHosts] ADD [os_platform] int NOT NULL DEFAULT (100);	
	END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 629; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 629)
BEGIN
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.BackupJobSessions]') AND [name] = 'is_full')
	BEGIN 
		EXEC sp_rename 'dbo.[C.Backup.Model.BackupJobSessions].[is_startfull]', 'is_full', 'COLUMN'
	END

		IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.BackupJobSessions]') AND [name] = 'is_active_full')
	BEGIN 
		ALTER TABLE [dbo].[C.Backup.Model.BackupJobSessions] ADD [is_active_full] BIT NOT NULL DEFAULT (0);
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 630; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 630)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.OibAdminAccounts]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[C.OibAdminAccounts]
		(
			[id] [uniqueidentifier] NOT NULL,
			[sid] [nvarchar](184) NOT NULL,
			[oib_id] [uniqueidentifier] NOT NULL,
			[account_type] [int] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
		)
		PRINT 'Table {C.OibAdminAccounts} has been successfully created'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 631; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 631)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.LoggedOnUserGroups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Security.LoggedOnUserGroups]
		(
			[id] [uniqueidentifier] NOT NULL,
			[login_id] [uniqueidentifier] NOT NULL,
			[sid] [nvarchar](184) NOT NULL
		)
		PRINT 'Table {Security.LoggedOnUserGroups} has been successfully created'
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 632; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 632)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.GuestDatabase]') AND type in (N'U'))
	BEGIN
	CREATE TABLE [dbo].[C.Backup.Model.GuestDatabase](
		[id] [uniqueidentifier] NOT NULL,
		[obj_id] [uniqueidentifier] NOT NULL,
		[vm_name] [nvarchar](1000) NOT NULL,
		[db_instance] [nvarchar](max) NOT NULL,
		[db_name] [nvarchar](max) NOT NULL,
		[creation_time] [datetime] NOT NULL,
		[is_system] [bit] NOT NULL,
		[synth_id] [nvarchar](512) NOT NULL,		
		[db_instance_id] [uniqueidentifier] NOT NULL
		 CONSTRAINT [PK_GuestDatabase] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		PRINT 'Table {C.Backup.Model.GuestDatabase} has been successfully created'
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 634; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 634)
BEGIN
	---------------------------------------------------	
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.OIBs]') AND [name] = 'has_sql')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.OIBs] ADD has_sql bit NOT NULL default (0)
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 635; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 635)
BEGIN
	---------------------------------------------------	
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.GuestDatabase]') AND [name] = 'server_name')
	BEGIN
			exec sp_rename '[dbo].[C.Backup.Model.GuestDatabase].[vm_name]', 'server_name', 'COLUMN'
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 636; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 636)
BEGIN
UPDATE [dbo].[Enterprise.ScalarSettings] 
		SET [default_sessions_retention_for_each_bserver_in_days]=
		(
			CASE WHEN [default_sessions_retention_for_each_bserver_in_days]  = 360 
				THEN 365  
				ELSE [default_sessions_retention_for_each_bserver_in_days]
			END
		)
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 637; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 637)
BEGIN
	---------------------------------------------------	
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.GuestDatabase]') AND [name] = 'db_id')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.Backup.Model.GuestDatabase]',
			'synth_id'
		ALTER TABLE [dbo].[C.Backup.Model.GuestDatabase] ADD [db_id] int NOT NULL default (0);
	END
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 638; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 638)
BEGIN

	ALTER TABLE [dbo].[C.Backup.Model.GuestDatabase] ADD [compatibility] int NOT NULL default (0);

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 639; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 639)
BEGIN
	IF NOT EXISTS(select * from syscolumns where id = OBJECT_ID(N'[dbo].[Security.HierarchyScopes]') and [name] = 'hierarchy_root_instance_name')
	BEGIN
		ALTER TABLE [dbo].[Security.HierarchyScopes] ADD  hierarchy_root_instance_name nvarchar(max) NOT NULL DEFAULT '';
	END;

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 640; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 640)
BEGIN

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'enable_license_auto_renewal' and objs.name = N'Enterprise.ScalarSettings')
	BEGIN
		ALTER TABLE [dbo].[Enterprise.ScalarSettings] ADD enable_license_auto_renewal smallint NOT NULL DEFAULT (0)
	END

	IF NOT EXISTS( SELECT * FROM sysobjects objs  INNER JOIN syscolumns cols ON objs.id=cols.id WHERE objs.type in (N'U') AND cols.name = N'aux_data' and objs.name = N'Enterprise.Sessions')
	BEGIN
		ALTER TABLE [dbo].[Enterprise.Sessions] ADD aux_data xml NULL
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 641; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 641)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.WanAccelerators]') AND type in (N'U'))
	BEGIN
		
		CREATE TABLE [dbo].[C.WanAccelerators](
			[id] [uniqueidentifier] NOT NULL,
			[name] [nvarchar](max) NOT NULL,
			[description] [nvarchar](max) NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[is_unavailable] [bit] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
		 CONSTRAINT [PK_WanAccelerators] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		PRINT 'Table {C.WanAccelerators} has been successfully created'
	END	

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.HostComponents]') AND type in (N'U'))
	BEGIN
		
		CREATE TABLE [dbo].[C.HostComponents](
			[id] [uniqueidentifier] NOT NULL,
			[physical_host_id] [uniqueidentifier] NOT NULL,
			[type] [int] NOT NULL,
			[version] [nvarchar](255) NOT NULL,
			[options] [xml] NOT NULL,
			[is_up_to_date] [bit] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
		 CONSTRAINT [PK_HostComponents] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]


		PRINT 'Table {C.HostComponents} has been successfully created'
	END	


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 642; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 642)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudGates]') AND type in (N'U'))
	BEGIN

		CREATE TABLE [dbo].[C.Backup.Model.CloudGates](
			[id] [uniqueidentifier] NOT NULL,
			[name] [nvarchar](max) NOT NULL,
			[description] [nvarchar](max) NOT NULL,
			[creds_id] [uniqueidentifier] NOT NULL,
			[options] [xml] NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,
			[disabled] [bit] NOT NULL,
			[is_available] [bit] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
		 CONSTRAINT [PK_Backup.Model.CloudGates] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		PRINT 'Table {C.Backup.Model.CloudGates} has been successfully created'
	END	


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 643; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 643)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Tenants]') AND type in (N'U'))
	BEGIN

		CREATE TABLE [dbo].[C.Tenants](
			[id] [uniqueidentifier] NOT NULL,
			[name] [nvarchar](max) NOT NULL,
			[description] [nvarchar](max) NOT NULL,
			[expire_time] [datetime] NULL,
			[disabled] [bit] NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
		PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		PRINT 'Table {C.Tenants} has been successfully created'
	END	


	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.TenantsResourcesQuota]') AND type in (N'U'))
	BEGIN
	
		CREATE TABLE [dbo].[C.TenantsResourcesQuota](
			[id] [uniqueidentifier] NOT NULL,
			[tenant_id] [uniqueidentifier] NOT NULL,
			[repository_id] [uniqueidentifier] NOT NULL,
			[folder] [nvarchar](max) NULL,
			[wan_id] [uniqueidentifier] NULL,
			[quota_mb] [int] NULL,
			[used_quota_mb] [int] NOT NULL,
			[friendly_name] [nvarchar](max) NOT NULL,
			[db_instance_id] [uniqueidentifier] NOT NULL
		PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		PRINT 'Table {C.TenantsResourcesQuota} has been successfully created'
	END	


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 644; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 644 AND current_version < 646)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.JobSessions]') AND name = N'IX_C.Backup.Model.JobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_C.Backup.Model.JobSessions_Id] ON dbo.[C.Backup.Model.JobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[70.Backup.Model.JobSessions]') AND name = N'IX_70.Backup.Model.JobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_70.Backup.Model.JobSessions_Id] ON dbo.[70.Backup.Model.JobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[65.Backup.Model.JobSessions]') AND name = N'IX_65.Backup.Model.JobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_65.Backup.Model.JobSessions_Id] ON dbo.[65.Backup.Model.JobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	-- BackupJobSessions
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.BackupJobSessions]') AND name = N'IX_C.Backup.Model.BackupJobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_C.Backup.Model.BackupJobSessions_Id] ON dbo.[C.Backup.Model.BackupJobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[70.Backup.Model.BackupJobSessions]') AND name = N'IX_70.Backup.Model.BackupJobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_70.Backup.Model.BackupJobSessions_Id] ON dbo.[70.Backup.Model.BackupJobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[65.Backup.Model.BackupJobSessions]') AND name = N'IX_65.Backup.Model.BackupJobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_65.Backup.Model.BackupJobSessions_Id] ON dbo.[65.Backup.Model.BackupJobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	-- RestoreJobSessions
	
		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') AND name = N'IX_C.Backup.Model.RestoreJobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_C.Backup.Model.RestoreJobSessions_Id] ON dbo.[C.Backup.Model.RestoreJobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[70.Backup.Model.RestoreJobSessions]') AND name = N'IX_70.Backup.Model.RestoreJobSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_70.Backup.Model.RestoreJobSessions_Id] ON dbo.[70.Backup.Model.RestoreJobSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	--- BackupTaskSessions
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.BackupTaskSessions]') AND name = N'IX_C.Backup.Model.BackupTaskSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_C.Backup.Model.BackupTaskSessions_Id] ON dbo.[C.Backup.Model.BackupTaskSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[70.Backup.Model.BackupTaskSessions]') AND name = N'IX_70.Backup.Model.BackupTaskSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_70.Backup.Model.BackupTaskSessions_Id] ON dbo.[70.Backup.Model.BackupTaskSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[65.Backup.Model.BackupTaskSessions]') AND name = N'IX_65.Backup.Model.BackupTaskSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_65.Backup.Model.BackupTaskSessions_Id] ON dbo.[65.Backup.Model.BackupTaskSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	-- RestoreTaskSessions
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreTaskSessions]') AND name = N'IX_C.Backup.Model.RestoreTaskSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_C.Backup.Model.RestoreTaskSessions_Id] ON dbo.[C.Backup.Model.RestoreTaskSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[70.Backup.Model.RestoreTaskSessions]') AND name = N'IX_70.Backup.Model.RestoreTaskSessions_Id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_70.Backup.Model.RestoreTaskSessions_Id] ON dbo.[70.Backup.Model.RestoreTaskSessions]
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON,			ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 646; END	

END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE  current_version >= 646 AND current_version < 648)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') and [name] = 'restored_obj_id')
	begin
		alter table [dbo].[C.Backup.Model.RestoreJobSessions] add [restored_obj_id] [uniqueidentifier] null
	end

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 648; END	
	END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE  current_version = 648 )
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.JobSessions]') AND name = N'IX_C.Backup.Model.JobSessions_end_time')
	BEGIN
	CREATE NONCLUSTERED INDEX [IX_C.Backup.Model.JobSessions_end_time] ON [dbo].[C.Backup.Model.JobSessions]
	(
		[end_time] ASC
	)
	INCLUDE (
		[id],
		[job_id],
		[result]
		) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[C.Backup.Model.JobSessions]') AND name = N'IX_C.Backup.Model.JobSessions_job_type_state')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_C.Backup.Model.JobSessions_job_type_state]
		ON [dbo].[C.Backup.Model.JobSessions] ([job_type],[state])
		INCLUDE ([creation_time],[end_time])
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 649; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 649 AND current_version < 652)
BEGIN
	---------------------------------------------------		
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.GuestDatabase]') AND [name] = 'family_guid')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.GuestDatabase] ADD [family_guid] uniqueidentifier default '00000000-0000-0000-0000-000000000000' NOT NULL
	END	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 652; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 652)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 653; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 653)
BEGIN
	---------------------------------------------------	
	IF EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.BJobs]') AND [name] = 'post_command_run_count')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.BJobs]',
			'post_command_run_count'
	END
	---------------------------------------------------	
	IF EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[65.BJobs]') AND [name] = 'post_command_run_count')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[65.BJobs]',
			'post_command_run_count'
	END
	---------------------------------------------------	
	IF EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[70.BJobs]') AND [name] = 'post_command_run_count')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[70.BJobs]',
			'post_command_run_count'
	END
	---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 654; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >=  654 AND current_version < 656)
BEGIN
	DELETE FROM [dbo].[Startup.InitialReportAttrs] WHERE [initial_page_id] IN (
		SELECT [id] FROM [dbo].[Startup.InitialReportPages] WHERE [report_id] = 'F3749311-9C91-4D89-8BF7-2F53EC171374'
	);

	DELETE FROM [dbo].[Startup.InitialReportPages] WHERE [report_id] = 'F3749311-9C91-4D89-8BF7-2F53EC171374'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 656; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 656 AND current_version < 666)
BEGIN
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Security.LoggedOnUserSessions]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Security.LoggedOnUserSessions](
				[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_LoggedOnUserSessions_id]  DEFAULT (newid()),
				[session_type] [int] NOT NULL default 0,
				[logged_on_win_user_id] [uniqueidentifier] NOT NULL, 
			 CONSTRAINT [PK_LoggedOnUserSessions] PRIMARY KEY NONCLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
	END

	exec sp_executesql @stat = N'
		IF EXISTS (select * from syscolumns where id = OBJECT_ID(N''[dbo].[Security.LoggedOnUsers]'') and [name] = ''is_self_restore_mode'')
		BEGIN
			declare @constraint nvarchar(100)
			declare @sqlcommand nvarchar(1000) 
			set @constraint = (select [name] from sys.default_constraints where [object_id] = (select cdefault from syscolumns where id = OBJECT_ID(N''[dbo].[Security.LoggedOnUsers]'') and [name] = ''is_self_restore_mode''))
			set @sqlcommand = N''Alter table [dbo].[Security.LoggedOnUsers] drop constraint ['' + @constraint + N'']''
			exec sp_sqlexec @sqlcommand
			ALTER TABLE [dbo].[Security.LoggedOnUsers] drop column [is_self_restore_mode]
		END'
	
	exec sp_executesql @stat = N'
		IF EXISTS (select * from syscolumns where id = OBJECT_ID(N''[dbo].[Security.LoggedOnUsers]'') and [name] = ''sessions'')
		BEGIN
			declare @constraint nvarchar(100)
			declare @sqlcommand nvarchar(1000) 
			set @constraint = (select [name] from sys.default_constraints where [object_id] = (select cdefault from syscolumns where id = OBJECT_ID(N''[dbo].[Security.LoggedOnUsers]'') and [name] = ''sessions''))
			set @sqlcommand = N''Alter table [dbo].[Security.LoggedOnUsers] drop constraint ['' + @constraint + N'']''
			exec sp_sqlexec @sqlcommand
			ALTER TABLE [dbo].[Security.LoggedOnUsers] drop column [sessions]
		END'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 666; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 666 AND current_version < 669)
BEGIN
	---------------------------------------------------		
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.GuestDatabase]') AND [name] = 'local_creation_time')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.GuestDatabase] ADD [local_creation_time] datetime default (getdate()) NOT NULL
	END	

	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 669; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 669 AND current_version < 670)
BEGIN
	---------------------------------------------------		
	IF NOT EXISTS(SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.GuestDatabase]') AND [name] = 'local_creation_time_str')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.GuestDatabase] ADD [local_creation_time_str] nvarchar(max) default '' NOT NULL
	END	

	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 670; END	
END
GO


--8.Next------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------




-----------------------------------------------------
-- DATA UPGRADE 8.0-9.0
-----------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 670 AND current_version < 800)
BEGIN
	DECLARE @time nvarchar(113)  
	SELECT @time = convert(nvarchar, CURRENT_TIMESTAMP, 113)
	print @time
	print '[Upgrade] Begin upgrade from v8 to v9'
	
	declare @table_name nvarchar(255)	
	declare tables_cursor cursor for
	select name from [dbo].[fn.Upgrade.v80_to_v90.GetTablesToUpgrade] ()
	
	open tables_cursor
	fetch next from tables_cursor into @table_name
	
	while @@FETCH_STATUS = 0
	BEGIN

		declare @renamed_table nvarchar(255)		
		set @renamed_table = [dbo].[fn.Upgrade.v80_to_v90.GetPreviousTableName] (@table_name)
		
		declare @current_table nvarchar(255)		
		set @current_table = [dbo].[fn.Upgrade.Common.GetCurrentTableName] (@table_name)
		
		if not exists(select * from sys.Tables where name = @renamed_table)
		begin 
			exec [dbo].[usp.Upgrade.Common.RenameTable] @renamed_table, @current_table

			if @table_name = 'Backup.Model.RestoreTaskSessions'
				GOTO continue_loop
			
			exec [dbo].[usp.Upgrade.Common.DuplicateTable] @current_table, @renamed_table
		end
		
		continue_loop:
			fetch next from tables_cursor into @table_name
	END
	
	close tables_cursor
	deallocate tables_cursor
	
	declare dbinst_cursor cursor for
	select id from [dbo].[Repl.Topology.BackupDbInstances]
	
	declare @dbinst uniqueidentifier
	declare @dbNum int	
		
	open dbinst_cursor
	fetch next from dbinst_cursor into @dbinst

	SELECT @time = convert(nvarchar, CURRENT_TIMESTAMP, 113)
	print @time
	print '[Upgrade] new tables were created'

	SET @dbNum = 0
	while @@FETCH_STATUS = 0
	begin
		print @time
		SET @dbNum = @dbNum + 1
		print '[Upgrade] Copying content to v9 tables. DB #' + CAST(@dbNum as varchar(20))
		
		exec [dbo].[usp.Upgrade.v80_to_v90.InternalSync] @dbinst, 0, N'C'
		fetch next from dbinst_cursor into @dbinst
	end	
	
	SELECT @time = convert(nvarchar, CURRENT_TIMESTAMP, 113)
	print @time
	print '[Upgrade] v8 content was copied to v9 tables'

	close dbinst_cursor
	deallocate dbinst_cursor
	
	if exists(select * from sys.tables where object_id = object_id('[dbo].[65.BSessionInfo]'))
		drop table [dbo].[65.BSessionInfo];

	if exists(select * from sys.tables where object_id = object_id('[dbo].[65.BSessions]'))
		drop table [dbo].[65.BSessions];


IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 800; END	
END
GO


--
-----------------------------------------------------

/*             END OF DATA UPGRADE 8.0 to 9.0			*/
/********************************************************/



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 799 AND current_version < 802)
BEGIN

    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudSessions]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.CloudSessions](
            [id] [uniqueidentifier] NOT NULL,
            [data_sent_to_client] [bigint] NOT NULL,
            [data_received_from_client] [bigint] NOT NULL,
            [session_type] [int] NOT NULL,
            [tenant_name] [nvarchar](max) NOT NULL,
            [db_instance_id] [uniqueidentifier] NOT NULL
            PRIMARY KEY CLUSTERED 
            (
                [id] ASC
            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
            ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

        PRINT 'Table {C.Backup.Model.CloudSessions} has been successfully created'
    END

    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudSessionsOnQuotas]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.CloudSessionsOnQuotas](
            [session_id] [uniqueidentifier] NOT NULL,
            [quota_id] [uniqueidentifier] NOT NULL,
			[id]  [uniqueidentifier] NOT NULL,
            [db_instance_id] [uniqueidentifier] NOT NULL,
            PRIMARY KEY CLUSTERED 
            (
                [session_id] ASC,
                [quota_id] ASC
            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
        ) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.CloudSessionsOnQuotas} has been successfully created'
    END

    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudVms]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.CloudVms](
            [id] [bigint] NOT NULL,
            [vm_uuid] [nvarchar](256) NOT NULL,
			[unique_id] [uniqueidentifier] NOT NULL,
            [db_instance_id] [uniqueidentifier] NOT NULL,
            PRIMARY KEY CLUSTERED 
            (
                [id] ASC
            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
        ) ON [PRIMARY]

        PRINT 'Table {C.Backup.Model.CloudVms} has been successfully created'
    END

    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudVmsOnQuotas]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.CloudVmsOnQuotas](
            [vm_id] [bigint] NOT NULL,
            [resource_quota_id] [uniqueidentifier] NOT NULL,
			[id] [uniqueidentifier] NOT NULL,
            [db_instance_id] [uniqueidentifier] NOT NULL,
        ) ON [PRIMARY]

        PRINT 'Table {C.Backup.Model.CloudVmsOnQuotas} has been successfully created'
    END


    
    ---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 802; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 802 AND current_version < 803)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.JobVssCredentials]') AND [name] = 'credentials_id')
	BEGIN
		exec sp_rename '[dbo].[C.JobVssCredentials].[credentials_id]', 'win_creds_id', 'COLUMN'
		PRINT 'Column [dbo].[C.JobVssCredentials].[credentials_id] has been successfully rename to [dbo].[C.JobVssCredentials].[win_creds_id]'
	END
			
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[80.JobVssCredentials]') AND [name] = 'credentials_id')
	BEGIN
		exec sp_rename '[dbo].[80.JobVssCredentials].[credentials_id]', 'win_creds_id', 'COLUMN'
		PRINT 'Column [dbo].[80.JobVssCredentials].[credentials_id] has been successfully rename to [dbo].[80.JobVssCredentials].[win_creds_id]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 803; 
END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 803)
BEGIN 
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.OIBs]') AND name = N'IX_C_Backup_Model_OIBs_object_id')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_C_Backup_Model_OIBs_object_id]
		ON [dbo].[C.Backup.Model.OIBs] ([is_corrupted],[has_sql])
		INCLUDE ([object_id])
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 804; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 804 AND current_version < 805)
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Notification.MailSettings]') AND type in (N'U'))
		BEGIN
			ALTER TABLE [dbo].[Notification.MailSettings] ADD [smtp_server_timeout] int NOT NULL DEFAULT (100);
		END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 805; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 805)
BEGIN	
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Repl.Topology.BackupServers]') and [name] = N'file_version')
	begin
		alter table [dbo].[Repl.Topology.BackupServers] add [file_version] nvarchar(50) DEFAULT NULL
	end	
	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 806; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 806)
BEGIN	

	-- create new columns

	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.JobSessions]') and [name] = N'initiator_sid')
	begin
		alter table [dbo].[C.Backup.Model.JobSessions] add [initiator_sid] nvarchar(255) DEFAULT NULL
		print 'New column {initiator_sid} has been successfully added to [dbo].[C.Backup.Model.JobSessions] table'
	end	

	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.JobSessions]') and [name] = N'initiator_name')
	begin
		alter table [dbo].[C.Backup.Model.JobSessions] add [initiator_name] nvarchar(255) DEFAULT NULL
		print 'New column {initiator_name} has been successfully added to [dbo].[C.Backup.Model.JobSessions] table'
	end	

	-- move data from old columns to new

	print 'Moving data of {initiator_sid} and {initiator_name} columns from [dbo].[C.Backup.Model.RestoreJobSessions] to [dbo].[C.Backup.Model.JobSessions] table'

	declare @statement nvarchar(max);

	set @statement =  N'UPDATE [dbo].[C.Backup.Model.JobSessions]
	SET [dbo].[C.Backup.Model.JobSessions].initiator_sid = [dbo].[C.Backup.Model.RestoreJobSessions].initiator_sid,
		[dbo].[C.Backup.Model.JobSessions].initiator_name = [dbo].[C.Backup.Model.RestoreJobSessions].initiator_name
	FROM [dbo].[C.Backup.Model.RestoreJobSessions]
	WHERE [dbo].[C.Backup.Model.JobSessions].db_instance_id = [dbo].[C.Backup.Model.RestoreJobSessions].db_instance_id
	  AND [dbo].[C.Backup.Model.JobSessions].id = [dbo].[C.Backup.Model.RestoreJobSessions].id';

	print @statement;
	execute sp_executesql @statement

	print 'Data of {initiator_sid} and {initiator_name} columns were moved from [dbo].[C.Backup.Model.RestoreJobSessions] to [dbo].[C.Backup.Model.JobSessions] table'

	-- remove old columns

	if exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') and [name] = N'initiator_sid')
	begin
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
					'[C.Backup.Model.RestoreJobSessions]',
					'initiator_sid'		
		print 'Old column {initiator_sid} has been successfully removed from [dbo].[C.Backup.Model.RestoreJobSessions] table'
	end	

	if exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.RestoreJobSessions]') and [name] = N'initiator_name')
	begin
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
					'[C.Backup.Model.RestoreJobSessions]',
					'initiator_name'
		print 'Old column {initiator_name} has been successfully removed from [dbo].[C.Backup.Model.RestoreJobSessions] table'
	end	

	---------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 807; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 807)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudFailoverPlan]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.CloudFailoverPlan]
		(
			[id] uniqueidentifier NOT NULL,
            [job_id] uniqueidentifier NOT NULL,
            [tenant_id] uniqueidentifier NOT NULL,
            [db_instance_id] uniqueidentifier NOT NULL,
        )

        PRINT 'Table {C.Backup.Model.CloudFailoverPlan} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 808; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 808)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViCloudTenantBackups]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.ViCloudTenantBackups]
		(
			[id] uniqueidentifier NOT NULL,
            [backup_id] uniqueidentifier NOT NULL,
            [quota_id] uniqueidentifier NOT NULL,
            [db_instance_id] uniqueidentifier NOT NULL,
        )

        PRINT 'Table {C.Backup.Model.ViCloudTenantBackups} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 809; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 809)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvCloudTenantBackups]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.HvCloudTenantBackups]
		(
			[id] uniqueidentifier NOT NULL,
            [backup_id] uniqueidentifier NOT NULL,
            [quota_id] uniqueidentifier NOT NULL,
            [db_instance_id] uniqueidentifier NOT NULL,
        )

        PRINT 'Table {C.Backup.Model.HvCloudTenantBackups} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 810; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 810)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.ViHardwareQuotas]
		(
			[id] uniqueidentifier NOT NULL,
            [tenantId] uniqueidentifier NOT NULL,
            [hardwarePlanId] uniqueidentifier NOT NULL,
            [db_instance_id] uniqueidentifier NOT NULL,
        )

        PRINT 'Table {C.Backup.Model.ViHardwareQuotas} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 811; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 811)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotas]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.HvHardwareQuotas]
		(
			[id] uniqueidentifier NOT NULL,
            [tenantId] uniqueidentifier NOT NULL,
            [hardwarePlanId] uniqueidentifier NOT NULL,
            [db_instance_id] uniqueidentifier NOT NULL,
        )

        PRINT 'Table {C.Backup.Model.HvHardwareQuotas} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 812; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 812)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.Backups]') and name = N'target_type')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.Backups] ADD target_type int NOT NULL DEFAULT 0
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.ViHardwarePlans]
		(
			[id] uniqueidentifier NOT NULL,
            [friendlyName] nvarchar(MAX) NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL,
        )

        PRINT 'Table {C.Backup.Model.ViHardwarePlans} has been successfully created'
    END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwarePlans]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.HvHardwarePlans]
		(
			[id] uniqueidentifier NOT NULL,
            [friendlyName] nvarchar(MAX) NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL,
        )

        PRINT 'Table {C.Backup.Model.HvHardwarePlans} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 813; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 813)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'password')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD password nvarchar(MAX) DEFAULT NULL
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 814; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 814)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.ExtRepo.ExtRepos]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.ExtRepo.ExtRepos]
		(
			[id] [uniqueidentifier] NOT NULL,
			[meta_repo_id] [uniqueidentifier] NOT NULL,
			[dependant_repo_id] [uniqueidentifier] NOT NULL,
			[options] [xml] NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL,
			CONSTRAINT [PK_C.Backup.ExtRepo.ExtRepos] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]


		PRINT 'Table {C.Backup.ExtRepo.ExtRepos} has been successfully created'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 815; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE  current_version = 815)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Repl.Topology.BackupDbInstances]') and [name] = 'installation_id')
	begin
		alter table [dbo].[Repl.Topology.BackupDbInstances] add [installation_id] [uniqueidentifier] null 
	end

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 816; END	
	END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE  current_version = 816)
BEGIN

	-- Provider side
	-- =========================================================================================
	-- create new columns [dbo].[C.Backup.Model.ViHardwarePlans]	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'hypervisorHostId')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD hypervisorHostId uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {hypervisorHostId} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'parentType')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD parentType int 
		PRINT 'New column {parentType} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'parentName')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD parentName nvarchar(MAX) NOT NULL DEFAULT ''
		PRINT 'New column {parentName} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'parentReference')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD parentReference nvarchar(MAX) NOT NULL DEFAULT ''
		PRINT 'New column {parentReference} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'rootResourcePool')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD rootResourcePool nvarchar(MAX) NOT NULL DEFAULT ''
		PRINT 'New column {rootResourcePool} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'rootFolder')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD rootFolder nvarchar(MAX) NOT NULL DEFAULT ''
		PRINT 'New column {rootFolder} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'processorUsageLimitMhz')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD processorUsageLimitMhz int 
		PRINT 'New column {processorUsageLimitMhz} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'memoryUsageLimitMb')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD memoryUsageLimitMb int 
		PRINT 'New column {memoryUsageLimitMb} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END

	-- create new table [dbo].[C.Backup.Model.ViHardwarePlanDatastores]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlanDatastores]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.ViHardwarePlanDatastores]
		(
			[id] uniqueidentifier NOT NULL,
			[hardwarePlanId] uniqueidentifier NOT NULL,
			[friendlyName] nvarchar(MAX) NOT NULL,
			[reference] nvarchar(MAX) NOT NULL,
			[rootPath] nvarchar(MAX) NOT NULL,
			[quotaGb] int,	
			[viType] NVARCHAR(MAX) NOT NULL default N'Datastore',
			[pbmProfileId] [nvarchar](max),
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.ViHardwarePlanDatastores} has been successfully created'
	END

	-- create new columns [dbo].[C.Backup.Model.ViHardwareQuotas]
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') and name = N'expireDate')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotas] ADD [expireDate] DATETIME
		PRINT 'New column {expireDate} has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotas] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') and name = N'folderReference')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotas] ADD folderReference nvarchar(MAX) NOT NULL DEFAULT ''
		PRINT 'New column {folderReference} has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotas] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') and name = N'resourcePoolReference')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotas] ADD resourcePoolReference nvarchar(MAX) NOT NULL DEFAULT ''
		PRINT 'New column {resourcePoolReference} has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotas] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') and name = N'is_enabled')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotas] ADD is_enabled bit NOT NULL DEFAULT 1
		PRINT 'New column {is_enabled} has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotas] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') and name = N'wan_id')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotas] ADD wan_id uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column {wan_id} has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotas] table'
	END

	-- create new table [dbo].[C.Backup.Model.ViHardwarePlanNetworks]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlanNetworks]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.ViHardwarePlanNetworks]
		(
			[id] uniqueidentifier NOT NULL,
			[hardwarePlanId] uniqueidentifier NOT NULL,			
			[countWithInternet] int NOT NULL,
			[countWithoutInternet] int NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.ViHardwarePlanNetworks} has been successfully created'
	END

	-- create new table [dbo].[C.Backup.Model.ViHardwareQuotaNetworks]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotaNetworks]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.ViHardwareQuotaNetworks]
		(
			[id] uniqueidentifier NOT NULL,			
			[hardwarePlanNetworkId] uniqueidentifier NOT NULL,
			[hardwareQuotaId] uniqueidentifier NOT NULL,
			[name] nvarchar(MAX) NOT NULL,
			[vlanId] int NOT NULL,
			[hasInternet] bit not null DEFAULT (0),
			[ifaceNum] int,
			[tenantInfo] xml,
			[hostNetworks] xml not null,
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.ViHardwareQuotaNetworks} has been successfully created'
	END

	-- create new columns [dbo].[C.Backup.Model.HvHardwarePlans]
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwarePlans]') and name = N'description')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwarePlans] ADD [description] nvarchar(MAX) NOT NULL DEFAULT ('')
		PRINT 'New column {description} has been successfully added to [dbo].[C.Backup.Model.HvHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwarePlans]') and name = N'hypervisorHostId')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwarePlans] ADD hypervisorHostId uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {hypervisorHostId} has been successfully added to [dbo].[C.Backup.Model.HvHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwarePlans]') and name = N'processorUsageLimitCores')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwarePlans] ADD processorUsageLimitCores int
		PRINT 'New column {processorUsageLimitCores} has been successfully added to [dbo].[C.Backup.Model.HvHardwarePlans] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwarePlans]') and name = N'memoryUsageLimitMb')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwarePlans] ADD memoryUsageLimitMb int
		PRINT 'New column {memoryUsageLimitMb} has been successfully added to [dbo].[C.Backup.Model.HvHardwarePlans] table'
	END

	-- create new table [dbo].[C.Backup.Model.HvHardwarePlanVolumes]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwarePlanVolumes]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.HvHardwarePlanVolumes]
		(
			[id] uniqueidentifier NOT NULL,
			[hardwarePlanId] uniqueidentifier NOT NULL,
			[friendlyName] nvarchar(MAX) NOT NULL,
			[volumePath] nvarchar(MAX) NOT NULL,			
			[quotaGb] int,	
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.HvHardwarePlanVolumes} has been successfully created'
	END
	
	-- create new table [dbo].[C.Backup.Model.HvHardwarePlanNetworks]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwarePlanNetworks]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.HvHardwarePlanNetworks]
		(
			[id] uniqueidentifier NOT NULL,
			[hardwarePlanId] uniqueidentifier NOT NULL,			
			[countWithInternet] int NOT NULL,
			[countWithoutInternet] int NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.HvHardwarePlanNetworks} has been successfully created'
	END

	-- create new columns [dbo].[C.Backup.Model.HvHardwareQuotas]
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotas]') and name = N'expireDate')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotas] ADD [expireDate] DATETIME
		PRINT 'New column {expireDate} has been successfully added to [dbo].[C.Backup.Model.HvHardwareQuotas] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotas]') and name = N'is_enabled')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotas] ADD is_enabled bit NOT NULL DEFAULT 1
		PRINT 'New column {is_enabled} has been successfully added to [dbo].[C.Backup.Model.HvHardwareQuotas] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotas]') and name = N'wan_id')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotas] ADD wan_id uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column {wan_id} has been successfully added to [dbo].[C.Backup.Model.HvHardwareQuotas] table'
	END

	-- create new table [dbo].[C.Backup.Model.HvHardwareQuotaNetworks]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotaNetworks]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.HvHardwareQuotaNetworks]
		(			
			[id] uniqueidentifier NOT NULL,
			[hardwarePlanNetworkId] uniqueidentifier NOT NULL,
			[hardwareQuotaId] uniqueidentifier NOT NULL,
			[name] nvarchar(MAX) NOT NULL,
			[vlanId] int NOT NULL,
			[hasInternet] bit not null DEFAULT (0),
			[ifaceNum] int,
			[tenantInfo] xml,			
			[switchName] nvarchar(MAX),
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.HvHardwareQuotaNetworks} has been successfully created'
	END

	-- create new columns [dbo].[C.Tenants]
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'options')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD [options] XML DEFAULT '<CloudTenantOptions/>'
		PRINT 'New column {options} has been successfully added to [dbo].[C.Tenants] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'throttling_speed_limit')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD throttling_speed_limit int
		PRINT 'New column {throttling_speed_limit} has been successfully added to [dbo].[C.Tenants] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'throttling_speed_unit')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD throttling_speed_unit int
		PRINT 'New column {throttling_speed_unit} has been successfully added to [dbo].[C.Tenants] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'max_concurent_tasks')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD max_concurent_tasks int
		PRINT 'New column {max_concurent_tasks} has been successfully added to [dbo].[C.Tenants] table'
	END

	-- create new columns [dbo].[C.Backup.Model.CloudFailoverPlan]
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudFailoverPlan]') and name = N'options')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.CloudFailoverPlan] ADD [options] xml DEFAULT ('<CloudFailoverPlanOptions/>')
		PRINT 'New column {options} has been successfully added to [dbo].[C.Backup.Model.CloudFailoverPlan] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudFailoverPlan]') and name = N'test_mode_job_id')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.CloudFailoverPlan] ADD test_mode_job_id uniqueidentifier NOT NULL DEFAULT newid()
		PRINT 'New column {test_mode_job_id} has been successfully added to [dbo].[C.Backup.Model.CloudFailoverPlan] table'
	END

	-- create new table [dbo].[C.Backup.Model.CloudPublicIp]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudPublicIp]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.CloudPublicIp]
		(			
			[id] uniqueidentifier NOT NULL,
			[ip_address] nvarchar(15) NOT NULL, 
			[tenant_id] [uniqueidentifier] NOT NULL,			
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.CloudPublicIp} has been successfully created'
	END

	-- create new table [dbo].[C.Backup.Model.TenantPublicIp]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.TenantPublicIp]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.TenantPublicIp]
		(			
			[cloud_public_ip_id] uniqueidentifier NOT NULL,
			[id] uniqueidentifier NOT NULL,
			[target_port] int,
			[source_ip_address] nvarchar(15),
			[source_port] int,
			[object_id] uniqueidentifier,
			[failoverplan_id] uniqueidentifier,
			[description] nvarchar(max),
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.Backup.Model.TenantPublicIp} has been successfully created'
	END

	-- create new table [dbo].[C.HostNetwork]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.HostNetwork]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.HostNetwork]
		(			
			[id] uniqueidentifier NOT NULL,
			[host_id] uniqueidentifier NOT NULL,
			[inet_vlans_left_bound] int NOT NULL,
			[inet_vlans_right_bound] int NOT NULL,
			[non_inet_vlans_left_bound] int NOT NULL,
			[non_inet_vlans_right_bound] int NOT NULL,
			[vi_cluster_ref] nvarchar(2000),
			[vi_cluster_name] nvarchar(2000),
			[vswitch_name] nvarchar(2000) NOT NULL DEFAULT '',
			[vswitch_type] int,
			[vswitch_id] nvarchar(2000),
			[db_instance_id] uniqueidentifier NOT NULL
		)
		PRINT 'Table {C.HostNetwork} has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 817; END	
	END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 817)
BEGIN
	-- create new columns [dbo].[C.Backup.Model.ViHardwarePlans]	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and name = N'description')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD [description] nvarchar(MAX) NOT NULL DEFAULT ('')
		PRINT 'New column {description} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 818; END 
END
GO


-----------------------------------------------------
--819
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version > 817 AND current_version < 821)
BEGIN	
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF EXISTS (select * from syscolumns where id = OBJECT_ID(N''[dbo].[C.Backup.Model.ViHardwarePlans]'') and [name] = ''rootResourcePool'')
		BEGIN
			declare @constraint nvarchar(100)
			declare @sqlcommand nvarchar(1000) 
			set @constraint = (select [name] from sys.default_constraints where [object_id] = (select cdefault from syscolumns where id = OBJECT_ID(N''[dbo].[C.Backup.Model.ViHardwarePlans]'') and [name] = ''rootResourcePool''))
			set @sqlcommand = N''Alter table [dbo].[C.Backup.Model.ViHardwarePlans] drop constraint ['' + @constraint + N'']''
			exec sp_sqlexec @sqlcommand
			ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] drop column [rootResourcePool]
		END'
	---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 821; END	
END
GO
--821
-----------------------------------------------------

-----------------------------------------------------
--822
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 821)
BEGIN	
	---------------------------------------------------
	IF EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwarePlans]') and [name] = 'rootFolder')
	exec sp_executesql @stat = N'
		IF EXISTS (select * from syscolumns where id = OBJECT_ID(N''[dbo].[C.Backup.Model.ViHardwarePlans]'') and [name] = ''rootFolder'')
		BEGIN
			declare @constraint nvarchar(100)
			declare @sqlcommand nvarchar(1000) 
			set @constraint = (select [name] from sys.default_constraints where [object_id] = (select cdefault from syscolumns where id = OBJECT_ID(N''[dbo].[C.Backup.Model.ViHardwarePlans]'') and [name] = ''rootFolder''))
			set @sqlcommand = N''Alter table [dbo].[C.Backup.Model.ViHardwarePlans] drop constraint ['' + @constraint + N'']''
			exec sp_sqlexec @sqlcommand
			ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] drop column [rootFolder]
		END'
	---------------------------------------------------
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 822; END	
END
GO
--822
-----------------------------------------------------

--823
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 822)
BEGIN	
	-- create new table [dbo].[C.Backup.Model.CloudAppliances]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudAppliances]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.CloudAppliances]
		(			
			[id] uniqueidentifier NOT NULL,
			[tenant_id] uniqueidentifier NOT NULL,
			[connhost_id] uniqueidentifier NOT NULL,			
			[pod_id] nvarchar(max) NOT NULL,
			[network_spec] xml NOT NULL,
			[live_info] xml NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL		
		)
		PRINT 'Table {C.Backup.Model.CloudAppliances} has been successfully created'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 823; END	
END
GO
--823


--824
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 823)
BEGIN	
	-- create new columns [dbo].[C.Tenants]	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'invalid_login_num')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD [invalid_login_num] integer NOT NULL DEFAULT (0)
		PRINT 'New column {invalid_login_num} has been successfully added to [dbo].[C.Tenants] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'last_activity_time')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD [last_activity_time] datetime DEFAULT NULL
		PRINT 'New column {last_activity_time} has been successfully added to [dbo].[C.Tenants] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 824; END	
END
GO
--825

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 824)
BEGIN	

	PRINT 'Creating clustered index on table C.Backup.Model.OIBs, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Backup.Model.OIBs', N'id'

	PRINT 'Creating clustered index on table C.Backup.Model.Storages, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Backup.Model.Storages', N'id'

	PRINT 'Creating clustered index on table C.Backup.Model.Points, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Backup.Model.Points', N'id'

	PRINT 'Creating clustered index on table C.Hosts, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Hosts', N'id'

	PRINT 'Creating clustered index on table C.BJobs, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.BJobs', N'id'

	PRINT 'Creating clustered index on table C.Backup.Model.Backups, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Backup.Model.Backups', N'id'

	PRINT 'Creating clustered index on table C.Backup.Model.BackupTaskSessions, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Backup.Model.BackupTaskSessions', N'id'

	PRINT 'Creating clustered index on table C.Backup.Model.BackupJobSessions, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Backup.Model.BackupJobSessions', N'id'

	PRINT 'Creating clustered index on table C.Backup.Model.JobSessions, column id'
	EXEC [dbo].[CreateClusteredIndex] N'C.Backup.Model.JobSessions', N'id'

	PRINT 'Creating nonclustered index on table C.Backup.Model.BackupTaskSessions, column session_id, included columns: creation_time, end_time, avg_speed'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.BackupTaskSessions', N'session_id', N'creation_time,end_time,avg_speed'
	
	PRINT 'Creating nonclustered index on table C.Backup.Model.BackupTaskSessions, columns id, db_instance_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.BackupTaskSessions', N'id,db_instance_id'

	PRINT 'Creating nonclustered index on table C.Backup.Model.OIBs, column is_corrupted, included columns: id, object_id, creation_time'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.OIBs', N'is_corrupted', N'id,object_id,creation_time'
		
	PRINT 'Creating nonclustered index on table C.Backup.Model.OIBs, columns point_id, object_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.OIBs', N'point_id,object_id'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 825; END	
END
GO
--826

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 825)
BEGIN	
	ALTER TABLE [dbo].[C.Backup.Model.CloudAppliances] ADD CONSTRAINT [PK_CBackupModelCloudAppliances] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelCloudAppliances} has been successfully added to [dbo].[C.Backup.Model.CloudAppliances] table'

	ALTER TABLE [dbo].[C.Backup.Model.CloudFailoverPlan] ADD CONSTRAINT [PK_CBackupModelCloudFailoverPlan] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelCloudFailoverPlan} has been successfully added to [dbo].[C.Backup.Model.CloudFailoverPlan] table'

	ALTER TABLE [dbo].[C.Backup.Model.CloudPublicIp] ADD CONSTRAINT [PK_CBackupModelCloudPublicIp] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelCloudPublicIp} has been successfully added to [dbo].[C.Backup.Model.CloudPublicIp] table'

	ALTER TABLE [dbo].[C.Backup.Model.HvCloudTenantBackups] ADD CONSTRAINT [PK_CBackupModelHvCloudTenantBackups] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelHvCloudTenantBackups} has been successfully added to [dbo].[C.Backup.Model.HvCloudTenantBackups] table'

	ALTER TABLE [dbo].[C.Backup.Model.HvHardwarePlanNetworks] ADD CONSTRAINT [PK_CBackupModelHvHardwarePlanNetworks] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelHvHardwarePlanNetworks} has been successfully added to [dbo].[C.Backup.Model.HvHardwarePlanNetworks] table'

	ALTER TABLE [dbo].[C.Backup.Model.HvHardwarePlans] ADD CONSTRAINT [PK_CBackupModelHvHardwarePlans] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelHvHardwarePlans} has been successfully added to [dbo].[C.Backup.Model.HvHardwarePlans] table'

	ALTER TABLE [dbo].[C.Backup.Model.HvHardwarePlanVolumes] ADD CONSTRAINT [PK_CBackupModelHvHardwarePlanVolumes] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelHvHardwarePlanVolumes} has been successfully added to [dbo].[C.Backup.Model.HvHardwarePlanVolumes] table'

	ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotaNetworks] ADD CONSTRAINT [PK_CBackupModelHvHardwareQuotaNetworks] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelHvHardwareQuotaNetworks} has been successfully added to [dbo].[C.Backup.Model.HvHardwareQuotaNetworks] table'

	ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotas] ADD CONSTRAINT [PK_CBackupModelHvHardwareQuotas] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelHvHardwareQuotas} has been successfully added to [dbo].[C.Backup.Model.HvHardwareQuotas] table'

	ALTER TABLE [dbo].[C.Backup.Model.TenantPublicIp] ADD CONSTRAINT [PK_CBackupModelTenantPublicIp] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelTenantPublicIp} has been successfully added to [dbo].[C.Backup.Model.TenantPublicIp] table'

	ALTER TABLE [dbo].[C.Backup.Model.ViCloudTenantBackups] ADD CONSTRAINT [PK_CBackupModelViCloudTenantBackups] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {[PK_CBackupModelViCloudTenantBackups]} has been successfully added to [dbo].[C.Backup.Model.ViCloudTenantBackups] table'

	ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlanDatastores] ADD CONSTRAINT [PK_CBackupModelViHardwarePlanDatastores] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelViHardwarePlanDatastores} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlanDatastores] table'

	ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlanNetworks] ADD CONSTRAINT [PK_CBackupModelViHardwarePlanNetworks] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelViHardwarePlanNetworks} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlanNetworks] table'

	ALTER TABLE [dbo].[C.Backup.Model.ViHardwarePlans] ADD CONSTRAINT [PK_CBackupModelViHardwarePlans] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelViHardwarePlans} has been successfully added to [dbo].[C.Backup.Model.ViHardwarePlans] table'

	ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotaNetworks] ADD CONSTRAINT [PK_CBackupModelViHardwareQuotaNetworks] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelViHardwareQuotaNetworks} has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotaNetworks] table'

	ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotas] ADD CONSTRAINT [PK_CBackupModelViHardwareQuotas] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CBackupModelViHardwareQuotas} has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotas] table'

	ALTER TABLE [dbo].[C.HostNetwork] ADD CONSTRAINT [PK_CHostNetwork] PRIMARY KEY CLUSTERED 
	(
		[id] ASC
	)
	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  ON [PRIMARY]
	PRINT 'Primary key {PK_CHostNetwork} has been successfully added to [dbo].[C.HostNetwork] table'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 826; END	
END
GO
--827

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 826)
BEGIN	
	-- modify columns [dbo].[C.Backup.Model.CloudAppliance]		
	ALTER TABLE [dbo].[C.Backup.Model.CloudAppliances] ALTER COLUMN [live_info] xml NULL
	PRINT 'Column {live_info} has been successfully modified in [dbo].[C.Backup.Model.CloudAppliances] table'
	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 827; END	
END
GO

--828
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 827)
BEGIN	
	-- create new columns [dbo].[C.Tenants]	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') and name = N'is_throttling_enabled')
	BEGIN
		ALTER TABLE [dbo].[C.Tenants] ADD [is_throttling_enabled] bit NOT NULL DEFAULT (0)
		PRINT 'New column {is_throttling_enabled} has been successfully added to [dbo].[C.Tenants] table'
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 828; END	
END
GO

--829
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 828)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.LicensedVms]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[C.Backup.Model.LicensedVms]
		(
			[id] uniqueidentifier NOT NULL,
            [object_id] uniqueidentifier NOT NULL,
            [first_start_time] datetime NOT NULL,
            [last_start_time] datetime NOT NULL,
			[db_instance_id] uniqueidentifier NOT NULL,
			CONSTRAINT [PK_C.Backup.Model.LicensedVms] PRIMARY KEY CLUSTERED 
			(
				[id]
			) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		)  ON [PRIMARY]

        PRINT 'Table {C.Backup.Model.LicensedVms} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 829; END	
END
GO

--830
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 829)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Replicas]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Replicas](
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[backup_id] [uniqueidentifier] NOT NULL,
			[object_id] [uniqueidentifier] NOT NULL,
			[vm_name] [nvarchar](1000) COLLATE Cyrillic_General_CI_AS NOT NULL,
			[source_location] [nvarchar](512) COLLATE Cyrillic_General_CI_AS NOT NULL,
			[target_location] [nvarchar](512) COLLATE Cyrillic_General_CI_AS NOT NULL,
			[target_vm_ref] [nvarchar](2000) COLLATE Cyrillic_General_CI_AS NOT NULL,
			[state] [int] NOT NULL,
			[usn] [bigint] NOT NULL DEFAULT (0),
			[target_vm_name] [nvarchar](1000) COLLATE Cyrillic_General_CI_AS NOT NULL DEFAULT (''),
			[vpn_state] [int] NOT NULL DEFAULT (0),
			[db_instance_id] uniqueidentifier NOT NULL
		 CONSTRAINT [PK_Replicas] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

        PRINT 'Table {C.Replicas} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 830; END	
END
GO

--831
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 830)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PerVmLicensingStatus]') AND type in (N'U'))
    BEGIN
        CREATE TABLE [dbo].[PerVmLicensingStatus]
		(
			[id] uniqueidentifier NOT NULL DEFAULT NEWSEQUENTIALID(),
			[license_state] int NOT NULL,
			[state_changed_time] varchar(max) NOT NULL,
			[previous_state_changed_time] varchar(max) NOT NULL,
			[last_licensed_vms_number] int NOT NULL,
			[platform] int NOT NULL,
			CONSTRAINT [PK_PerVmLicensingStatus] PRIMARY KEY CLUSTERED 
			(
				[id]
			) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 831; END	
END
GO

--832
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 831)
BEGIN	
	-- modify columns [dbo].[C.Tenants]	
	ALTER TABLE [dbo].[C.Tenants] ALTER COLUMN [is_throttling_enabled] bit NULL
	PRINT 'Column {is_throttling_enabled} has been successfully modified in [dbo].[C.Tenants] table'	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 832; END	
END
GO

--833
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 832)
BEGIN
	DECLARE @constraint sysname;
	DECLARE @statement NVARCHAR(255);

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') AND name = N'invalid_login_num')
	BEGIN
		SET @constraint = (select object_name(cdefault) from syscolumns where [id] = object_id(N'[dbo].[C.Tenants]') and [name] = 'invalid_login_num')
		IF (@constraint IS NOT NULL)
		BEGIN				
			SET @statement = N'ALTER TABLE [dbo].[C.Tenants] DROP CONSTRAINT [' + @constraint + ']'		
			exec sp_executesql @statement
			PRINT 'Constraint ' + @constraint + ' was successfully removed from [dbo].[C.Tenants]'
		END

		ALTER TABLE [dbo].[C.Tenants] DROP COLUMN [invalid_login_num]
		PRINT 'Column {invalid_login_num} has been successfully dropped from [dbo].[C.Tenants] table'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Tenants]') AND name = N'last_activity_time')
	BEGIN
		SET @constraint = (select object_name(cdefault) from syscolumns where [id] = object_id(N'[dbo].[C.Tenants]') and [name] = 'last_activity_time')
		IF (@constraint IS NOT NULL)
		BEGIN				
			SET @statement = N'ALTER TABLE [dbo].[C.Tenants] DROP CONSTRAINT [' + @constraint + ']'		
			exec sp_executesql @statement
			PRINT 'Constraint ' + @constraint + ' was successfully removed from [dbo].[C.Tenants]'
		END

		ALTER TABLE [dbo].[C.Tenants] DROP COLUMN [last_activity_time]
		PRINT 'Column {last_activity_time} has been successfully dropped from [dbo].[C.Tenants] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 833; END	
END
GO

--834
-- remove column usn from tables
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 833)
BEGIN
	DECLARE @constraint sysname;
	DECLARE @statement NVARCHAR(255);
	
	--80.Backup.Model.RestoreTaskSessions
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[80.Backup.Model.RestoreTaskSessions]') AND name = N'usn')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[80.Backup.Model.RestoreTaskSessions]',
			'usn'
		PRINT 'Column {usn} has been successfully dropped from [dbo].[80.Backup.Model.RestoreTaskSessions] table'
	END	

	--C.Replicas
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Replicas]') AND name = N'usn')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[C.Replicas]',
			'usn'
		PRINT 'Column {usn} has been successfully dropped from [dbo].[C.Replicas] table'
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 834; END	
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 834)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') and [name] = N'is_enabled')
	BEGIN
		EXEC sp_rename N'[dbo].[C.Backup.Model.ViHardwareQuotas].is_enabled', N'isCorrespondsToPlan', 'COLUMN';
		PRINT 'Column [is_enabled] has been successfully renamed to [is_corresponds_plan] in table [dbo].[C.Backup.Model.ViHardwareQuotas]'
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotas]') and [name] = N'isCorrespondsToPlan')
		BEGIN
			ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotas] ADD [isCorrespondsToPlan] bit NOT NULL DEFAULT 1
			PRINT 'New column [C.isCorrespondsToPlan] has been successfully added to [dbo].[C.Backup.Model.ViHardwareQuotas]'
		END		
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotas]') and [name] = N'is_enabled')
	BEGIN
		EXEC sp_rename N'[dbo].[C.Backup.Model.HvHardwareQuotas].is_enabled', N'isCorrespondsToPlan', 'COLUMN';
		PRINT 'Column [is_enabled] has been successfully renamed to [isCorrespondsToPlan] in table [dbo].[C.Backup.Model.HvHardwareQuotas]'
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotas]') and [name] = N'isCorrespondsToPlan')
		BEGIN
			ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotas] ADD [isCorrespondsToPlan] bit NOT NULL DEFAULT 1
			PRINT 'New column [isCorrespondsToPlan] has been successfully added to [dbo].[C.Backup.Model.HvHardwareQuotas]'
		END		
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 835; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 835)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.Backups]') and name = N'dir_path')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.Backups] ADD [dir_path] nvarchar(MAX) NOT NULL DEFAULT ('')
		PRINT 'New column {dir_path} has been successfully added to [dbo].[C.Backup.Model.Backups] table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 836; END 
END
GO



IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 836)
BEGIN

	--80.Backup.Model.RestoreTaskSessions
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[80.Backup.Model.RestoreTaskSessions]') AND name = N'process')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[80.Backup.Model.RestoreTaskSessions]',
			'process'
		PRINT 'Column {process} has been successfully dropped from [dbo].[80.Backup.Model.RestoreTaskSessions] table'
	END	

		--70.Backup.Model.RestoreTaskSessions
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[70.Backup.Model.RestoreTaskSessions]') AND name = N'process')
	BEGIN
		EXEC [dbo].[usp.RemoveColumnWithDefaultConstraints]
			'[70.Backup.Model.RestoreTaskSessions]',
			'process'
		PRINT 'Column {process} has been successfully dropped from [dbo].[70.Backup.Model.RestoreTaskSessions] table'
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 837; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 837)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.Storages]') and name = N'availability')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.Storages] ADD [availability] smallint NOT NULL DEFAULT (0)
		PRINT 'New column {availability} has been successfully added to [dbo].[C.Backup.Model.Storages] table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 838; END 
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 838)
BEGIN
	PRINT 'Creating nonclustered index on table C.Backup.Model.BackupTaskSessions, columns status, end_time, included columns: session_id, avg_speed, db_instance_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.BackupTaskSessions', N'status,end_time', N'session_id,avg_speed,db_instance_id'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 839; END 
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 839)
BEGIN
	EXEC [dbo].[CreatePrimaryKey] N'C.HostsByJobs', 'id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.Backup.Model.RestoreJobSessions', 'id', 'CLUSTERED'	
	EXEC [dbo].[CreatePrimaryKey] N'C.BackupProxies', 'unique_id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.BackupRepositories', 'unique_id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.JobVssCredentials ', 'id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.Backup.Model.GuestDatabase', 'id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.WanAccelerators', 'id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.HostComponents', 'id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.Backup.Model.CloudGates', 'id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.Tenants', 'id', 'CLUSTERED'
	EXEC [dbo].[CreatePrimaryKey] N'C.TenantsResourcesQuota', 'id', 'CLUSTERED'

	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.JobSessions', N'end_time', N'id,job_id,result'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.JobSessions', N'job_type,state', N'creation_time,end_time'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 840; END 
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 840)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.ReplicaConfigurations]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.ReplicaConfigurations](
		[id] [uniqueidentifier] NOT NULL,
		[cpuCount] [int] NOT NULL,
		[memoryMb] [int] NOT NULL,
		[specific] [xml] NULL,		
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_ReplicaConfigurations] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
		CONSTRAINT [FK_ReplicaConfigurations_Replicas] FOREIGN KEY([id])
		REFERENCES [dbo].[C.Replicas] ([id])
		ON DELETE CASCADE
		) ON [PRIMARY]		

        PRINT 'Table {C.ReplicaConfigurations} has been successfully created'
    END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotaDatastoreUsages]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.ViHardwareQuotaDatastoreUsages](
		[hardwareDatastoreQuotaId] [uniqueidentifier] NOT NULL,
		[replicaId] [uniqueidentifier] NOT NULL,
		[usageBytes] [bigint] NOT NULL DEFAULT ((0)),
		[id] [uniqueidentifier] NOT NULL,	
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C.Backup.Model.ViHardwareQuotaDatastoreUsages] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
		CONSTRAINT [FK_C.Backup.Model.ViHardwareQuotaDatastoreUsages_Replicas] FOREIGN KEY([replicaId])
		REFERENCES [dbo].[C.Replicas] ([id])
		ON DELETE CASCADE		
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.ViHardwareQuotaDatastoreUsages} has been successfully created'
    END
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotaVolumeUsages]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.HvHardwareQuotaVolumeUsages](
		[hardwareVolumeQuotaId] [uniqueidentifier] NOT NULL,
		[replicaId] [uniqueidentifier] NOT NULL,
		[usageBytes] [bigint] NOT NULL DEFAULT ((0)),
		[id] [uniqueidentifier] NOT NULL,	
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C.Backup.Model.HvHardwareQuotaVolumeUsages] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
		CONSTRAINT [FK_C.Backup.Model.HvHardwareQuotaVolumeUsages_Replicas] FOREIGN KEY([replicaId])
		REFERENCES [dbo].[C.Replicas] ([id])
		ON DELETE CASCADE		
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.HvHardwareQuotaVolumeUsages} has been successfully created'
    END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViHardwareQuotaDatastores]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.ViHardwareQuotaDatastores](
		[id] [uniqueidentifier] NOT NULL,
		[hardwarePlanDatastoreId] [uniqueidentifier] NOT NULL,
		[hardwareQuotaId] [uniqueidentifier] NOT NULL,
		[relativePath] [nvarchar](max) COLLATE Cyrillic_General_CI_AS NOT NULL,
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C.Backup.Model.ViHardwareQuotaDatastores] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
		CONSTRAINT [FK_C.Backup.Model.ViHardwareQuotaDatastores_ViHardwarePlanDatastores] FOREIGN KEY([hardwarePlanDatastoreId])
		REFERENCES [dbo].[C.Backup.Model.ViHardwarePlanDatastores] ([id])
		ON DELETE CASCADE		
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.ViHardwareQuotaDatastores} has been successfully created'
    END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvHardwareQuotaVolumes]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.HvHardwareQuotaVolumes](
		[id] [uniqueidentifier] NOT NULL,
		[hardwarePlanVolumeId] [uniqueidentifier] NOT NULL,
		[hardwareQuotaId] [uniqueidentifier] NOT NULL,
		[relativePath] [nvarchar](max) COLLATE Cyrillic_General_CI_AS NOT NULL,
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C.Backup.Model.HvHardwareQuotaVolumes] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
		CONSTRAINT [FK_C.Backup.Model.HvHardwareQuotaVolumes_HvHardwarePlanVolumes] FOREIGN KEY([hardwarePlanVolumeId])
		REFERENCES [dbo].[C.Backup.Model.HvHardwarePlanVolumes] ([id])
		ON DELETE CASCADE		
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.HvHardwareQuotaVolumes} has been successfully created'
    END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 841; END 
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 841)
BEGIN	
	--drop FK [dbo].[C.ReplicaConfigurations]
	IF EXISTS (SELECT * FROM sys.objects WHERE name = (N'FK_ReplicaConfigurations_Replicas') and type='F')
	BEGIN
		ALTER TABLE [dbo].[C.ReplicaConfigurations] DROP CONSTRAINT [FK_ReplicaConfigurations_Replicas]
		PRINT 'FK {FK_ReplicaConfigurations_Replicas} has been successfully dropped from [dbo].[C.ReplicaConfigurations] table'
	END
	--drop FK [dbo].[C.Backup.Model.ViHardwareQuotaDatastoreUsages]
	IF EXISTS (SELECT * FROM sys.objects WHERE name = (N'FK_C.Backup.Model.ViHardwareQuotaDatastoreUsages_Replicas') and type='F')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotaDatastoreUsages] DROP CONSTRAINT [FK_C.Backup.Model.ViHardwareQuotaDatastoreUsages_Replicas]
		PRINT 'FK {FK_C.Backup.Model.ViHardwareQuotaDatastoreUsages_Replicas} has been successfully dropped from [dbo].[C.Backup.Model.ViHardwareQuotaDatastoreUsages] table'
	END
	--drop FK [dbo].[C.Backup.Model.HvHardwareQuotaVolumeUsages]
	IF EXISTS (SELECT * FROM sys.objects WHERE name = (N'FK_C.Backup.Model.HvHardwareQuotaVolumeUsages_Replicas') and type='F')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotaVolumeUsages] DROP CONSTRAINT [FK_C.Backup.Model.HvHardwareQuotaVolumeUsages_Replicas]
		PRINT 'FK {FK_C.Backup.Model.HvHardwareQuotaVolumeUsages_Replicas} has been successfully dropped from [dbo].[C.Backup.Model.HvHardwareQuotaVolumeUsages] table'
	END
	--drop FK [dbo].[C.Backup.Model.ViHardwareQuotaDatastores]
	IF EXISTS (SELECT * FROM sys.objects WHERE name = (N'FK_C.Backup.Model.ViHardwareQuotaDatastores_ViHardwarePlanDatastores') and type='F')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.ViHardwareQuotaDatastores] DROP CONSTRAINT [FK_C.Backup.Model.ViHardwareQuotaDatastores_ViHardwarePlanDatastores]
		PRINT 'FK {FK_C.Backup.Model.ViHardwareQuotaDatastores_ViHardwarePlanDatastores} has been successfully dropped from [dbo].[C.Backup.Model.ViHardwareQuotaDatastores] table'
	END
	--drop FK [dbo].[C.Backup.Model.HvHardwareQuotaVolumes]
	IF EXISTS (SELECT * FROM sys.objects WHERE name = (N'FK_C.Backup.Model.HvHardwareQuotaVolumes_HvHardwarePlanVolumes') and type='F')
	BEGIN
		ALTER TABLE [dbo].[C.Backup.Model.HvHardwareQuotaVolumes] DROP CONSTRAINT [FK_C.Backup.Model.HvHardwareQuotaVolumes_HvHardwarePlanVolumes]
		PRINT 'FK {FK_C.Backup.Model.HvHardwareQuotaVolumes_HvHardwarePlanVolumes} has been successfully dropped from [dbo].[C.Backup.Model.HvHardwareQuotaVolumes] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 842; END 
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 842)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.OIBs]') and name = N'is_recheck_corrupted')
	BEGIN	
		ALTER TABLE [dbo].[C.Backup.Model.OIBs] ADD [is_recheck_corrupted] bit NOT NULL DEFAULT (0)
		PRINT 'Column {is_recheck_corrupted} has been successfully modified in [dbo].[C.Backup.Model.OIBs] table'	
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 843; END 
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 843)
BEGIN
	-- create [dbo].[C.Backup.Model.CloudLicensedObjects]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudLicensedObjects]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.CloudLicensedObjects](
		[object_id] [uniqueidentifier] NOT NULL,
		[number] [bigint] NOT NULL,
		[id] [uniqueidentifier] NOT NULL,	
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C.Backup.Model.CloudLicensedObjects] PRIMARY KEY CLUSTERED 
		(
			[object_id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]	
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.CloudLicensedObjects} has been successfully created'
    END

	-- create [dbo].[C.Backup.Model.HvCloudQuotaObjects]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.HvCloudQuotaObjects]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.HvCloudQuotaObjects](
		[object_id] [uniqueidentifier] NOT NULL,
		[quota_id] [uniqueidentifier] NOT NULL,
		[id] [uniqueidentifier] NOT NULL,
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C.Backup.Model.HvCloudQuotaObjects] PRIMARY KEY CLUSTERED 
		(
			[object_id] ASC,
			[quota_id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]		
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.HvCloudQuotaObjects} has been successfully created'
    END
	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.ViCloudQuotaObjects]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.ViCloudQuotaObjects](
		[object_id] [uniqueidentifier] NOT NULL,
		[quota_id] [uniqueidentifier] NOT NULL,
		[id] [uniqueidentifier] NOT NULL,
		[db_instance_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_C.Backup.Model.ViCloudQuotaObjects] PRIMARY KEY CLUSTERED 
		(
			[object_id] ASC,
			[quota_id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]		
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.ViCloudQuotaObjects} has been successfully created'
    END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 844; END 
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 844)
BEGIN

	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.BackupTaskSessions', N'object_id';
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 845; END 
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 845)
BEGIN
	-- create [dbo].[C.Backup.Model.CloudSessionsOnHvHardwareQuotas]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudSessionsOnHvHardwareQuotas]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.CloudSessionsOnHvHardwareQuotas](
		[session_id] [uniqueidentifier] NOT NULL,
		[quota_id] [uniqueidentifier] NOT NULL,
		[id] [uniqueidentifier] NOT NULL,
		[db_instance_id] [uniqueidentifier] NOT NULL
		CONSTRAINT [PK_C.Backup.Model.CloudSessionsOnHvHardwareQuotas] PRIMARY KEY CLUSTERED 
		(
				[session_id] ASC,
				[quota_id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]	
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.CloudSessionsOnHvHardwareQuotas} has been successfully created'
    END

	-- create [dbo].[C.Backup.Model.CloudSessionsOnViHardwareQuotas]
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudSessionsOnViHardwareQuotas]') AND type in (N'U'))
    BEGIN
		CREATE TABLE [dbo].[C.Backup.Model.CloudSessionsOnViHardwareQuotas](
		[session_id] [uniqueidentifier] NOT NULL,
		[quota_id] [uniqueidentifier] NOT NULL,
		[id] [uniqueidentifier] NOT NULL,
		[db_instance_id] [uniqueidentifier] NOT NULL
		CONSTRAINT [PK_C.Backup.Model.CloudSessionsOnViHardwareQuotas] PRIMARY KEY CLUSTERED 
		(
				[session_id] ASC,
				[quota_id] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]	
		) ON [PRIMARY]		

        PRINT 'Table {C.Backup.Model.CloudSessionsOnViHardwareQuotas} has been successfully created'
    END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[C.Backup.Model.CloudSessions]') and name = N'tenant_id')
	BEGIN	
		ALTER TABLE [dbo].[C.Backup.Model.CloudSessions] ADD [tenant_id] [uniqueidentifier] NOT NULL DEFAULT(CAST(CAST(0 AS BINARY) AS UNIQUEIDENTIFIER))
		PRINT 'Column {tenant_id} has been successfully added to [dbo].[C.Backup.Model.CloudSessions] table'	
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 846; END 
END


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 846)
BEGIN
	
	PRINT 'Creating nonclustered index on table C.Backup.Model.JobSessions, column job_id, included columns: creation_time'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.JobSessions', N'job_id', N'creation_time';

	PRINT 'Creating nonclustered index on table C.Backup.Model.JobSessions, columns job_id, db_instance_id, creation_time'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.JobSessions', N'job_id,db_instance_id,creation_time';

	PRINT 'Creating nonclustered index on table C.Backup.Model.JobSessions, column state, result, included columns: job_id, end_time, db_instance_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'C.Backup.Model.JobSessions', N'state,result', N'job_id,end_time,db_instance_id';


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 847; END 
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 847 AND current_version < 849)
	UPDATE [dbo].[Version] SET current_version = 849; 
GO
------------------------------------------------------------------
-- IF ANOTHER SCRIPTS WAS UPDATED:
-- 1. UNCOMMENT AND INCREMENT VERSION
-- 2. MAKE SURE THAT THE SCRIPT VERSIONS EQUALS TO THE VERSIONS OF THE CONFIG FILE.
--IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 656 AND current_version < 658)
--	@@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 658;
GO
