﻿IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2017 and current_version < 2118)
BEGIN
	-- Server
	-- =========================================================================================

	-- Create table ViHardwarePlans
	IF OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlans]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViHardwarePlans](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.ViHardwarePlans] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.ViHardwarePlans_id] DEFAULT (newid()),
			friendlyName nvarchar(MAX) NOT NULL,
			description nvarchar(MAX) NOT NULL,
			hypervisorHostId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwarePlans_Hosts] FOREIGN KEY REFERENCES [dbo].[Hosts] (id) ON DELETE CASCADE,
			parentType int,
			parentName nvarchar(MAX) NOT NULL,
			parentReference nvarchar(MAX) NOT NULL,
			rootResourcePool nvarchar(MAX) NOT NULL,
			rootFolder nvarchar(MAX) NOT NULL,
			processorUsageLimitMhz int,
			memoryUsageLimitMb int,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.ViHardwarePlans] has been successfully created'
	END

	-- Create table ViHardwarePlanDatastores
	IF OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlanDatastores]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViHardwarePlanDatastores](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.ViHardwarePlanDatastores] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.ViHardwarePlanDatastores_id] DEFAULT (newid()),
			hardwarePlanId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwarePlanDatastores_ViHardwarePlans] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwarePlans] (id) ON DELETE NO ACTION, -- cannot cascade delete (two-way deletion)
			friendlyName nvarchar(MAX) NOT NULL,
			reference nvarchar(MAX) NOT NULL,
			rootPath nvarchar(MAX) NOT NULL,
			quotaGb int,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.ViHardwarePlanDatastores] has been successfully created'
	END

	-- Create table ViHardwarePlanNetworks
	IF OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlanNetworks]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViHardwarePlanNetworks](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.ViHardwarePlanNetworks] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.ViHardwarePlanNetworks_id] DEFAULT (newid()),
			hardwarePlanId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwarePlanNetworks_ViHardwarePlans] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwarePlans] (id) ON DELETE NO ACTION, -- cannot cascade delete (two-way deletion)
			switchId nvarchar(MAX) NOT NULL,
			countWithInternent int NOT NULL,
			countWithoutInternent int NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.ViHardwarePlanNetworks] has been successfully created'
	END

	-- Create table ViHardwareQuotas
	IF OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotas]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViHardwareQuotas](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.ViHardwareQuotas] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.ViHardwareQuotas_id] DEFAULT (newid()),
			hardwarePlanId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotas_ViHardwarePlans] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwarePlans] (id) ON DELETE CASCADE,
			tenantId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotas_Tenants] FOREIGN KEY REFERENCES [dbo].[Tenants] (id) ON DELETE CASCADE,
			expireDate DATETIME,
			folderReference nvarchar(MAX) NOT NULL,
			resourcePoolReference nvarchar(MAX) NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.ViHardwareQuotas] has been successfully created'
	END

	-- Create table ViHardwareQuotaDatastores
	IF OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaDatastores]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViHardwareQuotaDatastores](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.ViHardwareQuotaDatastores] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.ViHardwareQuotaDatastores_id] DEFAULT (newid()),
			hardwarePlanDatastoreId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotaDatastores_ViHardwarePlanDatastores] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwarePlanDatastores] (id) ON DELETE CASCADE,
			hardwareQuotaId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotaDatastores_ViHardwareQuotas] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwareQuotas] (id) ON DELETE CASCADE,
			relativePath nvarchar(MAX) NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.ViHardwareQuotaDatastores] has been successfully created'
	END

	-- Create table ViHardwareQuotaNetworks
	IF OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks](
			groupId uniqueidentifier NOT NULL,
			hostId uniqueidentifier NOT NULL,
				CONSTRAINT [PK_Backup.Model.ViHardwareQuotaNetworks] PRIMARY KEY CLUSTERED (groupId, hostId) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
			hardwarePlanNetworkId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotaNetworks_ViHardwarePlanNetworks] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwarePlanNetworks] (id) ON DELETE CASCADE,
			hardwareQuotaId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotaNetworks_ViHardwareQuotas] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwareQuotas] (id) ON DELETE CASCADE,
			name nvarchar(MAX) NOT NULL,
			vlanId int NOT NULL,
			flags int NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.ViHardwareQuotaNetworks] has been successfully created'
	END

	-- Create table HvHardwarePlans
	IF OBJECT_ID(N'[dbo].[Backup.Model.HvHardwarePlans]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvHardwarePlans](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.HvHardwarePlans] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.HvHardwarePlans_id] DEFAULT (newid()),
			friendlyName nvarchar(MAX) NOT NULL,
			description nvarchar(MAX) NOT NULL,
			hypervisorHostId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwarePlans_Hosts] FOREIGN KEY REFERENCES [dbo].[Hosts] (id) ON DELETE CASCADE,
			processorUsageLimitCores int,
			memoryUsageLimitMb int,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.HvHardwarePlans] has been successfully created'
	END

	-- Create table HvHardwarePlanVolumes
	IF OBJECT_ID(N'[dbo].[Backup.Model.HvHardwarePlanVolumes]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvHardwarePlanVolumes](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.HvHardwarePlanVolumes] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.HvHardwarePlanVolumes_id] DEFAULT (newid()),
			hardwarePlanId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwarePlanVolumes_HvHardwarePlans] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwarePlans] (id) ON DELETE NO ACTION, -- cannot cascade delete (two-way deletion)
			friendlyName nvarchar(MAX) NOT NULL,
			volumePath nvarchar(MAX) NOT NULL,
			quotaGb int,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.HvHardwarePlanVolumes] has been successfully created'
	END

	-- Create table HvHardwarePlanNetworks
	IF OBJECT_ID(N'[dbo].[Backup.Model.HvHardwarePlanNetworks]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvHardwarePlanNetworks](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.HvHardwarePlanNetworks] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.HvHardwarePlanNetworks_id] DEFAULT (newid()),
			hardwarePlanId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwarePlanNetworks_HvHardwarePlans] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwarePlans] (id) ON DELETE NO ACTION, -- cannot cascade delete (two-way deletion)
			switchId nvarchar(MAX) NOT NULL,
			countWithInternent int NOT NULL,
			countWithoutInternent int NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.HvHardwarePlanNetworks] has been successfully created'
	END

	-- Create table HvHardwareQuotas
	IF OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotas]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvHardwareQuotas](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.HvHardwareQuotas] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.HvHardwareQuotas_id] DEFAULT (newid()),
			hardwarePlanId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotas_HvHardwarePlans] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwarePlans] (id) ON DELETE CASCADE,
			tenantId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotas_Tenants] FOREIGN KEY REFERENCES [dbo].[Tenants] (id) ON DELETE CASCADE,
			expireDate DATETIME,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.HvHardwareQuotas] has been successfully created'
	END

	-- Create table HvHardwareQuotaVolumes
	IF OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaVolumes]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvHardwareQuotaVolumes](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.HvHardwareQuotaVolumes] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.HvHardwareQuotaVolumes_id] DEFAULT (newid()),
			hardwarePlanVolumeId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotaVolumes_HvHardwarePlanVolumes] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwarePlanVolumes] (id) ON DELETE CASCADE,
			hardwareQuotaId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotaVolumes_HvHardwareQuotas] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwareQuotas] (id) ON DELETE CASCADE,
			relativePath nvarchar(MAX) NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.HvHardwareQuotaVolumes] has been successfully created'
	END

	-- Create table HvHardwareQuotaNetworks
	IF OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.HvHardwareQuotaNetworks] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.HvHardwareQuotaNetworks_id] DEFAULT (newid()),
			hardwarePlanNetworkId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotaNetworks_HvHardwarePlanNetworks] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwarePlanNetworks] (id) ON DELETE CASCADE,
			hardwareQuotaId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotaNetworks_HvHardwareQuotas] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwareQuotas] (id) ON DELETE CASCADE,
			name nvarchar(MAX) NOT NULL,
			vlanId int NOT NULL,
			flags int NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.HvHardwareQuotaNetworks] has been successfully created'
	END

	-- Create vi triggers
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.ViHardwarePlans'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.ViHardwarePlanDatastores'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.ViHardwarePlanNetworks'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.ViHardwareQuotas'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.ViHardwareQuotaDatastores'
	-- exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.ViHardwareQuotaNetworks' -- no id column
	
	-- Create hv triggers
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.HvHardwarePlans'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.HvHardwarePlanVolumes'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.HvHardwarePlanNetworks'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.HvHardwareQuotas'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.HvHardwareQuotaVolumes'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.HvHardwareQuotaNetworks'

	-- Client
	-- =========================================================================================
	-- Create table CloudConnectHosts
	IF OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectHosts]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudConnectHosts](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.CloudConnectHosts] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.CloudConnectHosts_id] DEFAULT (newid()),
			providerId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.CloudConnectHosts_CloudProviders] FOREIGN KEY REFERENCES [dbo].[Backup.Model.CloudProviders] (id) ON DELETE CASCADE,
			platform int NOT NULL,
			friendlyName nvarchar(MAX) NOT NULL,
			flags bigint NOT NULL,
			options xml,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.CloudConnectHosts] has been successfully created'
	END

	-- Create table CloudConnectStorages
	IF OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectStorages]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudConnectStorages](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.CloudConnectStorages] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.CloudConnectStorages_id] DEFAULT (newid()),
			availableHostId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.CloudConnectStorages_CloudConnectHosts] FOREIGN KEY REFERENCES [dbo].[Backup.Model.CloudConnectHosts] (id) ON DELETE CASCADE,
			friendlyName nvarchar(MAX) NOT NULL,
			quotaGb int,
			flags bigint NOT NULL,
			options xml,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.CloudConnectStorages] has been successfully created'
	END

	-- Create table CloudConnectNetworks
	IF OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectNetworks]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudConnectNetworks](
			id uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [PK_Backup.Model.CloudConnectNetworks] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
				CONSTRAINT [DF_Backup.Model.CloudConnectNetworks_id] DEFAULT (newid()),
			availableHostId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.CloudConnectNetworks_CloudConnectHosts] FOREIGN KEY REFERENCES [dbo].[Backup.Model.CloudConnectHosts] (id) ON DELETE CASCADE,
			friendlyName nvarchar(MAX) NOT NULL,
			flags bigint NOT NULL,
			usn bigint NOT NULL default 0
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.CloudConnectNetworks] has been successfully created'
	END
	
	-- Create triggers
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudConnectHosts'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudConnectStorages'
	exec [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudConnectNetworks'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2118; END
END
GO

--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2118)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HostNetwork]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[HostNetwork] 
		(
			[id] uniqueidentifier NOT NULL CONSTRAINT [DF_HostNetwork_id]  DEFAULT (newid()),
			[host_id] uniqueidentifier NOT NULL,
			[inet_vlans_left_bound] int NOT NULL,
			[inet_vlans_right_bound] int NOT NULL,
			[non_inet_vlans_left_bound] int NOT NULL,
			[non_inet_vlans_right_bound] int NOT NULL,
			[usn] bigint NOT NULL DEFAULT 0
			
			CONSTRAINT [PK_HostNetwork] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		
		) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2119; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2119)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[HostNetwork]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''HostNetwork''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2120; END	
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2120)
BEGIN
	IF OBJECT_ID(N'[dbo].[Backup.Model.StoreOnceRepositoryServers]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.StoreOnceRepositoryServers](
			[id] [uniqueidentifier] NOT NULL,
			[repository_id] [uniqueidentifier] NOT NULL,
			[storeonce_server_name] [nvarchar](255) NOT NULL,		
			[storeonce_creds_id] [uniqueidentifier] NOT NULL,
			[connection_type] int NOT NULL,
			[usn] [bigint] DEFAULT 0 NOT NULL
			CONSTRAINT [PK_Backup.StoreOnceRepositoryServers] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
			
		PRINT 'Create table [dbo].[Backup.Model.StoreOnceRepositoryServers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2121; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2121)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.StoreOnceRepositoryServers]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.StoreOnceRepositoryServers''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2122; END	
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2122)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BackupProxyGroups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[BackupProxyGroups](
		[id] [uniqueidentifier] NOT NULL,
		[name] nvarchar(255) NOT NULL,
		[platform] [int] NOT NULL,
		[usn] bigint NOT NULL  DEFAULT 0
		 CONSTRAINT [PK_BackupProxyGroups] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BackupProxyGroupItems]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[BackupProxyGroupItems](
		[id] [uniqueidentifier] NOT NULL,
		[proxy_group_id] [uniqueidentifier] NOT NULL,
		[proxy_id] [uniqueidentifier] NOT NULL,
		[usn] bigint NOT NULL DEFAULT 0
		 CONSTRAINT [PK_BackupProxyGroupItems] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END

	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.JobProxyGroups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.JobProxyGroups](
		[id] [uniqueidentifier] NOT NULL,
		[job_id] [uniqueidentifier] NOT NULL,
		[proxy_group_id] [uniqueidentifier] NOT NULL,
		[type] [int] NOT NULL,
		[usn] bigint NOT NULL DEFAULT 0
		 CONSTRAINT [PK_Backup.Model.JobProxyGroups] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2123; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2123)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tenants]') AND [name] = 'options')
	BEGIN		
		ALTER TABLE [dbo].[Tenants] ADD [options] XML DEFAULT '<CloudTenantOptions/>'
		PRINT 'New column {options} has been successfully added to [dbo].[Tenants] table'

		exec sp_executesql N'UPDATE [dbo].[Tenants] SET [options] = ''<CloudTenantOptions><UsageOptions><BackupResource>true</BackupResource></UsageOptions></CloudTenantOptions>'''
		ALTER TABLE [dbo].[Tenants] ALTER COLUMN [options] xml NOT NULL
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2124; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2124)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotTransferResources]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.SanSnapshotTransferResources](
				[id] [uniqueidentifier] NOT NULL,
				[source_volume_id] [uniqueidentifier] NOT NULL,	
				[target_volume_id] [uniqueidentifier] NOT NULL,
				[target_snapshot_lun_id] [uniqueidentifier] NOT NULL,
				[session_id] [uniqueidentifier] NOT NULL,
				[state] [int] NOT NULL
			CONSTRAINT [PK_Backup.SanSnapshotTransferResources] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
			
			PRINT 'Create table [dbo].[Backup.Model.SanSnapshotTransferResources]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2125; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2125)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotTransferResources]') AND [name] = 'target_snapshot_lun_id')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.SanSnapshotTransferResources] DROP COLUMN [target_snapshot_lun_id]
			ALTER TABLE [dbo].[Backup.Model.SanSnapshotTransferResources] ADD [target_snapshot_name] [nvarchar](max) NULL
			ALTER TABLE [dbo].[Backup.Model.SanSnapshotTransferResources] ADD [lease_id] [uniqueidentifier] NOT NULL
			ALTER TABLE [dbo].[Backup.Model.SanSnapshotTransferResources] ADD [type] [int] NOT NULL
		END
		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2126; END
	END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2126)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'object_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [object_id] uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {object_id} has been successfully added to [dbo].[Backup.Model.Storages] table'                     
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2127; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2127)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.ExtRepo.ExtRepos]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.ExtRepo.ExtRepos]
		(
			id uniqueidentifier NOT NULL,
			meta_repo_id uniqueidentifier NOT NULL,
			dependant_repo_id uniqueidentifier NOT NULL,
			options xml NOT NULL,
			CONSTRAINT [PK_Backup.ExtRepo.ExtRepos] PRIMARY KEY CLUSTERED 
			(
	        	id
			) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.ExtRepo.ExtRepos] ADD CONSTRAINT [FK_Backup.ExtRepo.ExtRepos_BackupRepositories] FOREIGN KEY ([meta_repo_id]) REFERENCES [dbo].[BackupRepositories] ([id]) ON DELETE CASCADE ON UPDATE NO ACTION
		ALTER TABLE [dbo].[Backup.ExtRepo.ExtRepos] ADD CONSTRAINT [FK_Backup.ExtRepo.ExtRepos_BackupRepositories_Dep] FOREIGN KEY ([dependant_repo_id]) REFERENCES [dbo].[BackupRepositories] ([id]) ON DELETE NO ACTION ON UPDATE NO ACTION

		PRINT 'Create table [dbo].[Backup.ExtRepo.ExtRepos]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2128; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2128)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.ExtRepo.Storages]') AND type in (N'U'))
	BEGIN
        CREATE TABLE [dbo].[Backup.ExtRepo.Storages]
        (
                        storage_id uniqueidentifier NOT NULL,
                        dependant_repo_id uniqueidentifier NOT NULL,
        CONSTRAINT [PK_Backup.ExtRepo.Storages] PRIMARY KEY CLUSTERED 
        (
                        storage_id,
                        dependant_repo_id
        ) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
        ) ON [PRIMARY]

        ALTER TABLE [dbo].[Backup.ExtRepo.Storages] ADD CONSTRAINT [FK_Backup.ExtRepo.ExtRepos_Storages] FOREIGN KEY ([storage_id]) REFERENCES [dbo].[Backup.Model.Storages] ([id]) ON DELETE CASCADE 
        ALTER TABLE [dbo].[Backup.ExtRepo.Storages] ADD CONSTRAINT [FK_Backup.ExtRepo.ExtRepos_Storages_Dep] FOREIGN KEY ([dependant_repo_id]) REFERENCES [dbo].[Backup.ExtRepo.ExtRepos] ([id]) ON DELETE CASCADE 

        PRINT 'Create table [dbo].[Backup.ExtRepo.Storages]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2129; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2129)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotTransferResources]') AND [name] = 'transfer_internal_id')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.SanSnapshotTransferResources] ADD [transfer_internal_id] [nvarchar](max) NOT NULL
		END
		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2130; 
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2130)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[BackupProxyGroups]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''BackupProxyGroups''
	end

	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[BackupProxyGroupItems]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''BackupProxyGroupItems''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2131; END	
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2131)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Stats.CloudGateways]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Stats.CloudGateways]
		(
			[id] uniqueidentifier NOT NULL DEFAULT NEWID(),
			[time] [datetime] NOT NULL,
			[tenant_id] uniqueidentifier NOT NULL,
			[gate_id] uniqueidentifier NOT NULL,
			[data_sent_to_client] bigint NOT NULL,
			[data_sent_by_client] bigint NOT NULL,
			[usn] bigint NOT NULL DEFAULT 0,
			[insert_time] [datetime] NOT NULL DEFAULT GETDATE()
		)
		PRINT 'Table [dbo].[Stats.CloudGateways] was created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2132; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2132)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.BackupCopyIntervals]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.BackupCopyIntervals]
		(
			[id] uniqueidentifier NOT NULL,
			[creation_time] [datetime] NOT NULL,
			[expiration_time] [datetime] NOT NULL,
			[is_active] bit NOT NULL,
			[backup_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_BackupCopyIntervals] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
		
		PRINT 'Table [dbo].[Backup.Model.BackupCopyIntervals] was created'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.BackupCopyIntervalStorages]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.BackupCopyIntervalStorages]
		(
			[id] uniqueidentifier NOT NULL,
			[interval_id] uniqueidentifier NOT NULL,
			[storage_id] uniqueidentifier NOT NULL
		CONSTRAINT [PK_BackupCopyIntervalStorages] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.BackupCopyIntervalStorages] was created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2133; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2133)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupCopyIntervals]') AND [name] = 'backup_id')
	BEGIN		
		alter table [dbo].[Backup.Model.BackupCopyIntervals] add backup_id uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {backup_id} has been successfully added to [dbo].[Backup.Model.BackupCopyIntervals] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2134; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2134)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Stats.WanAccelerators]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Stats.WanAccelerators]
		(
			[id] uniqueidentifier NOT NULL DEFAULT NEWID(),
			[time] [datetime] NOT NULL,
			[source_accelerator_id] uniqueidentifier NOT NULL,
			[target_accelerator_id] uniqueidentifier NOT NULL,
			[transferred_data] bigint NOT NULL,
			[written_data] bigint NOT NULL,
			[cache_size] bigint NOT NULL DEFAULT 0,
			[usn] bigint NOT NULL DEFAULT 0,
			[insert_time] [datetime] NOT NULL DEFAULT GETDATE()
		)
		PRINT 'Table [dbo].[Stats.WanAccelerators] was created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2135; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2135)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupCopyIntervals]') AND [name] = 'is_active')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.BackupCopyIntervals] DROP COLUMN [is_active]
		print 'Column {is_active} has been successfully removed from [dbo].[Backup.Model.BackupCopyIntervals] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupCopyIntervals]') AND [name] = 'state')
	BEGIN		
		alter table [dbo].[Backup.Model.BackupCopyIntervals] add [state] int NOT NULL DEFAULT (0)
		print 'New column {state} has been successfully added to [dbo].[Backup.Model.BackupCopyIntervals] table'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'state')
	BEGIN		
		print 'Generating BackupCopy intervals for existing BackupCopy backups'

		exec sp_executesql N'

		DECLARE @storage_id uniqueidentifier
		DECLARE @storage_creation_time datetime
		DECLARE @storage_expiration_date datetime
		DECLARE @storage_state int
		DECLARE @storage_backup_id uniqueidentifier

		DECLARE @interval_id uniqueidentifier

		DECLARE storage_cursor CURSOR FOR
			SELECT
				storages.[id],
				storages.[creation_time],
				storages.[expiration_date],
				storages.[state],
				storages.[backup_id]
			FROM [dbo].[Backup.Model.Storages] storages
				INNER JOIN [dbo].[Backup.Model.Backups] backups ON storages.[backup_id] = backups.[id] AND storages.[expiration_date] IS NOT NULL
				INNER JOIN [dbo].[BJobs] jobs ON backups.[job_id] = jobs.[id] AND jobs.[type] = 51
				order by storages.[creation_time]

		OPEN storage_cursor

		FETCH NEXT FROM storage_cursor INTO
			@storage_id,
			@storage_creation_time,
			@storage_expiration_date,
			@storage_state,
			@storage_backup_id

		WHILE @@FETCH_STATUS = 0
		BEGIN
			BEGIN TRY
				IF NOT EXISTS (SELECT TOP 1 * FROM [dbo].[Backup.Model.BackupCopyIntervalStorages] WHERE [storage_id] = @storage_id)
				BEGIN
					SET NOCOUNT ON;

					SET @interval_id = NEWID()

					INSERT INTO [dbo].[Backup.Model.BackupCopyIntervals]
						(
							[id],
							[creation_time],
							[expiration_time],
							[backup_id],
							[state]
						)
					VALUES
						(
							@interval_id,
							@storage_creation_time,
							@storage_expiration_date,
							@storage_backup_id,
							@storage_state
						)

					INSERT INTO [dbo].[Backup.Model.BackupCopyIntervalStorages]
						(
							[id],
							[interval_id],
							[storage_id]
						)
					VALUES
						(
							NEWID(),
							@interval_id,
							@storage_id
						)
				END
			END TRY
			BEGIN CATCH END CATCH
			FETCH NEXT FROM storage_cursor INTO
				@storage_id,
				@storage_creation_time,
				@storage_expiration_date,
				@storage_state,
				@storage_backup_id
		END

		CLOSE storage_cursor
		DEALLOCATE storage_cursor
		'
					
		DECLARE @constr sysname;
		
		SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.Storages]') and [name] = 'state')
		IF (@constr IS NOT NULL)
		BEGIN		
			DECLARE @statement NVARCHAR(255);					
			SET @statement = N'ALTER TABLE [dbo].[Backup.Model.Storages] DROP CONSTRAINT [' + @constr + ']'		
			exec sp_executesql @statement
			PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.Storages]'
		END

		ALTER TABLE [dbo].[Backup.Model.Storages] DROP COLUMN [state]
		print 'Column {state} has been successfully removed from [dbo].[Backup.Model.Storages] table'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'expiration_date')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] DROP COLUMN [expiration_date]
		print 'Column {expiration_date} has been successfully removed from [dbo].[Backup.Model.Storages] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2136; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2136)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessionsOnQuotas]') AND [name] = 'id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudSessionsOnQuotas]
		ADD [id] uniqueidentifier not null default NEWID();
		print 'New column {id} has been successfully added to [dbo].[Backup.Model.CloudSessionsOnQuotas] table'		
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVmsOnQuotas]') AND [name] = 'id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudVmsOnQuotas]
		ADD [id] uniqueidentifier not null default NEWID();
		print 'New column {id} has been successfully added to [dbo].[Backup.Model.CloudVmsOnQuotas] table'		
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessionsOnQuotas]') AND [name] = 'usn')
	BEGIN		
		alter table [dbo].[Backup.Model.CloudSessionsOnQuotas] add [usn] bigint not null default 0
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.CloudSessionsOnQuotas] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVms]') AND [name] = 'usn')
	BEGIN		
		alter table [dbo].[Backup.Model.CloudVms] add [usn] bigint not null default 0
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.CloudVms] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVms]') AND [name] = 'unique_id')
	BEGIN		
		alter table [dbo].[Backup.Model.CloudVms] add [unique_id] uniqueidentifier not null default NEWID()
		print 'New column {unique_id} has been successfully added to [dbo].[Backup.Model.CloudVms] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudVmsOnQuotas]') AND [name] = 'usn')
	BEGIN		
		alter table [dbo].[Backup.Model.CloudVmsOnQuotas] add [usn] bigint not null default 0
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.CloudVmsOnQuotas] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2137; END
	END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2137)
BEGIN
	declare @usn bigint

	exec [dbo].[IncrementUsn] @usn OUTPUT
	UPDATE
		[dbo].[Backup.Model.CloudSessionsOnQuotas] 
	SET
		[usn] = @usn
	
	exec [dbo].[IncrementUsn] @usn OUTPUT
	UPDATE
		[dbo].[Backup.Model.CloudVms] 
	SET
		[usn] = @usn
	
	exec [dbo].[IncrementUsn] @usn OUTPUT
	UPDATE
		[dbo].[Backup.Model.CloudVmsOnQuotas] 
	SET
		[usn] = @usn
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2138; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2138)
BEGIN
	IF OBJECT_ID(N'[dbo].[Tape.media_pool_libraries]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Tape.media_pool_libraries](
			[media_pool_id] [uniqueidentifier] NOT NULL,
			[library_id] [uniqueidentifier] NOT NULL,
			[priority] [int] NOT NULL,
			CONSTRAINT [PK_Tape.media_pool_libraries] PRIMARY KEY CLUSTERED 
		(
			[media_pool_id] ASC,
			[library_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Tape.media_pool_libraries]  WITH CHECK ADD  CONSTRAINT [FK_Tape.media_pool_libraries_Tape.libraries] FOREIGN KEY([library_id]) REFERENCES [dbo].[Tape.libraries] ([id]) ON DELETE CASCADE
		ALTER TABLE [dbo].[Tape.media_pool_libraries] CHECK CONSTRAINT [FK_Tape.media_pool_libraries_Tape.libraries]

		ALTER TABLE [dbo].[Tape.media_pool_libraries]  WITH CHECK ADD  CONSTRAINT [FK_Tape.media_pool_libraries_Tape.media_pools] FOREIGN KEY([media_pool_id]) REFERENCES [dbo].[Tape.media_pools] ([id]) ON DELETE CASCADE
		ALTER TABLE [dbo].[Tape.media_pool_libraries] CHECK CONSTRAINT [FK_Tape.media_pool_libraries_Tape.media_pools]
       
		exec sp_executesql @stat = N'	

		INSERT INTO [Tape.media_pool_libraries] (media_pool_id, library_id, priority)
		SELECT id, library_id, 0
		FROM [Tape.media_pools]'

		PRINT 'Create table [dbo].[Tape.media_pool_libraries]'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2139; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2139)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') AND [name] = 'object_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [object_id] uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {object_id} has been successfully added to [dbo].[Backup.Model.Storages] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2140; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2140)
BEGIN
	CREATE TABLE #ids (id uniqueidentifier)

	DECLARE @id AS UNIQUEIDENTIFIER
	DECLARE @s AS NVARCHAR(MAX)

	SET @id = NEWID()
	INSERT INTO #ids (id) VALUES (@id)
	SET @s = N'INSERT INTO [Tape.media_pools] (id, name, [description], [type], options, library_id, crypto_key_id, vault_id) VALUES (''' + CONVERT(nvarchar(36), @id) + ''', N''Unrecognized'', N''This media pool contains all unrecognized tapes. You should perform inventory on tapes in this pool.'', 0, ''<MediaPoolOptions/>'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'')'
	exec sp_executesql @stat = @s

	SET @id = NEWID()
	INSERT INTO #ids (id) VALUES (@id)
	SET @s = N'INSERT INTO [Tape.media_pools] (id, name, [description], [type], options, library_id, crypto_key_id, vault_id) VALUES (''' + CONVERT(nvarchar(36), @id) + ''', N''Free'', N''This media pool contains all known free tapes.'', 1, ''<MediaPoolOptions/>'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'')'
	exec sp_executesql @stat = @s

	SET @id = NEWID()
	INSERT INTO #ids (id) VALUES (@id)
	SET @s = N'INSERT INTO [Tape.media_pools] (id, name, [description], [type], options, library_id, crypto_key_id, vault_id) VALUES (''' + CONVERT(nvarchar(36), @id) + ''', N''Imported'', N''This media pool contains all imported tapes.'', 2, ''<MediaPoolOptions/>'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'')'
	exec sp_executesql @stat = @s

	SET @id = NEWID()
	INSERT INTO #ids (id) VALUES (@id)
	SET @s = N'INSERT INTO [Tape.media_pools] (id, name, [description], [type], options, library_id, crypto_key_id, vault_id) VALUES (''' + CONVERT(nvarchar(36), @id) + ''', N''Retired'', N''This media pool contains all retired tapes.'', 3, ''<MediaPoolOptions/>'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'', ''00000000-0000-0000-0000-000000000000'')'
	exec sp_executesql @stat = @s

	exec sp_executesql @stat = N'
	
	UPDATE 
		[Tape.tape_mediums]
	SET
		[Tape.tape_mediums].media_pool_id = mn.id
	FROM 
		[Tape.tape_mediums] t 
		INNER JOIN [Tape.media_pools] m ON t.media_pool_id = m.id 
		INNER JOIN [Tape.media_pools] mn ON m.type = mn.type
	WHERE 
		m.type <> 4 AND
		mn.library_id = ''00000000-0000-0000-0000-000000000000'''

	INSERT INTO 
		[Tape.media_pool_libraries] (media_pool_id, library_id, priority)
	SELECT 
		m.id, t.id, 0 
	FROM 
		#ids m, 
		[Tape.libraries] t

	exec sp_executesql @stat = N'
	
	DELETE FROM 
		[Tape.media_pools] 
	WHERE 
		type <> 4 AND 
		library_id <> ''00000000-0000-0000-0000-000000000000'''
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2141; END
END
GO 

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2141)
BEGIN
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BObjects]') AND name = N'IX_BObjects')
	BEGIN
		DROP INDEX [IX_BObjects] ON [dbo].[BObjects] WITH ( ONLINE = OFF )
		print 'Index {IX_BObjects} has been successfully droped from [dbo].[BObjects] table'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2142; END
END
GO

--------------------------------------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2142)
BEGIN	
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[HostNetwork]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''HostNetwork''
	end
	'
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2143; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2143)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostNetwork]') AND [name] = 'vi_cluster_ref')
	BEGIN
		ALTER TABLE [dbo].[HostNetwork] ADD [vi_cluster_ref] nvarchar(2000) NULL
		print 'New column {vi_cluster_ref} has been successfully added to [dbo].[HostNetwork] table'		
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostNetwork]') AND [name] = 'vi_cluster_name')
	BEGIN
		ALTER TABLE [dbo].[HostNetwork] ADD [vi_cluster_name] nvarchar(2000) NULL
		print 'New column {vi_cluster_name} has been successfully added to [dbo].[HostNetwork] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2144; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2144)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BackupRepositories]') AND [name] = 'is_dependant')
	BEGIN
		ALTER TABLE [dbo].[BackupRepositories] ADD [is_dependant] bit NOT NULL DEFAULT(0)
		print 'New column {is_dependant} has been successfully added to [dbo].[BackupRepositories] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2145; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2145)
BEGIN

	-- Alter HostsByJobs delete trigger (bug fix 40676)
	exec sp_executesql @stat = N'ALTER trigger [dbo].[d_HostsByJobs] on [dbo].[HostsByJobs] for delete 
	as 	begin  
		declare @id uniqueidentifier
		declare enumerator cursor LOCAL
			for select id from deleted
			
		open enumerator
		fetch next from enumerator into @id
	
		while @@FETCH_STATUS = 0
		begin
		  exec dbo.TrackChange N''HostsByJobs'', @id, 2
		  fetch next from enumerator into @id
		end

		close enumerator
		deallocate enumerator
	end'
	print 'Trigger [dbo].[LicensedHosts].{d_HostsByJobs} has been successfully changed'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2146; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2146)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotTransferResources]') AND [name] = '[target_snapshot_name]')
		BEGIN
			IF EXISTS(SELECT * FROM sys.columns 
			WHERE [name] = N'[target_snapshot_lun_id]' AND [object_id] = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotTransferResources]'))
			BEGIN
				ALTER TABLE [dbo].[Backup.Model.SanSnapshotTransferResources] DROP COLUMN [target_snapshot_lun_id]
			END			
		END
		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2147; END
	END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2147)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'backup_session_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [backup_session_id] uniqueidentifier NULL
		print 'New column {backup_session_id} has been successfully added to [dbo].[Tape.backup_sets] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2148; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2148)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ObjectsInApplicationGroups]') AND [name] = 'creds_id')
	BEGIN		
		alter table [dbo].[ObjectsInApplicationGroups] add creds_id uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {creds_id} has been successfully added to [dbo].[ObjectsInApplicationGroups] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[SbVerificationRules]') AND [name] = 'creds_id')
	BEGIN		
		alter table [dbo].[SbVerificationRules] add creds_id uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {creds_id} has been successfully added to [dbo].[SbVerificationRules] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2149; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2149)
BEGIN
	IF OBJECT_ID(N'[dbo].[PhysHost_Share]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[PhysHost_Share](
			[id] [uniqueidentifier] NOT NULL,
			[physhost_id] [uniqueidentifier] NOT NULL,
			[remote_host] [nvarchar](max) NOT NULL,
			[remote_path] [nvarchar](max) NOT NULL,
			[is_manual_added] [bit] DEFAULT 0 NOT NULL,
			[datastore_name] [nvarchar](max) DEFAULT '' NOT NULL,
			[vms_count] [int] DEFAULT 0 NOT NULL,
			[usn] [bigint] DEFAULT 0 NOT NULL
			
		 CONSTRAINT [PK_PhysHostShare] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		) ON [PRIMARY]

		PRINT 'Create table [dbo].[PhysHost_Share]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2150; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2150)
BEGIN
	exec [dbo].[AddTrackChangeTriggers] N'PhysHost_Share'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2151; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2151)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.DataDomainRepositoryServers]') AND [name] = 'encryption_type')
	BEGIN		
		alter table [dbo].[Backup.Model.DataDomainRepositoryServers] add encryption_type int not null default 0
		print 'New column {encryption_type} has been successfully added to [dbo].[Backup.Model.DataDomainRepositoryServers] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2152; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2152)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudTenantBackups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViCloudTenantBackups]
		(
			backup_id uniqueidentifier NOT NULL,
			quota_id uniqueidentifier NOT NULL
		 CONSTRAINT [PK_Backup.Model.ViCloudTenantBackups] PRIMARY KEY CLUSTERED 
		(
			backup_id,
			quota_id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.ViCloudTenantBackups] ADD CONSTRAINT [FK_Backup.Model.ViCloudTenantBackups_Backups] FOREIGN KEY ([backup_id]) REFERENCES [dbo].[Backup.Model.Backups] ([id]) ON DELETE CASCADE
		ALTER TABLE [dbo].[Backup.Model.ViCloudTenantBackups] ADD CONSTRAINT [FK_Backup.Model.ViCloudTenantBackups_ViHardwareQuotas] FOREIGN KEY ([quota_id]) REFERENCES [dbo].[Backup.Model.ViHardwareQuotas] ([id]) ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.ViCloudTenantBackups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2153; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2153)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_pools]') AND ([name] = 'library_id'))
	BEGIN
		ALTER TABLE [dbo].[Tape.media_pools] DROP COLUMN [library_id]
		PRINT 'Columns [library_id] was successfully removed from [dbo].[Tape.media_pools]'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2154; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2154)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = N'has_oracle')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [has_oracle] bit NOT NULL DEFAULT 0
			PRINT 'New column {has_oracle} has been successfully added to dbo.[Backup.Model.OIBs]'
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2155; END
	END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2155)
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.Shared]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.TrackedActions.Shared] (
		[id] [uniqueidentifier] NOT NULL
            CONSTRAINT [PK_Backup.TrackedActions.Shared] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON),
		[key] nvarchar(max) NOT NULL,	
		[type] int NOT NULL,	
		[data] xml NOT NULL,
		)

        PRINT 'Table [dbo].[Backup.TrackedActions.Shared] has been successfully created'
	END
			
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2156; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2156)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.Shared.Leases]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.TrackedActions.Shared.Leases] (
		[action_id] [uniqueidentifier] NOT NULL
            CONSTRAINT [FK_Backup.TrackedActions.Shared.Leases_ActionId] FOREIGN KEY REFERENCES [dbo].[Backup.TrackedActions.Shared] (id),
		[lease_id] [uniqueidentifier] NOT NULL
            CONSTRAINT [FK_Backup.TrackedActions.Shared.Leases_LeaseId] FOREIGN KEY REFERENCES [dbo].[Backup.TrackedActions.Leases] (id)		            
		)

        PRINT 'Table [dbo].[Backup.TrackedActions.Shared.Leases] has been successfully created'
	END	
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2157; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2157)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.OracleGuestDatabase]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.OracleGuestDatabase](
			[id] [uniqueidentifier] NOT NULL,
			[obj_id] [uniqueidentifier] NOT NULL,
			[db_name] [nvarchar](1000) NOT NULL,
			[db_id] [nvarchar](max) NOT NULL,
			[home_name] [nvarchar](128) NOT NULL,
			[server_name] [nvarchar](1000) NOT NULL,
			[oracle_sid] [nvarchar](max) NOT NULL,
			[usn] [bigint] NOT NULL
		CONSTRAINT [PK_OracleGuestDatabase] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [IX_OracleGuestDatabase_ObjId] ON [dbo].[Backup.Model.OracleGuestDatabase]
		(
			[obj_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2158; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2158)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudTenantBackups]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvCloudTenantBackups]
		(
			backup_id uniqueidentifier NOT NULL,
			quota_id uniqueidentifier NOT NULL
		 CONSTRAINT [PK_Backup.Model.HvCloudTenantBackups] PRIMARY KEY CLUSTERED 
		(
			backup_id,
			quota_id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.HvCloudTenantBackups] ADD CONSTRAINT [FK_Backup.Model.HvCloudTenantBackups_Backups] FOREIGN KEY ([backup_id]) REFERENCES [dbo].[Backup.Model.Backups] ([id]) ON DELETE CASCADE
		ALTER TABLE [dbo].[Backup.Model.HvCloudTenantBackups] ADD CONSTRAINT [FK_Backup.Model.HvCloudTenantBackups_HvHardwareQuotas] FOREIGN KEY ([quota_id]) REFERENCES [dbo].[Backup.Model.HvHardwareQuotas] ([id]) ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.HvCloudTenantBackups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2159; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2159)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.OracleOIBs](
			[id] [uniqueidentifier] NOT NULL,
			[guest_db_id] [uniqueidentifier] NOT NULL,
			[stg_id] [uniqueidentifier] NOT NULL,
			[inside_dir] [nvarchar](1024) NOT NULL,
			[creation_time] [datetime] DEFAULT (GETDATE()) NOT NULL,
			[file_name] [nvarchar](400) NOT NULL,
			[size] [bigint] NOT NULL,
			[is_corrupted] [bit] NOT NULL,
			[creation_usn] [bigint] NOT NULL,
			[first_scn] [nvarchar](15) NOT NULL,
			[first_time] [datetime] DEFAULT (GETDATE()) NOT NULL,
			[last_scn] [nvarchar](15) NOT NULL,
			[last_time] [datetime] DEFAULT (GETDATE()) NOT NULL,
			[usn] [bigint] NOT NULL

			CONSTRAINT [PK_OracleOIBs] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.OracleOIBs] WITH CHECK ADD CONSTRAINT [FK_OracleOIBs.guest_db_id] FOREIGN KEY([guest_db_id])
		REFERENCES [dbo].[Backup.Model.OracleGuestDatabase] ([id])

		ALTER TABLE [dbo].[Backup.Model.OracleOIBs] WITH CHECK ADD CONSTRAINT [FK_OracleOIBs.stg_id] FOREIGN KEY([stg_id])
		REFERENCES [dbo].[Backup.Model.Storages] ([id])

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_OracleOIBs_usn' AND object_id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]'))
		BEGIN
			CREATE NONCLUSTERED INDEX [IX_OracleOIBs_usn] ON [dbo].[Backup.Model.OracleOIBs]
			(
				[usn] ASC
			) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
			PRINT 'New index {IX_OracleOIBs_usn} has been successfully added to [dbo].[Backup.Model.OracleOIBs] table'
		END

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_OracleOIBs_creation_usn' AND object_id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]'))
		BEGIN
			CREATE NONCLUSTERED INDEX [IX_OracleOIBs_creation_usn] ON [dbo].[Backup.Model.OracleOIBs]
			(
				[creation_usn] ASC
			) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
			PRINT 'New index {IX_OracleOIBs_creation_usn} has been successfully added to [dbo].[Backup.Model.OracleOIBs] table'
		END

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_OracleOIBs_guest_db_id' AND object_id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]'))
		BEGIN
			CREATE NONCLUSTERED INDEX [IX_OracleOIBs_guest_db_id] ON [dbo].[Backup.Model.OracleOIBs]
			(
				[guest_db_id] ASC
			) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
			PRINT 'New index {IX_OracleOIBs_guest_db_id} has been successfully added to [dbo].[Backup.Model.OracleOIBs] table'
		END

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_OracleOIBs_stg_id' AND object_id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]'))
		BEGIN
			CREATE NONCLUSTERED INDEX [IX_OracleOIBs_stg_id] ON [dbo].[Backup.Model.OracleOIBs]
			(
				[stg_id] ASC
			) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
			PRINT 'New index {IX_OracleOIBs_stg_id} has been successfully added to [dbo].[Backup.Model.OracleOIBs] table'
		END

		exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.OracleOIBs]''))
		begin
			exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.OracleOIBs''
		end
		'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2160; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2160)
BEGIN
exec sp_executesql @stat = N'ALTER TRIGGER [Tape.after_delete_media_pools] 
   ON  [dbo].[Tape.media_pools] 
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- update deleted_usns
	
	DECLARE @highest_committed_usn bigint, @id uniqueidentifier
	
	DECLARE deleted_cursor CURSOR FOR SELECT id FROM deleted
	OPEN deleted_cursor
	
	FETCH NEXT FROM deleted_cursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [Tape.next_highest_committed_usn] @highest_committed_usn OUT
		
		INSERT INTO [Tape.deleted_usns] 
			(id, usn, table_name, delete_time) 
		VALUES 
			(@id, @highest_committed_usn, N''media_pools'', GETDATE())
			
		FETCH NEXT FROM deleted_cursor INTO @id
	END
	
	CLOSE deleted_cursor
	DEALLOCATE deleted_cursor
END'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2161; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2161)
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeLunExportLocks]') AND type in (N'U'))
	BEGIN
	
		PRINT N'Creating [dbo].[Backup.Model.SanVolumeLunExportLocks] table'
	
		CREATE TABLE [dbo].[Backup.Model.SanVolumeLunExportLocks]
		(
			[id] [uniqueidentifier] NOT NULL,
			[lun_id] [uniqueidentifier] NOT NULL,
			[session_id] [uniqueidentifier] NOT NULL,			
			[lock_type] [int] NOT NULL,
			[lock_status] [int] NOT NULL
		
			CONSTRAINT [PK_Backup_Model_SanVolumeLunExportLocks_id] PRIMARY KEY NONCLUSTERED 
			(
				[id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]
	END	

    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2162; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2162)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudAppliances]') AND type in (N'U'))
	BEGIN
	
		PRINT N'Creating [dbo].[Backup.Model.CloudAppliances] table'
	
		CREATE TABLE [dbo].[Backup.Model.CloudAppliances]
		(
			[tenant_id] [uniqueidentifier] NOT NULL,
			[connhost_id] [uniqueidentifier] NOT NULL,
			[pod_id] nvarchar(64) NOT NULL,			
			[network_spec] xml NOT NULL,
			[live_info] xml
		
			CONSTRAINT [PK_Backup_Model_CloudAppliances] PRIMARY KEY NONCLUSTERED 
			(
				[tenant_id] ASC,
				[connhost_id] ASC,
				[pod_id] ASC
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.CloudAppliances] ADD CONSTRAINT [FK_Backup.Model.CloudAppliances_Tenants] 
			FOREIGN KEY ([tenant_id]) REFERENCES [dbo].[Tenants] ([id])

		ALTER TABLE [dbo].[Backup.Model.CloudAppliances] ADD CONSTRAINT [FK_Backup.Model.CloudAppliances_Hosts] 
			FOREIGN KEY ([connhost_id]) REFERENCES [dbo].[Hosts] ([id])

	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2163; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2163)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_drives]') and [name] = N'minimum_block_size')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_drives] ADD [minimum_block_size] int NOT NULL DEFAULT 65536
		PRINT 'New column [minimum_block_size] has been successfully added to [dbo].[Tape.tape_drives]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_drives]') and [name] = N'maximum_block_size')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_drives] ADD [maximum_block_size] int NOT NULL DEFAULT 65536
		PRINT 'New column [maximum_block_size] has been successfully added to [dbo].[Tape.tape_drives]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_drives]') and [name] = N'default_block_size')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_drives] ADD [default_block_size] int NOT NULL DEFAULT 65536
		PRINT 'New column [default_block_size] has been successfully added to [dbo].[Tape.tape_drives]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_drives]') and [name] = N'current_block_size')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_drives] ADD [current_block_size] int NULL
		PRINT 'New column [current_block_size] has been successfully added to [dbo].[Tape.tape_drives]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2164; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2164)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TombStones.Tenants]') AND type in (N'U'))
	BEGIN
	PRINT N'Creating [dbo].[TombStones.Tenants] table'
	CREATE TABLE [dbo].[TombStones.Tenants](
	[tombstoneUsn] bigint NOT NULL,
	[tenantId] uniqueidentifier NOT NULL

	CONSTRAINT [FK_TombStones.Tenants_TombStones] FOREIGN KEY (tombstoneUsn) REFERENCES [dbo].[TombStones] (usn) ON DELETE CASCADE)
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2165; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2165)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') and [name] = N'ifaceNum')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] ADD [ifaceNum] int NULL
		PRINT 'New column [ifaceNum] has been successfully added to [dbo].[Backup.Model.ViHardwareQuotaNetworks]'
	END
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') and [name] = N'tenantInfo')
BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] ADD [tenantInfo] xml
		PRINT 'New column [tenantInfo] has been successfully added to [dbo].[Backup.Model.ViHardwareQuotaNetworks]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2166; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2166)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeLunExportLocks]') and [name] = N'volume_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumeLunExportLocks] ADD [volume_id] [uniqueidentifier] NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column [volume_id] has been successfully added to [dbo].[Backup.Model.SanVolumeLunExportLocks]'
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2167; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2167)
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudFailoverPlan]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudFailoverPlan]
			(
				[job_id] [uniqueidentifier] NOT NULL,
				[tenant_id] [uniqueidentifier] NOT NULL,
				[options] [xml] NULL 
			)
		
		ALTER TABLE [dbo].[Backup.Model.CloudFailoverPlan] ADD  DEFAULT ('<CloudFailoverPlanOptions/>') FOR [options]

        PRINT 'Table [dbo].[Backup.Model.CloudFailoverPlan] has been successfully created'
	END
				
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2168; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2168)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeLunExportLocks]') and [name] = N'snapshot_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumeLunExportLocks] ADD [snapshot_id] [uniqueidentifier] NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column [snapshot_id] has been successfully added to [dbo].[Backup.Model.SanVolumeLunExportLocks]'
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2169; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2169)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') and [name] = N'ifaceNum')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks] ADD [ifaceNum] int NULL
		PRINT 'New column [ifaceNum] has been successfully added to [dbo].[Backup.Model.HvHardwareQuotaNetworks]'
	END
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') and [name] = N'tenantInfo')
BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks] ADD [tenantInfo] xml
		PRINT 'New column [tenantInfo] has been successfully added to [dbo].[Backup.Model.HvHardwareQuotaNetworks]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2170; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2170)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') and [name] = N'usageCount')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] ADD [usageCount] int NOT NULL DEFAULT 0
		PRINT 'New column [usageCount] has been successfully added to [dbo].[Backup.Model.ViHardwareQuotaNetworks]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2171; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2171)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotas]') and [name] = N'is_enabled')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotas] ADD [is_enabled] bit NOT NULL DEFAULT 1
		PRINT 'New column [is_enabled] has been successfully added to [dbo].[Backup.Model.ViHardwareQuotas]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotas]') and [name] = N'is_enabled')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotas] ADD [is_enabled] bit NOT NULL DEFAULT 1
		PRINT 'New column [is_enabled] has been successfully added to [dbo].[Backup.Model.HvHardwareQuotas]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2172; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2172)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') and [name] = N'usageCount')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks] ADD [usageCount] int NOT NULL DEFAULT 0
		PRINT 'New column [usageCount] has been successfully added to [dbo].[Backup.Model.HvHardwareQuotaNetworks]'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2173; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2173)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]') and [name] = N'seq_num')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OracleOIBs] ADD [seq_num] nvarchar(40) NOT NULL DEFAULT '0'
		PRINT 'New column [seq_num] has been successfully added to [dbo].[Backup.Model.OracleOIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2174; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2174)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_families]') and [name] = N'lock_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.media_families] ADD [lock_id] uniqueidentifier NULL
		PRINT 'New column [lock_id] has been successfully added to [dbo].[Tape.media_families]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_families]') and [name] = N'is_closed')
	BEGIN
		ALTER TABLE [dbo].[Tape.media_families] ADD [is_closed] bit NOT NULL DEFAULT 0
		PRINT 'New column [is_closed] has been successfully added to [dbo].[Tape.media_families]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_families]') and [name] = N'creation_time')
	BEGIN
		ALTER TABLE [dbo].[Tape.media_families] ADD [creation_time] datetime NULL
		PRINT 'New column [creation_time] has been successfully added to [dbo].[Tape.media_families]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_families]') and [name] = N'media_pool_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.media_families] ADD [media_pool_id] uniqueidentifier NULL
		PRINT 'New column [media_pool_id] has been successfully added to [dbo].[Tape.media_families]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2175; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2175)
BEGIN
	-- Move old media sets to archive
    
	UPDATE [Tape.media_families] 
    SET is_closed = 1
    WHERE id NOT IN (
		SELECT MAX([Tape.media_families].id) 
		FROM [Tape.media_families] 
			INNER JOIN [Tape.tape_mediums] ON [Tape.media_families].id = [Tape.tape_mediums].media_family_id 
			INNER JOIN [Tape.media_pools] ON [Tape.tape_mediums].media_pool_id = [Tape.media_pools].id 
		GROUP BY [Tape.media_pools].id)
	    
    UPDATE [Tape.media_families]
    SET creation_time = (
		SELECT MIN(last_write_time) 
		FROM [Tape.tape_mediums] 
		WHERE media_family_id = [Tape.media_families].id)
    WHERE is_closed = 0

    UPDATE [dbo].[Tape.media_families]
    SET [Tape.media_families].media_pool_id = (
		SELECT TOP 1 media_pool_id 
		FROM [Tape.tape_mediums] 
		WHERE media_family_id = [Tape.media_families].id)
    WHERE is_closed = 0

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2176; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2176)
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudPublicIp]
			(
				[id] [uniqueidentifier] NOT NULL,
				[ip_address] nvarchar(15) NOT NULL, 
				[tenant_id] [uniqueidentifier] NOT NULL,
				[object_id] [uniqueidentifier] NOT NULL
			)
		
        PRINT 'Table [dbo].[Backup.Model.CloudPublicIp] has been successfully created'
	END
				
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2177; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2177)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') and [name] = N'media_set_type')
	BEGIN
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD [media_set_type] tinyint NULL
		PRINT 'New column [media_set_type] has been successfully added to [dbo].[Tape.tape_mediums]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2178; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2178)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_families]') and [name] = N'type')
	BEGIN
		EXEC sp_rename N'[dbo].[Tape.media_families].type', N'type_id', 'COLUMN';
		PRINT 'Column [type] has been successfully renamed to [type_id] in table [dbo].[Tape.media_families]'
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.media_families]') and [name] = N'type_id')
		BEGIN
			ALTER TABLE [dbo].[Tape.media_families] ADD [type_id] int NOT NULL DEFAULT 0
			PRINT 'New column [type_id] has been successfully added to [dbo].[Tape.media_families]'
		END		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2179; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2179)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotas]') and [name] = N'wan_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotas] ADD [wan_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column [wan_id] has been successfully added to [dbo].[Backup.Model.ViHardwareQuotas]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2180; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2180)
BEGIN
    IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanVolumeLUNs]') AND [name] = 'local_path')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.SanVolumeLUNs] ADD [local_path] [nvarchar](max) DEFAULT '' NOT NULL
		print 'New column {local_path} has been successfully added to [dbo].[Backup.Model.SanVolumeLUNs] table'		
	END

    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2181; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2181)
BEGIN   
    UPDATE [dbo].[Backup.Model.SanVolumeLUNs]
    SET [dbo].[Backup.Model.SanVolumeLUNs].[local_path] = [dbo].[Backup.Model.SanVolumeLUNs].[internal_id]
    WHERE [dbo].[Backup.Model.SanVolumeLUNs].[type] = 1 

    print 'Updating {local_path} for existing NFS shares in [dbo].[Backup.Model.SanVolumeLUNs] table completed'		

    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2182; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2182)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]') and [name] = N'failoverplan_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudPublicIp] ADD [failoverplan_id] [uniqueidentifier] NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column [failoverplan_id] has been successfully added to [dbo].[Backup.Model.CloudPublicIp]'
	END	

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]') and [name] = N'details')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudPublicIp] ADD [details] xml NOT NULL DEFAULT ('<CloudPublicIpDetails/>')
		PRINT 'New column [details] has been successfully added to [dbo].[Backup.Model.CloudPublicIp]'
	END	
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2183; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2183)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotas]') and [name] = N'wan_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotas] ADD [wan_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column [wan_id] has been successfully added to [dbo].[Backup.Model.HvHardwareQuotas]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2184; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2184)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LinkedJobs]') and [name] = N'creation_time')
	BEGIN
		ALTER TABLE [dbo].[LinkedJobs] ADD [creation_time] datetime not null DEFAULT GETDATE();
		PRINT 'New column [creation_time] has been successfully added to [dbo].[LinkedJobs]'
END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LinkedBackupRepositories]') and [name] = N'creation_time')
BEGIN
		ALTER TABLE [dbo].[LinkedBackupRepositories] ADD [creation_time] datetime not null DEFAULT GETDATE();
		PRINT 'New column [creation_time] has been successfully added to [dbo].[LinkedBackupRepositories]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2185; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2185)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ItemRestoreAudits]') and [name] = N'operation_type')
	BEGIN
		ALTER TABLE [dbo].[ItemRestoreAudits] ADD operation_type int DEFAULT -1 NOT NULL
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2186; END
END		
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2186)
BEGIN
	-- CloudConnectHosts
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectHosts]') and [name] = N'is_wan_accelerator_enabled')
	BEGIN
		EXEC sp_RENAME '[dbo].[Backup.Model.CloudConnectHosts].is_wan_accelerator_enabled', 'isWanEnabled', 'COLUMN'
		PRINT 'Old column [is_wan_accelerator_enabled] has been successfully renamed to [isWanEnabled]'
	END ELSE BEGIN
		IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectHosts]') and [name] = N'isWanEnabled')
		BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudConnectHosts] ADD [isWanEnabled] bit not null DEFAULT (0);
		PRINT 'New column [isWanEnabled] has been successfully added to [dbo].[Backup.Model.CloudConnectHosts]'
	END
	END

	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectHosts]') and [name] = N'flags')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.CloudConnectHosts] DROP COLUMN [flags]
	PRINT 'Old column [flags] has been successfully droped from [dbo].[Backup.Model.CloudConnectHosts]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectHosts]') and [name] = N'isUnavailable')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.CloudConnectHosts] ADD [isUnavailable] bit not null DEFAULT (0);
	PRINT 'New column [isUnavailable] has been successfully added to [dbo].[Backup.Model.CloudConnectHosts]'
	END

	-- CloudConnectStorages	
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectStorages]') and [name] = N'flags')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.CloudConnectStorages] DROP COLUMN [flags]
	PRINT 'Old column [flags] has been successfully droped from [dbo].[Backup.Model.CloudConnectStorages]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectStorages]') and [name] = N'isUnavailable')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.CloudConnectStorages] ADD [isUnavailable] bit not null DEFAULT (0);
	PRINT 'New column [isUnavailable] has been successfully added to [dbo].[Backup.Model.CloudConnectStorages]'
	END

	-- CloudConnectNetworks
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectNetworks]') AND [name] = 'default_gateway')
	BEGIN
		EXEC sp_RENAME '[dbo].[Backup.Model.CloudConnectNetworks].default_gateway', 'defaultGateway', 'COLUMN'
		PRINT 'Old column [default_gateway] has been successfully renamed to [defaultGateway]'
	END ELSE BEGIN
		IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectNetworks]') AND [name] = 'defaultGateway')
		BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudConnectNetworks] ADD [defaultGateway] nvarchar(18) NULL -- Max J.
		print 'New column [default_gateway] has been successfully added to [dbo].[Backup.Model.CloudConnectNetworks] table'		
	END
	END

	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectNetworks]') AND [name] = 'flags')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.CloudConnectNetworks] DROP COLUMN [flags]
	PRINT 'Old column [flags] has been successfully droped from [dbo].[Backup.Model.CloudConnectNetworks]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectNetworks]') AND [name] = 'isUnavailable')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.CloudConnectNetworks] ADD [isUnavailable] bit not null DEFAULT (0);
	PRINT 'New column [isUnavailable] has been successfully added to [dbo].[Backup.Model.CloudConnectNetworks]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectNetworks]') AND [name] = 'hasInternet')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.CloudConnectNetworks] ADD [hasInternet] bit not null DEFAULT (0);
	PRINT 'New column [hasInternet] has been successfully added to [dbo].[Backup.Model.CloudConnectNetworks]'
	END

	-- ViHardwareQuotaNetworks
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') AND [name] = 'flags')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] DROP COLUMN [flags]
	PRINT 'Old column [flags] has been successfully droped from [dbo].[Backup.Model.ViHardwareQuotaNetworks]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') AND [name] = 'hasInternet')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] ADD [hasInternet] bit not null DEFAULT (0);
	PRINT 'Old column [hasInternet] has been successfully added to [dbo].[Backup.Model.ViHardwareQuotaNetworks]'
	END

	-- HvHardwareQuotaNetworks
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') AND [name] = 'flags')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks] DROP COLUMN [flags]
	PRINT 'Old column [flags] has been successfully droped from [dbo].[Backup.Model.HvHardwareQuotaNetworks]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') AND [name] = 'hasInternet')
	BEGIN
	ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks] ADD [hasInternet] bit not null DEFAULT (0);
	PRINT 'Old column [hasInternet] has been successfully added to [dbo].[Backup.Model.HvHardwareQuotaNetworks]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2187; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2187)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlanDatastores]') AND [name] = 'viType')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwarePlanDatastores]
		ADD [viType] NVARCHAR(MAX) not null default N'Datastore';
		print 'New column {viType} has been successfully added to [dbo].[Backup.Model.ViHardwarePlanDatastores] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2188; END
	END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2188)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.changers]') and [name] = N'is_driver_installed')
	BEGIN
		ALTER TABLE [dbo].[Tape.changers] ADD [is_driver_installed] bit not null DEFAULT (1);
		PRINT 'New column [is_driver_installed] has been successfully added to [dbo].[Tape.changers]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.changers]') and [name] = N'use_scsi')
	BEGIN
		ALTER TABLE [dbo].[Tape.changers] ADD [use_scsi] bit not null DEFAULT (0);
		PRINT 'New column [use_scsi] has been successfully added to [dbo].[Tape.changers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2189; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2189)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.JobSessions]') AND [name] = 'initiator_sid')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.JobSessions] ADD [initiator_sid] [nvarchar](255) DEFAULT NULL
		print 'New column {initiator_sid} has been successfully added to [dbo].[Backup.Model.JobSessions] table'		
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.JobSessions]') AND [name] = 'initiator_name')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.JobSessions] ADD [initiator_name] [nvarchar](255) DEFAULT NULL
		print 'New column {initiator_name} has been successfully added to [dbo].[Backup.Model.JobSessions] table'		
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2190; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2190)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'initiator_sid')
	BEGIN
		exec sp_executesql N'
			UPDATE js
				SET [initiator_sid] = rjs.[initiator_sid],
					[initiator_name] = rjs.[initiator_name]

			FROM [dbo].[Backup.Model.JobSessions] as js
			INNER JOIN [dbo].[Backup.Model.RestoreJobSessions] as rjs
			ON js.[id] = rjs.[id]

			print ''{initiator_sid} and {initiator_name} column values has been successfully copied to [dbo].[Backup.Model.JobSessions] table''

			DECLARE @constr sysname;
		
			SET @constr = (select object_name(cdefault) from syscolumns where [id] = object_id(N''[dbo].[Backup.Model.RestoreJobSessions]'') and [name] = ''initiator_sid'')
			IF (@constr IS NOT NULL)
			BEGIN		
				DECLARE @statement NVARCHAR(255);					
				SET @statement = N''ALTER TABLE [dbo].[Backup.Model.RestoreJobSessions] DROP CONSTRAINT ['' + @constr + '']''		
				exec sp_executesql @statement
				PRINT ''Constraint '' + @constr + '' was successfully removed from [dbo].[Backup.Model.RestoreJobSessions]''
			END

			ALTER TABLE [dbo].[Backup.Model.RestoreJobSessions] DROP COLUMN [initiator_sid]
			print ''Column {initiator_sid} has been removed from [dbo].[Backup.Model.RestoreJobSessions] table''
		'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.RestoreJobSessions]') AND [name] = 'initiator_name')
	BEGIN
		exec sp_executesql N'
			DECLARE @constr sysname;

			SET @constr = (select object_name(cdefault) from syscolumns where [id] = object_id(N''[dbo].[Backup.Model.RestoreJobSessions]'') and [name] = ''initiator_name'')
			IF (@constr IS NOT NULL)
			BEGIN			
				DECLARE @statement NVARCHAR(255);						
				SET @statement = N''ALTER TABLE [dbo].[Backup.Model.RestoreJobSessions] DROP CONSTRAINT ['' + @constr + '']''		
				exec sp_executesql @statement
				PRINT ''Constraint '' + @constr + '' was successfully removed from [dbo].[Backup.Model.RestoreJobSessions]''
			END

			ALTER TABLE [dbo].[Backup.Model.RestoreJobSessions] DROP COLUMN [initiator_name]
			print ''Column {initiator_name} has been removed from [dbo].[Backup.Model.RestoreJobSessions] table''
		'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2191; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2191)
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.TenantPublicIp]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.TenantPublicIp]
			(
				[cloud_public_ip_id] uniqueidentifier NOT NULL,
				[id] uniqueidentifier NOT NULL,
				[target_port] int,
				[source_ip_address] nvarchar(15),
				[source_port] int,
				[object_id] uniqueidentifier,
				[failoverplan_id] uniqueidentifier,
				[description] nvarchar(max)
			)
		
        PRINT 'Table [dbo].[Backup.Model.TenantPublicIp] has been successfully created'
	END
	
	DECLARE @constr sysname;
	DECLARE @statement NVARCHAR(255);
		
	SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.CloudPublicIp]') and [name] = 'failoverplan_id')
	IF (@constr IS NOT NULL)
	BEGIN							
		SET @statement = N'ALTER TABLE [dbo].[Backup.Model.CloudPublicIp] DROP CONSTRAINT [' + @constr + ']'		
		exec sp_executesql @statement
		PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.CloudPublicIp]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]') AND ([name] = 'failoverplan_id'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudPublicIp]
		DROP COLUMN [failoverplan_id]
		PRINT 'Columns [failoverplan_id] was successfully removed from [dbo].[Backup.Model.CloudPublicIp]'
	END
	
	SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.CloudPublicIp]') and [name] = 'details')
	IF (@constr IS NOT NULL)
	BEGIN				
		SET @statement = N'ALTER TABLE [dbo].[Backup.Model.CloudPublicIp] DROP CONSTRAINT [' + @constr + ']'		
		exec sp_executesql @statement
		PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.CloudPublicIp]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]') AND ([name] = 'details'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudPublicIp]
		DROP COLUMN [details]
		PRINT 'Columns [details] was successfully removed from [dbo].[Backup.Model.CloudPublicIp]'
	END
			
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]') AND ([name] = 'object_id'))
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudPublicIp]
		DROP COLUMN [object_id]
		PRINT 'Columns [object_id] was successfully removed from [dbo].[Backup.Model.CloudPublicIp]'
	END
				
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2192; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2192)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.SanSnapshotTransferResources]') AND [name] = 'is_allowed_for_target_backup')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.SanSnapshotTransferResources] ADD [is_allowed_for_target_backup] bit not null DEFAULT 0;
			print 'New column {is_allowed_for_target_backup} has been successfully added to [dbo].[Backup.Model.SanSnapshotTransferResources] table'		
		END
		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2193; 
	END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2193)
BEGIN
	IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[PK_Backup.Model.ViHardwareQuotaNetworks]'))
	BEGIN
		DELETE FROM [Backup.Model.ViHardwareQuotaNetworks]
		ALTER TABLE [Backup.Model.ViHardwareQuotaNetworks] DROP CONSTRAINT [PK_Backup.Model.ViHardwareQuotaNetworks]
		ALTER TABLE [Backup.Model.ViHardwareQuotaNetworks] ADD CONSTRAINT [PK_Backup.Model.ViHardwareQuotaNetworks] PRIMARY KEY CLUSTERED (groupId) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		print 'Column hostId has been successfully removed from [dbo].[Backup.Model.ViHardwareQuotaNetworks] table primary key'		
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') AND [name] = 'hostId')
	BEGIN
		ALTER TABLE [Backup.Model.ViHardwareQuotaNetworks] DROP COLUMN [hostId]
		PRINT 'Column hostId has been successfully removed from [dbo].[Backup.Model.ViHardwareQuotaNetworks]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') AND [name] = 'hostNetworks')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] ADD [hostNetworks] xml not null;
		print 'New column {hostNetworks} has been successfully added to [dbo].[Backup.Model.ViHardwareQuotaNetworks] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2194; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2194)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tenants]') AND [name] = 'throttling_speed_limit')
	BEGIN		
		alter table [dbo].[Tenants] add throttling_speed_limit decimal
		print 'New column {throttling_speed_limit} has been successfully added to [dbo].[Tenants] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tenants]') AND [name] = 'throttling_speed_unit')
	BEGIN		
		alter table [dbo].[Tenants] add throttling_speed_unit int
		print 'New column {throttling_speed_unit} has been successfully added to [dbo].[Tenants] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tenants]') AND [name] = 'max_concurent_tasks')
	BEGIN		
		alter table [dbo].[Tenants] add max_concurent_tasks int
		print 'New column {max_concurent_tasks} has been successfully added to [dbo].[Tenants] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2195; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2195)
BEGIN
	-- Backup.Model.CloudFailoverPlan
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudFailoverPlan]') AND name = 'id')
	BEGIN
		PRINT 'ekoleda: DEBUG 0'
		ALTER TABLE [dbo].[Backup.Model.CloudFailoverPlan] ADD id uniqueidentifier NOT NULL DEFAULT newid()
		PRINT 'New column {id} has been successfully added to [dbo].[Backup.Model.CloudFailoverPlan] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudFailoverPlan]') AND name = 'usn')
	BEGIN
		PRINT 'ekoleda: DEBUG 1'
		ALTER TABLE [dbo].[Backup.Model.CloudFailoverPlan] ADD usn bigint NOT NULL DEFAULT 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.CloudFailoverPlan] table'
	END

	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudFailoverPlan]'))
	BEGIN
		PRINT 'ekoleda: DEBUG 2'
		EXEC [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudFailoverPlan'
	END
	
	-- Backup.Model.ViCloudTenantBackups
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudTenantBackups]') AND name = 'id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViCloudTenantBackups] ADD id uniqueidentifier NOT NULL DEFAULT newid()
		PRINT 'New column {id} has been successfully added to [dbo].[Backup.Model.ViCloudTenantBackups] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudTenantBackups]') AND name = 'usn')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViCloudTenantBackups] ADD usn bigint NOT NULL DEFAULT 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.ViCloudTenantBackups] table'
	END
	
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudTenantBackups]'))
	BEGIN
		EXEC [dbo].[AddTrackChangeTriggers] N'Backup.Model.ViCloudTenantBackups'
	END

	-- Backup.Model.HvCloudTenantBackups
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudTenantBackups]') AND name = 'id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvCloudTenantBackups] ADD id uniqueidentifier NOT NULL DEFAULT newid()
		PRINT 'New column {id} has been successfully added to [dbo].[Backup.Model.HvCloudTenantBackups] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudTenantBackups]') AND name = 'usn')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvCloudTenantBackups] ADD usn bigint NOT NULL DEFAULT 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.HvCloudTenantBackups] table'
	END

	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudTenantBackups]'))
	BEGIN
		EXEC [dbo].[AddTrackChangeTriggers] N'Backup.Model.HvCloudTenantBackups'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2196; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2196)
BEGIN

    IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.lock_opened_media_set_with_min_free_space]') AND type in (N'P', N'PC'))
        DROP PROCEDURE [dbo].[Tape.lock_opened_media_set_with_min_free_space]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2197; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2197)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.SanTargetSnapshotLuns]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.SanTargetSnapshotLuns](
			[id] [uniqueidentifier] NOT NULL,
			[transfer_resource_id] [uniqueidentifier] NOT NULL,	
			[target_volume_lun_id] [uniqueidentifier] NOT NULL,
			[snapshot_lun_path] [nvarchar](max) NOT NULL
		CONSTRAINT [PK_Backup.SanTargetSnapshotLuns] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
			
		PRINT 'Create table [dbo].[Backup.Model.SanTargetSnapshotLuns]'
	END

    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2198; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2198)
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudApplianceTenantSide]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudApplianceTenantSide]
			(
				[id] [uniqueidentifier] NOT NULL,
				[datastore_ref] nvarchar(max) NOT NULL,
				[folder_ref] nvarchar(max) NOT NULL, 
				[resourcepool_ref] nvarchar(max) NOT NULL, 
				[esx_id] [uniqueidentifier] NOT NULL,
				[live_info] [xml],
				[network_spec] [xml]
			)
		
        PRINT 'Table [dbo].[Backup.Model.CloudApplianceTenantSide] has been successfully created'
	END
				
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2199; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2199)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2200; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2200)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2221; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2221)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[LinkedJobs]') AND [name] = 'order_no')
	BEGIN		
		alter table [dbo].[LinkedJobs] add order_no int
		print 'New column {order_no} has been successfully added to [dbo].[LinkedJobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2222; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2222 AND current_version < 2225)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2225; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2225)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostNetwork]') AND [name] = 'vswitch_name')
	BEGIN		
		alter table [dbo].[HostNetwork] add vswitch_name nvarchar(2000) NOT NULL DEFAULT ''
		print 'New column {vswitch_name} has been successfully added to [dbo].[HostNetwork] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2226; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2226 AND current_version < 2232)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2232; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2232)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.Hp3ParAdapters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.Hp3ParAdapters](
				[id] [uniqueidentifier] NOT NULL,
				[server_id] [uniqueidentifier] NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[iscsi_iqn] [nvarchar](255) NOT NULL
			CONSTRAINT [PK_Backup.Hp3ParAdapters] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			PRINT 'Create table [dbo].[Backup.Model.Hp3ParAdapters]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2233; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2233)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanClusters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.HPSanClusters](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL,
				[usn] [bigint] NOT NULL default 0,
			CONSTRAINT [PK_Backup.HPSanClusters] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

            PRINT 'Create table [dbo].[Backup.Model.HPSanClusters]'
	END

    IF EXISTS (SELECT * FROM [dbo].[Backup.Model.SanVolumes] WHERE host_id IS NULL)
	BEGIN
		DECLARE @parent_id uniqueidentifier, @host_id uniqueidentifier

		DECLARE sanvolumes_cursor CURSOR FOR
		SELECT DISTINCT [parent_id] FROM [dbo].[Backup.Model.SanVolumes]	

		OPEN sanvolumes_cursor
		FETCH NEXT FROM sanvolumes_cursor INTO @parent_id

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @host_id = (SELECT [host_id] FROM [dbo].[Backup.Model.HPSanClusters] WHERE [id] = @parent_id)

			UPDATE [dbo].[Backup.Model.SanVolumes]
			SET [host_id] = @host_id WHERE [parent_id] = @parent_id


			FETCH NEXT FROM sanvolumes_cursor INTO @parent_id
		END

		CLOSE sanvolumes_cursor
		DEALLOCATE sanvolumes_cursor
		print 'Updating {host_id} on existing volumes in dbo.Backup.Model.SanVolumes table has been successfully completed'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2234; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2234)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanClusters]') AND [name] = 'space_total')
	BEGIN
		alter table [dbo].[Backup.Model.HPSanClusters] add space_total bigint DEFAULT -1  NOT NULL
		print 'New column {space_total} has been successfully added to [dbo].[Backup.Model.HPSanClusters] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanClusters]') AND [name] = 'space_free')
	BEGIN
		alter table [dbo].[Backup.Model.HPSanClusters] add space_free bigint DEFAULT -1  NOT NULL
		print 'New column {space_free} has been successfully added to [dbo].[Backup.Model.HPSanClusters] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2235; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2235)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanStorageSystems]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.HPSanStorageSystems](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[cluster_id] [uniqueidentifier] NOT NULL,
				[eth0_ip] [nvarchar](255) NOT NULL,
				[eth1_ip] [nvarchar](255) NOT NULL,
				CONSTRAINT [PK_Backup.HPSanStorageSystems] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2236; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2236)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanStorageSystemNics]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.HPSanStorageSystemNics](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[storage_system_id] [uniqueidentifier] NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[netmask] [nvarchar](255) NOT NULL,
				CONSTRAINT [PK_Backup.HPSanStorageSystemsNics] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2237; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2237)
BEGIN
	IF (EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanStorageSystems]') AND [name] = 'eth0_ip') AND
		EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanStorageSystems]') AND [name] = 'eth1_ip'))
	BEGIN
		exec sp_executesql @statement = N'
		DECLARE @storage_id uniqueidentifier, @host_id uniqueidentifier, @eth0_ip [nvarchar](255), @eth1_ip [nvarchar](255)

		DECLARE hpstorages_cursor CURSOR FOR
		SELECT DISTINCT [id] FROM [dbo].[Backup.Model.HPSanStorageSystems]

		OPEN hpstorages_cursor
		FETCH NEXT FROM hpstorages_cursor INTO @storage_id

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @eth0_ip = (SELECT [eth0_ip]  FROM [dbo].[Backup.Model.HPSanStorageSystems] WHERE [id] = @storage_id)
			SET @eth1_ip = (SELECT [eth1_ip]  FROM [dbo].[Backup.Model.HPSanStorageSystems] WHERE [id] = @storage_id)

			INSERT INTO
				[dbo].[Backup.Model.HPSanStorageSystemNics]
				([id], [name], [storage_system_id], [ip], [netmask])
			VALUES
				(NEWID(), ''eth0'', @storage_id, @eth0_ip, ''0.0.0.0'');

			INSERT INTO
				[dbo].[Backup.Model.HPSanStorageSystemNics]
				([id], [name], [storage_system_id], [ip], [netmask])
			VALUES
				(NEWID(), ''eth1'', @storage_id, @eth1_ip, ''0.0.0.0'');

			FETCH NEXT FROM hpstorages_cursor INTO @storage_id
		END

		CLOSE hpstorages_cursor
		DEALLOCATE hpstorages_cursor
		print ''Updating storage systems nics on storage systems sucessfully completed''
		'
	END
	ELSE
	BEGIN
		PRINT 'No need for updating storage system nics for HP P4k storage systems, because eth0_ip or eth1_ip columns is not exists.'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2238; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2238)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanStorageSystems]') AND [name] = 'eth0_ip')
	BEGIN
		exec sp_executesql @statement = N'
		ALTER TABLE
			[dbo].[Backup.Model.HPSanStorageSystems]
		DROP COLUMN
			[eth0_ip];
		print ''Collumn eth0_ip from [dbo].[Backup.Model.HPSanStorageSystems] successfully deleted''
		'
	END
	ELSE
	BEGIN
		PRINT 'No need for deleting eth0_ip column on HPSanStorageSystems table, because eth0_ip is not exists.'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HPSanStorageSystems]') AND [name] = 'eth1_ip')
	BEGIN
		exec sp_executesql @statement = N'
		ALTER TABLE
			[dbo].[Backup.Model.HPSanStorageSystems]
		DROP COLUMN
			[eth1_ip];
		print ''Collumn eth1_ip from [dbo].[Backup.Model.HPSanStorageSystems] successfully deleted''
		'
	END
	ELSE
	BEGIN
		PRINT 'No need for deleting eth1_ip column on HPSanStorageSystems table, because eth1_ip is not exists.'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2239; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2239)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVFilers]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.NetAppVFilers](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[uuid] [nvarchar](255) NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL,
				[iscsi_iqn] [nvarchar](255) NOT NULL
			CONSTRAINT [PK_Backup.NetAppVFilers] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
			) ON [PRIMARY]

			PRINT 'Create table [dbo].[Backup.Model.NetAppVFilers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2240; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2240)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVFilerAdapters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.NetAppVFilerAdapters](
				[id] [uniqueidentifier] NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[vfiler_id] [uniqueidentifier] NOT NULL,
			CONSTRAINT [PK_Backup.NetAppVFilerAdapters] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			print 'Create table Backup.Model.NetAppVFilerAdapters'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2241; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2241)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVServers]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.NetAppVServers](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[uuid] [nvarchar](255) NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL,
				[iscsi_iqn] [nvarchar](255) NOT NULL
			CONSTRAINT [PK_Backup.NetAppVServers] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			PRINT 'Create table [dbo].[Backup.Model.NetAppVServers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2242; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2242)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVFilers]') AND [name] = 'fc_wwnn')
	BEGIN
		alter table [dbo].[Backup.Model.NetAppVFilers] add fc_wwnn [nvarchar](255) DEFAULT ''  NOT NULL
		print 'New column {fc_wwnn} has been successfully added to [dbo].[Backup.Model.NetAppVFilers] table'
	END

   IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVServers]') AND [name] = 'fc_wwnn')
	BEGIN
		alter table [dbo].[Backup.Model.NetAppVServers] add fc_wwnn [nvarchar](255) DEFAULT ''  NOT NULL
		print 'New column {fc_wwnn} has been successfully added to [dbo].[Backup.Model.NetAppVServers] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2243; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2243)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVFilers]') AND [name] = 'usn')
	BEGIN
		alter table [dbo].[Backup.Model.NetAppVFilers] add usn bigint DEFAULT 0  NOT NULL
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.NetAppVFilers] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVServers]') AND [name] = 'usn')
	BEGIN
		alter table [dbo].[Backup.Model.NetAppVServers] add usn bigint DEFAULT 0  NOT NULL
		print 'New column {usn} has been successfully added to [dbo].[Backup.Model.NetAppVServers] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2244; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2244)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.NetAppVFilers]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.NetAppVFilers''
	end
	'

	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.NetAppVServers]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.NetAppVServers''
	end
	'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2245; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2245)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVServerAdapters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.NetAppVServerAdapters](
				[id] [uniqueidentifier] NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[vserver_id] [uniqueidentifier] NOT NULL,
			CONSTRAINT [PK_Backup.NetAppVServerAdapters] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			print 'Create table Backup.Model.NetAppVServerAdapters'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2246; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2246)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVFilerAdapters]') AND [name] = 'adapter_type')
	BEGIN
		alter table [dbo].[Backup.Model.NetAppVFilerAdapters] add adapter_type int DEFAULT 0  NOT NULL
		print 'New column {adapter_type} has been successfully added to [dbo].[Backup.Model.NetAppVFilerAdapters] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2247; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2247)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVServerAdapters]') AND [name] = 'adapter_type')
	BEGIN
		alter table [dbo].[Backup.Model.NetAppVServerAdapters] add adapter_type int DEFAULT 0  NOT NULL
		print 'New column {adapter_type} has been successfully added to [dbo].[Backup.Model.NetAppVServerAdapters] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2248; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2248)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVeeamSnapshots]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.NetAppVeeamSnapshots](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[volume_name] [nvarchar](255) NOT NULL,
				[volume_id] [uniqueidentifier] NOT NULL,
				[creation_time] [datetime] NOT NULL,

			CONSTRAINT [PK_Backup.NetAppVeeamSnapshots] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			print 'Create table Backup.Model.NetAppVeeamSnapshots'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2249; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2249)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVFilerAdapters]') AND [name] = 'speed_mode')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.NetAppVFilerAdapters] ADD speed_mode int not null default 0
		PRINT 'New column {speed_mode} has been successfully added to [dbo].[Backup.Model.NetAppVFilerAdapters] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2250; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2250)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppVServerAdapters]') AND [name] = 'speed_mode')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.NetAppVServerAdapters] ADD speed_mode int not null default 0
		PRINT 'New column {speed_mode} has been successfully added to [dbo].[Backup.Model.NetAppVServerAdapters] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2251; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2251)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.VnxDataMovers]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.VnxDataMovers](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[internal_id] [nvarchar](255) NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL,	
			CONSTRAINT [PK_Backup.VnxDataMovers] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
			
			PRINT 'Create table [dbo].[Backup.Model.VnxDataMovers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2252; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2252)
BEGIN
	if not exists (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Backup.Model.VnxDataMovers]') and [name] = 'usn')
	begin
		alter table [dbo].[Backup.Model.VnxDataMovers] add usn bigint not null default 0
		print 'New column {usn} has been successfully added to dbo.Backup.Model.VnxDataMovers table'
	end

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2253; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2253)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.VnxDataMovers]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.VnxDataMovers''
	end
	'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2254; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2254)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.VnxAdapters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.VnxAdapters](
				[id] [uniqueidentifier] NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[type] [int] NOT NULL,
				[speed_mode] [int] NOT NULL,
				[data_mover_id] [uniqueidentifier] NOT NULL
			CONSTRAINT [PK_Backup.VnxAdapters] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
			
			print 'Create table Backup.Model.VnxAdapters'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2255; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2255)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.VNXeNasServers]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.VNXeNasServers](
				[id] [uniqueidentifier] NOT NULL,
				[name] [nvarchar](255) NOT NULL,
				[internal_id] [nvarchar](255) NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL,
			CONSTRAINT [PK_Backup.VNXeNasServers] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			PRINT 'Create table [dbo].[Backup.Model.VNXeNasServers]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2256; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2256)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.VNXeNasServerAdapters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.VNXeNasServerAdapters](
				[id] [uniqueidentifier] NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[type] [int] NOT NULL,
				[speed_mode] [int] NOT NULL,
				[nas_server_id] [uniqueidentifier] NOT NULL
			CONSTRAINT [PK_Backup.VNXeNasServerAdapters] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]

			print 'Create table Backup.Model.VNXeNasServerAdapters'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2257; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2257)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.VNXeBlockAdapters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.VNXeBlockAdapters](
				[id] [uniqueidentifier] NOT NULL,
				[iqn_or_wwn] [nvarchar](255) NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[type] [int] NOT NULL,
				[speed_mode] [int] NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL
			CONSTRAINT [PK_Backup.VNXeBlockAdapters] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
			
			print 'Create table Backup.Model.VNXeBlockAdapters'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2258; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2258 AND current_version < 2260)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2260; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2260)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[PhysHost_Share]') AND [name] = 'hops_distance')
	BEGIN
		ALTER TABLE [dbo].[PhysHost_Share] ADD [hops_distance] int NOT NULL DEFAULT 0
		print 'New column {hops_distance} has been successfully added to [dbo].[PhysHost_Share] table'                     
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2261; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2261 AND current_version < 2262)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2262; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2262)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudNetworkUsage]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViCloudNetworkUsage](
			[id] [uniqueidentifier] NOT NULL DEFAULT newid(),
			[object_id] [uniqueidentifier] NOT NULL,
			[network_id] [uniqueidentifier] NOT NULL,
			[failover_plan_id] [uniqueidentifier] NULL
			CONSTRAINT [PK_Backup_Model_ViCloudNetworkUsage] PRIMARY KEY NONCLUSTERED 
			(
				[object_id] ASC,
				[network_id] ASC
			) WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.ViCloudNetworkUsage] ADD CONSTRAINT [FK_Backup.Model.ViCloudNetworkUsage_BObjects] 
			FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id])

		ALTER TABLE [dbo].[Backup.Model.ViCloudNetworkUsage] ADD CONSTRAINT [FK_Backup.Model.ViCloudNetworkUsage_ViHardwareQuotaNetworks] 
			FOREIGN KEY ([network_id]) REFERENCES [dbo].[Backup.Model.ViHardwareQuotaNetworks] ([groupId])
			
		print '[dbo].[Backup.Model.ViCloudNetworkUsage] has been successfully created'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudNetworkUsage]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvCloudNetworkUsage](
			[id] [uniqueidentifier] NOT NULL DEFAULT newid(),
			[object_id] [uniqueidentifier] NOT NULL,
			[network_id] [uniqueidentifier] NOT NULL,
			[failover_plan_id] [uniqueidentifier] NULL
			CONSTRAINT [PK_Backup_Model_HvCloudNetworkUsage] PRIMARY KEY NONCLUSTERED 
			(
				[object_id] ASC,
				[network_id] ASC
			) WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.HvCloudNetworkUsage] ADD CONSTRAINT [FK_Backup.Model.HvCloudNetworkUsage_BObjects] 
			FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id])

		ALTER TABLE [dbo].[Backup.Model.HvCloudNetworkUsage] ADD CONSTRAINT [FK_Backup.Model.HvCloudNetworkUsage_HvHardwareQuotaNetworks] 
			FOREIGN KEY ([network_id]) REFERENCES [dbo].[Backup.Model.HvHardwareQuotaNetworks] ([id])
			
		print '[dbo].[Backup.Model.HvCloudNetworkUsage] has been successfully created'
	END

	DECLARE @constr sysname;
	DECLARE @statement NVARCHAR(255);
		
	SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') and [name] = 'usageCount')
	IF (@constr IS NOT NULL)
	BEGIN							
		SET @statement = N'ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] DROP CONSTRAINT [' + @constr + ']'		
		exec sp_executesql @statement
		PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.ViHardwareQuotaNetworks]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaNetworks]') AND [name] = 'usageCount')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaNetworks] DROP COLUMN [usageCount]
	END

	SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') and [name] = 'usageCount')
	IF (@constr IS NOT NULL)
	BEGIN							
		SET @statement = N'ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks] DROP CONSTRAINT [' + @constr + ']'		
		exec sp_executesql @statement
		PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.HvHardwareQuotaNetworks]'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') AND [name] = 'usageCount')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaNetworks] DROP COLUMN [usageCount]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2263; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2263 AND current_version < 2265)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2265; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2265)
BEGIN

	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.Plugins]') AND type in (N'U'))
	BEGIN
		DROP TABLE [dbo].[Backup.Model.Plugins]
		print 'Old table {Backup.Model.Plugins} has been deleted.'
	END		

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2266; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2266 AND current_version < 2267)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudApplianceTenantSide]') AND [name] = 'provider_id')
	BEGIN
		DELETE FROM [dbo].[Backup.Model.CloudApplianceTenantSide]
		ALTER TABLE [dbo].[Backup.Model.CloudApplianceTenantSide] ADD [provider_id] UNIQUEIDENTIFIER NOT NULL
		print 'New column {provider_id} has been successfully added to [dbo].[Backup.Model.CloudApplianceTenantSide] table'                     
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2267; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2267)
BEGIN
	UPDATE  [dbo].[Tape.media_pools]
		SET     [options].modify('insert <ParallelProcessingOptions><Enabled>false</Enabled><DriveCount>2</DriveCount></ParallelProcessingOptions> into (/MediaPoolOptions)[1]')
		WHERE   [options].exist('/MediaPoolOptions/TapeParallelProcessingOptions') = 0
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2268; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2268)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.VeeamZIPRetention]') AND [name] = 'backup_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.VeeamZIPRetention] ADD [backup_id] UNIQUEIDENTIFIER NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {backup_id} has been successfully added to [dbo].[Backup.Model.VeeamZIPRetention] table'                     
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2269; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2269 AND current_version < 2270)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2270; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2270)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobVssCredentials]') AND [name] = 'oracle_sysdba_creds_id')
	BEGIN
		ALTER TABLE [dbo].[JobVssCredentials] ADD [oracle_sysdba_creds_id] uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {oracle_sysdba_creds_id} has been successfully added to [dbo].[JobVssCredentials] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2271; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2271 AND current_version < 2273)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2273; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2273 AND current_version < 2274)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudNetworkUsage]') AND [name] = 'cloud_session_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.ViCloudNetworkUsage] ADD [cloud_session_id] UNIQUEIDENTIFIER NULL
		print 'New column {cloud_session_id} has been successfully added to [dbo].[Backup.Model.ViCloudNetworkUsage] table'                     
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudNetworkUsage]') AND [name] = 'cloud_session_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvCloudNetworkUsage] ADD [cloud_session_id] UNIQUEIDENTIFIER NULL
		print 'New column {cloud_session_id} has been successfully added to [dbo].[Backup.Model.HvCloudNetworkUsage] table'                     
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2274; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2274 AND current_version < 2276)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2276; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2276)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BackupRepositories]') AND [name] = 'status')
	BEGIN
		ALTER TABLE [dbo].[BackupRepositories] ADD [status] int NOT NULL DEFAULT(0)
		print 'New column {status} has been successfully added to [dbo].[BackupRepositories] table'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2277; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2277 AND current_version < 2278)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2278; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2278)
BEGIN

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessions]') AND [name] = 'tenant_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudSessions] ADD [tenant_id] UNIQUEIDENTIFIER NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		print 'New column {tenant_id} has been successfully added to [dbo].[Backup.Model.CloudSessions] table'                     
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2279; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2279 AND current_version < 2280)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2280; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2280)
BEGIN
	IF OBJECT_ID(N'[dbo].[Backup.TrackedActions.TemporaryFiles]', N'U') IS NULL
	BEGIN

		CREATE TABLE [dbo].[Backup.TrackedActions.TemporaryFiles]
		(
			[id] uniqueidentifier NOT NULL
				CONSTRAINT [PK_Backup.TrackedActions.TemporaryFiles] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
			[session_id] uniqueidentifier NOT NULL,
			[repository_id] uniqueidentifier NOT NULL,
			[host_id] uniqueidentifier NOT NULL,
			[file_path] nvarchar(MAX) NOT NULL
		)  ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.TrackedActions.TemporaryFiles] has been successfully created'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2281; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2281 AND current_version < 2282)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2282; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2282)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.ExtRepo.Storages]') AND [name] = 'id')
	BEGIN		
		alter table [dbo].[Backup.ExtRepo.Storages] add [id] uniqueidentifier not null default ('00000000-0000-0000-0000-000000000000')
		print 'New column {id} has been successfully added to [dbo].[Backup.ExtRepo.Storages] table'
	END


	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.ExtRepo.ExtRepos]') AND [name] = 'usn')
	BEGIN		
		alter table [dbo].[Backup.ExtRepo.ExtRepos] add [usn] bigint not null default 0
		exec [dbo].[AddTrackChangeTriggers] N'Backup.ExtRepo.ExtRepos'
		print 'New column {usn} has been successfully added to [dbo].[Backup.ExtRepo.ExtRepos] table'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.ExtRepo.Storages]') AND [name] = 'usn')
	BEGIN		
		alter table [dbo].[Backup.ExtRepo.Storages] add [usn] bigint not null default 0
		exec [dbo].[AddTrackChangeTriggers] N'Backup.ExtRepo.Storages'
		print 'New column {usn} has been successfully added to [dbo].[Backup.ExtRepo.Storages] table'
	END


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2283; END
END
GO
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2283 AND current_version < 2285)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2285; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2285)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlanDatastores]') AND [name] = 'pbmProfileId')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.ViHardwarePlanDatastores] ADD [pbmProfileId] [nvarchar](max) NULL
			print 'New column {pbmProfileId} has been successfully added to [dbo].[Backup.Model.ViHardwarePlanDatastores] table'                     
		END
		IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2286; END
	END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2286 AND current_version < 2289)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2289; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2289 AND current_version < 2291)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'ora_enabled')
	BEGIN		
		alter table [dbo].[BJobs] add ora_enabled bit DEFAULT 0 not null
		print 'New column {ora_enabled} has been successfully added to [dbo].[BJobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2291; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2291 AND current_version < 2292)
BEGIN
	
	UPDATE [dbo].[Backup.Model.Session.Filters]
	SET [data] = '<?xml version="1.0"?><ReportCriteria><Criterions><string>([job_type] = 0 OR [job_type] = 40 OR [job_type] = 52 OR [job_type] = 54)</string></Criterions><Order><Ascending>false</Ascending><PropertyName>creation_time</PropertyName></Order></ReportCriteria>'
	WHERE [id] = '83B702D1-2C19-4EC1-BB5E-CB701CD77273'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2292; END
END	
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2292)
BEGIN
IF OBJECT_ID(N'[dbo].[Backup.TrackedActions.MaintModeRepos]', N'U') IS NULL
	BEGIN

		CREATE TABLE [dbo].[Backup.TrackedActions.MaintModeRepos]
		(
			[id] uniqueidentifier NOT NULL
				CONSTRAINT [PK_Backup.TrackedActions.MaintModeRepos] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
			[session_id] uniqueidentifier NOT NULL,
			[repository_id] uniqueidentifier NOT NULL
		)  ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.TrackedActions.MaintModeRepos] has been successfully created'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2293; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2293 AND current_version < 2294)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[TenantsWans]') AND [name] = 'installation_id')
	BEGIN		
		alter table [dbo].[TenantsWans] add installation_id uniqueidentifier DEFAULT '00000000-0000-0000-0000-000000000000' not null
		print 'New column {installation_id} has been successfully added to [dbo].[TenantsWans] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2294; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2294 AND current_version < 2296)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2296; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2296)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.VNXBlockAdapters]') AND type in (N'U'))
	BEGIN
			CREATE TABLE [dbo].[Backup.Model.VNXBlockAdapters](
				[id] [uniqueidentifier] NOT NULL,
				[iqn_or_wwn] [nvarchar](255) NOT NULL,
				[ip] [nvarchar](255) NOT NULL,
				[type] [int] NOT NULL,
				[speed_mode] [int] NOT NULL,
				[host_id] [uniqueidentifier] NOT NULL
			CONSTRAINT [PK_Backup.VNXBlockAdapters] PRIMARY KEY CLUSTERED
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
			
			print 'Create table Backup.Model.VNXBlockAdapters'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2297; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2297 AND current_version < 2298)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2298; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2298)
BEGIN

		DECLARE @localHostId uniqueidentifier
		SET @localHostId = '6745a759-2205-4cd2-b172-8ec8f7e60ef8'

		UPDATE 
			[dbo].[Hosts] 
		SET
			[description] = 'Backup server'
		WHERE
			[id] = @localHostId AND [description] = ''

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2299; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2299 AND current_version < 2300)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2300; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2300)
BEGIN
	DECLARE @constr sysname;
	DECLARE @statement NVARCHAR(255);
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlanNetworks]') AND [name] = 'switchId')
	BEGIN
		SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.ViHardwarePlanNetworks]') and [name] = 'switchId')
		IF (@constr IS NOT NULL)
		BEGIN				
			SET @statement = N'ALTER TABLE [dbo].[Backup.Model.ViHardwarePlanNetworks] DROP CONSTRAINT [' + @constr + ']'		
			exec sp_executesql @statement
			PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.ViHardwarePlanNetworks]'
		END
		ALTER TABLE [dbo].[Backup.Model.ViHardwarePlanNetworks] DROP COLUMN [switchId]
	END
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwarePlanNetworks]') AND [name] = 'switchId')
	BEGIN
		SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[Backup.Model.HvHardwarePlanNetworks]') and [name] = 'switchId')
		IF (@constr IS NOT NULL)
		BEGIN				
			SET @statement = N'ALTER TABLE [dbo].[Backup.Model.HvHardwarePlanNetworks] DROP CONSTRAINT [' + @constr + ']'		
			exec sp_executesql @statement
			PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[Backup.Model.HvHardwarePlanNetworks]'
		END
		ALTER TABLE [dbo].[Backup.Model.HvHardwarePlanNetworks] DROP COLUMN [switchId]
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2301; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2301 AND current_version < 2308)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2308; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2308 AND current_version < 2309)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.OibOracleArchiveLogs]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.OibOracleArchiveLogs](
			[id] uniqueidentifier NOT NULL,
			[oib_id] uniqueidentifier NOT NULL,
			[path] nvarchar(max) NOT NULL,
			[size] bigint NOT NULL,
			[scn_from] nvarchar(15) NOT NULL,
			[scn_to] nvarchar(15) NOT NULL,
			[utc_time_from] datetime NOT NULL,
			[utc_time_to] datetime NOT NULL,
			[seq_num] nvarchar(40) NOT NULL

			CONSTRAINT [PK_OibOracleArchiveLogs] PRIMARY KEY CLUSTERED 
			(
				[id] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX [IX_OibOracleArchiveLogs_OibId] ON [dbo].[Backup.Model.OibOracleArchiveLogs]
		(
			[oib_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		print 'Table [dbo].[Backup.Model.OibOracleArchiveLogs] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2309; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2309 AND current_version < 2310)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2310; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2310 AND current_version < 2312)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OibOracleArchiveLogs]') AND [name] = 'database_id')
	BEGIN		
		alter table [dbo].[Backup.Model.OibOracleArchiveLogs] add database_id nvarchar(40) NOT NULL DEFAULT ('0')

		CREATE NONCLUSTERED INDEX [IX_OibOracleArchiveLogs_DatabaseId] ON [dbo].[Backup.Model.OibOracleArchiveLogs]
		(
			[database_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

		print 'New column {database_id} has been successfully added to [dbo].[Backup.Model.OibOracleArchiveLogs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2312; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2311 AND current_version < 2313)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2313; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2313)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2314; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2314 AND current_version < 2316)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Replicas]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Replicas](
			[id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Replicas_ID]  DEFAULT (newid()),
			[backup_id] [uniqueidentifier] NOT NULL,
			[object_id] [uniqueidentifier] NOT NULL,
			[vm_name] [nvarchar](1000) NOT NULL,
			[source_location] [nvarchar](512) NOT NULL,
			[target_location] [nvarchar](512) NOT NULL,
			[target_vm_ref] [nvarchar](2000) NOT NULL,
			[state] [int] NOT NULL,
			[usn] [bigint] NOT NULL DEFAULT ((0)),
		 CONSTRAINT [PK_Replicas] PRIMARY KEY CLUSTERED 
		(
			[id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Replicas]  WITH CHECK ADD  CONSTRAINT [FK_Replicas_Backup.Model.Backups] FOREIGN KEY([backup_id])
		REFERENCES [dbo].[Backup.Model.Backups] ([id])

		ALTER TABLE [dbo].[Replicas] CHECK CONSTRAINT [FK_Replicas_Backup.Model.Backups]

		ALTER TABLE [dbo].[Replicas]  WITH CHECK ADD  CONSTRAINT [FK_Replicas_BObjects] FOREIGN KEY([object_id])
		REFERENCES [dbo].[BObjects] ([id])

		ALTER TABLE [dbo].[Replicas] CHECK CONSTRAINT [FK_Replicas_BObjects]

		PRINT '[dbo].[Replicas] has been successfully created'

		PRINT 'Migrating data from [dbo].[ReportIndexedOibsView] to [dbo].[Replicas]'
		INSERT INTO [dbo].[Replicas] (backup_id, object_id, vm_name, source_location, target_location, target_vm_ref, state, usn) 
			(
			SELECT	[backup_id]
					,[object_id]
					,[vmname]
					,ISNULL([aux_data].value('(/COibAuxData/SnapReplicaAuxData/ReplSummary/Summary/OrigLocation/node())[1]', 'nvarchar(max)'), ISNULL([aux_data].value('(/COibAuxData/HvAuxData/Host/@path)[1]', 'nvarchar(max)'), ''))
					,ISNULL([aux_data].value('(/COibAuxData/SnapReplicaAuxData/ReplSummary/Summary/ReplLocation/node())[1]', 'nvarchar(max)'), ISNULL([aux_data].value('(/COibAuxData/HvAuxData/replica/@hostPath)[1]', 'nvarchar(max)'), ''))
					,ISNULL([aux_data].value('(/COibAuxData/SnapReplicaAuxData/ReplVmRef/node())[1]', 'nvarchar(max)'), ISNULL([aux_data].value('(/COibAuxData/HvAuxData/replica/@VmID)[1]', 'nvarchar(max)'), ''))
					,CASE WHEN fi.id is not null and fi.[failback_object_id] <> CAST(0x0 AS UNIQUEIDENTIFIER) THEN 3 -- Failback
						  WHEN fi.id is not null THEN 2 -- Failover
						  WHEN [state] = 0 THEN 1 -- Ready
					  	  ELSE 0 END
					,riov.[usn] 
			FROM (SELECT points.backup_id
						,oibs.id as [oib_id]
						,oibs.[object_id]
						,oibs.[state]
						,oibs.[vmname]
						,oibs.[aux_data]
						,oibs.[usn]
						,ROW_NUMBER() OVER (PARTITION BY points.backup_id, oibs.object_id ORDER BY [state] DESC, points.num DESC, oibs.[creation_time] DESC) [row_no]
				  FROM   [dbo].[Backup.Model.OIBs] oibs 
						 INNER JOIN [dbo].[Backup.Model.Points] points ON oibs.point_id = points.id
				 ) riov
			INNER JOIN [dbo].[Backup.Model.Backups] back on riov.backup_id = back.id
			LEFT JOIN [dbo].[Backup.Model.OIBsFailoverInfo] fi on riov.oib_id = fi.oib_id
			WHERE back.target_type in (2, 5, 100) -- (SnapReplica, LegacyReplica, CloudSnapReplica)WHERE riov.[row_no] = 1
				  AND riov.row_no = 1
			)
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2316; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2316)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = N'is_recheck_corrupted')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [is_recheck_corrupted] bit NOT NULL DEFAULT 0
		PRINT 'New column {is_recheck_corrupted} has been successfully added to dbo.[Backup.Model.OIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2317; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2317)
BEGIN
	DECLARE @oldStoreOnceCifsRepoType int, @cifsRepoType int	
	SET @oldStoreOnceCifsRepoType = 5
	SET @cifsRepoType = 2
	
	UPDATE
		[dbo].[BackupRepositories]
	SET
		[type] = @cifsRepoType
	WHERE
		[type] = @oldStoreOnceCifsRepoType
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2318; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2318)
BEGIN
	-- Server
	-- =========================================================================================

	-- Create table ViHardwareQuotaDatastoreUsages
	IF OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages](
			hardwareDatastoreQuotaId uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotaDatastoreUsages_ViHardwareQuotaDatastores] FOREIGN KEY REFERENCES [dbo].[Backup.Model.ViHardwareQuotaDatastores] (id) ON DELETE CASCADE,
			replicaId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.ViHardwareQuotaDatastoreUsages_Replicas] FOREIGN KEY REFERENCES [dbo].[Replicas] (id) ON DELETE CASCADE,
			usageBytes bigint NOT NULL default 0

			CONSTRAINT [PK_Backup.Model.ViHardwareQuotaDatastoreUsages] PRIMARY KEY CLUSTERED
			(
				[hardwareDatastoreQuotaId] ASC,
				[replicaId] ASC
			) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
			
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] has been successfully created'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2319; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2319 AND current_version < 2320)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2320; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2320)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BackupRepositories]') AND [name] = 'use_nfs_on_mount_host')
	BEGIN		
		alter table [dbo].[BackupRepositories] add use_nfs_on_mount_host bit not null default 0
		print 'New column {use_nfs_on_mount_host} has been successfully added to [dbo].[BackupRepositories] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2321; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2321)
BEGIN
		UPDATE 
			[dbo].[BackupRepositories] 
		SET
			[use_nfs_on_mount_host] = 1
		WHERE 
			ISNULL([mount_host_id], '00000000-0000-0000-0000-000000000000') <> '00000000-0000-0000-0000-000000000000'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2322; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2322)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaNetworks]') AND [name] = 'switchName')
	BEGIN		
		alter table [dbo].[Backup.Model.HvHardwareQuotaNetworks] add switchName nvarchar(MAX)
		print 'New column {switchName} has been successfully added to [dbo].[Backup.Model.HvHardwareQuotaNetworks] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2323; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2323 AND current_version < 2327)
  BEGIN
  IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2327; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2327 AND current_version < 2328)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Replicas]') and [name] = N'target_vm_name')
	BEGIN
		ALTER TABLE [dbo].[Replicas] ADD [target_vm_name] NVARCHAR(1000) NOT NULL DEFAULT ''
		PRINT 'New column {target_vm_name} has been successfully added to [dbo].[Replicas]'
	END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2327 AND current_version < 2328)
BEGIN
	UPDATE dbo.[Replicas]
	SET target_vm_name = ISNULL([aux_data].value('(/COibAuxData/SnapReplicaAuxData/ReplVmName/node())[1]', 'nvarchar(max)'), ISNULL([aux_data].value('(/COibAuxData/HvAuxData/@vmName)[1]', 'nvarchar(max)'), ''))
	FROM dbo.[Replicas] repl
	INNER JOIN (SELECT	points.backup_id
						,oibs.[object_id]
						,oibs.[aux_data]
						,ROW_NUMBER() OVER (PARTITION BY points.backup_id, oibs.object_id ORDER BY [state] DESC, points.num DESC, oibs.[creation_time] DESC) [row_no]
				FROM	[dbo].[Backup.Model.OIBs] oibs 
				INNER JOIN [dbo].[Backup.Model.Points] points ON oibs.point_id = points.id
			) riov ON riov.backup_id = repl.backup_id
					AND riov.[object_id] = repl.[object_id]
					AND riov.row_no = 1
	PRINT 'Migrated data to [dbo].[Replicas].target_vm_name'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2328; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2328)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Stats.CloudGateways]') AND [name] = 'data_sent_by_client')
	BEGIN		
		ALTER TABLE [dbo].[Stats.CloudGateways] ADD data_sent_by_client bigint NOT NULL DEFAULT (0)
		print 'New column {data_sent_by_client} has been successfully added to [dbo].[Stats.CloudGateways] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2329; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2329 AND current_version < 2334)
  BEGIN
  IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2334; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2334)
BEGIN
    IF OBJECT_ID(N'[dbo].[ReplicaConfigurations]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[ReplicaConfigurations](
			[replicaId] uniqueidentifier  NOT NULL
				CONSTRAINT [FK_ReplicaConfigurations_Replicas] FOREIGN KEY REFERENCES [dbo].[Replicas] (id) ON DELETE CASCADE,
			[cpuCount] int NOT NULL,
			[memoryMb] int NOT NULL,
			[specific] xml)

		PRINT '[dbo].[ReplicaConfigurations] has been successfully created'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2335; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2335 AND current_version < 2337)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2337; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2337)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudFailoverPlan]') AND name = 'test_mode_job_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudFailoverPlan] ADD test_mode_job_id uniqueidentifier NOT NULL DEFAULT newid()
		PRINT 'New column {test_mode_job_id} has been successfully added to [dbo].[Backup.Model.CloudFailoverPlan] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2338; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2338)
BEGIN
	IF EXISTS ( SELECT * FROM  sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Backup.TrackedActions.Shared.Leases_LeaseId]' ) 
		AND parent_object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActions.Shared.Leases]') ) 
	BEGIN
		ALTER TABLE [dbo].[Backup.TrackedActions.Shared.Leases] DROP CONSTRAINT [FK_Backup.TrackedActions.Shared.Leases_LeaseId]
		PRINT 'Foreign key {FK_Backup.TrackedActions.Shared.Leases_LeaseId} has been successfully removed'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2339; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2339)
BEGIN
	-- Server
	-- =========================================================================================

	-- Create table HvHardwareQuotaVolumeUsages
	IF OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaVolumeUsages]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages](
			hardwareVolumeQuotaId uniqueidentifier ROWGUIDCOL NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotaVolumeUsages_HvHardwareQuotaVolume] FOREIGN KEY REFERENCES [dbo].[Backup.Model.HvHardwareQuotaVolumes] (id) ON DELETE CASCADE,
			replicaId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.HvHardwareQuotaVolumeUsages_Replicas] FOREIGN KEY REFERENCES [dbo].[Replicas] (id) ON DELETE CASCADE,
			usageBytes bigint NOT NULL default 0

			CONSTRAINT [PK_Backup.Model.HvHardwareQuotaVolumeUsages] PRIMARY KEY CLUSTERED
			(
				[hardwareVolumeQuotaId] ASC,
				[replicaId] ASC
			) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
			
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] has been successfully created'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2340; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2340 AND current_version < 2345)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2345; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2345)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') and [name] = N'availability')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [availability] smallint NOT NULL CONSTRAINT [DF_Backup.Model.Storages_availability] DEFAULT 0
		PRINT 'New column {availability} has been successfully added to [dbo].[Backup.Model.Storages]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2346; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2346)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudApplianceTenantSide]') and [name] = N'platform')
	BEGIN
		EXEC sp_rename N'[dbo].[Backup.Model.CloudApplianceTenantSide].esx_id', N'host_id', 'COLUMN';

		ALTER TABLE [dbo].[Backup.Model.CloudApplianceTenantSide] ADD [platform] INT NOT NULL DEFAULT 0
		PRINT 'New column {platform} has been successfully added to [dbo].[Backup.Model.CloudApplianceTenantSide]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2347; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2347)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2348; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2348)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostNetwork]') AND [name] = 'vswitch_type')
	BEGIN
		ALTER TABLE [dbo].[HostNetwork] ADD [vswitch_type] int NULL
		print 'New column {vswitch_type} has been successfully added to [dbo].[HostNetwork] table'		
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostNetwork]') AND [name] = 'vswitch_id')
	BEGIN
		ALTER TABLE [dbo].[HostNetwork] ADD [vswitch_id] nvarchar(2000) NULL
		print 'New column {vswitch_id} has been successfully added to [dbo].[HostNetwork] table'		
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2349; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2349)
BEGIN
	IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID('[dbo].[Replicas]') AND referenced_object_id = OBJECT_ID('[dbo].[BObjects]'))
	BEGIN
		ALTER TABLE [dbo].[Replicas] DROP CONSTRAINT FK_Replicas_BObjects
		print 'Foreign key on [dbo].[BObjects].{id} in [dbo].[Replicas] table has been dropped'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2350; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2350)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]') and [name] = N'rec_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OracleOIBs] ADD [rec_id] nvarchar(40) NOT NULL DEFAULT '0'
		PRINT 'New column [rec_id] has been successfully added to [dbo].[Backup.Model.OracleOIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2351; END
END
GO

-- After v9.0 Preview 1

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2350 and current_version < 2501)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2501; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2501)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActionsToLeases]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.TrackedActionsToLeases]
		(
			[action_id] [uniqueidentifier] NOT NULL
				CONSTRAINT [FK_Backup.TrackedActionsToLeases_ActionId] FOREIGN KEY REFERENCES [dbo].[Backup.TrackedActions] (id),
			
			[lease_id] [uniqueidentifier] NOT NULL
				CONSTRAINT [FK_Backup.TrackedActionsToLeases_LeaseId] FOREIGN KEY REFERENCES [dbo].[Backup.TrackedActions.Leases] (id)
		)

        PRINT 'Table [dbo].[Backup.TrackedActionsToLeases] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2502; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2502)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2503; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2503 AND current_version < 2506)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2506; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2506)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobState]') and [name] = N'latest_recheck')
BEGIN
		ALTER TABLE [dbo].[JobState] ADD [latest_recheck] datetime DEFAULT null
		PRINT 'New column [latest_recheck] has been successfully added to [dbo].[JobState]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2507; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2507 AND current_version < 2511)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2511; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2511)
BEGIN
    IF OBJECT_ID(N'[dbo].[Backup.Model.ResourceScan]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ResourceScan](
			[id] uniqueidentifier NOT NULL
				CONSTRAINT [PK_Backup_Model_ResourceScan] PRIMARY KEY CLUSTERED (id) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
			[type] int NOT NULL,
			[availability] int NOT NULL,
			[options] nvarchar(MAX) NULL,
			[last_update_time] datetime NOT NULL,
			[rescan_period_sec] int NOT NULL,
			[is_rescan_forced] bit NOT NULL
		)

		PRINT '[dbo].[Backup.Model.ResourceScan] has been successfully created'
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2512; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2512 AND current_version < 2514)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2514; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2514)
BEGIN
	
	-- Backup.Model.ViHardwareQuotaNetworks
	IF EXISTS (SELECT * FROM sys.columns WHERE Name = N'groupId' AND object_id = OBJECT_ID(N'dbo.[Backup.Model.ViHardwareQuotaNetworks]'))
    BEGIN
		EXEC sp_rename 'dbo.[Backup.Model.ViHardwareQuotaNetworks].[groupId]', 'id', 'COLUMN'
		PRINT 'Column {groupId} has been successfully renamed to {id} in [dbo].[Backup.Model.ViHardwareQuotaNetworks] table'
	END

	-- Backup.Model.TenantPublicIp
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.TenantPublicIp]') AND name = 'usn')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.TenantPublicIp] ADD usn bigint NOT NULL DEFAULT 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.TenantPublicIp] table'
	END

	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.TenantPublicIp]'))
	BEGIN		
		EXEC [dbo].[AddTrackChangeTriggers] N'Backup.Model.TenantPublicIp'
	END

	-- Backup.Model.CloudPublicIp
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]') AND name = 'usn')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.CloudPublicIp] ADD usn bigint NOT NULL DEFAULT 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.CloudPublicIp] table'
	END

	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudPublicIp]'))
	BEGIN		
		EXEC [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudPublicIp'
	END

	-- 
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2515; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2515 AND current_version < 2519)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') and [name] = N'last_recheck_time')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [last_recheck_time] datetime DEFAULT null
		PRINT 'New column [last_recheck_time] has been successfully added to [dbo].[Backup.Model.Storages]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.AwayStorages]') and [name] = N'object_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.AwayStorages] ADD [object_id] uniqueidentifier NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column [object_id] has been successfully added to [dbo].[Backup.Model.AwayStorages]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.AwayStorages]') and [name] = N'last_recheck_time')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.AwayStorages] ADD [last_recheck_time] datetime DEFAULT null
		PRINT 'New column [last_recheck_time] has been successfully added to [dbo].[Backup.Model.AwayStorages]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2519; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2519 AND current_version < 2520)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudApplianceTenantSide]') and [name] = N'actual_ip_network')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudApplianceTenantSide] ADD [actual_ip_network] XML NULL
		PRINT 'New column {actual_ip_network} has been successfully added to [dbo].[Backup.Model.CloudApplianceTenantSide]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2520; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2520)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OracleOIBs]') and [name] = N'stamp')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OracleOIBs] ADD [stamp] nvarchar(40) NOT NULL DEFAULT '0'
		PRINT 'New column [stamp] has been successfully added to [dbo].[Backup.Model.OracleOIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2521; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2521)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlans]') AND [name] = 'rootResourcePool')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.ViHardwarePlans] DROP COLUMN [rootResourcePool]
		print 'Column {rootResourcePool} has been successfully removed from [dbo].[Backup.Model.ViHardwarePlans] table'
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwarePlans]') AND [name] = 'rootFolder')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.ViHardwarePlans] DROP COLUMN [rootFolder]
		print 'Column {rootFolder} has been successfully removed from [dbo].[Backup.Model.ViHardwarePlans] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2522; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2522 AND current_version < 2526)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2526; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2526)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tenants]') AND [name] = 'is_throttling_enabled')
	BEGIN		
		alter table [dbo].[Tenants] add is_throttling_enabled bit
		print 'New column {is_throttling_enabled} has been successfully added to [dbo].[Tenants] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2527; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2527)
	BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2528; END
	END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2528)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.file_versions]') AND [name] = 'incomplete')
	BEGIN		
		ALTER TABLE [dbo].[Tape.file_versions] ADD incomplete bit NOT NULL DEFAULT 0
		PRINT 'New column {incomplete} has been successfully added to [dbo].[Tape.file_versions] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2529; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2529)
BEGIN
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND name = N'media_family_id_media_sequence_number')
	BEGIN
		DROP INDEX [media_family_id_media_sequence_number] ON [dbo].[Tape.tape_mediums]
		PRINT 'Index {media_family_id_media_sequence_number} has been successfully droped from [dbo].[Tape.tape_mediums] table'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.tape_mediums]') AND [name] = 'media_sequence_number_unique')
	BEGIN		
		ALTER TABLE [dbo].[Tape.tape_mediums] ADD media_sequence_number_unique int NULL DEFAULT 0
		PRINT 'New column {media_sequence_number_unique} has been successfully added to [dbo].[Tape.tape_mediums] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2530; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2530)
BEGIN
	UPDATE [Tape.tape_mediums]
	SET media_sequence_number_unique = m.media_sequence_number
	FROM 
		[Tape.tape_mediums] t INNER JOIN 
		(SELECT media_family_id media_family_id, MAX(media_sequence_number) media_sequence_number
		FROM [Tape.tape_mediums] 
		GROUP BY media_family_id 
		HAVING media_family_id IS NOT NULL) m ON t.media_family_id = m.media_family_id AND t.media_sequence_number = m.media_sequence_number
	WHERE 
		(SELECT COUNT(*) 
		FROM [Tape.tape_mediums] 
		WHERE 
			[Tape.tape_mediums].media_family_id = m.media_family_id AND 
			[Tape.tape_mediums].media_sequence_number = m.media_sequence_number) = 1

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2531; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2531)
BEGIN
	IF NOT EXISTS (select * from syscolumns where id = OBJECT_ID(N'[dbo].[Backup.Model.OIBsFailoverInfo]') and [name] = 'replica_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBsFailoverInfo] ADD [replica_id] uniqueidentifier NOT NULL DEFAULT CAST(0x0 AS uniqueidentifier)
		PRINT 'New column {replica_id} has been successfully added to dbo.Backup.Model.OIBsFailoverInfo'		
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2532; END	
END		
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2532)
BEGIN
	UPDATE [dbo].[Backup.Model.OIBsFailoverInfo]
	SET replica_id = r.id
	FROM   [dbo].[Backup.Model.OIBsFailoverInfo] fi
	INNER JOIN [dbo].[Backup.Model.OIBs] oib ON oib.id=fi.oib_id
	INNER JOIN [dbo].[Backup.Model.Points] p ON p.id=oib.point_id
	INNER JOIN [dbo].[Backup.Model.Backups] b ON b.id=p.backup_id
	INNER JOIN [dbo].[Replicas] r ON r.backup_id=b.id AND r.object_id=oib.object_id

	PRINT 'Populated [dbo].[Backup.Model.OIBsFailoverInfo].{replica_id}'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2533; END	
END		
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2533)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2534; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2534)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.BackupJobSessions]') AND [name] = 'is_recheck_retry')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.BackupJobSessions] ADD [is_recheck_retry] bit NOT NULL DEFAULT 0
		print 'New column {is_recheck_retry} has been successfully added to [dbo].[Backup.Model.BackupJobSessions] table'               
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2535; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2535 AND current_version < 2538)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2538; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2538)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2539; END
END
GO
	
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2539)
BEGIN
	-- Backup.Model.CloudAppliances
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudAppliances]') AND name = 'id')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.CloudAppliances] ADD id uniqueidentifier NOT NULL DEFAULT newid()
		PRINT 'New column {id} has been successfully added to [dbo].[Backup.Model.CloudAppliances] table'
	END

	-- Backup.Model.CloudAppliances
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudAppliances]') AND name = 'usn')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.CloudAppliances] ADD usn bigint NOT NULL DEFAULT 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.CloudAppliances] table'
	END

	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudAppliances]'))
	BEGIN		
		EXEC [dbo].[AddTrackChangeTriggers] N'Backup.Model.CloudAppliances'
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2540; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2540 AND current_version < 2541)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2541; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2541)
BEGIN
	IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Backup.TrackedActionsToLeases_LeaseId]') AND 
													parent_object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActionsToLeases]'))
	BEGIN
		ALTER TABLE [dbo].[Backup.TrackedActionsToLeases] DROP CONSTRAINT [FK_Backup.TrackedActionsToLeases_LeaseId]
		PRINT 'Foreign key {FK_Backup.TrackedActionsToLeases_LeaseId} has been successfully removed'
	END


	IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Backup.TrackedActionsToLeases_ActionId]') AND 
													parent_object_id = OBJECT_ID(N'[dbo].[Backup.TrackedActionsToLeases]'))
	BEGIN
		ALTER TABLE [dbo].[Backup.TrackedActionsToLeases] DROP CONSTRAINT [FK_Backup.TrackedActionsToLeases_ActionId]
		PRINT 'Foreign key {FK_Backup.TrackedActionsToLeases_ActionId} has been successfully removed'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2542; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2542 AND current_version < 2544)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2544; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2544 AND current_version < 2545)
BEGIN
	
	PRINT 'Creating clustered index on table Backup.Model.BackupTaskSessions, column id'
	EXEC [dbo].[CreateClusteredIndex] N'Backup.Model.BackupTaskSessions', N'id'
	
	PRINT 'Creating clustered index on table Backup.Model.BackupJobSessions, column id'
	EXEC [dbo].[CreateClusteredIndex] N'Backup.Model.BackupJobSessions', N'id'
	
	PRINT 'Creating clustered index on table Backup.Model.JobSessions, column id'
	EXEC [dbo].[CreateClusteredIndex] N'Backup.Model.JobSessions', N'id'

	PRINT 'Creating clustered index on table Backup.Model.BackupTaskSessionsProgress, column session_id'
	EXEC [dbo].[CreateClusteredIndex] N'Backup.Model.BackupTaskSessionsProgress', N'session_id'

	PRINT 'Creating clustered index on table Backup.Model.Points, column id'
	EXEC [dbo].[CreateClusteredIndex] N'Backup.Model.Points', N'id'

	PRINT 'Creating clustered index on table Backup.Model.OIBs, column id'
	EXEC [dbo].[CreateClusteredIndex] N'Backup.Model.OIBs', N'id'
	
	PRINT 'Creating nonclustered index on table Backup.Model.OIBs, column is_corrupted, included columns: id,object_id,point_id,creation_time,usn,parent_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.OIBs', N'is_corrupted', N'id,object_id,point_id,creation_time,usn,parent_id'
	
	PRINT 'Creating nonclustered index on table ObjectsInJobs, column job_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'ObjectsInJobs', N'job_id'
	
	PRINT 'Creating nonclustered index on table Tape.file_parts, column format_logical_address'
	EXEC [dbo].[CreateNonClusteredIndex] N'Tape.file_parts', N'format_logical_address'
	
	PRINT 'Creating nonclustered index on table Backup.Model.JobSessions, columns: result, job_type, end_time, usn'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.JobSessions', N'result,job_type,end_time,usn'
	
	PRINT 'Creating nonclustered index on table Backup.Model.BackupTaskSessions, columns result, included columns: id, session_id, object_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.BackupTaskSessions', N'status', N'id,session_id,object_id'
	
	PRINT 'Creating nonclustered index on table Backup.Model.OIBs, columns [is_corrupted], included columns: id, storage_id, vmname, usn, display_name'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.OIBs', N'is_corrupted', N'id,storage_id,vmname,usn,display_name'
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2545; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2545 AND current_version < 2546)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2546; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2546)
BEGIN
	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.RestoreJobSessions]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.RestoreJobSessions'',1,1,0
	end
	'

	exec sp_executesql @stat = N'
	IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N''[dbo].[Backup.Model.RestoreTaskSessions]''))
	begin
		exec [dbo].[AddTrackChangeTriggers] N''Backup.Model.RestoreTaskSessions'',1,1,0
	end
	'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2547; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2547)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[JobState]') AND [name] = 'latest_recheck')
	BEGIN	
		DECLARE @constr nvarchar(max)	
		SET @constr = (select object_name(cdefault)  from syscolumns where [id] = object_id(N'[dbo].[JobState]') and [name] = 'latest_recheck')
		IF (@constr IS NOT NULL)
		BEGIN		
			DECLARE @statement NVARCHAR(max);					
			SET @statement = N'ALTER TABLE [dbo].[JobState] DROP CONSTRAINT [' + @constr + ']'		
			exec sp_executesql @statement
			PRINT 'Constraint ' + @constr + ' was successfully removed from [dbo].[JobState]'
		END

		ALTER TABLE [dbo].[JobState] DROP COLUMN [latest_recheck]
		print 'Column {latest_recheck} has been successfully removed from [dbo].[JobState] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2548; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2548)
BEGIN

	DECLARE @row_id UNIQUEIDENTIFIER
	SET @row_id = 'CA3F6C74-6FF1-4C3E-B618-0912BC68E6DD'
	IF NOT EXISTS(SELECT * FROM [dbo].[Options] where id = @row_id)
	BEGIN
		INSERT INTO [dbo].[Options] (id, name, value) VALUES (@row_id, 'InstallationId', CAST(NEWID() AS nvarchar(50)))
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2549; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2549 AND current_version < 2552)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2552; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2552)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectHosts]') and [name] = N'processorUsageLimitMhz')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudConnectHosts] ADD [processorUsageLimitMhz] int not null DEFAULT (0);
		PRINT 'New column [processorUsageLimitMhz] has been successfully added to [dbo].[Backup.Model.CloudConnectHosts]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectHosts]') and [name] = N'memoryUsageLimitMb')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudConnectHosts] ADD [memoryUsageLimitMb] int not null DEFAULT (0);
		PRINT 'New column [memoryUsageLimitMb] has been successfully added to [dbo].[Backup.Model.CloudConnectHosts]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2553; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2553 AND current_version < 2555)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2555; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2555)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') and [name] = N'schedule_enabled_time')
	BEGIN
		ALTER TABLE [dbo].[BJobs] ADD [schedule_enabled_time] datetime null DEFAULT (null);
		PRINT 'New column [schedule_enabled_time] has been successfully added to [dbo].[BJobs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2556; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2556 AND current_version < 2557)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2557; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2557)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudQuotaObjects]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.ViCloudQuotaObjects]
		(
			[object_id] uniqueidentifier NOT NULL,
			quota_id uniqueidentifier NOT NULL,
			[unique_id] uniqueidentifier not null default NEWID(),
			[usn] bigint not null default 0
		 CONSTRAINT [PK_Backup.Model.ViCloudQuotaObjects] PRIMARY KEY CLUSTERED 
		(
			[object_id],
			quota_id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.ViCloudQuotaObjects] ADD CONSTRAINT [FK_Backup.Model.ViCloudQuotaObjects_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON DELETE CASCADE
		ALTER TABLE [dbo].[Backup.Model.ViCloudQuotaObjects] ADD CONSTRAINT [FK_Backup.Model.ViCloudQuotaObjects_ViHardwareQuotas] FOREIGN KEY ([quota_id]) REFERENCES [dbo].[Backup.Model.ViHardwareQuotas] ([id]) ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.ViCloudQuotaObjects]'
	END

	
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudQuotaObjects]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.HvCloudQuotaObjects]
		(
			[object_id] uniqueidentifier NOT NULL,
			quota_id uniqueidentifier NOT NULL,
			[unique_id] uniqueidentifier not null default NEWID(),
			[usn] bigint not null default 0
		 CONSTRAINT [PK_Backup.Model.HvCloudQuotaObjects] PRIMARY KEY CLUSTERED 
		(
			[object_id],
			quota_id
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.HvCloudQuotaObjects] ADD CONSTRAINT [FK_Backup.Model.HvCloudQuotaObjects_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON DELETE CASCADE
		ALTER TABLE [dbo].[Backup.Model.HvCloudQuotaObjects] ADD CONSTRAINT [FK_Backup.Model.HvCloudQuotaObjects_HvHardwareQuotas] FOREIGN KEY ([quota_id]) REFERENCES [dbo].[Backup.Model.HvHardwareQuotas] ([id]) ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.HvCloudQuotaObjects]'
	END

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudLicensedObjects]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudLicensedObjects]
		(
			[object_id] uniqueidentifier NOT NULL,
			[number] bigint IDENTITY(1,1) NOT NULL,
			[unique_id] uniqueidentifier not null default NEWID(),
			[usn] bigint not null default 0
		 CONSTRAINT [PK_Backup.Model.CloudLicensedObjects] PRIMARY KEY CLUSTERED 
		(
			[object_id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.CloudLicensedObjects] ADD CONSTRAINT [FK_Backup.Model.CloudLicensedObjects_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.CloudLicensedObjects]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2558; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2558)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2559; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2559)
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudApplianceTenantSideUsages]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudApplianceTenantSideUsages]
			(
				[appliance_id] [uniqueidentifier] NOT NULL,
				[replica_id] [uniqueidentifier] NOT NULL,
				[vm_ip_info] [xml] NOT NULL

				CONSTRAINT [PK_CloudApplianceTenantSideUsages] PRIMARY KEY CLUSTERED 
				(
					[appliance_id] ASC,
					[replica_id] ASC
				)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
			) ON [PRIMARY]
		
        PRINT 'Table [dbo].[Backup.Model.CloudApplianceTenantSideUsages] has been successfully created'
	END
				
    IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2560; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2560 AND current_version < 2564)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2564; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2564)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Stats.CloudGateways]') and [name] = N'installation_id')
	BEGIN
		ALTER TABLE [dbo].[Stats.CloudGateways] ADD [installation_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column [installation_id] has been successfully added to [dbo].[Stats.CloudGateways]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2565; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2565 AND current_version < 2566)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2566; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2566 AND current_version < 2569)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2569; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2569)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Stats.WanAccelerators]') and [name] = N'source_accelerator_db_id')
	BEGIN
		ALTER TABLE [dbo].[Stats.WanAccelerators] ADD [source_accelerator_db_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column [source_accelerator_db_id] has been successfully added to [dbo].[Stats.WanAccelerators]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2570; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2570)
BEGIN
	-- CloudConnectStorages	
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudConnectStorages]') and [name] = N'usedSizeInBytes')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudConnectStorages] ADD [usedSizeInBytes] bigint not null DEFAULT (0);
		PRINT 'New column [usedSizeInBytes] has been successfully added to [dbo].[Backup.Model.CloudConnectStorages]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2571; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2571)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Stats.WanAccelerators]') and [name] = N'tenant_id')
	BEGIN
		ALTER TABLE [dbo].[Stats.WanAccelerators] ADD [tenant_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column [tenant_id] has been successfully added to [dbo].[Stats.WanAccelerators]'
	END
	
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Stats.WanAccelerators]') and [name] = N'installation_id')
	BEGIN
		ALTER TABLE [dbo].[Stats.WanAccelerators] ADD [installation_id] uniqueidentifier not null DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column [installation_id] has been successfully added to [dbo].[Stats.WanAccelerators]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2572; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2572)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppSnapshotJobInfos]') AND type in (N'U'))
	BEGIN
	
		PRINT N'Creating [dbo].[Backup.Model.NetAppSnapshotJobInfos] table'


		CREATE TABLE [dbo].[Backup.Model.NetAppSnapshotJobInfos]
		(
            [id] [uniqueidentifier] NOT NULL,
			[snapshot_name] [nvarchar](255) NOT NULL,
            [snapshot_uuid] [nvarchar](255) NOT NULL,
            [volume_name] [nvarchar](255) NOT NULL,
            [volume_uuid] [nvarchar](255) NOT NULL,
			[host_id] [uniqueidentifier] NOT NULL,			
            [job_id] [uniqueidentifier] NOT NULL,
            [type] [int] NOT NULL
		
			CONSTRAINT [PK_Backup_Model_NetAppSnapshotJobInfos] PRIMARY KEY CLUSTERED 
			(
				[id] ASC			
			)
			WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
		)
		ON [PRIMARY]		      

        PRINT N'Creating nonclustered index for [dbo].[Backup.Model.NetAppSnapshotJobInfos] table'

        CREATE NONCLUSTERED INDEX [IX_NetAppSnapshotJobInfos_VolumeJobSnapshots] ON [dbo].[Backup.Model.NetAppSnapshotJobInfos]
		(
			[job_id] ASC,
            [host_id] ASC,
            [volume_uuid] ASC,
            [type] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)          
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2573; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2573)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CurrentConnections]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CurrentConnections]
		(
			[session_id] uniqueidentifier NOT NULL,
			[machine_name] nvarchar(255) NOT NULL,
			[remote_endpoint] nvarchar(255) NOT NULL,
			[account_name] nvarchar(255) NOT NULL,
			[operation] nvarchar(255) NOT NULL,
		 CONSTRAINT [PK_Backup.Model.CurrentConnections] PRIMARY KEY CLUSTERED 
		(
			[session_id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		PRINT 'Created table [dbo].[Backup.Model.CurrentConnections]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2574; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2574 AND current_version < 2575)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2575; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2575 AND current_version < 2576)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2576; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2576)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Replicas]') and [name] = N'vpn_state')
	BEGIN
		ALTER TABLE [dbo].[Replicas] ADD [vpn_state] int NOT NULL DEFAULT 0
		PRINT 'New column {vpn_state} has been successfully added to dbo.[Replicas]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2577; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2577 AND current_version < 2579)
BEGIN
	-- Create table Backup.Model.CloudProviders.Reporting
	IF OBJECT_ID(N'[dbo].[Backup.Model.CloudProviders.Reporting]', N'U') IS NULL
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudProviders.Reporting](
			providerId uniqueidentifier NOT NULL
				CONSTRAINT [FK_Backup.Model.CloudProviders.Reporting_CloudProviders] FOREIGN KEY REFERENCES [dbo].[Backup.Model.CloudProviders] (id) ON DELETE CASCADE,
			usn bigint NOT NULL default 0,
			providerUsn bigint NOT NULL default 0
		) ON [PRIMARY]

		PRINT 'Table [dbo].[Backup.Model.CloudProviders.Reporting] has been successfully created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2579; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2579)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Stats.WanAcceleratorMetrics]') AND type in (N'U'))

	BEGIN
		CREATE TABLE [dbo].[Stats.WanAcceleratorMetrics]
		(
			[id] uniqueidentifier NOT NULL DEFAULT NEWID(),
			[time] [datetime] NOT NULL,
			[accelerator_id] uniqueidentifier NOT NULL,
			[cache_size] bigint NOT NULL,
			[insert_time] [datetime] NOT NULL DEFAULT GETDATE(),
			[usn] bigint NOT NULL
		)
		PRINT 'Table [dbo].[Stats.WanAcceleratorMetrics] was created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2580; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2580 AND current_version < 2581)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2581; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2581)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.LicensedVms]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.LicensedVms]
		(
			[id] uniqueidentifier NOT NULL DEFAULT (newid()),
			[object_id] uniqueidentifier NOT NULL,
			[first_start_time] datetime NOT NULL,
			[last_start_time] datetime NOT NULL,
			[usn] BIGINT NOT NULL default 0
			
		 CONSTRAINT [PK_Backup.Model.LicensedVms] PRIMARY KEY CLUSTERED 
		(
			[id]
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		ALTER TABLE [dbo].[Backup.Model.LicensedVms] ADD CONSTRAINT [FK_Backup.Model.LicensedVms_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.LicensedVms]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2582; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2582 AND current_version < 2591)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2591; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2591)
BEGIN

	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.CloudSessionsOnViHardwareQuotas]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Backup.Model.CloudSessionsOnViHardwareQuotas](
			[session_id] [uniqueidentifier] NOT NULL,
			[quota_id] [uniqueidentifier] NOT NULL,
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[usn] [bigint] NOT NULL DEFAULT ((0)),
			 CONSTRAINT [PK_Backup.Model.CloudSessionsOnViHardwareQuotas] PRIMARY KEY CLUSTERED 
			(
				[session_id] ASC,
				[quota_id] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
			) ON [PRIMARY]


		ALTER TABLE [dbo].[Backup.Model.CloudSessionsOnViHardwareQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudSessionsOnViHardwareQuotas_Backup.Model.CloudSessions] FOREIGN KEY([session_id])
			REFERENCES [dbo].[Backup.Model.CloudSessions] ([id])
			ON DELETE CASCADE

		ALTER TABLE [dbo].[Backup.Model.CloudSessionsOnViHardwareQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudSessionsOnViHardwareQuotas_ViHardwareQuotas] FOREIGN KEY([quota_id])
			REFERENCES [dbo].[Backup.Model.ViHardwareQuotas] ([id])
			ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.CloudSessionsOnViHardwareQuotas]'

		CREATE TABLE [dbo].[Backup.Model.CloudSessionsOnHvHardwareQuotas](
			[session_id] [uniqueidentifier] NOT NULL,
			[quota_id] [uniqueidentifier] NOT NULL,
			[id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
			[usn] [bigint] NOT NULL DEFAULT ((0)),
			 CONSTRAINT [PK_Backup.Model.CloudSessionsOnHvHardwareQuotas] PRIMARY KEY CLUSTERED 
			(
				[session_id] ASC,
				[quota_id] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
			) ON [PRIMARY]


		ALTER TABLE [dbo].[Backup.Model.CloudSessionsOnHvHardwareQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudSessionsOnHvHardwareQuotas_Backup.Model.CloudSessions] FOREIGN KEY([session_id])
			REFERENCES [dbo].[Backup.Model.CloudSessions] ([id])
			ON DELETE CASCADE

		ALTER TABLE [dbo].[Backup.Model.CloudSessionsOnHvHardwareQuotas]  WITH CHECK ADD  CONSTRAINT [FK_Backup.Model.CloudSessionsOnHvHardwareQuotas_HvHardwareQuotas] FOREIGN KEY([quota_id])
			REFERENCES [dbo].[Backup.Model.HvHardwareQuotas] ([id])
			ON DELETE CASCADE

		PRINT 'Created table [dbo].[Backup.Model.CloudSessionsOnHvHardwareQuotas]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2592; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2592 AND current_version < 2595)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2595; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2595)
BEGIN
	PRINT 'Creating clustered index on table Backup.Model.BackupJobSessions, column cur_point_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.BackupJobSessions', N'cur_point_id'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2596; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2596 AND current_version < 2616)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2616; END
END
GO

--
-----------------------------------------------------
--
-- UPGRADE DB FROM 8.0 TO 9.0
--
-- Condition: 2616
--
-----------------------------------------------------
--

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2616 AND current_version < 2633)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2633; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2633)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudProviders]') and [name] = N'network_resources')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudProviders] ADD [network_resources] bit NOT NULL DEFAULT 0
		PRINT 'New column {network_resources} has been successfully added to dbo.[Backup.Model.CloudProviders]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2634; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2634 AND current_version < 2637)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2637; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2637)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'created_by')
	BEGIN		
		alter table [dbo].[BJobs] add created_by [nvarchar](512) NOT NULL DEFAULT ''
		print 'New column {created_by} has been successfully added to [dbo].[BJobs] table'
	END
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'creation_date')
	BEGIN		
		alter table [dbo].[BJobs] add creation_date datetime DEFAULT GETUTCDATE()
		print 'New column {creation_date} has been successfully added to [dbo].[BJobs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2638; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2638 AND current_version < 2640)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2640; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2640)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BJobs]') AND [name] = 'version')
	BEGIN		
		ALTER TABLE [dbo].[BJobs] ADD [version] bigint DEFAULT 0
		PRINT 'New column {version} has been successfully added to [dbo].[BJobs] table'
	END
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.jobs]') AND [name] = 'version')
	BEGIN	
		ALTER TABLE [Tape.jobs] ADD [version] bigint DEFAULT 0
		PRINT 'New column {version} has been successfully added to [dbo].[Tape.jobs] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[version] SET current_version = 2641; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2641 AND current_version < 2643)
BEGIN
    -- Add stg_id index to SqlOIBs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SqlOIBs_stg_id' AND object_id = OBJECT_ID('[Backup.Model.SqlOIBs]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_SqlOIBs_stg_id] ON [dbo].[Backup.Model.SqlOIBs]
		(
			[stg_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_SqlOIBs_stg_id} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	-- Add group_db_id index to SqlOIBs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SqlOIBs_group_db_id' AND object_id = OBJECT_ID('[Backup.Model.SqlOIBs]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_SqlOIBs_group_db_id] ON [dbo].[Backup.Model.SqlOIBs]
		(
			[group_db_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_SqlOIBs_group_db_id} has been successfully added to [dbo].[Backup.Model.SqlOIBs] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2643; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2643)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Backup_ExtRepo_Storages_StgId' AND object_id = OBJECT_ID('[Backup.ExtRepo.Storages]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Backup_ExtRepo_Storages_StgId] ON [dbo].[Backup.ExtRepo.Storages]
		(
			[storage_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_Backup_ExtRepo_Storages_StgId} has been successfully added to [dbo].[Backup.ExtRepo.Storages] table'

		ALTER TABLE dbo.[Backup.ExtRepo.Storages]
			DROP CONSTRAINT [PK_Backup.ExtRepo.Storages]

		ALTER TABLE dbo.[Backup.ExtRepo.Storages] ADD CONSTRAINT
			[PK_Backup.ExtRepo.Storages] PRIMARY KEY CLUSTERED 
			(
			id
			) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		print 'New PK {PK_Backup.ExtRepo.Storages} has been successfully added to [dbo].[Backup.ExtRepo.Storages] table'
	END

	-- Add group_db_id index to SqlOIBs
	IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Backup_ExtRepo_Storages_RepoId' AND object_id = OBJECT_ID('[Backup.ExtRepo.Storages]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Backup_ExtRepo_Storages_RepoId] ON [dbo].[Backup.ExtRepo.Storages]
		(
			[dependant_repo_id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_Backup_ExtRepo_Storages_RepoId} has been successfully added to [dbo].[Backup.ExtRepo.Storages] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2644; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2644)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[BackupRepositories]') AND [name] = 'creation_date')
BEGIN
		alter table [dbo].[BackupRepositories] add creation_date datetime DEFAULT GETDATE()
		print 'New column {creation_date} has been successfully added to [dbo].[BackupRepositories] table'

		CREATE NONCLUSTERED INDEX [IX_BackupRepositories_CreationDate] ON [dbo].[BackupRepositories]
		(
			[creation_date] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
		print 'New index {IX_BackupRepositories_CreationDate} has been successfully added to [dbo].[BackupRepositories] table'

	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2645; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2645 AND current_version < 2647)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2647; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2647)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBsFailoverInfo]') and [name] = N'permanent_time')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBsFailoverInfo] ADD [permanent_time] DATETIME
		PRINT 'New column {permanent_time} has been successfully added to dbo.[Backup.Model.OIBsFailoverInfo]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2648; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2648 AND current_version < 2655)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2655; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2655)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') and [name] = N'original_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD [original_id] UNIQUEIDENTIFIER NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {original_id} has been successfully added to dbo.[Backup.Model.Backups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2656; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2656)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Tape.backup_sets]') AND [name] = 'encrypted_imported_backup_id')
	BEGIN
		ALTER TABLE [dbo].[Tape.backup_sets] ADD [encrypted_imported_backup_id] uniqueidentifier NULL
		print 'New column {encrypted_imported_backup_id} has been successfully added to [dbo].[Tape.backup_sets] table'		

		ALTER TABLE [Tape.backup_sets] WITH NOCHECK 
		ADD CONSTRAINT [FK_Tape.backup_sets_Tape.encrypted_imported_backups] FOREIGN KEY (encrypted_imported_backup_id) REFERENCES [Tape.encrypted_imported_backups] (id) ON DELETE SET NULL ON UPDATE NO ACTION
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2657; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2657)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.JobSessions]') and [name] = N'logs_folder')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.JobSessions] ADD [logs_folder] [nvarchar](max) 
			PRINT 'New column {logs_folder} has been successfully added to [dbo].[Backup.Model.JobSessions]'
		END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2658; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2658 AND current_version < 2663)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2663; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2663)
BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotas]') and [name] = N'is_enabled')
	BEGIN
		EXEC sp_rename N'[dbo].[Backup.Model.ViHardwareQuotas].is_enabled', N'isCorrespondsToPlan', 'COLUMN';
		PRINT 'Column [is_enabled] has been successfully renamed to [is_corresponds_plan] in table [dbo].[Backup.Model.ViHardwareQuotas]'
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotas]') and [name] = N'isCorrespondsToPlan')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotas] ADD [isCorrespondsToPlan] bit NOT NULL DEFAULT 1
			PRINT 'New column [isCorrespondsToPlan] has been successfully added to [dbo].[Backup.Model.ViHardwareQuotas]'
		END		
	END

	IF EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotas]') and [name] = N'is_enabled')
	BEGIN
		EXEC sp_rename N'[dbo].[Backup.Model.HvHardwareQuotas].is_enabled', N'isCorrespondsToPlan', 'COLUMN';
		PRINT 'Column [is_enabled] has been successfully renamed to [isCorrespondsToPlan] in table [dbo].[Backup.Model.HvHardwareQuotas]'
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotas]') and [name] = N'isCorrespondsToPlan')
		BEGIN
			ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotas] ADD [isCorrespondsToPlan] bit NOT NULL DEFAULT 1
			PRINT 'New column [isCorrespondsToPlan] has been successfully added to [dbo].[Backup.Model.HvHardwareQuotas]'
		END		
	END	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2664; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2664 AND current_version < 2669)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2669; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2669)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') and [name] = N'creation_time_utc')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD [creation_time_utc] [datetime] NOT NULL DEFAULT ('01.01.1900')
		PRINT 'New column {creation_time_utc} has been successfully added to [dbo].[Backup.Model.Backups]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Points]') and [name] = N'creation_time_utc')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Points] ADD [creation_time_utc] [datetime] NOT NULL DEFAULT ('01.01.1900')
		PRINT 'New column {creation_time_utc} has been successfully added to [dbo].[Backup.Model.Points]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Storages]') and [name] = N'creation_time_utc')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Storages] ADD [creation_time_utc] [datetime] NOT NULL DEFAULT ('01.01.1900')
		PRINT 'New column {creation_time_utc} has been successfully added to [dbo].[Backup.Model.Storages]'
	END

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = N'creation_time_utc')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [creation_time_utc] [datetime] NOT NULL DEFAULT ('01.01.1900')
		PRINT 'New column {creation_time_utc} has been successfully added to [dbo].[Backup.Model.OIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2670; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2670)
BEGIN
	UPDATE [dbo].[Backup.Model.Backups] SET [creation_time_utc] = [creation_time] WHERE [creation_time] IS NOT NULL
	UPDATE [dbo].[Backup.Model.Points] SET [creation_time_utc] = [creation_time] WHERE [creation_time] IS NOT NULL
	UPDATE [dbo].[Backup.Model.Storages] SET [creation_time_utc] = [creation_time] WHERE [creation_time] IS NOT NULL
	UPDATE [dbo].[Backup.Model.OIBs] SET [creation_time_utc] = [creation_time] WHERE [creation_time] IS NOT NULL

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2671; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2671 AND current_version < 2673)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2673; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version = 2673)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[HostCreds]') AND [name] = N'ssh_protocol')
	BEGIN		
		alter table [dbo].[HostCreds] add ssh_protocol int NOT NULL DEFAULT (0)
		print 'New column {ssh_protocol} has been successfully added to [dbo].[HostCreds] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2674; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2674)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2675; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2675)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.NetAppSnapshotJobInfos]') and [name] = N'snapshot_logical_uuid')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.NetAppSnapshotJobInfos] ADD [snapshot_logical_uuid] nvarchar(255) not null DEFAULT ('00000000-0000-0000-0000-000000000000');
		PRINT 'New column [snapshot_logical_uuid] has been successfully added to [dbo].[Backup.Model.NetAppSnapshotJobInfos]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2676; 
	END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2676 AND current_version < 2682)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2682; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2682)
BEGIN
	IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Stats.CloudGatewaysPerRule]') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[Stats.CloudGatewaysPerRule]
		(
			[id] uniqueidentifier NOT NULL DEFAULT NEWID(),
			[time] [datetime] NOT NULL,
			[gate_id] uniqueidentifier NOT NULL,
			[rule_id] uniqueidentifier NOT NULL,
			[data_sent_to_client] bigint NOT NULL,
			[data_sent_by_client] bigint NOT NULL
		)
		PRINT 'Table [dbo].[Stats.CloudGatewaysPerRule] was created'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2683; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2683 AND current_version < 2685)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2685; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2685 AND current_version < 2686)
BEGIN
	PRINT 'Creating nonclustered index on table Backup.Model.JobSessions, column job_type, included columns: id, job_id'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.JobSessions', N'job_type', N'id,job_id'

	PRINT 'Creating nonclustered index on table Backup.Model.JobSessions, columns job_id, job_type, creation_time'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.JobSessions', N'job_id', N'job_type,creation_time'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2686; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2686 AND current_version < 2690)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2690; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2690)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[CryptoKeys]') AND [name] = 'version')
	BEGIN	
		ALTER TABLE [CryptoKeys] ADD [version] bigint NOT NULL DEFAULT 0
		PRINT 'New column {version} has been successfully added to [dbo].[CryptoKeys] table'
	END
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[version] SET current_version = 2691; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE current_version >= 2691 AND current_version < 2692)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.OIBs]') and [name] = N'is_licensed')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.OIBs] ADD [is_licensed] bit NOT NULL DEFAULT 0
		PRINT 'New column {is_licensed} has been successfully added to [dbo].[Backup.Model.OIBs]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2692; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2692 AND current_version < 2693)
BEGIN
	PRINT 'Creating nonclustered index on table Backup.Model.BackupJobSessions, column usn, included columns: job_source_type, id, processed_objects, stored_size, avg_speed, is_active_full, is_full, is_retry, total_size, processed_size, cur_point_id, total_objects'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.BackupJobSessions', N'usn', N'job_source_type,id,processed_objects,stored_size,avg_speed,is_active_full,is_full,is_retry,total_size,processed_size,cur_point_id,total_objects'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2693; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2693 AND current_version < 2695)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2695; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2695)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.Backups]') and [name] = N'is_just_migrated_to_sobr')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.Backups] ADD [is_just_migrated_to_sobr] bit not null DEFAULT 0
		PRINT 'New column [is_just_migrated_to_sobr] has been successfully added to [dbo].[Backup.Model.Backups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2696; 
	END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2696 AND current_version < 2698)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2698; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2698 AND current_version < 2699)
BEGIN

	ALTER TABLE [dbo].[Backup.Model.LicensedVms] DROP CONSTRAINT [FK_Backup.Model.LicensedVms_BObjects] 
	ALTER TABLE [dbo].[Backup.Model.LicensedVms] ADD CONSTRAINT [FK_Backup.Model.LicensedVms_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON UPDATE CASCADE ON DELETE CASCADE

	ALTER TABLE [dbo].[Backup.Model.ViCloudQuotaObjects] DROP CONSTRAINT [FK_Backup.Model.ViCloudQuotaObjects_BObjects] 
	ALTER TABLE [dbo].[Backup.Model.ViCloudQuotaObjects] ADD CONSTRAINT [FK_Backup.Model.ViCloudQuotaObjects_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON UPDATE CASCADE ON DELETE CASCADE

	ALTER TABLE [dbo].[Backup.Model.HvCloudQuotaObjects] DROP CONSTRAINT [FK_Backup.Model.HvCloudQuotaObjects_BObjects] 
	ALTER TABLE [dbo].[Backup.Model.HvCloudQuotaObjects] ADD CONSTRAINT [FK_Backup.Model.HvCloudQuotaObjects_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON UPDATE CASCADE ON DELETE CASCADE

	ALTER TABLE [dbo].[Backup.Model.CloudLicensedObjects] DROP CONSTRAINT [FK_Backup.Model.CloudLicensedObjects_BObjects] 
	ALTER TABLE [dbo].[Backup.Model.CloudLicensedObjects] ADD CONSTRAINT [FK_Backup.Model.CloudLicensedObjects_BObjects] FOREIGN KEY ([object_id]) REFERENCES [dbo].[BObjects] ([id]) ON UPDATE CASCADE ON DELETE CASCADE	

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2699; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2699 AND current_version < 2704)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2704; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2704)
BEGIN

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[ReplicaConfigurations]') AND [name] = 'usn')
	BEGIN		
		ALTER TABLE [dbo].[ReplicaConfigurations] ADD [usn] bigint NOT NULL default 0
		PRINT 'New column {usn} has been successfully added to [dbo].[ReplicaConfigurations] table'

		EXEC sp_RENAME '[dbo].[ReplicaConfigurations].replicaId', 'id', 'COLUMN'
		PRINT 'Old column [replicaId] has been successfully renamed to [id]'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages]') AND [name] = 'usn')
	BEGIN		
		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] ADD id uniqueidentifier NOT NULL CONSTRAINT [DF_Backup.Model.ViHardwareQuotaDatastoreUsages_id] DEFAULT (newid())
		PRINT 'New column {id} has been successfully added to [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] table'

		ALTER TABLE [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] ADD [usn] bigint NOT NULL default 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.ViHardwareQuotaDatastoreUsages] table'
	END

	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvHardwareQuotaVolumeUsages]') AND [name] = 'usn')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] ADD id uniqueidentifier NOT NULL CONSTRAINT [DF_Backup.Model.HvHardwareQuotaVolumeUsages_id] DEFAULT (newid())
		PRINT 'New column {id} has been successfully added to [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] table'

		ALTER TABLE [dbo].[Backup.Model.HvHardwareQuotaVolumeUsages] ADD [usn] bigint NOT NULL default 0
		PRINT 'New column {usn} has been successfully added to [dbo].[Backup.Model.HvHardwareQuotaVolumeUsagess] table'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2705; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2705 AND current_version < 2708)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2708; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2708 AND current_version < 2709)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2709; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2709)
BEGIN
	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.ViCloudQuotaObjects]') AND [name] = 'unique_id')
	BEGIN
		EXEC sp_RENAME '[dbo].[Backup.Model.ViCloudQuotaObjects].unique_id', 'id', 'COLUMN'
		PRINT 'Old column [unique_id] has been successfully renamed to [id] in table [dbo].[Backup.Model.ViCloudQuotaObjects]'
	END

	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.HvCloudQuotaObjects]') AND [name] = 'unique_id')
	BEGIN
		EXEC sp_RENAME '[dbo].[Backup.Model.HvCloudQuotaObjects].unique_id', 'id', 'COLUMN'
		PRINT 'Old column [unique_id] has been successfully renamed to [id] in table [dbo].[Backup.Model.HvCloudQuotaObjects]'
	END

	IF EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudLicensedObjects]') AND [name] = 'unique_id')
	BEGIN
		EXEC sp_RENAME '[dbo].[Backup.Model.CloudLicensedObjects].unique_id', 'id', 'COLUMN'
		PRINT 'Old column [unique_id] has been successfully renamed to [id] in table [dbo].[Backup.Model.CloudLicensedObjects]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2710; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2710 AND current_version < 2712)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2712; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2712)
BEGIN

	PRINT 'Creating nonclustered index on table Backup.Model.JobSessions, columns job_id, creation_time, job_type'
	EXEC [dbo].[CreateNonClusteredIndex] N'Backup.Model.JobSessions', N'job_id,creation_time,job_type'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2713; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2713)
BEGIN
	IF NOT EXISTS (SELECT 1 FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.CloudProviders]') and [name] = N'version')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.CloudProviders] ADD [version] nvarchar(max) NOT NULL DEFAULT '8.0.0.0'
		PRINT 'New column {version} has been successfully added to dbo.[Backup.Model.CloudProviders]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2714; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2714)
BEGIN
	update [dbo].[Credentials]
	set description = 'Helper appliance credentials'
	where id = '70275B03-E805-49E1-9535-1867C62371E2' and description like 'FLR helper appliance credentials'
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2715; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2715 AND current_version < 2719)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2719; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2719)
BEGIN
	
	IF NOT EXISTS (SELECT 1 FROM [dbo].[Credentials] WHERE id = 'fd0041d1-4a68-4abd-aefe-b2bf02bb7ca9')
	BEGIN
		exec sp_executesql @stat = N'
			DECLARE @usn BIGINT
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
		
			INSERT INTO [dbo].[Credentials] VALUES (''fd0041d1-4a68-4abd-aefe-b2bf02bb7ca9'', N''root'',N'''', @usn, N''Provider-side network extension appliance credentials'', 1, GETUTCDATE())
			print ''default Provider-side network extension appliance credentials added to [dbo].[Credentials] table'''
	END

	IF NOT EXISTS (SELECT 1 FROM [dbo].[Credentials] WHERE id = 'b5ebaf50-1a63-4c48-839f-5f8a5452520b')
	BEGIN
		exec sp_executesql @stat = N'
			DECLARE @usn BIGINT
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
		
			INSERT INTO [dbo].[Credentials] VALUES (''b5ebaf50-1a63-4c48-839f-5f8a5452520b'', N''root'',N'''', @usn, N''Tenant-side network extension appliance credentials'', 1, GETUTCDATE())
			print ''defaultTenant-side network extension appliance credentials added to [dbo].[Credentials] table'''
	END
		
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2720; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2720 AND current_version < 2721)
BEGIN
	
	PRINT 'Creating XML indexes on table Backup.Model.OIBs'
    
	IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'XML_guest_os_info_primary' AND object_id = OBJECT_ID('[Backup.Model.OIBs]')) AND NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('[Backup.Model.OIBs]') AND type = '3')
	
	CREATE PRIMARY XML INDEX XML_guest_os_info_primary ON dbo.[Backup.Model.OIBs] (guest_os_info)

	IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'XML_guest_os_info_path' AND object_id = OBJECT_ID('[Backup.Model.OIBs]'))
	
	CREATE XML INDEX XML_guest_os_info_path ON dbo.[Backup.Model.OIBs] (guest_os_info) USING XML INDEX XML_guest_os_info_primary FOR PATH


	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2721; END

END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2721)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2722; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2722)
BEGIN
	
	PRINT 'Updating Mount Hosts for Backup Repositories';

	UPDATE  dbo.BackupRepositories
	SET     mount_host_id = host_id
	WHERE   host_id IN (
			SELECT  id
			FROM    Hosts
			WHERE   physical_host_id IN ( SELECT    id
										  FROM      dbo.PhysicalHosts
										  WHERE     os_platform = '1' ) )
			AND host_id IN ( SELECT id
							 FROM   Hosts
							 WHERE  type IN ( 3, 5 ) )
			AND type != 4;

	UPDATE  dbo.BackupRepositories
	SET     mount_host_id = ( SELECT    id
							  FROM      Hosts
							  WHERE     type = 3
							)
	WHERE   mount_host_id IN (
			SELECT  id
			FROM    Hosts
			WHERE   physical_host_id IN ( SELECT    id
										  FROM      dbo.PhysicalHosts
										  WHERE     os_platform <> '1' ) )
			AND type <> 4;

	WHILE EXISTS ( SELECT a.physical_host_id
					 FROM   Hosts a
							JOIN dbo.BackupRepositories b ON a.id = b.mount_host_id
					 WHERE  NOT EXISTS ( SELECT 1
										 FROM   dbo.HostComponents c
										 WHERE  c.physical_host_id = a.physical_host_id
												AND c.type = 10 ) AND a.type <> 3 AND b.type <> 4 )
		BEGIN

			DECLARE @usn BIGINT;
			EXEC dbo.IncrementUsn @usn OUTPUT;

			DECLARE @phys_host_id UNIQUEIDENTIFIER;
			SET @phys_host_id = (SELECT TOP 1
								a.physical_host_id
						FROM    Hosts a
								JOIN dbo.BackupRepositories b ON a.id = b.mount_host_id
						WHERE   NOT EXISTS ( SELECT 1
											 FROM   dbo.HostComponents c
											 WHERE  c.physical_host_id = a.physical_host_id
													AND c.type = 10 )
								AND a.physical_host_id IS NOT NULL AND a.type <> 3 AND b.type <> 4)
			

			INSERT  INTO HostComponents
			VALUES ( DEFAULT,
					  @phys_host_id, 
					  '10', '9.0.0.0', '<RestoreProxyClientOptions><MgmtPort>6170</MgmtPort></RestoreProxyClientOptions>', @usn, 0);  

		END;
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2723; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2723 AND current_version < 2726)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2726; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2726 AND current_version < 2727)
BEGIN
	
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Tape.files]') AND name = N'directory_id_files')
	BEGIN
		DROP INDEX directory_id_files ON [dbo].[Tape.files] WITH ( ONLINE = OFF )
	END

	PRINT 'Creating nonclustered index on table Tape.files, column directory_id, included columns: name'
	EXEC [dbo].[CreateNonClusteredIndex] N'Tape.files', N'directory_id', N'name'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2727; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2727 AND current_version < 2732)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2732; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2732)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2733; END -- DON'T OPTIMIZE: IDatabaseVersionCommand IN USE!
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2733)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2734; END 
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2734 AND current_version < 2735)
BEGIN
	UPDATE cs
	SET tenant_id = t.id
	FROM 
		Tenants t 
		inner join TenantsResourcesQuota tq on tq.tenant_id = t.id 
		inner join [Backup.Model.CloudSessionsOnQuotas] cq on cq.quota_id = tq.id
		inner join [Backup.Model.CloudSessions] cs on cs.id = cq.session_id
	WHERE cs.tenant_id = '00000000-0000-0000-0000-000000000000'

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2735; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2735 AND current_version < 2738)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2738; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2738)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.EncryptedImportBackups]') and [name] = N'original_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.EncryptedImportBackups] ADD [original_id] UNIQUEIDENTIFIER NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {original_id} has been successfully added to dbo.[Backup.Model.EncryptedImportBackups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2739; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2738)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.EncryptedImportBackups]') and [name] = N'original_id')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.EncryptedImportBackups] ADD [original_id] UNIQUEIDENTIFIER NOT NULL DEFAULT ('00000000-0000-0000-0000-000000000000')
		PRINT 'New column {original_id} has been successfully added to dbo.[Backup.Model.EncryptedImportBackups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2739; END
END
GO


IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2739)
BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE id = OBJECT_ID(N'[dbo].[Backup.Model.EncryptedImportBackups]') AND [name] = 'meta_version')
	BEGIN
		ALTER TABLE [dbo].[Backup.Model.EncryptedImportBackups] ADD [meta_version] bigint not null default -1
		PRINT 'Column [meta_version] has been successfully added to [dbo].[Backup.Model.EncryptedImportBackups]'
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2740; END
END
GO

--ne sxlopivaite!!!
IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2740 AND current_version < 2750)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2750; END
END
GO

IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2750 AND current_version < 2754)
BEGIN
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2754; END
END
GO





-- Templates
--IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version = 2314)
--BEGIN
--	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2315; END
--END
--GO

--IF EXISTS (SELECT 1 FROM [dbo].[Version] WHERE current_version >= 2314 AND current_version < 2316)
--BEGIN
--	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET current_version = 2316; END
--END
--GO