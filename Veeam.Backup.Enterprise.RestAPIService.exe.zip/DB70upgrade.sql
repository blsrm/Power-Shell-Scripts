﻿-- WasViHostEverAdded = true

IF (NOT EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = '91BF2EB1-51AC-4C75-A472-22610288191D'))
BEGIN
	INSERT INTO [dbo].[Options]
		([id],
		[name],
		[value])
	VALUES
		('91BF2EB1-51AC-4C75-A472-22610288191D',
		'WasViHostEverAdded',
		'True')
END

GO

-- WasHvHostEverAdded = true

IF (NOT EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = '21182F90-DE92-4A6E-850A-4E2A90D2C68E'))
BEGIN
	INSERT INTO [dbo].[Options]
		([id],
		[name],
		[value])
	VALUES
		('21182F90-DE92-4A6E-850A-4E2A90D2C68E',
		'WasHvHostEverAdded',
		'True')
END

GO


-- WasAnyHostEverAdded = true

IF (NOT EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = '6B5FDC9C-6E1D-4533-B17C-5FECC304589F'))
BEGIN
	INSERT INTO [dbo].[Options]
		([id],
		[name],
		[value])
	VALUES
		('6B5FDC9C-6E1D-4533-B17C-5FECC304589F',
		'WasAnyHostEverAdded',
		'True')
END

GO

-- WereShellPanelsAutoChecked = true

IF (NOT EXISTS (SELECT * FROM [dbo].[Options] WHERE [id] = '9A720800-FA76-4911-A6FD-55D9A44F26AA'))
BEGIN
	INSERT INTO [dbo].[Options]
		([id],
		[name],
		[value])
	VALUES
		('9A720800-FA76-4911-A6FD-55D9A44F26AA',
		'WereShellPanelsAutoChecked',
		'True')
END

GO


