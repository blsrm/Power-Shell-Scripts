-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.List_TablesBindings]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn.List_TablesBindings]
GO
CREATE FUNCTION [dbo].[fn.List_TablesBindings] ()
RETURNS 
@Result TABLE 
(
	[id] [uniqueidentifier], 
	[source_table] [nvarchar](255),
	[source_id_field] [nvarchar](255),
	[target_table] [nvarchar](255),
	[target_id_field] [nvarchar](255),
	[import_updates_procedure] [nvarchar](100),
	[import_dels_procedure] [nvarchar](100),
	[vbsrv_version_major] int,
	[vbsrv_version_minor] int
)
AS
BEGIN

	INSERT INTO @Result
	
	-- C. Table bindings
	-- C.Folder_Host
	SELECT '8eba7efa-9373-4ef5-90f2-afe4e05c4260', 'Folder_Host', 'id', 'C.Folder_Host', 'id', 'usp_Import_Folder_Host_Changes', 'usp_Import_Folder_Host_Dels', 0, 0
	UNION
	-- C.ObjectsInJobs
	SELECT '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'ObjectsInJobs', 'id', 'C.ObjectsInJobs', 'id', 'usp_Import_ObjectsInJobs_Changes', 'usp_Import_ObjectsInJobs_Dels', 0, 0
	UNION
	-- C.Soap_creds
	SELECT '8e9c5194-db32-4def-bdbc-93873daf19bf', 'Soap_creds', 'id', 'C.Soap_creds', 'id', 'usp_Import_Soap_creds_Changes', 'usp_Import_Soap_creds_Dels', 0, 0
	UNION
	-- C.BJobs
	SELECT '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'BJobs', 'id', 'C.BJobs', 'id', 'usp_Import_BJobs_Changes', 'usp_Import_BJobs_Dels', 0, 0
	UNION
	-- C.BObjects
	SELECT 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'BObjects', 'id', 'C.BObjects', 'id', 'usp_Import_BObjects_Changes', 'usp_Import_BObjects_Dels', 0, 0
	UNION
	-- C.Backup.Model.Backups
	SELECT 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'Backup.Model.Backups', 'id', 'C.Backup.Model.Backups', 'id', 'usp_Import_Backup_Model_Backups_Changes', 'usp_Import_Backup_Model_Backups_Dels', 0, 0
	UNION
	-- C.Backup.Model.Storages
	SELECT '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'Backup.Model.Storages', 'id', 'C.Backup.Model.Storages', 'id', 'usp_Import_Backup_Model_Storages_Changes', 'usp_Import_Backup_Model_Storages_Dels', 0, 0
	UNION
	-- C.HostsByJobs
	SELECT 'e6472193-1851-40b4-9d46-e781e96fb07b', 'HostsByJobs', 'id', 'C.HostsByJobs', 'id', 'usp_Import_HostsByJobs_Changes', 'usp_Import_HostsByJobs_Dels', 0, 0
	UNION
	-- C.Backup.Model.Points
	SELECT '259b9ddc-8afe-4547-8447-c4313499f1d6', 'Backup.Model.Points', 'id', 'C.Backup.Model.Points', 'id', 'usp_Import_Backup_Model_Points_Changes', 'usp_Import_Backup_Model_Points_Dels', 0, 0
	UNION
	-- C.Ssh_creds
	SELECT '7294ec7f-7114-483f-b650-ce26748235b0', 'Ssh_creds', 'id', 'C.Ssh_creds', 'id', 'usp_Import_Ssh_creds_Changes', 'usp_Import_Ssh_creds_Dels', 0, 0
	UNION
	-- C.Backup.Model.OIBs
	SELECT 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'Backup.Model.OIBs', 'id', 'C.Backup.Model.OIBs', 'id', 'usp_Import_Backup_Model_OIBs_Changes', 'usp_Import_Backup_Model_OIBs_Dels', 0, 0
	UNION
	-- C.LicensedHosts
	SELECT '14be9db1-201e-4e53-8e2e-9ce2b7bb49fe', 'LicensedHosts', 'id', 'C.LicensedHosts', 'id', 'usp_Import_LicensedHosts_Changes', 'usp_Import_LicensedHosts_Dels', 0, 0
	UNION
	-- C.Hosts
	SELECT 'abd59640-02db-415d-a20a-9b34521404ba', 'Hosts', 'id', 'C.Hosts', 'id', 'usp_Import_Hosts_Changes', 'usp_Import_Hosts_Dels', 0, 0
	UNION
	-- C.Folders
	SELECT '6f741c1b-69fd-4820-aa45-1a0e0f221d3c', 'Folders', 'id', 'C.Folders', 'id', 'usp_Import_Folders_Changes', 'usp_Import_Folders_Dels', 0, 0
	UNION
	-- C.VirtualLabs
	SELECT 'ce4013f6-bad7-4f27-953d-b923639851a6', 'VirtualLabs', 'id', 'C.VirtualLabs', 'id', 'usp_Import_VirtualLabs_Changes', 'usp_Import_VirtualLabs_Dels', 0, 0
	UNION
	-- C.ObjectsInApplicationGroups
	SELECT '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'ObjectsInApplicationGroups', 'id', 'C.ObjectsInApplicationGroups', 'id', 'usp_Import_ObjectsInApplicationGroups_Changes', 'usp_Import_ObjectsInApplicationGroups_Dels', 0, 0
	UNION
	-- C.DRRoles
	SELECT 'f1d79e4a-b76d-4a45-8813-d77d8d7ea69b', 'DRRoles', 'id', 'C.DRRoles', 'id', 'usp_Import_DRRoles_Changes', 'usp_Import_DRRoles_Dels', 0, 0
	UNION
	-- C.Backup.Model.JobSessions
	SELECT '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'Backup.Model.JobSessions', 'id', 'C.Backup.Model.JobSessions', 'id', 'usp_Import_Backup_Model_JobSessions_Changes', 'usp_Import_Backup_Model_JobSessions_Dels', 0, 0
	UNION
	-- C.Backup.Model.SbTaskSessions
	SELECT '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'Backup.Model.SbTaskSessions', 'id', 'C.Backup.Model.SbTaskSessions', 'id', 'usp_Import_Backup_Model_SbTaskSessions_Changes', 'usp_Import_Backup_Model_SbTaskSessions_Dels', 0, 0
	UNION
	-- C.Backup.Model.SbSessions
	SELECT 'f8781835-d56c-4efb-bf22-fec03a871092', 'Backup.Model.SbSessions', 'id', 'C.Backup.Model.SbSessions', 'id', 'usp_Import_Backup_Model_SbSessions_Changes', 'usp_Import_Backup_Model_SbSessions_Dels', 0, 0
	UNION
	-- C.Backup.Model.BackupJobSessions
	SELECT '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'Backup.Model.BackupJobSessions', 'id', 'C.Backup.Model.BackupJobSessions', 'id', 'usp_Import_Backup_Model_BackupJobSessions_Changes', 'usp_Import_Backup_Model_BackupJobSessions_Dels', 0, 0
	UNION
	-- C.Backup.Model.BackupTaskSessions
	SELECT '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'Backup.Model.BackupTaskSessions', 'id', 'C.Backup.Model.BackupTaskSessions', 'id', 'usp_Import_Backup_Model_BackupTaskSessions_Changes', 'usp_Import_Backup_Model_BackupTaskSessions_Dels', 0, 0
	UNION
	-- C.LinkedJobs
	SELECT 'd41a6240-8120-4552-b9e2-89717b0a451c', 'LinkedJobs', 'id', 'C.LinkedJobs', 'id', 'usp_Import_LinkedJobs_Changes', 'usp_Import_LinkedJobs_Dels', 0, 0
	UNION
	-- C.SbVerificationRules
	SELECT 'edc854ff-0763-4910-a0ec-01c5ef05d0d7', 'SbVerificationRules', 'id', 'C.SbVerificationRules', 'id', 'usp_Import_SbVerificationRules_Changes', 'usp_Import_SbVerificationRules_Dels', 0, 0
	UNION
	-- C.BackupProxies
	SELECT '118c8f53-8c4b-42f1-bf47-57746e113510', 'BackupProxies', 'id', 'C.BackupProxies', 'id', 'usp_Import_BackupProxies_Changes', 'usp_Import_BackupProxies_Dels', 0, 0
	UNION
	-- C.BackupRepositories
	SELECT '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'BackupRepositories', 'unique_id', 'C.BackupRepositories', 'unique_id', 'usp_Import_BackupRepositories_Changes', 'usp_Import_BackupRepositories_Dels', 0, 0
	UNION
	-- C.Credentials
	SELECT '0bfe1660-40eb-4032-9fa0-42f5be6ac7e6', 'Credentials', 'id', 'C.Credentials', 'id', 'usp_Import_Credentials_Changes', 'usp_Import_Credentials_Dels', 0, 0
	UNION
	-- C.Backup.Model.RestoreJobSessions
	SELECT '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'Backup.Model.RestoreJobSessions', 'id', 'C.Backup.Model.RestoreJobSessions', 'id', 'usp_Import_Backup_Model_RestoreJobSessions_Changes', 'usp_Import_Backup_Model_RestoreJobSessions_Dels', 0, 0
	UNION
	-- C.JobVssCredentials
	SELECT '5830cb30-7ea5-475b-84d1-84d2014b52bf', 'JobVssCredentials', 'id', 'C.JobVssCredentials', 'id', 'usp_Import_JobVssCredentials_Changes', 'usp_Import_JobVssCredentials_Dels', 0, 0
	UNION
	-- C.PhysicalHosts
	SELECT 'd0555593-dff4-49f2-90c0-f8afc4264561', 'PhysicalHosts', 'id', 'C.PhysicalHosts', 'id', 'usp_Import_PhysicalHosts_Changes', 'usp_Import_PhysicalHosts_Dels', 0, 0
	UNION
	-- C.OibAdminAccounts
	SELECT 'fb3459cb-a8f1-4ff5-ae7c-84905c4edd04', 'OibAdminAccounts', 'id', 'C.OibAdminAccounts', 'id', 'usp_Import_OibAdminAccounts_Changes', 'usp_Import_OibAdminAccounts_Dels', 0, 0
	UNION
	-- C.Backup.Model.GuestDatabase
	SELECT 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'Backup.Model.GuestDatabase', 'id', 'C.Backup.Model.GuestDatabase', 'id', 'usp_Import_Backup_Model_GuestDatabase_Changes', 'usp_Import_Backup_Model_GuestDatabase_Dels', 0, 0
	UNION
	-- C.WanAccelerators
	SELECT '5e67c6b7-3564-4eb8-8328-37f1d4486ad5', 'WanAccelerators', 'id', 'C.WanAccelerators', 'id', 'usp_Import_WanAccelerators_Changes', 'usp_Import_WanAccelerators_Dels', 0, 0
	UNION
	-- C.HostComponents
	SELECT 'd278a0ca-6c61-41a8-9fe4-a5fbdc05c824', 'HostComponents', 'id', 'C.HostComponents', 'id', 'usp_Import_HostComponents_Changes', 'usp_Import_HostComponents_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudGates
	SELECT 'a498d420-25ee-4314-a61f-22a1296b3502', 'Backup.Model.CloudGates', 'id', 'C.Backup.Model.CloudGates', 'id', 'usp_Import_Backup_Model_CloudGates_Changes', 'usp_Import_Backup_Model_CloudGates_Dels', 0, 0
	UNION
	-- C.Tenants
	SELECT 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'Tenants', 'id', 'C.Tenants', 'id', 'usp_Import_Tenants_Changes', 'usp_Import_Tenants_Dels', 0, 0
	UNION
	-- C.TenantsResourcesQuota
	SELECT '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'TenantsResourcesQuota', 'id', 'C.TenantsResourcesQuota', 'id', 'usp_Import_TenantsResourcesQuota_Changes', 'usp_Import_TenantsResourcesQuota_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudSessions
	SELECT '9031c649-ec6e-41b0-b1e2-f2c5e08849e5', 'Backup.Model.CloudSessions', 'id', 'C.Backup.Model.CloudSessions', 'id', 'usp_Import_Backup_Model_CloudSessions_Changes', 'usp_Import_Backup_Model_CloudSessions_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudSessionsOnQuotas
	SELECT '4a4d9923-574a-4772-9423-f02c9fa57e45', 'Backup.Model.CloudSessionsOnQuotas', 'id', 'C.Backup.Model.CloudSessionsOnQuotas', 'id', 'usp_Import_Backup_Model_CloudSessionsOnQuotas_Changes', 'usp_Import_Backup_Model_CloudSessionsOnQuotas_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudVms
	SELECT 'ff4af2ac-3d05-493a-8567-79f74df15ebe', 'Backup.Model.CloudVms', 'id', 'C.Backup.Model.CloudVms', 'id', 'usp_Import_Backup_Model_CloudVms_Changes', 'usp_Import_Backup_Model_CloudVms_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudVmsOnQuotas
	SELECT 'c49097c3-9e4e-4393-b729-eefcf8f3dde4', 'Backup.Model.CloudVmsOnQuotas', 'id', 'C.Backup.Model.CloudVmsOnQuotas', 'id', 'usp_Import_Backup_Model_CloudVmsOnQuotas_Changes', 'usp_Import_Backup_Model_CloudVmsOnQuotas_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudFailoverPlan
	SELECT '9d064913-c254-40e2-83dd-8cbf77fc24f1', 'Backup.Model.CloudFailoverPlan', 'id', 'C.Backup.Model.CloudFailoverPlan', 'id', 'usp_Import_Backup_Model_CloudFailoverPlan_Changes', 'usp_Import_Backup_Model_CloudFailoverPlan_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViCloudTenantBackups
	SELECT '7a80ca99-bca5-477d-b459-6f63d4512f30', 'Backup.Model.ViCloudTenantBackups', 'id', 'C.Backup.Model.ViCloudTenantBackups', 'id', 'usp_Import_Backup_Model_ViCloudTenantBackups_Changes', 'usp_Import_Backup_Model_ViCloudTenantBackups_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvCloudTenantBackups
	SELECT '616b2cd6-8776-415c-88b8-d03963e27fba', 'Backup.Model.HvCloudTenantBackups', 'id', 'C.Backup.Model.HvCloudTenantBackups', 'id', 'usp_Import_Backup_Model_HvCloudTenantBackups_Changes', 'usp_Import_Backup_Model_HvCloudTenantBackups_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViHardwareQuotas
	SELECT 'e065129e-eaf9-45ae-b924-955029490a71', 'Backup.Model.ViHardwareQuotas', 'id', 'C.Backup.Model.ViHardwareQuotas', 'id', 'usp_Import_Backup_Model_ViHardwareQuotas_Changes', 'usp_Import_Backup_Model_ViHardwareQuotas_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvHardwareQuotas
	SELECT 'f9469e9d-f71b-4323-9926-e48d0614df0c', 'Backup.Model.HvHardwareQuotas', 'id', 'C.Backup.Model.HvHardwareQuotas', 'id', 'usp_Import_Backup_Model_HvHardwareQuotas_Changes', 'usp_Import_Backup_Model_HvHardwareQuotas_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViHardwarePlans
	SELECT '753ec64d-c819-4f5c-9927-b0c49b30d033', 'Backup.Model.ViHardwarePlans', 'id', 'C.Backup.Model.ViHardwarePlans', 'id', 'usp_Import_Backup_Model_ViHardwarePlans_Changes', 'usp_Import_Backup_Model_ViHardwarePlans_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvHardwarePlans
	SELECT 'e7682942-da89-4f43-9faa-4b9b942d20a3', 'Backup.Model.HvHardwarePlans', 'id', 'C.Backup.Model.HvHardwarePlans', 'id', 'usp_Import_Backup_Model_HvHardwarePlans_Changes', 'usp_Import_Backup_Model_HvHardwarePlans_Dels', 0, 0
	UNION
	-- C.Backup.ExtRepo.ExtRepos
	SELECT '45ee48c5-781a-4bd5-b931-f67c8619af86', 'Backup.ExtRepo.ExtRepos', 'id', 'C.Backup.ExtRepo.ExtRepos', 'id', 'usp_Import_Backup_ExtRepo_ExtRepos_Changes', 'usp_Import_Backup_ExtRepo_ExtRepos_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViHardwarePlanDatastores
	SELECT 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'Backup.Model.ViHardwarePlanDatastores', 'id', 'C.Backup.Model.ViHardwarePlanDatastores', 'id', 'usp_Import_Backup_Model_ViHardwarePlanDatastores_Changes', 'usp_Import_Backup_Model_ViHardwarePlanDatastores_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViHardwarePlanNetworks
	SELECT 'ef6178c8-d035-4ef2-bd2f-7d1011a0e89a', 'Backup.Model.ViHardwarePlanNetworks', 'id', 'C.Backup.Model.ViHardwarePlanNetworks', 'id', 'usp_Import_Backup_Model_ViHardwarePlanNetworks_Changes', 'usp_Import_Backup_Model_ViHardwarePlanNetworks_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViHardwareQuotaNetworks
	SELECT '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'Backup.Model.ViHardwareQuotaNetworks', 'id', 'C.Backup.Model.ViHardwareQuotaNetworks', 'id', 'usp_Import_Backup_Model_ViHardwareQuotaNetworks_Changes', 'usp_Import_Backup_Model_ViHardwareQuotaNetworks_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvHardwarePlanVolumes
	SELECT 'e3b5c848-c2cf-41bc-9a25-1f9c09d2a893', 'Backup.Model.HvHardwarePlanVolumes', 'id', 'C.Backup.Model.HvHardwarePlanVolumes', 'id', 'usp_Import_Backup_Model_HvHardwarePlanVolumes_Changes', 'usp_Import_Backup_Model_HvHardwarePlanVolumes_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvHardwarePlanNetworks
	SELECT '44907a6d-0a08-45db-a4d9-461a52544246', 'Backup.Model.HvHardwarePlanNetworks', 'id', 'C.Backup.Model.HvHardwarePlanNetworks', 'id', 'usp_Import_Backup_Model_HvHardwarePlanNetworks_Changes', 'usp_Import_Backup_Model_HvHardwarePlanNetworks_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvHardwareQuotaNetworks
	SELECT '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'Backup.Model.HvHardwareQuotaNetworks', 'id', 'C.Backup.Model.HvHardwareQuotaNetworks', 'id', 'usp_Import_Backup_Model_HvHardwareQuotaNetworks_Changes', 'usp_Import_Backup_Model_HvHardwareQuotaNetworks_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudPublicIp
	SELECT '76cfd01b-6522-4e5d-adbb-b6143af179b6', 'Backup.Model.CloudPublicIp', 'id', 'C.Backup.Model.CloudPublicIp', 'id', 'usp_Import_Backup_Model_CloudPublicIp_Changes', 'usp_Import_Backup_Model_CloudPublicIp_Dels', 0, 0
	UNION
	-- C.Backup.Model.TenantPublicIp
	SELECT 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'Backup.Model.TenantPublicIp', 'id', 'C.Backup.Model.TenantPublicIp', 'id', 'usp_Import_Backup_Model_TenantPublicIp_Changes', 'usp_Import_Backup_Model_TenantPublicIp_Dels', 0, 0
	UNION
	-- C.HostNetwork
	SELECT 'fbc2d077-61e2-407a-acb8-b244918d1551', 'HostNetwork', 'id', 'C.HostNetwork', 'id', 'usp_Import_HostNetwork_Changes', 'usp_Import_HostNetwork_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudAppliances
	SELECT 'c8c62bde-0316-4d48-929a-9a703f0d96c8', 'Backup.Model.CloudAppliances', 'id', 'C.Backup.Model.CloudAppliances', 'id', 'usp_Import_Backup_Model_CloudAppliances_Changes', 'usp_Import_Backup_Model_CloudAppliances_Dels', 0, 0
	UNION
	-- C.Backup.Model.LicensedVms
	SELECT '1674166f-9653-48b1-a9a2-c55c905af95a', 'Backup.Model.LicensedVms', 'id', 'C.Backup.Model.LicensedVms', 'id', 'usp_Import_Backup_Model_LicensedVms_Changes', 'usp_Import_Backup_Model_LicensedVms_Dels', 0, 0
	UNION
	-- C.Replicas
	SELECT '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'Replicas', 'id', 'C.Replicas', 'id', 'usp_Import_Replicas_Changes', 'usp_Import_Replicas_Dels', 0, 0
	UNION
	-- C.ReplicaConfigurations
	SELECT '1371fd80-79b3-4193-a51f-18ab75c558b2', 'ReplicaConfigurations', 'id', 'C.ReplicaConfigurations', 'id', 'usp_Import_ReplicaConfigurations_Changes', 'usp_Import_ReplicaConfigurations_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViHardwareQuotaDatastoreUsages
	SELECT 'da5b637a-7516-4906-8823-52ee793bd4bb', 'Backup.Model.ViHardwareQuotaDatastoreUsages', 'id', 'C.Backup.Model.ViHardwareQuotaDatastoreUsages', 'id', 'usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Changes', 'usp_Import_Backup_Model_ViHardwareQuotaDatastoreUsages_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvHardwareQuotaVolumeUsages
	SELECT '37c0d950-8467-4207-a0ef-faea4975303d', 'Backup.Model.HvHardwareQuotaVolumeUsages', 'id', 'C.Backup.Model.HvHardwareQuotaVolumeUsages', 'id', 'usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Changes', 'usp_Import_Backup_Model_HvHardwareQuotaVolumeUsages_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViHardwareQuotaDatastores
	SELECT 'e908e7a9-7a34-4793-82db-43749944be3d', 'Backup.Model.ViHardwareQuotaDatastores', 'id', 'C.Backup.Model.ViHardwareQuotaDatastores', 'id', 'usp_Import_Backup_Model_ViHardwareQuotaDatastores_Changes', 'usp_Import_Backup_Model_ViHardwareQuotaDatastores_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvHardwareQuotaVolumes
	SELECT 'b34892f4-ac31-4968-8f9b-f8009fd4fe38', 'Backup.Model.HvHardwareQuotaVolumes', 'id', 'C.Backup.Model.HvHardwareQuotaVolumes', 'id', 'usp_Import_Backup_Model_HvHardwareQuotaVolumes_Changes', 'usp_Import_Backup_Model_HvHardwareQuotaVolumes_Dels', 0, 0
	UNION
	-- C.Backup.Model.ViCloudQuotaObjects
	SELECT '9e632ecf-6527-40af-935e-a1e88351a1d5', 'Backup.Model.ViCloudQuotaObjects', 'id', 'C.Backup.Model.ViCloudQuotaObjects', 'id', 'usp_Import_Backup_Model_ViCloudQuotaObjects_Changes', 'usp_Import_Backup_Model_ViCloudQuotaObjects_Dels', 0, 0
	UNION
	-- C.Backup.Model.HvCloudQuotaObjects
	SELECT '4d690c23-32db-45c6-bd5c-118b150f4d3b', 'Backup.Model.HvCloudQuotaObjects', 'id', 'C.Backup.Model.HvCloudQuotaObjects', 'id', 'usp_Import_Backup_Model_HvCloudQuotaObjects_Changes', 'usp_Import_Backup_Model_HvCloudQuotaObjects_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudLicensedObjects
	SELECT '0de70df7-9804-4417-bb93-1c92ed6b82b2', 'Backup.Model.CloudLicensedObjects', 'id', 'C.Backup.Model.CloudLicensedObjects', 'id', 'usp_Import_Backup_Model_CloudLicensedObjects_Changes', 'usp_Import_Backup_Model_CloudLicensedObjects_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudSessionsOnViHardwareQuotas
	SELECT '58d00f78-f139-42a2-b027-5f7662b372dc', 'Backup.Model.CloudSessionsOnViHardwareQuotas', 'id', 'C.Backup.Model.CloudSessionsOnViHardwareQuotas', 'id', 'usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Changes', 'usp_Import_Backup_Model_CloudSessionsOnViHardwareQuotas_Dels', 0, 0
	UNION
	-- C.Backup.Model.CloudSessionsOnHvHardwareQuotas
	SELECT '37d44463-a699-4ca5-b2ea-9132e5b7daaf', 'Backup.Model.CloudSessionsOnHvHardwareQuotas', 'id', 'C.Backup.Model.CloudSessionsOnHvHardwareQuotas', 'id', 'usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Changes', 'usp_Import_Backup_Model_CloudSessionsOnHvHardwareQuotas_Dels', 0, 0

-- 70. Table bindings
	union
	select 'caf74948-e076-4841-b07b-22cb02e7c8ff','Folder_Host','id','70.Folder_Host','id','usp_Import_70_Folder_Host_Changes','usp_Import_70_Folder_Host_Dels',7,0 
	union
	select 'eef2831c-dea1-42f6-8695-2c552e7c438b','ObjectsInJobs','id','70.ObjectsInJobs','id','usp_Import_70_ObjectsInJobs_Changes','usp_Import_70_ObjectsInJobs_Dels',7,0 
	union
	select 'aa3d66b0-70cf-44ce-a487-fa0d01c0645e','Soap_creds','id','70.Soap_creds','id','usp_Import_70_Soap_creds_Changes','usp_Import_70_Soap_creds_Dels',7,0 
	union
	select 'a9bac128-2cd0-4209-9160-7440a032a305','BJobs','id','70.BJobs','id','usp_Import_70_BJobs_Changes','usp_Import_70_BJobs_Dels',7,0 
	union
	select '3b530c7f-d127-4204-a96c-5e795dd94b10','BObjects','id','70.BObjects','id','usp_Import_70_BObjects_Changes','usp_Import_70_BObjects_Dels',7,0 
	union
	select '75fb1228-0262-4141-b337-bec9a7ebfa2c','Ssh_creds','id','70.Ssh_creds','id','usp_Import_70_Ssh_creds_Changes','usp_Import_70_Ssh_creds_Dels',7,0 
	union
	select '8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','LicensedHosts','id','70.LicensedHosts','id','usp_Import_70_LicensedHosts_Changes','usp_Import_70_LicensedHosts_Dels',7,0 
	union
	select 'dab7e9e8-af9b-47e6-90c3-eebc6e05a025','Hosts','id','70.Hosts','id','usp_Import_70_Hosts_Changes','usp_Import_70_Hosts_Dels',7,0 
	union
	select '9c547b18-cca0-42a6-b5ce-e62003468612','Folders','id','70.Folders','id','usp_Import_70_Folders_Changes','usp_Import_70_Folders_Dels',7,0 
	union
	select '4D698E5F-CE7C-44dd-9588-880E6245C322','HostsByJobs','id','70.HostsByJobs','id','usp_Import_70_HostsByJobs_Changes','usp_Import_70_HostsByJobs_Dels',7,0 
	union
	--70.Backup.Model.Points
	select 'b9031345-6254-49bb-ad16-75b5ed1253ee','Backup.Model.Points','id','70.Backup.Model.Points','id','usp_Import_70_Backup_Model_Points_Changes','usp_Import_70_Backup_Model_Points_Dels',7,0	
	--70.Backup.Model.Backups
	union
	select '51e173b5-9861-4d84-b4aa-dbf0ac0e3422','Backup.Model.Backups','id','70.Backup.Model.Backups','id','usp_Import_70_Backup_Model_Backups_Changes','usp_Import_70_Backup_Model_Backups_Dels',7,0	
	--70.Backup.Model.Storages
	union
	select '429b9f57-c345-4b29-afc6-75a0677af118','Backup.Model.Storages','id','70.Backup.Model.Storages','id','usp_Import_70_Backup_Model_Storages_Changes','usp_Import_70_Backup_Model_Storages_Dels',7,0
	--70.Backup.Model.OIBs
	union
	select '6fe0e4cb-1363-45b8-9886-1349368972a3','Backup.Model.OIBs','id','70.Backup.Model.OIBs','id','usp_Import_70_Backup_Model_OIBs_Changes','usp_Import_70_Backup_Model_OIBs_Dels',7,0
	--70.VirtualLabs
	union
	select 'bee28906-9676-407b-b8c4-3892b09f1265','VirtualLabs','id','70.VirtualLabs','id','usp_Import_70_VirtualLabs_Changes','usp_Import_70_VirtualLabs_Dels',7,0
	--70.DRObjectsInFolders
	union
	select '67534bb6-4347-473d-a78c-37a7261e5944','ObjectsInApplicationGroups','id','70.ObjectsInApplicationGroups','id','usp_Import_70_ObjectsInApplicationGroups_Changes','usp_Import_70_ObjectsInApplicationGroups_Dels',7,0
	--70.DRRoles
	union
	select 'e41fdf30-772b-47cf-8f49-bfa3ebc16997','DRRoles','id','70.DRRoles','id','usp_Import_70_DRRoles_Changes','usp_Import_70_DRRoles_Dels',7,0
	union
	--70.Backup.Model.SbTaskSessions
	select 'cb3509b8-37cc-4129-bcc4-0945b14731f1','Backup.Model.SbTaskSessions','id','70.Backup.Model.SbTaskSessions','id','usp_Import_70_Backup_Model_SbTaskSessions_Changes','usp_Import_70_Backup_Model_SbTaskSessions_Dels',7,0	
	--70.Backup.Model.JobSessions
	union
	select 'a112794c-ec45-40a1-bc1d-04a4c5727828','Backup.Model.JobSessions','id','70.Backup.Model.JobSessions','id','usp_Import_70_Backup_Model_JobSessions_Changes','usp_Import_70_Backup_Model_JobSessions_Dels',7,0	
	--70.Backup.Model.SbSessions
	union
	select '0cb8315b-ba1c-4e76-b8b9-0e03a156f967','Backup.Model.SbSessions','id','70.Backup.Model.SbSessions','id','usp_Import_70_Backup_Model_SbSessions_Changes','usp_Import_70_Backup_Model_SbSessions_Dels',7,0
	--70.Backup.Model.BackupJobSessions
	union
	select '3121a39d-833c-446b-8017-f6f37423425b','Backup.Model.BackupJobSessions','id','70.Backup.Model.BackupJobSessions','id','usp_Import_70_Backup_Model_BackupJobSessions_Changes','usp_Import_70_Backup_Model_BackupJobSessions_Dels',7,0
	--70.Backup.Model.BackupTaskSessions
	union
	select '13989ab6-d7b7-46ef-a39a-f5f188acfecc','Backup.Model.BackupTaskSessions','id','70.Backup.Model.BackupTaskSessions','id','usp_Import_70_Backup_Model_BackupTaskSessions_Changes','usp_Import_70_Backup_Model_BackupTaskSessions_Dels',7,0
	union
	--70.LinkedJobs
	select '4a7c0dbd-f0d0-4b30-9185-2af22bec06db','LinkedJobs','id','70.LinkedJobs','id','usp_Import_70_LinkedJobs_Changes','usp_Import_70_LinkedJobs_Dels',7,0
	union
	--70.Backup.Model.RestoreJobSessions
	select '1fafb90e-bc5f-436f-a5c8-4f01055bab0e','Backup.Model.RestoreJobSessions','id','70.Backup.Model.RestoreJobSessions','id','usp_Import_70_Backup_Model_RestoreJobSessions_Changes','usp_Import_70_Backup_Model_RestoreJobSessions_Dels',7,0
	union
	--70.Backup.Model.RestoreTaskSessions
	select 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'Backup.Model.RestoreTaskSessions', 'id','70.Backup.Model.RestoreTaskSessions', 'id', 'usp_Import_70_Backup_Model_RestoreTaskSessions_Changes', 'usp_Import_70_Backup_Model_RestoreTaskSessions_Dels', 7,0
	union
	-- 70.PhysicalHosts
	select 'D927D22E-51A1-4fd1-B87E-69B1DD5D24DC', 'PhysicalHosts', 'id','70.PhysicalHosts', 'id', 'usp_Import_70_PhysicalHosts_Changes', 'usp_Import_70_PhysicalHosts_Dels', 7,0
	UNION
	-- 70.BackupProxies
	SELECT 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'BackupProxies', 'id', '70.BackupProxies', 'id', 'usp_Import_70_BackupProxies_Changes', 'usp_Import_70_BackupProxies_Dels', 7, 0
	UNION
	-- 70.BackupRepositories
	SELECT 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'BackupRepositories', 'id', '70.BackupRepositories', 'id', 'usp_Import_70_BackupRepositories_Changes', 'usp_Import_70_BackupRepositories_Dels', 7, 0
	UNION
	-- 70.Credentials
	SELECT '6dcc5fb4-a702-483a-89b4-0f0ffc74ef08', 'Credentials', 'id', '70.Credentials', 'id', 'usp_Import_70_Credentials_Changes', 'usp_Import_70_Credentials_Dels', 7, 0
	-- 70.JobVssCredentials
	UNION
	SELECT '61CEED55-5A94-487D-B85E-266AA1CF4E51', 'JobVssCredentials', 'id', '70.JobVssCredentials', 'id', 'usp_Import_70_JobVssCredentials_Changes', 'usp_Import_70_JobVssCredentials_Dels', 7, 0

	
	-- 80. Table bindings
	UNION
	-- 80.Folder_Host
	SELECT '237e5135-4917-443b-9808-a055a77398ee', 'Folder_Host', 'id', '80.Folder_Host', 'id', 'usp_Import_80_Folder_Host_Changes', 'usp_Import_80_Folder_Host_Dels', 8, 0
	UNION
	-- 80.ObjectsInJobs
	SELECT '49dabcdd-daca-4094-ac31-8c10e73b3143', 'ObjectsInJobs', 'id', '80.ObjectsInJobs', 'id', 'usp_Import_80_ObjectsInJobs_Changes', 'usp_Import_80_ObjectsInJobs_Dels', 8, 0
	UNION
	-- 80.Soap_creds
	SELECT '99644d75-8c81-4d96-964a-c52dd7f5b073', 'Soap_creds', 'id', '80.Soap_creds', 'id', 'usp_Import_80_Soap_creds_Changes', 'usp_Import_80_Soap_creds_Dels', 8, 0
	UNION
	-- 80.BJobs
	SELECT 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'BJobs', 'id', '80.BJobs', 'id', 'usp_Import_80_BJobs_Changes', 'usp_Import_80_BJobs_Dels', 8, 0
	UNION
	-- 80.BObjects
	SELECT 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'BObjects', 'id', '80.BObjects', 'id', 'usp_Import_80_BObjects_Changes', 'usp_Import_80_BObjects_Dels', 8, 0
	UNION
	-- 80.Backup.Model.Backups
	SELECT 'f205250c-89b8-4bb3-9428-4065a79a785d', 'Backup.Model.Backups', 'id', '80.Backup.Model.Backups', 'id', 'usp_Import_80_Backup_Model_Backups_Changes', 'usp_Import_80_Backup_Model_Backups_Dels', 8, 0
	UNION
	-- 80.Backup.Model.Storages
	SELECT 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'Backup.Model.Storages', 'id', '80.Backup.Model.Storages', 'id', 'usp_Import_80_Backup_Model_Storages_Changes', 'usp_Import_80_Backup_Model_Storages_Dels', 8, 0
	UNION
	-- 80.HostsByJobs
	SELECT 'e4660122-40a4-4123-b028-169f641f152d', 'HostsByJobs', 'id', '80.HostsByJobs', 'id', 'usp_Import_80_HostsByJobs_Changes', 'usp_Import_80_HostsByJobs_Dels', 8, 0
	UNION
	-- 80.Backup.Model.Points
	SELECT '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'Backup.Model.Points', 'id', '80.Backup.Model.Points', 'id', 'usp_Import_80_Backup_Model_Points_Changes', 'usp_Import_80_Backup_Model_Points_Dels', 8, 0
	UNION
	-- 80.Ssh_creds
	SELECT '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'Ssh_creds', 'id', '80.Ssh_creds', 'id', 'usp_Import_80_Ssh_creds_Changes', 'usp_Import_80_Ssh_creds_Dels', 8, 0
	UNION
	-- 80.Backup.Model.OIBs
	SELECT '8d8379ea-b485-4797-88dd-950fa8e7019c', 'Backup.Model.OIBs', 'id', '80.Backup.Model.OIBs', 'id', 'usp_Import_80_Backup_Model_OIBs_Changes', 'usp_Import_80_Backup_Model_OIBs_Dels', 8, 0
	UNION
	-- 80.LicensedHosts
	SELECT '398759f0-ec62-4428-96b1-146e9efe2af1', 'LicensedHosts', 'id', '80.LicensedHosts', 'id', 'usp_Import_80_LicensedHosts_Changes', 'usp_Import_80_LicensedHosts_Dels', 8, 0
	UNION
	-- 80.Hosts
	SELECT '3faba35c-5ebb-4333-9dc7-519267932533', 'Hosts', 'id', '80.Hosts', 'id', 'usp_Import_80_Hosts_Changes', 'usp_Import_80_Hosts_Dels', 8, 0
	UNION
	-- 80.Folders
	SELECT '8db93b11-34ef-4403-8a41-ba92e6fed380', 'Folders', 'id', '80.Folders', 'id', 'usp_Import_80_Folders_Changes', 'usp_Import_80_Folders_Dels', 8, 0
	UNION
	-- 80.VirtualLabs
	SELECT '63847daf-ffb9-47eb-9e1e-2e214f0402df', 'VirtualLabs', 'id', '80.VirtualLabs', 'id', 'usp_Import_80_VirtualLabs_Changes', 'usp_Import_80_VirtualLabs_Dels', 8, 0
	UNION
	-- 80.ObjectsInApplicationGroups
	SELECT '0ad95260-f574-4d50-9afb-be20bcf294d4', 'ObjectsInApplicationGroups', 'id', '80.ObjectsInApplicationGroups', 'id', 'usp_Import_80_ObjectsInApplicationGroups_Changes', 'usp_Import_80_ObjectsInApplicationGroups_Dels', 8, 0
	UNION
	-- 80.DRRoles
	SELECT '2a5345b7-74a5-4277-b778-3df1f4d7452a', 'DRRoles', 'id', '80.DRRoles', 'id', 'usp_Import_80_DRRoles_Changes', 'usp_Import_80_DRRoles_Dels', 8, 0
	UNION
	-- 80.Backup.Model.JobSessions
	SELECT '1317b265-8218-4580-bc90-16339cee82ef', 'Backup.Model.JobSessions', 'id', '80.Backup.Model.JobSessions', 'id', 'usp_Import_80_Backup_Model_JobSessions_Changes', 'usp_Import_80_Backup_Model_JobSessions_Dels', 8, 0
	UNION
	-- 80.Backup.Model.SbTaskSessions
	SELECT '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'Backup.Model.SbTaskSessions', 'id', '80.Backup.Model.SbTaskSessions', 'id', 'usp_Import_80_Backup_Model_SbTaskSessions_Changes', 'usp_Import_80_Backup_Model_SbTaskSessions_Dels', 8, 0
	UNION
	-- 80.Backup.Model.SbSessions
	SELECT '05a7d244-a0b3-463c-a246-14a79085a198', 'Backup.Model.SbSessions', 'id', '80.Backup.Model.SbSessions', 'id', 'usp_Import_80_Backup_Model_SbSessions_Changes', 'usp_Import_80_Backup_Model_SbSessions_Dels', 8, 0
	UNION
	-- 80.Backup.Model.BackupJobSessions
	SELECT 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'Backup.Model.BackupJobSessions', 'id', '80.Backup.Model.BackupJobSessions', 'id', 'usp_Import_80_Backup_Model_BackupJobSessions_Changes', 'usp_Import_80_Backup_Model_BackupJobSessions_Dels', 8, 0
	UNION
	-- 80.Backup.Model.BackupTaskSessions
	SELECT 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'Backup.Model.BackupTaskSessions', 'id', '80.Backup.Model.BackupTaskSessions', 'id', 'usp_Import_80_Backup_Model_BackupTaskSessions_Changes', 'usp_Import_80_Backup_Model_BackupTaskSessions_Dels', 8, 0
	UNION
	-- 80.LinkedJobs
	SELECT '556527d7-ca77-418a-8708-77fc740dde4b', 'LinkedJobs', 'id', '80.LinkedJobs', 'id', 'usp_Import_80_LinkedJobs_Changes', 'usp_Import_80_LinkedJobs_Dels', 8, 0
	UNION
	-- 80.SbVerificationRules
	SELECT '976472bd-4208-42bc-a941-57bc66cad016', 'SbVerificationRules', 'id', '80.SbVerificationRules', 'id', 'usp_Import_80_SbVerificationRules_Changes', 'usp_Import_80_SbVerificationRules_Dels', 8, 0
	UNION
	-- 80.BackupProxies
	SELECT '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'BackupProxies', 'id', '80.BackupProxies', 'id', 'usp_Import_80_BackupProxies_Changes', 'usp_Import_80_BackupProxies_Dels', 8, 0
	UNION
	-- 80.BackupRepositories
	SELECT 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'BackupRepositories', 'id', '80.BackupRepositories', 'id', 'usp_Import_80_BackupRepositories_Changes', 'usp_Import_80_BackupRepositories_Dels', 8, 0
	UNION
	-- 80.Credentials
	SELECT 'f87e7fbb-cae3-4b33-97a0-fee43e6fbc6e', 'Credentials', 'id', '80.Credentials', 'id', 'usp_Import_80_Credentials_Changes', 'usp_Import_80_Credentials_Dels', 8, 0
	UNION
	-- 80.Backup.Model.RestoreJobSessions
	SELECT '4adc8fb6-1976-4403-86c4-e51f425922dc', 'Backup.Model.RestoreJobSessions', 'id', '80.Backup.Model.RestoreJobSessions', 'id', 'usp_Import_80_Backup_Model_RestoreJobSessions_Changes', 'usp_Import_80_Backup_Model_RestoreJobSessions_Dels', 8, 0
	UNION
	-- 80.JobVssCredentials
	SELECT 'd1c32ef0-f453-44f9-85b2-3005105836d7', 'JobVssCredentials', 'id', '80.JobVssCredentials', 'id', 'usp_Import_80_JobVssCredentials_Changes', 'usp_Import_80_JobVssCredentials_Dels', 8, 0
	UNION
	-- 80.PhysicalHosts
	SELECT '17b68fd5-6494-409e-a904-ed15c9710a2a', 'PhysicalHosts', 'id', '80.PhysicalHosts', 'id', 'usp_Import_80_PhysicalHosts_Changes', 'usp_Import_80_PhysicalHosts_Dels', 8, 0
	UNION
	-- 80.Backup.Model.RestoreTaskSessions
	SELECT '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'Backup.Model.RestoreTaskSessions', 'id', '80.Backup.Model.RestoreTaskSessions', 'id', 'usp_Import_80_Backup_Model_RestoreTaskSessions_Changes', 'usp_Import_80_Backup_Model_RestoreTaskSessions_Dels', 8, 0
	UNION
	-- 80.OibAdminAccounts
	SELECT '2497bafe-acf0-439b-b405-90cce32c309b', 'OibAdminAccounts', 'id', '80.OibAdminAccounts', 'id', 'usp_Import_80_OibAdminAccounts_Changes', 'usp_Import_80_OibAdminAccounts_Dels', 8, 0
	UNION
	-- 80.Backup.Model.GuestDatabase
	SELECT '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'Backup.Model.GuestDatabase', 'id', '80.Backup.Model.GuestDatabase', 'id', 'usp_Import_80_Backup_Model_GuestDatabase_Changes', 'usp_Import_80_Backup_Model_GuestDatabase_Dels', 8, 0
	UNION
	-- 80.WanAccelerators
	SELECT '00917a71-9d27-4ce5-ac7c-687735e1c623', 'WanAccelerators', 'id', '80.WanAccelerators', 'id', 'usp_Import_80_WanAccelerators_Changes', 'usp_Import_80_WanAccelerators_Dels', 8, 0
	UNION
	-- 80.HostComponents
	SELECT 'e3ec5e82-306f-46ef-b3ab-6ec8f627b2e8', 'HostComponents', 'id', '80.HostComponents', 'id', 'usp_Import_80_HostComponents_Changes', 'usp_Import_80_HostComponents_Dels', 8, 0
	UNION
	-- 80.Backup.Model.CloudGates
	SELECT '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'Backup.Model.CloudGates', 'id', '80.Backup.Model.CloudGates', 'id', 'usp_Import_80_Backup_Model_CloudGates_Changes', 'usp_Import_80_Backup_Model_CloudGates_Dels', 8, 0
	UNION
	-- 80.Tenants
	SELECT '04302e40-2287-4446-8357-d09a25ca2866', 'Tenants', 'id', '80.Tenants', 'id', 'usp_Import_80_Tenants_Changes', 'usp_Import_80_Tenants_Dels', 8, 0
	UNION
	-- 80.TenantsResourcesQuota
	SELECT '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'TenantsResourcesQuota', 'id', '80.TenantsResourcesQuota', 'id', 'usp_Import_80_TenantsResourcesQuota_Changes', 'usp_Import_80_TenantsResourcesQuota_Dels', 8, 0

	RETURN 
END
GO
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.List_ColumnsBindings]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn.List_ColumnsBindings]
GO
CREATE FUNCTION [dbo].[fn.List_ColumnsBindings] ()
RETURNS 
@Result TABLE 
(
	[id] [uniqueidentifier],
	[tables_binding] [uniqueidentifier],
	[source_field] [nvarchar](50),
	[target_field] [nvarchar](50),
	[column_sql_type] [int]
)
AS
BEGIN

	INSERT INTO @Result
	
-- C. Column bindings
-- C.Folder_Host
	SELECT '4f618456-1feb-40b4-a300-c5d970f1e801', '8eba7efa-9373-4ef5-90f2-afe4e05c4260', 'id', 'id', 14
	UNION
	SELECT '5f737628-0132-4f1d-8cae-d9fa99592432', '8eba7efa-9373-4ef5-90f2-afe4e05c4260', 'host_id', 'host_id', 14
	UNION
	SELECT 'bc577817-aa47-4b21-9f65-73f0f97ca8b1', '8eba7efa-9373-4ef5-90f2-afe4e05c4260', 'folder_id', 'folder_id', 14
-- C.ObjectsInJobs
	UNION
	SELECT '694eceb4-f748-4923-88f0-db698e325998', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'type', 'type', 8
	UNION
	SELECT 'c86ffeb5-b4b8-457b-820d-2b8c54046262', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'location', 'location', 12
	UNION
	SELECT '428fbfb8-d65f-48bd-82dd-211917600401', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'approx_size', 'approx_size', 0
	UNION
	SELECT '48f068d7-2257-4186-9698-2cc2f354a146', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'folder_id', 'folder_id', 14
	UNION
	SELECT '35c40876-98d7-4f17-ac35-115cb51f14cf', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'id', 'id', 14
	UNION
	SELECT '1628d7a6-21bc-4b3a-b895-80e271108614', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'job_id', 'job_id', 14
	UNION
	SELECT 'e4608313-6e19-4ec1-ab19-124c8650bf0e', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'object_id', 'object_id', 14
	UNION
	SELECT '034e350f-6864-42dd-8206-deff5a22aff3', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'vss_options', 'vss_options', 25
	UNION
	SELECT '2e48684e-445c-4f55-a625-a30906ef0a7c', '28a7d6d2-ca10-4ed0-ade6-019677f0bb65', 'order_no', 'order_no', 8
-- C.Soap_creds
	UNION
	SELECT '09f7be4c-aa46-471b-bddc-e6f8869f497d', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'port', 'port', 8
	UNION
	SELECT 'bb88df37-6ce9-4f44-80fe-df5cefcfa5e1', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'enabled', 'enabled', 2
	UNION
	SELECT '897b5984-e1ba-4223-9a77-97e84da95348', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'useproxy', 'useproxy', 2
	UNION
	SELECT '234f7eb2-63ff-4139-ab15-b54f5122def0', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'savepassword', 'savepassword', 2
	UNION
	SELECT '1e3a84c7-b734-4bed-9000-505b7b2af127', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'proxyip', 'proxyip', 12
	UNION
	SELECT 'b06a6ae9-a5d8-4180-a94b-c69cf91c80e5', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'host_id', 'host_id', 14
	UNION
	SELECT '4bda125f-35a2-40d0-bea7-34dfb12920d2', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'proxyport', 'proxyport', 8
	UNION
	SELECT '37080109-7b97-4000-b7bf-60499420124a', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'id', 'id', 14
	UNION
	SELECT '46115cc4-f4b3-4f36-a946-205be5b52f43', '8e9c5194-db32-4def-bdbc-93873daf19bf', 'creds', 'creds', 14
-- C.BJobs
	UNION
	SELECT '89d5929f-1a4a-4917-9b3a-1da053a225bd', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'latest_result', 'latest_result', 8
	UNION
	SELECT '2a145e30-dd94-4ce7-8ed0-8a3dc9fb2937', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'target_type', 'target_type', 8
	UNION
	SELECT '03f90242-1cef-42a0-8996-661cc15e586c', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'id', 'id', 14
	UNION
	SELECT '12a4bee1-afa9-4365-a255-4db223304a0e', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'is_deleted', 'is_deleted', 2
	UNION
	SELECT '88a94364-8676-49a1-b6ed-dcef70041dfa', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'options', 'options', 25
	UNION
	SELECT 'f1216aeb-2d77-485a-930c-18e20c5bdef1', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'platform', 'platform', 8
	UNION
	SELECT 'e86b1584-2bd1-4609-845c-2f21a89d8b36', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'target_host_id', 'target_host_id', 14
	UNION
	SELECT 'd5c4baa4-2b9f-4e20-b2f7-c971213d2caa', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'schedule', 'schedule', 25
	UNION
	SELECT '10d9c660-5cdc-492b-b965-85aa7d43c388', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'vss_options', 'vss_options', 25
	UNION
	SELECT 'a32176df-b036-45f2-9d99-f8f4f6d2162d', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'target_file', 'target_file', 12
	UNION
	SELECT 'ce33cf07-5887-4e3f-b5c9-97aa5522cfab', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'vcb_host_id', 'vcb_host_id', 14
	UNION
	SELECT '7bc4caeb-05f2-4c17-9688-9976e43fa60f', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'description', 'description', 12
	UNION
	SELECT 'c854e70a-1c84-4945-b0e8-c936b38930b3', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'name', 'name', 12
	UNION
	SELECT '1b20b4af-a176-43fd-8abc-0e104354e83f', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'schedule_enabled', 'schedule_enabled', 2
	UNION
	SELECT '7f362607-a187-4066-9e7f-2449eec43769', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'type', 'type', 8
	UNION
	SELECT 'f4795515-4908-4097-9b9f-bab77d8615fe', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'target_dir', 'target_dir', 12
	UNION
	SELECT '4677dbeb-b6fd-449e-ba12-4e4dbf40cb08', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'parent_schedule_id', 'parent_schedule_id', 14
	UNION
	SELECT '4896d5c1-65e2-4e75-84ef-8198b11efac8', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'repository_id', 'repository_id', 14
	UNION
	SELECT 'a3426204-63b2-4695-ac88-d9804dc83fd4', '085ffc12-17e4-494f-9c4b-13cede5c8b29', 'pwd_key_id', 'pwd_key_id', 14
-- C.BObjects
	UNION
	SELECT '172a3f73-881e-49c7-abaa-7d294b5342a2', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'id', 'id', 14
	UNION
	SELECT '1701cc1d-f2cd-4623-a084-2ba628914182', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'object_name', 'object_name', 12
	UNION
	SELECT '713a749c-046c-4891-be87-e0642b14bf09', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'guest_os', 'guest_os', 25
	UNION
	SELECT '7147fc7f-5ff7-4d71-9c52-81fa2c7afdb9', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'host_id', 'host_id', 14
	UNION
	SELECT '15e44a18-0ef9-46ed-9bba-e5fbfccac73f', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'object_id', 'object_id', 12
	UNION
	SELECT '4086ab4a-7d4f-4089-a73c-68d1dcd5771d', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'viobject_type', 'viobject_type', 12
	UNION
	SELECT 'feba5181-381d-4abd-a278-fa07c7050df7', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'type', 'type', 8
	UNION
	SELECT 'bccd9013-40a8-4109-a81f-5929c369c4a9', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'unique_key_hash', 'unique_key_hash', 21
	UNION
	SELECT 'bce72dea-b611-47d2-a40a-7a49f6affff2', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'display_name', 'display_name', 12
	UNION
	SELECT '063fdda4-7ee1-47c6-a119-2e8ac2ea131f', 'ab33d4bc-d249-4ce6-a5e7-58aa8df87823', 'platform', 'platform', 8
-- C.Backup.Model.Backups
	UNION
	SELECT '39b409ea-5a47-431d-b2b2-62bc9de75a7b', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'job_source_type', 'job_source_type', 8
	UNION
	SELECT '812cedff-f28d-4a50-a0ce-165922f3066e', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'id', 'id', 14
	UNION
	SELECT '1e5cb0fc-bfb1-45a4-9baf-b8d69f2501f9', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'job_name', 'job_name', 12
	UNION
	SELECT '5dca62f5-5ebf-4b94-aa8c-5fcde90f63d4', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'job_target_host_protocol', 'job_target_host_protocol', 8
	UNION
	SELECT '0cf9539e-8e77-4b84-9c73-44da5f318c21', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'job_target_host_id', 'job_target_host_id', 14
	UNION
	SELECT 'c683da09-0dad-4971-8ee8-74f6e75c9ec0', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'job_target_type', 'job_target_type', 8
	UNION
	SELECT '73175f71-ceb2-4a6a-ad88-0eb011aa500f', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'job_id', 'job_id', 14
	UNION
	SELECT 'a4d3011e-055b-49f0-88a8-8458aa9c57f6', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'repository_id', 'repository_id', 14
	UNION
	SELECT 'a607809f-f2f4-49cd-999b-1e317bd0b4b1', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'platform', 'platform', 8
	UNION
	SELECT 'fd757e24-c0f4-4d75-8fc3-1b9a9a3c5f46', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'target_type', 'target_type', 8
	UNION
	SELECT '59742673-60C4-42BD-8031-220F4FDE6A4A', 'bdcaa3da-60c0-439b-8736-0123bbc08b4b', 'dir_path', 'dir_path', 12
-- C.Backup.Model.Storages
	UNION
	SELECT 'ed31106a-04e1-4edf-8b8e-d2f77af4317a', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'block_size', 'block_size', 8
	UNION
	SELECT '33050135-90df-425d-b922-7fedb3e22a17', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'backup_id', 'backup_id', 14
	UNION
	SELECT '1a55a981-c37d-4324-9e33-6cd9d2a94f57', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'stats', 'stats', 25
	UNION
	SELECT '05ce19c6-1491-43ad-9b67-db37f9260025', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'modification_time', 'modification_time', 4
	UNION
	SELECT '13cc886f-d9c7-40af-b3e0-9132b74a22f9', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'version', 'version', 8
	UNION
	SELECT '88a9604f-7487-45b7-9f97-015f9ffd2e9c', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'id', 'id', 14
	UNION
	SELECT '32a7545c-05a4-4284-a4af-31e713ef363b', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'file_path', 'file_path', 12
	UNION
	SELECT '569c5c43-745f-4b36-b565-c01da3dc4297', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'creation_time', 'creation_time', 4
	UNION
	SELECT 'b1e144fb-af71-4749-a2ef-4556941877b2', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'host_id', 'host_id', 14
	UNION
	SELECT 'B4912717-5E9A-44B4-9A2C-53C79D5D7470', '2de1121e-40fa-42fb-a8ea-cfc09c4014bc', 'availability', 'availability', 16
-- C.HostsByJobs
	UNION
	SELECT 'e81dadae-ab72-4ffa-b244-cba4d82c1e21', 'e6472193-1851-40b4-9d46-e781e96fb07b', 'job_id', 'job_id', 14
	UNION
	SELECT '608678b7-71a1-46ca-9f48-547c8775ea01', 'e6472193-1851-40b4-9d46-e781e96fb07b', 'host_id', 'host_id', 14
	UNION
	SELECT '543d2fde-76fe-4228-a47d-aa18b0adef33', 'e6472193-1851-40b4-9d46-e781e96fb07b', 'id', 'id', 14
-- C.Backup.Model.Points
	UNION
	SELECT '75791f82-8017-49d4-9595-97792a1c39d0', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'link_id', 'link_id', 14
	UNION
	SELECT '45cf21ac-36c3-4158-9f32-31671d456d01', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'num', 'num', 5
	UNION
	SELECT 'ca7478f2-27d0-4fc0-95e1-5061d8a297ad', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'id', 'id', 14
	UNION
	SELECT '40684fc0-5a04-4d12-afe8-67be67c5ba2f', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'alg', 'alg', 8
	UNION
	SELECT 'd6b46e7a-0de5-4469-a4f5-bd001d4ca715', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'backup_id', 'backup_id', 14
	UNION
	SELECT 'f79a83f7-54e1-4445-97ac-001b49de5b7b', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'group_id', 'group_id', 14
	UNION
	SELECT 'fcb84faf-19dd-44b6-96b1-b7f57f874857', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'type', 'type', 8
	UNION
	SELECT '45f7061b-bd28-4e62-b9b7-708b690aff63', '259b9ddc-8afe-4547-8447-c4313499f1d6', 'creation_time', 'creation_time', 4
-- C.Ssh_creds
	UNION
	SELECT 'b71ac31a-7524-4738-90f4-ef3748d54c56', '7294ec7f-7114-483f-b650-ce26748235b0', 'adjust_firewall', 'adjust_firewall', 2
	UNION
	SELECT '71fecfab-cb2a-430f-b836-4371d2e2cf66', '7294ec7f-7114-483f-b650-ce26748235b0', 'isftserver', 'isftserver', 2
	UNION
	SELECT '6865db50-98be-4bbb-9285-d4d15d7affa6', '7294ec7f-7114-483f-b650-ce26748235b0', 'endftport', 'endftport', 8
	UNION
	SELECT '4ab2e68f-e19a-4479-9071-338c442ab85a', '7294ec7f-7114-483f-b650-ce26748235b0', 'auto_sudo', 'auto_sudo', 2
	UNION
	SELECT '2ada4117-c083-4ac4-9bf7-e7d21c55ed38', '7294ec7f-7114-483f-b650-ce26748235b0', 'port', 'port', 8
	UNION
	SELECT 'b620a238-66a3-4bd9-ae67-c6b3701b60a6', '7294ec7f-7114-483f-b650-ce26748235b0', 'enabled', 'enabled', 2
	UNION
	SELECT 'e2d8aba8-0802-4643-ae24-36b50047e7bc', '7294ec7f-7114-483f-b650-ce26748235b0', 'startftport', 'startftport', 8
	UNION
	SELECT '14d9552d-6171-4c63-ac8b-4db2c826f1ee', '7294ec7f-7114-483f-b650-ce26748235b0', 'timeout', 'timeout', 8
	UNION
	SELECT '73a2f63c-99d8-4d99-afa7-6ec92ef761c5', '7294ec7f-7114-483f-b650-ce26748235b0', 'elevatetoroot', 'elevatetoroot', 2
	UNION
	SELECT '8f8c5265-2d41-41ac-aef3-324e5a3cf52a', '7294ec7f-7114-483f-b650-ce26748235b0', 'buffersize', 'buffersize', 8
	UNION
	SELECT 'ae804e22-6e92-40a4-8ec7-4be5ca776b9a', '7294ec7f-7114-483f-b650-ce26748235b0', 'id', 'id', 14
	UNION
	SELECT '535b26e4-a8cd-40de-b53d-c11f4b9e7c7a', '7294ec7f-7114-483f-b650-ce26748235b0', 'creds', 'creds', 14
-- C.Backup.Model.OIBs
	UNION
	SELECT 'c0e2e9d7-5503-461b-802a-78400a573804', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'has_index', 'has_index', 2
	UNION
	SELECT 'd9053bef-a7af-47b3-a3ae-77dd2621e9a9', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'has_exchange', 'has_exchange', 2
	UNION
	SELECT '15787dc7-bdd7-46f8-8f8b-a232786e2bdf', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'type', 'type', 8
	UNION
	SELECT 'f5d2fa19-6136-499f-885f-7ee09de2750e', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'is_corrupted', 'is_corrupted', 2
	UNION
	SELECT '952fe0ea-6c03-4af5-aa4c-be9ee6fe2374', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'alg', 'alg', 8
	UNION
	SELECT 'f3b20dea-556b-44e3-861d-1486401f4416', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'creation_time', 'creation_time', 4
	UNION
	SELECT '5e7ad8b7-572a-4105-87bc-62180c8caee7', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'is_consistent', 'is_consistent', 2
	UNION
	SELECT 'cc693a74-4212-44d2-860d-1f722ba87fe9', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'storage_id', 'storage_id', 14
	UNION
	SELECT 'eecfe8e1-ecf4-446a-b0d0-2b774e73545f', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'inside_dir', 'inside_dir', 12
	UNION
	SELECT '1a4a5388-cc95-4ed7-92c6-d6e4b08bb1f8', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'state', 'state', 8
	UNION
	SELECT '00693794-4843-4629-bdee-4ff2e5a86162', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'id', 'id', 14
	UNION
	SELECT 'd6e19049-674d-44a5-b679-13fdca27bcba', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'guest_os_info', 'guest_os_info', 25
	UNION
	SELECT '5efab4bf-9bc6-48ec-b468-f4b4f27b5aee', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'memory', 'memory', 0
	UNION
	SELECT 'b9ba6617-c5d0-4c7c-b9a8-4448310f66d9', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'point_id', 'point_id', 14
	UNION
	SELECT 'd824151a-2f1e-4022-8988-ac6ad8bfa5d2', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'link_id', 'link_id', 14
	UNION
	SELECT 'f3291423-30f4-40ad-a344-3ff845f00376', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'approx_size', 'approx_size', 0
	UNION
	SELECT 'd0125887-d4ab-46a5-92dd-93cced22c76c', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'vmname', 'vmname', 12
	UNION
	SELECT '1a6d600b-eca5-4b3c-9a9a-e6dadb49a1c8', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'process_id', 'process_id', 8
	UNION
	SELECT '229f23ea-28f9-4421-bf58-a6b806a6272f', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'object_id', 'object_id', 14
	UNION
	SELECT 'daac1a4a-05e5-48f6-9e6d-053f9ad4dfb9', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'aux_data', 'aux_data', 25
	UNION
	SELECT '7676e338-432b-4e02-bc6b-7f55b75f71d3', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'display_name', 'display_name', 12
	UNION
	SELECT '7e69a098-3b2e-4893-b9d3-820018b5c37a', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'original_oib_id', 'original_oib_id', 14
	UNION
	SELECT 'b0902049-a48f-4af6-920d-c31aa90b53f4', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'fqdn', 'fqdn', 12
	UNION
	SELECT '54e2d8fe-3acc-4665-b88b-ab65fea55f19', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'has_sql', 'has_sql', 2
	UNION 
	SELECT '89f708d6-5491-4ed4-858e-517f975abd93', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'parent_id', 'parent_id', 14
	UNION 
	SELECT 'E15F372A-7429-4256-86C3-1EB3D4E91AEA', 'ba0a908b-a9b4-462a-821e-b47acbeebf94', 'is_recheck_corrupted', 'is_recheck_corrupted', 2
-- C.LicensedHosts
	UNION
	SELECT '70e8bb48-68f2-4681-b834-b96b514eabf6', '14be9db1-201e-4e53-8e2e-9ce2b7bb49fe', 'lic_edition', 'lic_edition', 8
	UNION
	SELECT '3fbb0615-5ac9-44ad-a49f-9efc9b8eb1a9', '14be9db1-201e-4e53-8e2e-9ce2b7bb49fe', 'is_licensed', 'is_licensed', 2
	UNION
	SELECT '9717e3f0-fd15-49e0-913b-9f7f438c335d', '14be9db1-201e-4e53-8e2e-9ce2b7bb49fe', 'type', 'type', 8
	UNION
	SELECT '1e6a26ea-03b5-40b8-b818-334d214f4057', '14be9db1-201e-4e53-8e2e-9ce2b7bb49fe', 'id', 'id', 14
	UNION
	SELECT '49a2d1ec-8952-48ae-9d25-5c28bf105d7c', '14be9db1-201e-4e53-8e2e-9ce2b7bb49fe', 'physical_host_id', 'physical_host_id', 14
	UNION
	SELECT '983121c5-be93-4563-95be-158b7303a3fd', '14be9db1-201e-4e53-8e2e-9ce2b7bb49fe', 'lic_tier', 'lic_tier', 8
-- C.Hosts
	UNION
	SELECT '87a8118d-6f38-47fd-acab-ac9ad2853adf', 'abd59640-02db-415d-a20a-9b34521404ba', 'description', 'description', 12
	UNION
	SELECT 'ac81af82-b6c8-4577-a816-fb600903c3f8', 'abd59640-02db-415d-a20a-9b34521404ba', 'protocol', 'protocol', 8
	UNION
	SELECT 'dcbff808-e60b-4e33-9c1f-2e03c244fa17', 'abd59640-02db-415d-a20a-9b34521404ba', 'info', 'info', 12
	UNION
	SELECT '39c32195-d7be-4960-a46b-262f48ee80cb', 'abd59640-02db-415d-a20a-9b34521404ba', 'ip', 'ip', 12
	UNION
	SELECT '12c43c1a-419c-45e1-98d8-6120c0cdc6b1', 'abd59640-02db-415d-a20a-9b34521404ba', 'parent_id', 'parent_id', 14
	UNION
	SELECT '502aa2e1-cfc6-44ea-86b6-5c164e1f5e91', 'abd59640-02db-415d-a20a-9b34521404ba', 'api_version', 'api_version', 8
	UNION
	SELECT '31c5ddeb-5ec6-456d-9470-01328fce18fd', 'abd59640-02db-415d-a20a-9b34521404ba', 'type', 'type', 8
	UNION
	SELECT '41143372-8748-4dcb-a10a-fdcc2764a7d4', 'abd59640-02db-415d-a20a-9b34521404ba', 'win_creds', 'win_creds', 25
	UNION
	SELECT '63de590b-0155-4888-82f5-202ffd9f611a', 'abd59640-02db-415d-a20a-9b34521404ba', 'id', 'id', 14
	UNION
	SELECT '74cd02e0-af8b-4a98-a916-943a25da1fc5', 'abd59640-02db-415d-a20a-9b34521404ba', 'name', 'name', 12
	UNION
	SELECT 'a6da0ccf-3889-48f1-a27e-a2edd51e1671', 'abd59640-02db-415d-a20a-9b34521404ba', 'reference', 'reference', 12
	UNION
	SELECT '07c8d3d1-c901-4ba4-8393-b5f17cb4a81b', 'abd59640-02db-415d-a20a-9b34521404ba', 'host_instance_id', 'host_instance_id', 22
	UNION
	SELECT 'a1b768c0-d2e7-4ca5-b66d-d37f2b418715', 'abd59640-02db-415d-a20a-9b34521404ba', 'physical_host_id', 'physical_host_id', 14
-- C.Folders
	UNION
	SELECT '1ce34858-7675-48de-b789-9f298ff292c4', '6f741c1b-69fd-4820-aa45-1a0e0f221d3c', 'name', 'name', 12
	UNION
	SELECT '3dc0eaf6-fc1e-4739-b700-a62d81ee4294', '6f741c1b-69fd-4820-aa45-1a0e0f221d3c', 'parent_id', 'parent_id', 14
	UNION
	SELECT '19ed8096-0658-4a49-afa4-10cd13a55e3f', '6f741c1b-69fd-4820-aa45-1a0e0f221d3c', 'id', 'id', 14
-- C.VirtualLabs
	UNION
	SELECT '4c555a1e-e03d-4298-855d-7176634b8506', 'ce4013f6-bad7-4f27-953d-b923639851a6', 'host_id', 'host_id', 14
	UNION
	SELECT '2d549075-e5b3-4970-9733-51d2fc568405', 'ce4013f6-bad7-4f27-953d-b923639851a6', 'vm_ref', 'vm_ref', 12
	UNION
	SELECT 'af1fd39e-db2f-4207-8ad3-ba2def47c2fb', 'ce4013f6-bad7-4f27-953d-b923639851a6', 'description', 'description', 12
	UNION
	SELECT '2b544066-153b-4eac-b335-96da84a145a9', 'ce4013f6-bad7-4f27-953d-b923639851a6', 'name', 'name', 12
	UNION
	SELECT '8cbe0b10-68dd-4569-8396-e3158ca40b6a', 'ce4013f6-bad7-4f27-953d-b923639851a6', 'id', 'id', 14
-- C.ObjectsInApplicationGroups
	UNION
	SELECT '86c83939-5d13-4a37-9282-f361293c2bc9', '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'effective_memory', 'effective_memory', 0
	UNION
	SELECT 'fe43edbd-d93a-4290-95f8-013208af047a', '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'guest_os_info', 'guest_os_info', 25
	UNION
	SELECT '9fafe2d1-c7a9-461e-b8f2-4304eb99d6ec', '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'options', 'options', 25
	UNION
	SELECT '66218d32-23c0-4bde-a99c-0e3cf82538ba', '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'id', 'id', 14
	UNION
	SELECT 'e36dfee7-4c6c-4a23-aa0e-0b8dacc9f442', '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'order', 'order', 8
	UNION
	SELECT '643fd208-b0ea-4bae-86ce-9df5ae0f99d7', '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'object_id', 'object_id', 14
	UNION
	SELECT 'c2993ffe-4a48-4202-94e4-c30dff379cd9', '9a0d15b5-b16b-40b2-a1c8-b8c2c06ba741', 'folder_id', 'folder_id', 14
-- C.DRRoles
	UNION
	SELECT '1bb0aec2-5a5d-4191-91a0-0c2dd52d4745', 'f1d79e4a-b76d-4a45-8813-d77d8d7ea69b', 'effective_memory', 'effective_memory', 0
	UNION
	SELECT '62030ba7-5877-46b3-a401-54663faea3e0', 'f1d79e4a-b76d-4a45-8813-d77d8d7ea69b', 'id', 'id', 14
	UNION
	SELECT 'c3735fbb-4826-4885-8968-1ddeb3a29310', 'f1d79e4a-b76d-4a45-8813-d77d8d7ea69b', 'boot_delay', 'boot_delay', 8
	UNION
	SELECT '02ba6f4e-b883-4161-8483-c4c804ef954d', 'f1d79e4a-b76d-4a45-8813-d77d8d7ea69b', 'test_script_file_full_name', 'test_script_file_full_name', 12
	UNION
	SELECT '518eb647-a4fc-47e0-a324-aa4693c1ad5c', 'f1d79e4a-b76d-4a45-8813-d77d8d7ea69b', 'name', 'name', 12
-- C.Backup.Model.JobSessions
	UNION
	SELECT '618cad14-f08a-42e0-bfb9-73cf2cb23cf6', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'log_xml', 'log_xml', 25
	UNION
	SELECT 'bb11e832-ef4a-42f9-aec4-28f55dfd6f60', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'progress', 'progress', 8
	UNION
	SELECT '0bb3047a-4dcc-4edb-a0a7-adebb5f176bb', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'job_name', 'job_name', 12
	UNION
	SELECT 'fbb6d001-65b3-480e-b1d8-39aad4b08fa3', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'result', 'result', 8
	UNION
	SELECT '0d64cc15-8ccb-4a10-a224-13fa56921502', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'job_id', 'job_id', 14
	UNION
	SELECT '51eeed42-f8d5-452a-bc5e-e2e2798ec743', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'state', 'state', 8
	UNION
	SELECT 'c1466005-e236-4382-9847-76d3824e99f4', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'job_type', 'job_type', 8
	UNION
	SELECT 'c2b54394-1338-4a76-97d9-ce3653336aa5', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'creation_time', 'creation_time', 4
	UNION
	SELECT '15eaa57d-f005-434b-bc03-9e2f2f708962', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'id', 'id', 14
	UNION
	SELECT '8bdfac1c-3f0f-4265-ad7e-da534d7cb67d', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'end_time', 'end_time', 4
	UNION
	SELECT '95441bba-9018-4a1d-ab5c-1a88645e92b3', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'operation', 'operation', 12
	UNION
	SELECT 'a565f496-35d8-4caf-8b7f-6609b3b33f51', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'control', 'control', 8
	UNION
	SELECT '1d54fc70-289c-4ef2-b432-279f18f88ed0', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'description', 'description', 18
	UNION
	SELECT 'c96f2ecc-17ef-4e01-80b7-88086266f8a9', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'usn', 'usn', 0
	UNION
	SELECT '54f0158b-ee7b-4478-9762-407d962004a4', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'initiator_sid', 'initiator_sid', 12
	UNION
	SELECT '3b2b9d78-8b76-46ed-b1ff-8396aa629734', '79ca7d2f-4782-42b0-ab71-9295ebab7be4', 'initiator_name', 'initiator_name', 12
-- C.Backup.Model.SbTaskSessions
	UNION
	SELECT 'd74e133f-4366-4f9e-8938-d05ecba912ba', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'order_num', 'order_num', 8
	UNION
	SELECT '16379415-6d5a-4bf0-a190-81d00b653879', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'object_id', 'object_id', 14
	UNION
	SELECT '9497aaeb-46c8-4390-a2a5-5031355f4a83', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'description', 'description', 12
	UNION
	SELECT 'e3f1c453-0981-4aef-ba4d-51895300daa8', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'powerOn_status', 'powerOn_status', 8
	UNION
	SELECT '47da6da6-3d99-4bfe-8f63-a238b8652639', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'restore_counter', 'restore_counter', 8
	UNION
	SELECT '3fda6c2c-1044-4469-81ae-244d925169ca', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'ping_status', 'ping_status', 8
	UNION
	SELECT 'f1d2a585-d2db-4bae-a962-d83928cbcc27', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'appliance_ip', 'appliance_ip', 12
	UNION
	SELECT '1ee4585c-66a6-4f56-9d1e-1a83463c10de', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'subnet_ip', 'subnet_ip', 12
	UNION
	SELECT '09754b41-6f32-4f01-8c63-062e37e7a21b', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'subnet_mask', 'subnet_mask', 12
	UNION
	SELECT '2e2541d3-224f-4a2b-8427-5567d7c7ea9c', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'vm_ref', 'vm_ref', 12
	UNION
	SELECT '0077b4b1-8b24-41c8-97c5-6d04db73becf', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'state', 'state', 8
	UNION
	SELECT 'ab9f3c14-c8b4-4b71-9159-1cc2be28ce0c', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'start_time', 'start_time', 4
	UNION
	SELECT '07b0261f-7edc-4fd4-9ae3-75cefb2f1e1b', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'drsession_id', 'drsession_id', 14
	UNION
	SELECT '45761652-c5f4-43d6-929b-aebac8a7c88b', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'total_steps', 'total_steps', 8
	UNION
	SELECT '70203ce3-e205-46a1-b668-7cd706091d28', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'percent', 'percent', 8
	UNION
	SELECT 'ad42824f-163f-4275-bddb-c8199c66303b', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'finish_time', 'finish_time', 4
	UNION
	SELECT '0517e2bf-d64b-43f5-930e-2ebeec154260', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'object_name', 'object_name', 12
	UNION
	SELECT '82ed2bee-e772-4dab-afe8-ab5e5a4dcf9f', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'id', 'id', 14
	UNION
	SELECT '06022cae-f33f-4b33-964a-1d396984a464', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'oib_id', 'oib_id', 14
	UNION
	SELECT 'f374a07e-b1c3-4133-9bb6-f880c00a7f80', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'heartbeat_status', 'heartbeat_status', 8
	UNION
	SELECT '21defdf4-6b8d-4d44-be55-8c77fe465e70', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'overall_status', 'overall_status', 8
	UNION
	SELECT 'bc45dede-1528-405e-a2c5-124f6b1fdb0a', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'control', 'control', 8
	UNION
	SELECT '3d484e09-e7b7-4fe1-bcbf-f017145fa238', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'type', 'type', 8
	UNION
	SELECT '628f2a3e-34af-4791-bb32-97114ff63130', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'test_script_error_code', 'test_script_error_code', 8
	UNION
	SELECT '45e718d7-2621-45ea-9fed-3964c8a23120', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'powerOff_status', 'powerOff_status', 8
	UNION
	SELECT '57b33bb3-1e9f-425a-a75e-768beefdf8f7', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'vm_external_ip', 'vm_external_ip', 12
	UNION
	SELECT '03abc636-c3de-45bb-8b9f-b6976cd24aae', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'test_script_status', 'test_script_status', 8
	UNION
	SELECT '05088b91-a662-4a75-8d3a-c50ec1e582e4', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'test_scripts_results', 'test_scripts_results', 25
	UNION
	SELECT '7e2df952-3c1c-4d49-9c5a-22d7f8df2687', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'oiag_id', 'oiag_id', 14
	UNION
	SELECT '444ae6b8-d0c1-4a41-ac7f-64fb97e561f0', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'processed_steps', 'processed_steps', 8
	UNION
	SELECT 'a5f42bfc-7f5c-4fa7-a5a4-a7debce1e4a5', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'leave_powered_on', 'leave_powered_on', 2
	UNION
	SELECT 'b73debe1-3ff8-4117-927e-b38b4575f5f6', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'validation_status', 'validation_status', 8
	UNION
	SELECT '5d5a0323-5e83-4d1e-9c4f-8cc280e66f70', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'log_xml', 'log_xml', 25
	UNION 
	SELECT '79d47f22-f6d0-4203-bbfb-a368427d5749', '1a7b7c52-1691-4630-9275-a6c77c54dbc9', 'usn', 'usn', 0
-- C.Backup.Model.SbSessions
	UNION
	SELECT '6fa261bb-50a8-4617-8493-fe7409488362', 'f8781835-d56c-4efb-bf22-fec03a871092', 'preferred_date', 'preferred_date', 4
	UNION
	SELECT '59c190e3-39e9-4128-8555-ff544fbdf18e', 'f8781835-d56c-4efb-bf22-fec03a871092', 'id', 'id', 14
-- C.Backup.Model.BackupJobSessions
	UNION
	SELECT 'c2f620ed-9a3e-4b1a-96f1-8829fc6dd206', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'is_full', 'is_full', 2
	UNION
	SELECT 'c4ba6033-c155-41b8-9916-9d1879f464f0', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'total_size', 'total_size', 0
	UNION
	SELECT '3c082d20-2fac-4195-8a18-17e6fc8e6328', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'processed_objects', 'processed_objects', 8
	UNION
	SELECT '1451b58b-5980-4af9-8a2d-8b3a51adb0fb', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'is_retry', 'is_retry', 2
	UNION
	SELECT '3e86f57c-0a06-4453-a31e-deeef8907546', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'total_objects', 'total_objects', 8
	UNION
	SELECT '7d88c893-4508-4a64-8d70-a1d4c3d76e90', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'processed_size', 'processed_size', 0
	UNION
	SELECT 'fc14136f-4389-4e48-bbc4-2d7e789393a7', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'avg_speed', 'avg_speed', 0
	UNION
	SELECT '9bff97ec-6810-4416-a65d-0698f75aefe4', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'job_source_type', 'job_source_type', 8
	UNION
	SELECT '1c5b9809-ea85-43cc-b432-12d0f3cb8ba8', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'id', 'id', 14
	UNION
	SELECT '883052fe-b4d5-4457-8a51-2c77555b5ed5', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'stored_size', 'stored_size', 0
	UNION
	SELECT '2c9c71c9-d2df-42dd-8ccf-33de352a4a05', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'is_active_full', 'is_active_full', 2
	UNION
	SELECT '8a02e1f8-00ae-4cf7-bba1-dd034ae17ecd', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'cur_point_id', 'cur_point_id', 14
	UNION
	SELECT 'fe1b4c26-7139-43fe-9550-86f2f71faca3', '0f3045b3-f69c-4dd1-84b0-4af551bfedfb', 'usn', 'usn', 0
-- C.Backup.Model.BackupTaskSessions
	UNION
	SELECT 'c32c1e1c-c0b4-4d1f-963c-ee7b9a0b6ee3', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'id', 'id', 14
	UNION
	SELECT '21399303-bb1e-4f4a-a7e8-a13436480a01', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'processed_size', 'processed_size', 0
	UNION
	SELECT '0200c519-b44e-41dc-84a9-58072c842e54', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'operation', 'operation', 12
	UNION
	SELECT '9cf2c12b-2599-4e0d-b74e-4d942353e5a5', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'end_time', 'end_time', 4
	UNION
	SELECT '8d12c6e8-8a28-4842-966b-476d650f6c13', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'object_name', 'object_name', 12
	UNION
	SELECT 'c13578f0-2e6e-42cc-a976-6a7ccb7dff7e', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'log_xml', 'log_xml', 25
	UNION
	SELECT '9c007e25-aa02-4352-a0f5-a99e254dadc4', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'read_size', 'read_size', 0
	UNION
	SELECT '3a28b255-98e7-4c03-9939-35f831eb1206', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'stored_size', 'stored_size', 0
	UNION
	SELECT '0d57d200-9749-4efb-b09f-d7441931cd3a', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'object_id', 'object_id', 14
	UNION
	SELECT '5b75f5fd-14f8-4e15-98f9-5c0ad5442bfb', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'processed_objects', 'processed_objects', 8
	UNION
	SELECT '0dc2ea26-9d3e-41e1-8d5d-3cbc80ae0d8a', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'session_id', 'session_id', 14
	UNION
	SELECT '619d1c85-818a-4c9d-a4c8-d5530c541c81', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'creation_time', 'creation_time', 4
	UNION
	SELECT '4c7c1b11-9fc1-4ea9-84c8-eefb0cf04590', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'mode', 'mode', 8
	UNION
	SELECT '80cce3c8-87b8-4407-9899-0d11fa55e5ba', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'total_objects', 'total_objects', 8
	UNION
	SELECT '8bf83071-9743-4524-bb57-f39804566a0a', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'total_size', 'total_size', 0
	UNION
	SELECT '49c8aa70-f47c-4425-886d-21014c7a9a34', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'reason', 'reason', 11
	UNION
	SELECT 'a196d15a-4644-4d26-aff3-f0273329e8ce', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'change_tracking', 'change_tracking', 2
	UNION
	SELECT '9c0e9b86-7654-4b97-a485-41b696a89a20', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'status', 'status', 8
	UNION
	SELECT '60f55acf-ec4b-4135-9a05-ee293f0138cb', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'avg_speed', 'avg_speed', 0
	UNION
	SELECT '85adc221-094f-4094-a029-727e95830128', '1d8960f4-ffb0-45cd-893b-1dc8cfdd48b9', 'usn', 'usn', 0
-- C.LinkedJobs
	UNION
	SELECT '6018d8b2-200c-4a29-be71-8e18b323e7fb', 'd41a6240-8120-4552-b9e2-89717b0a451c', 'linked_job_id', 'linked_job_id', 14
	UNION
	SELECT '4aad4a63-34ec-423c-86ea-c90866bc0bab', 'd41a6240-8120-4552-b9e2-89717b0a451c', 'id', 'id', 14
	UNION
	SELECT '78c0b4eb-5eb3-4bcf-a806-2754c6d4b820', 'd41a6240-8120-4552-b9e2-89717b0a451c', 'job_id', 'job_id', 14
-- C.SbVerificationRules
	UNION
	SELECT '05d3d0e5-abd9-4a40-b37a-67d01ac72920', 'edc854ff-0763-4910-a0ec-01c5ef05d0d7', 'id', 'id', 14
	UNION
	SELECT '5854fcf3-4123-4fc9-89bc-7b5ee53f0c8f', 'edc854ff-0763-4910-a0ec-01c5ef05d0d7', 'options', 'options', 25
	UNION
	SELECT '58149076-81b4-439b-8453-73211387dd10', 'edc854ff-0763-4910-a0ec-01c5ef05d0d7', 'job_id', 'job_id', 14
	UNION
	SELECT 'd46ecc2b-4517-4f48-9d59-3f24de21d0b3', 'edc854ff-0763-4910-a0ec-01c5ef05d0d7', 'object_type', 'object_type', 8
	UNION
	SELECT '6da1c166-7980-438d-9546-f6c457498680', 'edc854ff-0763-4910-a0ec-01c5ef05d0d7', 'object_id', 'object_id', 14
-- C.BackupProxies
	UNION
	SELECT '85ee3013-eff0-4b91-bbf9-4975873b2a2f', '118c8f53-8c4b-42f1-bf47-57746e113510', 'id', 'id', 14
	UNION
	SELECT 'f0e298cd-770f-4584-9580-c989d0468b31', '118c8f53-8c4b-42f1-bf47-57746e113510', 'name', 'name', 12
	UNION
	SELECT '1f51c672-2fc0-49c8-860b-467a12f84c70', '118c8f53-8c4b-42f1-bf47-57746e113510', 'description', 'description', 12
	UNION
	SELECT '0276f1f5-a8a1-4447-8207-217a0af93c17', '118c8f53-8c4b-42f1-bf47-57746e113510', 'type', 'type', 8
	UNION
	SELECT 'ca4aeba7-f958-41c9-95f9-52ef8dd9f3b5', '118c8f53-8c4b-42f1-bf47-57746e113510', 'options', 'options', 25
	UNION
	SELECT 'd65f264e-4bd1-40df-8bf9-c440c624ef5e', '118c8f53-8c4b-42f1-bf47-57746e113510', 'disabled', 'disabled', 2
	UNION
	SELECT 'dda6614a-6eeb-4012-b59b-28290ca420b7', '118c8f53-8c4b-42f1-bf47-57746e113510', 'is_busy', 'is_busy', 2
	UNION
	SELECT '213219d6-e2f4-4f9a-99a2-d518806381fd', '118c8f53-8c4b-42f1-bf47-57746e113510', 'is_unavailable', 'is_unavailable', 2
	UNION
	SELECT 'beca3112-d1cc-478c-b611-da8322fd78bc', '118c8f53-8c4b-42f1-bf47-57746e113510', 'unique_id', 'unique_id', 14
-- C.BackupRepositories
	UNION
	SELECT 'f8b11f60-286d-480b-89c4-c8309340d395', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'id', 'id', 14
	UNION
	SELECT '961b7731-34bb-48df-81bb-e9c6b99fcfe7', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'name', 'name', 12
	UNION
	SELECT '3c4ec706-ae1c-4bc5-815f-0f746da61efc', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'description', 'description', 12
	UNION
	SELECT '4d96427a-532f-416f-9147-91220323ea02', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'type', 'type', 8
	UNION
	SELECT '38bdafab-defc-40f9-8c27-4063d2b319c7', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'host_id', 'host_id', 14
	UNION
	SELECT '9ae2b8de-9a1b-4c52-b650-c375ddc19b13', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'mount_host_id', 'mount_host_id', 14
	UNION
	SELECT '43a1f6f8-dcab-4344-9232-53a2c1a0e757', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'path', 'path', 12
	UNION
	SELECT 'ed5e6339-77cd-4eb5-b171-ff507e92dbc2', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'options', 'options', 25
	UNION
	SELECT '3476b530-7964-4f54-b2ec-021bc8a4b750', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'is_busy', 'is_busy', 2
	UNION
	SELECT 'f54cc0a1-bc98-4c32-915a-e943d0af6529', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'is_unavailable', 'is_unavailable', 2
	UNION
	SELECT '5e845c35-4af5-469e-b198-9460be06f124', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'is_full', 'is_full', 2
	UNION
	SELECT 'cba2a436-6809-4862-8743-7048bf96e88d', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'total_space', 'total_space', 0
	UNION
	SELECT '16829ae2-847f-4e96-a719-286a78647c37', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'free_space', 'free_space', 0
	UNION
	SELECT '438202fe-66fd-4414-960e-55f6a1106348', '226bb31d-44c2-466a-8db1-0a7123d6ec1b', 'unique_id', 'unique_id', 14
-- C.Credentials
	UNION
	SELECT '79122510-768f-4c52-815f-2dcb55d18e54', '0bfe1660-40eb-4032-9fa0-42f5be6ac7e6', 'id', 'id', 14
	UNION
	SELECT 'f26a213d-9c3a-4274-bbcf-79cb1f68652a', '0bfe1660-40eb-4032-9fa0-42f5be6ac7e6', 'user_name', 'user_name', 12
-- C.Backup.Model.RestoreJobSessions
	UNION
	SELECT 'e6dc927e-c0ce-42d2-9424-5c3a9c62fa90', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'id', 'id', 14
	UNION
	SELECT 'ed8ee37c-3aca-4551-bdf2-4ed55f25a2a8', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'action', 'action', 8
	UNION
	SELECT '9a064e7e-4083-4351-9252-44eb0bfe12b0', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'usn', 'usn', 0
	UNION
	SELECT '63d206e6-f20b-4aa7-b5dd-2e9b8e203606', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'options', 'options', 25
	UNION
	SELECT '653b09c1-67a8-43a4-8697-9ddf4f663d36', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'reason', 'reason', 12
	UNION
	SELECT '7381643f-528e-4fac-b6cd-630277b59f0a', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'files_log_xml', 'files_log_xml', 25
	UNION
	SELECT '2d31bbc3-2ee8-4eab-83a3-e732971f4822', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'platform', 'platform', 8
	UNION
	SELECT 'c6056532-742a-414e-a357-d2873281af63', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'multi_restore_id', 'multi_restore_id', 14
	UNION
	SELECT 'f80a0c50-808f-4db9-adc2-6742400d1c07', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'restore_type', 'restore_type', 8
	UNION
	SELECT '1472de5f-b039-4c3a-87ed-91f0d65bb981', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'oib_id', 'oib_id', 14
	UNION
	SELECT '451fae03-a1a7-44b7-99c6-003f2c5236d4', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'is_internal', 'is_internal', 2
	UNION
	SELECT '6a67486a-9ba8-41f2-8337-949919b2499c', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'oib_display_name', 'oib_display_name', 12
	UNION
	SELECT '48178521-5e9e-476f-be63-693cdabb904c', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'oib_creation_time', 'oib_creation_time', 4
	UNION
	SELECT 'ba08aee5-959c-43b3-9e05-a370ab423541', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'sub_type', 'sub_type', 8
	UNION
	SELECT 'a90228e9-b486-4cfe-b7f7-5e985ad8e9d4', '8a6c47f8-ba76-4c8a-ad5c-d10e98e79aaf', 'restored_obj_id', 'restored_obj_id', 14
-- C.JobVssCredentials
	UNION
	SELECT 'ba1524c2-e501-483f-a46d-45a714c904f8', '5830cb30-7ea5-475b-84d1-84d2014b52bf', 'id', 'id', 14
	UNION
	SELECT 'fcea67c1-a52e-4559-ab9d-ce240dffc96f', '5830cb30-7ea5-475b-84d1-84d2014b52bf', 'job_id', 'job_id', 14
	UNION
	SELECT '45730ecd-592c-4595-a2da-19d51c9cb4b1', '5830cb30-7ea5-475b-84d1-84d2014b52bf', 'oij_id', 'oij_id', 14
	UNION
	SELECT 'f68ea18f-a8a4-41fb-b734-ddb64b7885ec', '5830cb30-7ea5-475b-84d1-84d2014b52bf', 'win_creds_id', 'win_creds_id', 14
-- C.PhysicalHosts
	UNION
	SELECT 'c3c28c99-72b2-4e5d-ae11-97f731769dd9', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'id', 'id', 14
	UNION
	SELECT 'dda1624d-9cb0-4e4a-ae61-3e3fe8b1b361', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'name', 'name', 12
	UNION
	SELECT '1c997c6f-79ca-4cb6-8231-5055880689fa', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'bios_uuid', 'bios_uuid', 12
	UNION
	SELECT '5c6189ba-fda6-4972-90e8-fae9d3680342', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'chassis_type', 'chassis_type', 8
	UNION
	SELECT '8d5b7957-3cdf-4046-a4d7-2de130b33ad8', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'hardware_info', 'hardware_info', 25
	UNION
	SELECT 'ac97d2e0-850c-474a-a51a-b6299d5e74da', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'net_info', 'net_info', 25
	UNION
	SELECT 'b5a3dbd2-e500-43e2-a457-9358c4e91af4', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'os_type', 'os_type', 8
	UNION
	SELECT 'b61d1359-ef8a-46a3-bcf8-c7df3759e59f', 'd0555593-dff4-49f2-90c0-f8afc4264561', 'os_platform', 'os_platform', 8
-- C.OibAdminAccounts
	UNION
	SELECT 'e1f8e206-5fb6-4e41-9494-2e552e25858d', 'fb3459cb-a8f1-4ff5-ae7c-84905c4edd04', 'id', 'id', 14
	UNION 
	SELECT 'ea3377c0-bd61-4ccf-aace-1163e4e3cf9e', 'fb3459cb-a8f1-4ff5-ae7c-84905c4edd04', 'sid', 'sid', 12
	UNION 
	SELECT '18bccf53-ebd9-4489-aba9-015214cfa0ac', 'fb3459cb-a8f1-4ff5-ae7c-84905c4edd04', 'oib_id', 'oib_id', 14
	UNION 
	SELECT '153d9e8b-dc44-4277-970c-288e4c1e97c0', 'fb3459cb-a8f1-4ff5-ae7c-84905c4edd04', 'account_type', 'account_type', 8
-- C.Backup.Model.GuestDatabase
	UNION 
	SELECT 'a2b0bc0e-157c-4270-a539-0c51fb6d2b9a', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'id', 'id', 14
	UNION 
	SELECT '95b2d2b3-b3f6-4a34-8c06-fd3e34e0061a', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'obj_id', 'obj_id', 14
	UNION
	SELECT '4d71a4fb-37ac-4b43-aacc-7de91529573a', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'server_name', 'server_name', 12
	UNION
	SELECT '406dff1a-197a-4106-afca-e5aa128d3f48', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'db_instance', 'db_instance', 12
	UNION
	SELECT '34e3ca08-c3ec-44c0-b284-2f8fc684b149', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'db_name', 'db_name', 12
	UNION
	SELECT 'b194a00a-3555-4103-941c-b7c312e5f0fd', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'creation_time', 'creation_time', 4
	UNION 
	SELECT '6e906dbf-f198-44b1-a73d-0141db765862', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'is_system', 'is_system', 2
	UNION
	SELECT 'fb21056f-1cfc-4458-87db-6c0ff8a8bbff', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'db_id', 'db_id', 8
	UNION
	SELECT '309a7ddf-befd-45c0-80ba-44f045d416ef', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'compatibility', 'compatibility', 8
	UNION
	SELECT '1a079f7c-3f28-4e4f-8543-9abd9d204d46', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'family_guid', 'family_guid', 14
	UNION 
	SELECT '7d2a2391-a2c6-495d-bf68-6ebed88864e3', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'local_creation_time', 'local_creation_time', 4
-- C.WanAccelerators
	UNION
	SELECT '8ef766e5-baeb-4165-b744-2cc7b0488729', '5e67c6b7-3564-4eb8-8328-37f1d4486ad5', 'id', 'id', 14
	UNION
	SELECT 'b34fd629-cdd5-4696-9cf8-648d28eea68b', '5e67c6b7-3564-4eb8-8328-37f1d4486ad5', 'host_id', 'host_id', 14
	UNION
	SELECT 'f519d52c-07a3-4280-8958-38d3fb815c1d', '5e67c6b7-3564-4eb8-8328-37f1d4486ad5', 'name', 'name', 12
	UNION
	SELECT '8308ef50-764b-4f95-b18a-358848490f2e', '5e67c6b7-3564-4eb8-8328-37f1d4486ad5', 'description', 'description', 12
	UNION
	SELECT '70371668-a11f-4fdc-a037-ba6184fd6e34', '5e67c6b7-3564-4eb8-8328-37f1d4486ad5', 'is_unavailable', 'is_unavailable', 2
-- C.HostComponents
	UNION 
	SELECT '2b71a517-4620-4060-9c8a-b69114ef5f7d', 'd278a0ca-6c61-41a8-9fe4-a5fbdc05c824', 'id', 'id', 14
	UNION
	SELECT 'f59d3d92-6960-4363-8240-06cac9bbc075', 'd278a0ca-6c61-41a8-9fe4-a5fbdc05c824', 'physical_host_id', 'physical_host_id', 14
	UNION
	SELECT '25f4b26e-70f3-447a-9d33-b56f3512c059', 'd278a0ca-6c61-41a8-9fe4-a5fbdc05c824', 'type', 'type', 8
	UNION
	SELECT '7f172f11-8c55-4465-b362-d50ab8151345', 'd278a0ca-6c61-41a8-9fe4-a5fbdc05c824', 'version', 'version', 12
	UNION
	SELECT '96b6c923-53df-4198-8c65-2650c2e6c4b6', 'd278a0ca-6c61-41a8-9fe4-a5fbdc05c824', 'options', 'options', 25
	UNION
	SELECT '391327f5-7d9d-429c-94ab-44112ccc95f1', 'd278a0ca-6c61-41a8-9fe4-a5fbdc05c824', 'is_up_to_date', 'is_up_to_date', 2
-- C.Backup.Model.CloudGates
	UNION
	SELECT '71f84208-de84-4a16-b1aa-cc5127d48672', 'a498d420-25ee-4314-a61f-22a1296b3502', 'id', 'id', 14
	UNION
	SELECT '32e76d18-307b-403d-b509-008bc2e4908c', 'a498d420-25ee-4314-a61f-22a1296b3502', 'name', 'name', 12
	UNION
	SELECT '7ab2db1f-57d2-43ef-87b8-e542f51535f1', 'a498d420-25ee-4314-a61f-22a1296b3502', 'description', 'description', 12
	UNION 
	SELECT 'a665178e-297a-4986-9df0-e501a5b84250', 'a498d420-25ee-4314-a61f-22a1296b3502', 'creds_id', 'creds_id', 14
	UNION
	SELECT '9a52d261-2d12-439d-8ccd-902efbb9a61d', 'a498d420-25ee-4314-a61f-22a1296b3502', 'options', 'options', 25
	UNION
	SELECT '7e75d6e2-2fc1-4e3f-b9f8-d32a8637bda3', 'a498d420-25ee-4314-a61f-22a1296b3502', 'host_id', 'host_id', 14
	UNION
	SELECT '6ec9b51d-8fc5-433a-884d-855fbca75827', 'a498d420-25ee-4314-a61f-22a1296b3502', 'disabled', 'disabled', 2
	UNION
	SELECT '63af7232-e9de-49ed-a9f6-06c912b67c97', 'a498d420-25ee-4314-a61f-22a1296b3502', 'is_available', 'is_available', 2
-- C.Tenants
	UNION
	SELECT 'e9ff2e11-fa61-40ba-9f4b-176ef5ef9b3e', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'id', 'id', 14
	UNION
	SELECT '66159584-f52b-4823-9974-9956db1086e5', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'name', 'name', 12
	UNION
	SELECT '1fc85ec3-70ab-49d9-820f-8682f8273e60', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'description', 'description', 12
	UNION
	SELECT 'c8f99ec1-45d8-4f6a-96f3-7df64d80cd48', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'expire_time', 'expire_time', 4
	UNION
	SELECT '645e62a0-be30-443f-a99c-4a0ca127beae', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'disabled', 'disabled', 2
	UNION
	SELECT '29bb69f9-20ec-486b-8e6d-94da7b8e970c', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'password', 'password', 12
	UNION
	SELECT 'd1169d66-f7e3-4185-9414-9ee22a578f57', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'options', 'options', 25
	UNION
	SELECT '2df84a43-05b0-4119-8ad4-05eac7778a6a', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'throttling_speed_limit', 'throttling_speed_limit', 8
	UNION
	SELECT '111a9ccc-b283-41c4-ad74-4113cffd4263', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'throttling_speed_unit', 'throttling_speed_unit', 8
	UNION
	SELECT '751fd6eb-14c5-41d5-8b61-6a9a8230b179', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'max_concurent_tasks', 'max_concurent_tasks', 8
	UNION
	SELECT 'd256d5ae-1775-4d3f-a1a4-3c0a80076a09', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'is_throttling_enabled', 'is_throttling_enabled', 2
-- C.TenantsResourcesQuota
	UNION
	SELECT '018d7641-c059-4e47-94d3-095d28c992e4', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'id', 'id', 14
	UNION
	SELECT 'fa627254-9738-495a-9693-aeab0599d781', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'tenant_id', 'tenant_id', 14
	UNION
	SELECT '2a66cc25-e4f1-4f8f-810e-0eb499e8a9b4', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'repository_id', 'repository_id', 14
	UNION
	SELECT 'cad87dfb-630b-40e2-a131-144f98ad4ebd', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'folder', 'folder', 12
	UNION
	SELECT 'bfbf300b-d49b-4a39-8e7d-788e34c3eea5', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'wan_id', 'wan_id', 14
	UNION
	SELECT '61889b22-feb6-4b6d-9c41-06c6a586442e', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'quota_mb', 'quota_mb', 8
	UNION
	SELECT '249b3833-c686-4b23-9056-1daab34009a6', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'used_quota_mb', 'used_quota_mb', 8
	UNION
	SELECT '66e2d663-3e8f-4e9e-a8f0-a1cfac160d72', '1ee67189-56f2-4b65-8661-7b95fc230bb9', 'friendly_name', 'friendly_name', 12
-- C.Backup.Model.CloudSessions
	UNION
	SELECT '62a61ef8-48c2-4206-9f53-65bcb86806ac', '9031c649-ec6e-41b0-b1e2-f2c5e08849e5', 'id', 'id', 14
	UNION
	SELECT 'b6870bd2-76ee-48d5-ac64-0c51114fbf0e', '9031c649-ec6e-41b0-b1e2-f2c5e08849e5', 'data_sent_to_client', 'data_sent_to_client', 0
	UNION
	SELECT 'd0083f6c-e13b-451c-94ee-349e7eb4fd17', '9031c649-ec6e-41b0-b1e2-f2c5e08849e5', 'data_received_from_client', 'data_received_from_client', 0
	UNION
	SELECT '4a7330b6-679d-4be1-9fc6-5f7f7265dd6a', '9031c649-ec6e-41b0-b1e2-f2c5e08849e5', 'session_type', 'session_type', 8
	UNION
	SELECT '71b7a3e7-ff16-49b3-ae32-1097118a2bb1', '9031c649-ec6e-41b0-b1e2-f2c5e08849e5', 'tenant_name', 'tenant_name', 12
	UNION
	SELECT '910f4b63-1f9f-4e2a-81cb-8b8f380a754f', '661c196c-0f84-4301-9461-baf7370a3a85', 'tenant_id', 'tenant_id', 14
-- C.Backup.Model.CloudSessionsOnQuotas
	UNION
	SELECT '92bc7038-e5a9-4e9d-b4a4-c2f8de5dfd41', '4a4d9923-574a-4772-9423-f02c9fa57e45', 'session_id', 'session_id', 14
	UNION
	SELECT '1fc5df8f-c595-45f7-b47b-5039c558b018', '4a4d9923-574a-4772-9423-f02c9fa57e45', 'quota_id', 'quota_id', 14
	UNION
	SELECT '1a50ea00-ee9f-402d-a410-5828e129a892', '4a4d9923-574a-4772-9423-f02c9fa57e45', 'id', 'id', 14
-- C.Backup.Model.CloudVms
	UNION
	SELECT '7b341f58-7209-4624-a790-2b0c7748ca0e', 'ff4af2ac-3d05-493a-8567-79f74df15ebe', 'id', 'id', 0
	UNION
	SELECT '9f8146af-3bab-4f4a-958a-a4a6ff6f9b4b', 'ff4af2ac-3d05-493a-8567-79f74df15ebe', 'vm_uuid', 'vm_uuid', 12
	UNION
	SELECT '4f4ee953-0010-403f-9a43-c62cb3d553e8', 'ff4af2ac-3d05-493a-8567-79f74df15ebe', 'unique_id', 'unique_id', 14
-- C.Backup.Model.CloudVmsOnQuotas
	UNION
	SELECT 'f35f16d9-8122-44dc-b13f-649576056834', 'c49097c3-9e4e-4393-b729-eefcf8f3dde4', 'vm_id', 'vm_id', 0
	UNION
	SELECT 'b52b6a5f-ef6f-4b43-bb06-4c738454815c', 'c49097c3-9e4e-4393-b729-eefcf8f3dde4', 'resource_quota_id', 'resource_quota_id', 14
	UNION
	SELECT '1dee8c20-ad4c-40a5-bc87-3f9efb00ae04', 'c49097c3-9e4e-4393-b729-eefcf8f3dde4', 'id', 'id', 14
-- C.Backup.Model.CloudFailoverPlan
	UNION
	SELECT 'c5c559c5-59f5-49f6-b531-d6b81e098bc5', '9d064913-c254-40e2-83dd-8cbf77fc24f1', 'id', 'id', 14
	UNION
	SELECT 'ca74372d-83e2-4d7e-84fb-5486dcaa3ea5', '9d064913-c254-40e2-83dd-8cbf77fc24f1', 'job_id', 'job_id', 14
	UNION
	SELECT 'aaff9d4c-5515-4073-b120-aa02d57bc802', '9d064913-c254-40e2-83dd-8cbf77fc24f1', 'tenant_id', 'tenant_id', 14
	UNION
	SELECT 'ee1bb8e5-6f01-45ef-ac5e-f49871f1ddd2', '9d064913-c254-40e2-83dd-8cbf77fc24f1', 'options', 'options', 25
	UNION
	SELECT 'c3a9d975-c94f-4321-9b56-53af55cff4c0', '9d064913-c254-40e2-83dd-8cbf77fc24f1', 'test_mode_job_id', 'test_mode_job_id', 14
-- C.Backup.Model.ViCloudTenantBackups
	UNION
	SELECT '567bcfff-bd26-4042-8fa8-f4d192e4cb81', '7a80ca99-bca5-477d-b459-6f63d4512f30', 'id', 'id', 14
	UNION
	SELECT '246ab207-09b3-46ff-88f1-68154304996a', '7a80ca99-bca5-477d-b459-6f63d4512f30', 'backup_id', 'backup_id', 14
	UNION
	SELECT 'c63bbef0-4cdd-4557-8111-4df0ade9c974', '7a80ca99-bca5-477d-b459-6f63d4512f30', 'quota_id', 'quota_id', 14
-- C.Backup.Model.HvCloudTenantBackups
	UNION
	SELECT '92a5ba48-de15-4c5b-9a7d-584994d0291b', '616b2cd6-8776-415c-88b8-d03963e27fba', 'id', 'id', 14
	UNION
	SELECT 'e0c10a51-aaa4-415e-9c5c-862f7041ab75', '616b2cd6-8776-415c-88b8-d03963e27fba', 'backup_id', 'backup_id', 14
	UNION
	SELECT '955c9013-5478-4343-b8ca-218684854c15', '616b2cd6-8776-415c-88b8-d03963e27fba', 'quota_id', 'quota_id', 14
-- C.Backup.Model.ViHardwareQuotas
	UNION
	SELECT 'f1b3b142-7612-4963-a87e-42dbfb1fa239', 'e065129e-eaf9-45ae-b924-955029490a71', 'id', 'id', 14
	UNION
	SELECT '2adf265f-8d38-4730-ba38-70316de66f8e', 'e065129e-eaf9-45ae-b924-955029490a71', 'tenantId', 'tenantId', 14
	UNION
	SELECT '23f7b90e-75f0-42d8-bbf5-480ea32bd252', 'e065129e-eaf9-45ae-b924-955029490a71', 'hardwarePlanId', 'hardwarePlanId', 14
	UNION
	SELECT '4b69e03e-cd28-409d-9d78-7e2ed192996c', 'e065129e-eaf9-45ae-b924-955029490a71', 'expireDate', 'expireDate', 4
	UNION
	SELECT '650a29e2-b6f9-4254-be50-97205a9285a4', 'e065129e-eaf9-45ae-b924-955029490a71', 'folderReference', 'folderReference', 12
	UNION
	SELECT 'f64cbccc-c4ec-4cd8-82a2-a3c3bdd4cbf1', 'e065129e-eaf9-45ae-b924-955029490a71', 'resourcePoolReference', 'resourcePoolReference', 12
	UNION
	SELECT 'f637edc2-7d94-4fd9-bd84-9d55f336485b', 'e065129e-eaf9-45ae-b924-955029490a71', 'isCorrespondsToPlan', 'isCorrespondsToPlan', 2
	UNION
	SELECT 'b55fb401-ab10-40b1-9629-0e2c6e4ede52', 'e065129e-eaf9-45ae-b924-955029490a71', 'wan_id', 'wan_id', 14
-- C.Backup.Model.HvHardwareQuotas
	UNION
	SELECT '0095139a-47cc-4103-a11e-df9a3995407c', 'f9469e9d-f71b-4323-9926-e48d0614df0c', 'id', 'id', 14
	UNION
	SELECT 'ebcbde45-c8aa-4bd1-afda-9c334545ac7e', 'f9469e9d-f71b-4323-9926-e48d0614df0c', 'tenantId', 'tenantId', 14
	UNION
	SELECT '0034a1c3-b7e8-4b6c-85ca-380dfe0173e0', 'f9469e9d-f71b-4323-9926-e48d0614df0c', 'hardwarePlanId', 'hardwarePlanId', 14
	UNION
	SELECT '496940b0-571e-420b-965e-cb442a682842', 'f9469e9d-f71b-4323-9926-e48d0614df0c', 'expireDate', 'expireDate', 4
	UNION
	SELECT '0063ba05-3435-4ba9-b05a-885320fe2023', 'f9469e9d-f71b-4323-9926-e48d0614df0c', 'isCorrespondsToPlan', 'isCorrespondsToPlan', 2
	UNION
	SELECT '674ef6e4-6ba0-4c31-bfdb-eb10e35a329b', 'f9469e9d-f71b-4323-9926-e48d0614df0c', 'wan_id', 'wan_id', 14
-- C.Backup.Model.ViHardwarePlans
	UNION
	SELECT '28f036b6-29ba-4407-9a70-6f4e37928d56', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'id', 'id', 14
	UNION
	SELECT '8b6b2ba6-82f3-4b0e-8258-520eeef66561', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'friendlyName', 'friendlyName', 12
	UNION
	SELECT '65B6C9D5-65C4-4603-8C0A-B2A864B30819', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'description', 'description', 12
	UNION
	SELECT '80ce5091-4da7-4ef5-9be7-2771fbfde70a', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'hypervisorHostId', 'hypervisorHostId', 14
	UNION
	SELECT 'c28f8104-42ce-4e52-9632-3a303b8f7807', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'parentType', 'parentType', 8
	UNION
	SELECT 'a9b7edb7-e572-4bdd-83ee-2ed38e3e78be', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'parentName', 'parentName', 12
	UNION
	SELECT '1df30b0c-44ea-4e00-bc26-e0134f10f0e3', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'parentReference', 'parentReference', 12	
	UNION
	SELECT '6dab129f-cb64-4749-aec3-adcc8edd459f', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'processorUsageLimitMhz', 'processorUsageLimitMhz', 8
	UNION
	SELECT 'f5234ea0-e12b-41c9-83a6-effd48fe2d55', '753ec64d-c819-4f5c-9927-b0c49b30d033', 'memoryUsageLimitMb', 'memoryUsageLimitMb', 8
-- C.Backup.Model.HvHardwarePlans
	UNION
	SELECT 'd4cbfcab-bd63-426c-97fd-247e44085cc8', 'e7682942-da89-4f43-9faa-4b9b942d20a3', 'id', 'id', 14
	UNION
	SELECT '45ca1aa6-6631-4dbd-ba42-bba776526d19', 'e7682942-da89-4f43-9faa-4b9b942d20a3', 'friendlyName', 'friendlyName', 12
	UNION
	SELECT '6a159776-0482-478e-baba-b55f22e0e281', 'e7682942-da89-4f43-9faa-4b9b942d20a3', 'description', 'description', 12
	UNION
	SELECT '0e25ae12-06c3-4919-9cf0-74e7c0c57e25', 'e7682942-da89-4f43-9faa-4b9b942d20a3', 'hypervisorHostId', 'hypervisorHostId', 14
	UNION
	SELECT '99a373c4-a024-4587-b09e-ed64b31e066c', 'e7682942-da89-4f43-9faa-4b9b942d20a3', 'processorUsageLimitCores', 'processorUsageLimitCores', 8
	UNION
	SELECT 'ac5c207d-4e1c-4d6e-9cfc-aad8e1b54ef3', 'e7682942-da89-4f43-9faa-4b9b942d20a3', 'memoryUsageLimitMb', 'memoryUsageLimitMb', 8

-- C.Backup.ExtRepo.ExtRepos
	UNION
	SELECT '93D1211E-61AB-4AD7-ABE6-BCF3110298D2', '45ee48c5-781a-4bd5-b931-f67c8619af86', 'id', 'id', 14
	UNION
	SELECT 'B3755D3B-8435-4F4C-B10D-F16FD4694B0C', '45ee48c5-781a-4bd5-b931-f67c8619af86', 'meta_repo_id', 'meta_repo_id', 14
	UNION
	SELECT '44E65F99-A0A9-4AD2-B474-59F4D73833BB', '45ee48c5-781a-4bd5-b931-f67c8619af86', 'dependant_repo_id', 'dependant_repo_id', 14
	UNION
	SELECT '96E39788-3F46-4E6B-88BB-2618D624ECC2', '45ee48c5-781a-4bd5-b931-f67c8619af86', 'options', 'options', 25

	-- C.Backup.Model.ViHardwarePlanDatastores
	UNION
	SELECT '28af2f84-a3ec-49ae-82ea-14e66804f51e', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'id', 'id', 14
	UNION
	SELECT 'b1df897b-6624-4b9e-a749-6e77aab95a8c', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'hardwarePlanId', 'hardwarePlanId', 14
	UNION
	SELECT '0aae4943-ed10-4071-8559-a7a7e8bb7c3c', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'friendlyName', 'friendlyName', 12
	UNION
	SELECT '3a214f57-97e2-4abb-acbb-2aada597108c', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'reference', 'reference', 12
	UNION
	SELECT '0a8998c6-bc0f-46b2-b489-55817cb36f18', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'rootPath', 'rootPath', 12
	UNION
	SELECT 'a84a612f-5f64-4c48-9c4b-3fa1e68d511b', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'quotaGb', 'quotaGb', 8
	UNION
	SELECT '8463d908-f5ac-4427-8f8c-8a055c36f81f', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'viType', 'viType', 12
	UNION
	SELECT 'e3490da4-7606-47b9-9ab4-3516b96d9cde', 'bd1e697b-d1e0-4c0b-8d8e-b7fbe36bd89b', 'pbmProfileId', 'pbmProfileId', 12
-- C.Backup.Model.ViHardwarePlanNetworks
	UNION
	SELECT '2389e818-15a2-4811-984f-a6923502c67c', 'ef6178c8-d035-4ef2-bd2f-7d1011a0e89a', 'id', 'id', 14
	UNION
	SELECT '874e3705-653c-4cd5-ab7c-cad7da42b870', 'ef6178c8-d035-4ef2-bd2f-7d1011a0e89a', 'hardwarePlanId', 'hardwarePlanId', 14
	UNION
	SELECT 'd5447b47-8b6f-4fdb-acc2-fe98d4b67296', 'ef6178c8-d035-4ef2-bd2f-7d1011a0e89a', 'countWithInternent', 'countWithInternet', 8
	UNION
	SELECT 'ea0524ba-c57c-4783-9608-db882dbfbe47', 'ef6178c8-d035-4ef2-bd2f-7d1011a0e89a', 'countWithoutInternent', 'countWithoutInternet', 8
-- C.Backup.Model.ViHardwareQuotaNetworks
	UNION
	SELECT 'ec31b900-ccdb-4bfb-aeee-405ac3b753d2', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'id', 'id', 14
	UNION
	SELECT 'b2fc6394-a3a1-43f7-8493-3b8360273f2a', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'hardwarePlanNetworkId', 'hardwarePlanNetworkId', 14
	UNION
	SELECT '5cb4f395-582d-473b-be04-c55325c8506b', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'hardwareQuotaId', 'hardwareQuotaId', 14
	UNION
	SELECT '3428a9ae-bd00-4f9a-bc98-852a4e7d8ea8', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'name', 'name', 12
	UNION
	SELECT 'dc40d181-4ad9-4b23-a1be-b5658c925755', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'vlanId', 'vlanId', 8
	UNION
	SELECT '2cd89921-1bd4-4fbd-b21c-0a2b9562ea5c', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'ifaceNum', 'ifaceNum', 8
	UNION
	SELECT '95feb794-f496-4290-bb7a-d789ef88aeb8', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'tenantInfo', 'tenantInfo', 25
	UNION
	SELECT '147298b4-87ac-4b78-bb5d-669c465a40bc', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'hasInternet', 'hasInternet', 2
	UNION
	SELECT '134196b0-d7f4-42fb-9792-b241e13b1ccd', '6f937919-0ab6-473b-bc83-3bb16aa8500a', 'hostNetworks', 'hostNetworks', 25
-- C.Backup.Model.HvHardwarePlanVolumes
	UNION
	SELECT '62882497-6278-4d01-923a-d7ed1aaadd18', 'e3b5c848-c2cf-41bc-9a25-1f9c09d2a893', 'id', 'id', 14
	UNION
	SELECT '91be1384-6b80-4e82-ba5f-ed7cc679b1d8', 'e3b5c848-c2cf-41bc-9a25-1f9c09d2a893', 'hardwarePlanId', 'hardwarePlanId', 14
	UNION
	SELECT '69d61988-f03f-4e30-8134-037abe5ee42a', 'e3b5c848-c2cf-41bc-9a25-1f9c09d2a893', 'friendlyName', 'friendlyName', 12
	UNION
	SELECT 'b626543f-1e1e-43a2-9e06-8c6560a02617', 'e3b5c848-c2cf-41bc-9a25-1f9c09d2a893', 'volumePath', 'volumePath', 12
	UNION
	SELECT '0f565c60-040c-4136-abe8-f195fab2265c', 'e3b5c848-c2cf-41bc-9a25-1f9c09d2a893', 'quotaGb', 'quotaGb', 8
-- C.Backup.Model.HvHardwarePlanNetworks
	UNION
	SELECT 'fc9b70a1-c390-408b-9a4f-cee52656e430', '44907a6d-0a08-45db-a4d9-461a52544246', 'id', 'id', 14
	UNION
	SELECT '2dc11a16-e47d-4303-bf1d-c09c2ff38460', '44907a6d-0a08-45db-a4d9-461a52544246', 'hardwarePlanId', 'hardwarePlanId', 14
	UNION
	SELECT '743376de-0f77-48d3-8b47-fa648c37dd69', '44907a6d-0a08-45db-a4d9-461a52544246', 'countWithInternent', 'countWithInternet', 8
	UNION
	SELECT '79449783-b2d7-4e0b-a097-371a95cc245f', '44907a6d-0a08-45db-a4d9-461a52544246', 'countWithoutInternent', 'countWithoutInternet', 8
-- C.Backup.Model.HvHardwareQuotaNetworks
	UNION
	SELECT 'b0874a39-1025-4613-a5c5-d4a672d7101f', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'id', 'id', 14
	UNION
	SELECT '46043699-4a2f-45a4-8500-fb495984b13e', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'hardwarePlanNetworkId', 'hardwarePlanNetworkId', 14
	UNION
	SELECT '751cc224-bfd6-4639-8511-d44192c061e4', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'hardwareQuotaId', 'hardwareQuotaId', 14
	UNION
	SELECT '493c8ed7-5c6c-4a1c-8209-d3775b0c1ae2', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'name', 'name', 12
	UNION
	SELECT '0829ff7a-5fcc-4b08-92dd-09e6423d1fa8', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'vlanId', 'vlanId', 8
	UNION
	SELECT '0145d654-abb5-426c-b509-884fd9d937cf', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'ifaceNum', 'ifaceNum', 8
	UNION
	SELECT 'aa3d07f3-1f12-437b-aefd-53888801110e', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'tenantInfo', 'tenantInfo', 25
	UNION
	SELECT '936d5095-2b88-4899-b5b9-a7b5ec5a09c9', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'hasInternet', 'hasInternet', 2
	UNION
	SELECT '53f55a01-84bf-4fba-957b-3f883c5c1538', '0588d1b9-4d0a-4b69-acaf-582aa97e8670', 'switchName', 'switchName', 12
-- C.Backup.Model.CloudPublicIp
	UNION
	SELECT '787e58c3-be67-4ef5-8daa-f9a81bf46cb5', '76cfd01b-6522-4e5d-adbb-b6143af179b6', 'id', 'id', 14
	UNION
	SELECT 'e2fc9246-84d9-4872-8b6a-5f80fc34c6f2', '76cfd01b-6522-4e5d-adbb-b6143af179b6', 'ip_address', 'ip_address', 12
	UNION
	SELECT '2ef9a99e-8691-418d-b501-e8f372e77810', '76cfd01b-6522-4e5d-adbb-b6143af179b6', 'tenant_id', 'tenant_id', 14
-- C.Backup.Model.TenantPublicIp
	UNION
	SELECT '5011f76e-17ac-4c63-a914-d71c1585a29c', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'cloud_public_ip_id', 'cloud_public_ip_id', 14
	UNION
	SELECT '134f7c43-61cd-4460-bbc4-a503cee7844e', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'id', 'id', 14
	UNION
	SELECT '029b9764-25f4-4a10-bcf1-dcf3505cbf11', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'target_port', 'target_port', 8
	UNION
	SELECT '79adc0ad-79bc-4fe5-9dfa-1e366841b57a', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'source_ip_address', 'source_ip_address', 12
	UNION
	SELECT '24158f03-b90b-4f21-beb9-819dfa81fcfa', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'source_port', 'source_port', 8
	UNION
	SELECT '7cf905f8-9a28-44df-bfdd-43bdfb2930de', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'object_id', 'object_id', 14
	UNION
	SELECT 'aef2704e-58a4-40a8-843c-a070c49d14dd', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'failoverplan_id', 'failoverplan_id', 14
	UNION
	SELECT 'ac3f5eb2-12c8-427e-85c7-e2d0ad795a23', 'f29ac01d-1abf-4785-b130-b86e63be3e17', 'description', 'description', 12
-- C.HostNetwork
	UNION
	SELECT '07ee879f-3fc0-4dff-82db-1a264f6070b1', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'id', 'id', 14
	UNION
	SELECT 'e3f7fed3-86d9-47c4-8cba-4f62c9a843cf', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'host_id', 'host_id', 14
	UNION
	SELECT '454ff4b8-def7-4421-b4ab-f28b186b339a', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'inet_vlans_left_bound', 'inet_vlans_left_bound', 8
	UNION
	SELECT '272e8a14-2c36-41d8-874e-f7de9b657436', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'inet_vlans_right_bound', 'inet_vlans_right_bound', 8
	UNION
	SELECT '86d6af0a-a978-4844-8155-b361f85d6e44', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'non_inet_vlans_left_bound', 'non_inet_vlans_left_bound', 8
	UNION
	SELECT '24257adf-9a40-4bd4-919a-7f6fc2690653', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'non_inet_vlans_right_bound', 'non_inet_vlans_right_bound', 8
	UNION
	SELECT '4cee9401-0378-44dd-a43b-f0f9e932ee6e', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'vi_cluster_ref', 'vi_cluster_ref', 12
	UNION
	SELECT 'b1c171de-d11a-40ae-b754-83ba986a2b4d', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'vi_cluster_name', 'vi_cluster_name', 12
	UNION
	SELECT '827ef4fa-34dc-422e-b47c-a73bdc35ad2e', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'vswitch_name', 'vswitch_name', 12
	UNION
	SELECT 'b5d959b3-3e54-4609-9370-8be954703264', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'vswitch_type', 'vswitch_type', 8
	UNION
	SELECT 'afb68360-40f3-4794-beba-19b0c70e7bd4', 'fbc2d077-61e2-407a-acb8-b244918d1551', 'vswitch_id', 'vswitch_id', 12
-- C.Backup.Model.CloudAppliances
	UNION
	SELECT '3d10a1cb-784a-473b-afad-233672822b29', 'c8c62bde-0316-4d48-929a-9a703f0d96c8', 'id', 'id', 14
	UNION
	SELECT '470fd974-77d6-430e-b981-20b6565277c7', 'c8c62bde-0316-4d48-929a-9a703f0d96c8', 'tenant_id', 'tenant_id', 14
	UNION
	SELECT '62cf0e87-0bc9-4e1d-9709-2eed34d780e0', 'c8c62bde-0316-4d48-929a-9a703f0d96c8', 'connhost_id', 'connhost_id', 14
	UNION
	SELECT '5eb02dfe-6e6a-4c3a-9e66-da4e9b9933cd', 'c8c62bde-0316-4d48-929a-9a703f0d96c8', 'pod_id', 'pod_id', 12
	UNION
	SELECT 'd7e43a55-78f7-4b54-88fd-95c611ea1c21', 'c8c62bde-0316-4d48-929a-9a703f0d96c8', 'network_spec', 'network_spec', 25
	UNION
	SELECT 'e119aad1-946d-4efb-91d1-8e78009df98e', 'c8c62bde-0316-4d48-929a-9a703f0d96c8', 'live_info', 'live_info', 25
-- C.Backup.Model.LicensedVms
	UNION
	SELECT '19de6644-b945-4468-9683-db680cea3f7c', '1674166f-9653-48b1-a9a2-c55c905af95a', 'id', 'id', 14
	UNION
	SELECT 'e934ebd1-09e4-4128-8fcc-847068554ffd', '1674166f-9653-48b1-a9a2-c55c905af95a', 'object_id', 'object_id', 14
	UNION
	SELECT 'fd0a8f87-065e-4eb0-826d-366360a4979e', '1674166f-9653-48b1-a9a2-c55c905af95a', 'first_start_time', 'first_start_time', 4
	UNION
	SELECT 'a9d3c772-0bf9-45e5-b9db-68e6129f9f14', '1674166f-9653-48b1-a9a2-c55c905af95a', 'last_start_time', 'last_start_time', 4
-- C.Replicas
	UNION
	SELECT '5ee6092d-b2d6-46e8-8c92-eec91a756c09', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'id', 'id', 14
	UNION
	SELECT '6814c423-a545-46e6-9b99-2555ebdbd65f', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'backup_id', 'backup_id', 14
	UNION
	SELECT '10949532-cb5e-4be2-b8a0-0835aed5d64f', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'object_id', 'object_id', 14
	UNION
	SELECT '5464b450-7d33-4adc-b051-ea9119c91def', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'vm_name', 'vm_name', 12
	UNION
	SELECT '229ef21b-6fe2-4a7a-9ef3-cd9545d76cb7', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'source_location', 'source_location', 12
	UNION
	SELECT 'cfad7ad5-7777-481f-a605-09c68993350b', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'target_location', 'target_location', 12
	UNION
	SELECT '95e00287-62db-4912-93fc-28db7ad40efe', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'target_vm_ref', 'target_vm_ref', 12
	UNION
	SELECT '0124a40a-62f0-47d8-901f-30ef193e911d', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'state', 'state', 8
	UNION
	SELECT 'd8b91c6c-1544-4257-8cef-2befcee8597a', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'target_vm_name', 'target_vm_name', 12
	UNION
	SELECT '04f797d7-1181-4462-9ab9-61e183bfab27', '1da1068a-c643-4aa9-a67b-85b84f248b1c', 'vpn_state', 'vpn_state', 8
-- C.ReplicaConfigurations
	UNION
	SELECT '1f5cf9ca-1062-44be-8fec-c46a6c36c8cf', '1371fd80-79b3-4193-a51f-18ab75c558b2', 'id', 'id', 14
	UNION
	SELECT 'f4c2671c-99a4-4255-a95f-4676e848652b', '1371fd80-79b3-4193-a51f-18ab75c558b2', 'cpuCount', 'cpuCount', 8
	UNION
	SELECT 'b8315c90-9c6e-473c-bb2d-cf189278c921', '1371fd80-79b3-4193-a51f-18ab75c558b2', 'memoryMb', 'memoryMb', 8
	UNION
	SELECT 'be606d77-e0e7-4f39-9b68-eb58aedc388c', '1371fd80-79b3-4193-a51f-18ab75c558b2', 'specific', 'specific', 25
-- C.Backup.Model.ViHardwareQuotaDatastoreUsages
	UNION
	SELECT '66fdfc34-6645-4429-b82e-e7f3c70e5dc4', 'da5b637a-7516-4906-8823-52ee793bd4bb', 'hardwareDatastoreQuotaId', 'hardwareDatastoreQuotaId', 14
	UNION
	SELECT 'e15d7372-bfff-4777-87f6-5fa5e0a86eaf', 'da5b637a-7516-4906-8823-52ee793bd4bb', 'replicaId', 'replicaId', 14
	UNION
	SELECT 'a26abd20-a71a-437b-8a98-f70c417ddaf9', 'da5b637a-7516-4906-8823-52ee793bd4bb', 'usageBytes', 'usageBytes', 0
	UNION
	SELECT '880141df-0ee7-4815-91d3-7fb811712f0e', 'da5b637a-7516-4906-8823-52ee793bd4bb', 'id', 'id', 14
-- C.Backup.Model.HvHardwareQuotaVolumeUsages
	UNION
	SELECT '92a70d7c-5c4d-4f42-9961-b26fea041131', '37c0d950-8467-4207-a0ef-faea4975303d', 'hardwareVolumeQuotaId', 'hardwareVolumeQuotaId', 14
	UNION
	SELECT '13ae8e81-1284-4220-ae2c-3b2ac6f7714f', '37c0d950-8467-4207-a0ef-faea4975303d', 'replicaId', 'replicaId', 14
	UNION
	SELECT '4d7ffb8c-27ce-47c7-b272-ba8b14dc24e7', '37c0d950-8467-4207-a0ef-faea4975303d', 'usageBytes', 'usageBytes', 0
	UNION
	SELECT '3125d5b7-5bed-4716-91dc-a3d486ca7fbd', '37c0d950-8467-4207-a0ef-faea4975303d', 'id', 'id', 14
-- C.Backup.Model.ViHardwareQuotaDatastores
	UNION
	SELECT '834f9602-3a8a-4bce-93ec-734f4cd61bb6', 'e908e7a9-7a34-4793-82db-43749944be3d', 'id', 'id', 14
	UNION
	SELECT '76f949cb-7cc3-4c5a-a25d-20f2b8b00ad1', 'e908e7a9-7a34-4793-82db-43749944be3d', 'hardwarePlanDatastoreId', 'hardwarePlanDatastoreId', 14
	UNION
	SELECT 'e4b0d39e-a313-4dc6-816d-a1dea8852924', 'e908e7a9-7a34-4793-82db-43749944be3d', 'hardwareQuotaId', 'hardwareQuotaId', 14
	UNION
	SELECT '8a27e79f-b09a-499f-aa4e-bf03ca63096c', 'e908e7a9-7a34-4793-82db-43749944be3d', 'relativePath', 'relativePath', 12
-- C.Backup.Model.HvHardwareQuotaVolumes
	UNION
	SELECT '9c7bbc46-3a0c-4363-b86c-1f56e5e67f22', 'b34892f4-ac31-4968-8f9b-f8009fd4fe38', 'id', 'id', 14
	UNION
	SELECT 'ec9d2f88-3a83-48cf-bee5-bae8fa6b3581', 'b34892f4-ac31-4968-8f9b-f8009fd4fe38', 'hardwarePlanVolumeId', 'hardwarePlanVolumeId', 14
	UNION
	SELECT '8ae24144-9cf3-4295-b4ba-ff59ea2c1ff5', 'b34892f4-ac31-4968-8f9b-f8009fd4fe38', 'hardwareQuotaId', 'hardwareQuotaId', 14
	UNION
	SELECT 'f5998073-eb7c-44c7-bd28-f7daab72c228', 'b34892f4-ac31-4968-8f9b-f8009fd4fe38', 'relativePath', 'relativePath', 12
-- C.Backup.Model.ViCloudQuotaObjects
	UNION
	SELECT '56247dc2-333c-4953-8620-1e6a76407973', '9e632ecf-6527-40af-935e-a1e88351a1d5', 'object_id', 'object_id', 14
	UNION
	SELECT 'c70b8fe1-d317-40fc-ba09-8940e3d167fd', '9e632ecf-6527-40af-935e-a1e88351a1d5', 'quota_id', 'quota_id', 14
	UNION
	SELECT 'afd5a626-7eb2-4cba-870b-6367fda6c9f6', '9e632ecf-6527-40af-935e-a1e88351a1d5', 'id', 'id', 14
-- C.Backup.Model.HvCloudQuotaObjects
	UNION
	SELECT '13b105c2-d393-483c-9526-1881dd92863d', '4d690c23-32db-45c6-bd5c-118b150f4d3b', 'object_id', 'object_id', 14
	UNION
	SELECT 'b3e3d1f4-6359-4350-885c-599bd8cecb8f', '4d690c23-32db-45c6-bd5c-118b150f4d3b', 'quota_id', 'quota_id', 14
	UNION
	SELECT '170a3e8c-ce25-484c-8fa9-9d6ec40977b6', '4d690c23-32db-45c6-bd5c-118b150f4d3b', 'id', 'id', 14
-- C.Backup.Model.CloudLicensedObjects
	UNION
	SELECT '067337e1-ccbb-4b52-9258-fa5768dee99f', '0de70df7-9804-4417-bb93-1c92ed6b82b2', 'object_id', 'object_id', 14
	UNION
	SELECT 'a24e5394-213b-4e1c-a0d5-814f7a9e0a0a', '0de70df7-9804-4417-bb93-1c92ed6b82b2', 'number', 'number', 0
	UNION
	SELECT '4abdd9be-6ad4-4e37-a315-601770ebc861', '0de70df7-9804-4417-bb93-1c92ed6b82b2', 'id', 'id', 14
-- C.Backup.Model.CloudSessionsOnViHardwareQuotas
	UNION
	SELECT 'cb92337f-054d-4e71-ac6f-c674de9fd5e2', '58d00f78-f139-42a2-b027-5f7662b372dc', 'session_id', 'session_id', 14
	UNION
	SELECT 'c808d242-c9e5-4715-9d62-b000aa2d5763', '58d00f78-f139-42a2-b027-5f7662b372dc', 'quota_id', 'quota_id', 14
	UNION
	SELECT '1408116a-a28d-4db8-a967-94bf567708d1', '58d00f78-f139-42a2-b027-5f7662b372dc', 'id', 'id', 14
-- C.Backup.Model.CloudSessionsOnHvHardwareQuotas
	UNION
	SELECT 'ee498b51-810e-4231-88d3-bd7f029b05f0', '37d44463-a699-4ca5-b2ea-9132e5b7daaf', 'session_id', 'session_id', 14
	UNION
	SELECT '68e41826-dfb5-4bb4-a79f-215ef3a4efa8', '37d44463-a699-4ca5-b2ea-9132e5b7daaf', 'quota_id', 'quota_id', 14
	UNION
	SELECT '7252ffc1-77bb-42a8-815f-0f64a2a0d3cc', '37d44463-a699-4ca5-b2ea-9132e5b7daaf', 'id', 'id', 14

--70.Backup.Model.Backups
	union
	select '346bff3c-683a-4543-99fe-50cd92548698','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','id','id','14'
	union
	select 'de405038-b0f0-4d80-96e9-58c4a4405812','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','job_id','job_id','14'
	union
	select 'a516a727-5d7f-46b0-9fb6-cde145d3c0b1','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','job_name','job_name','12'
	union
	select 'c480b08b-8f36-46e4-88d5-a9cd01ea6cac','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','job_source_type','job_source_type','8'
	union
	select '87f8350f-b4bc-4b6d-88a1-c4e7377e1b01','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','job_target_type','job_target_type','8'
	union
	select 'b5e9ba6c-b673-4a42-9813-4df3230e0617','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','job_target_host_id','job_target_host_id','14'
	union
	select 'f7f1ec79-d726-4c38-b945-8a30d665e679','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','job_target_host_protocol','job_target_host_protocol','8'
	union
	select '6B9B12C3-D0FF-42AB-AB6A-1C425BFE44EF','51e173b5-9861-4d84-b4aa-dbf0ac0e3422','platform','platform','8'
	union
	select 'c44cce3d-208b-4814-bc31-9d21f606edb7', '51e173b5-9861-4d84-b4aa-dbf0ac0e3422', 'repository_id', 'repository_id', '14'
	


	--70.Backup.Model.Storages
	union
	select '5b93ce1f-9c45-4ad1-85b4-cd54a342b51c','429b9f57-c345-4b29-afc6-75a0677af118','id','id','14'
	union
	select 'd81546b3-b4d0-4e55-82b0-68ace3e69ba0','429b9f57-c345-4b29-afc6-75a0677af118','file_path','file_path','12'
	union
	select '80742a3a-434c-4ddf-bd3a-c8cf6566095f','429b9f57-c345-4b29-afc6-75a0677af118','backup_id','backup_id','14'
	union
	select 'c31e6235-0261-4c8f-97b5-f14342058b80','429b9f57-c345-4b29-afc6-75a0677af118','host_id','host_id','14'
	union
	select 'd90ed96b-42c0-494f-87b6-64014f77d4fd','429b9f57-c345-4b29-afc6-75a0677af118','creation_time','creation_time','4'
	union
	select '3de4d71f-ff6a-48d2-bea0-e0af660e0128','429b9f57-c345-4b29-afc6-75a0677af118','modification_time','modification_time','4'
	union
	select 'b0ddf22c-827f-4a50-9c9a-09ddb5229099','429b9f57-c345-4b29-afc6-75a0677af118','stats','stats','25'
	union
	select 'bd7796c9-5a3f-4875-8e14-5342b28ab1ca','429b9f57-c345-4b29-afc6-75a0677af118','version','version','8'
	union
	select 'd5403390-8b97-4006-bb3b-975d36ef799e','429b9f57-c345-4b29-afc6-75a0677af118','block_size','block_size','8'
	union
		
	--70.Backup.Model.Points
	select 'f505faca-7de6-40ed-bae9-ec3503f96c09','b9031345-6254-49bb-ad16-75b5ed1253ee','id','id','14'
	union
	select '2913942a-16ee-431f-8b50-ea6f424271c5','b9031345-6254-49bb-ad16-75b5ed1253ee','link_id','link_id','14'
	union
	select 'b8782495-509b-4eca-bdff-beee4c5b9643','b9031345-6254-49bb-ad16-75b5ed1253ee','creation_time','creation_time','4'
	union
	select '09cd6b1e-4458-4f95-9601-d124184bb20c','b9031345-6254-49bb-ad16-75b5ed1253ee','type','type','8'
	union
	select '1934ff48-7b99-4e99-a9ea-c6d2d39e4fbb','b9031345-6254-49bb-ad16-75b5ed1253ee','alg','alg','8'
	union
	select '0c8d0a7d-d514-484e-bc58-490162144b7b','b9031345-6254-49bb-ad16-75b5ed1253ee','group_id','group_id','14'
	union
	select '6ac64c22-8606-4a48-abdd-dc2084b6ea7d','b9031345-6254-49bb-ad16-75b5ed1253ee','backup_id','backup_id','14'
	union
	select '2f940133-bb24-4ec8-a13e-00abfd8f59fd','b9031345-6254-49bb-ad16-75b5ed1253ee','num','num','5'
	union


	--70.Backup.Model.OIBs
	select 'd65a9274-a7e9-41b4-b78c-68259569be31','6fe0e4cb-1363-45b8-9886-1349368972a3','id','id','14'
	union
	select 'f96a9a83-fde1-4110-8b9b-4f022aa01a6e','6fe0e4cb-1363-45b8-9886-1349368972a3','object_id','object_id','14'
	union
	select '9aed57a2-9169-4228-84af-f9179c7d3020','6fe0e4cb-1363-45b8-9886-1349368972a3','point_id','point_id','14'
	union
	select '8aca59ab-791f-42b8-9592-79d3b3322acb','6fe0e4cb-1363-45b8-9886-1349368972a3','storage_id','storage_id','14'
	union
	select '1f7783b5-0373-43d8-a078-50359d508582','6fe0e4cb-1363-45b8-9886-1349368972a3','link_id','link_id','14'
	union
	select 'baa927c5-7bf4-4705-95cb-fcc70736cd19','6fe0e4cb-1363-45b8-9886-1349368972a3','is_corrupted','is_corrupted','2'
	union
	select 'da7eb9e9-dade-4302-8e69-8c5e4d28291a','6fe0e4cb-1363-45b8-9886-1349368972a3','is_consistent','is_consistent','2'
	union
	select 'c651a0a5-3f70-4739-b93f-08235161f648','6fe0e4cb-1363-45b8-9886-1349368972a3','state','state','8'
	union
	select '2a61ee23-49ff-452f-ab5f-8c2b20f746ec','6fe0e4cb-1363-45b8-9886-1349368972a3','type','type','8'
	union
	select '9ad45f17-9c46-40bf-930e-4d04f97da515','6fe0e4cb-1363-45b8-9886-1349368972a3','alg','alg','8'
	union
	select '83c04cc2-60e7-49c8-b9ba-c7e67e0cf217','6fe0e4cb-1363-45b8-9886-1349368972a3','inside_dir','inside_dir','12'
	union
	select 'ed230870-b559-47b8-b490-121143f956b1','6fe0e4cb-1363-45b8-9886-1349368972a3','creation_time','creation_time','4'
	union
	select '1888aa42-6ea9-4c07-9163-56f2458a2569','6fe0e4cb-1363-45b8-9886-1349368972a3','vmname','vmname','12'
	union
	select 'd3697afa-351b-474a-8478-6fec5f9fb154','6fe0e4cb-1363-45b8-9886-1349368972a3','guest_os_info','guest_os_info','25'
	union
	select 'e91164bf-c94b-4b26-9f6f-9a6683bd39d7','6fe0e4cb-1363-45b8-9886-1349368972a3','memory','memory','0'
	union
	select '785db358-61d6-4403-bb5c-0b41f44c7245','6fe0e4cb-1363-45b8-9886-1349368972a3','approx_size','approx_size','0'
	union
	select '2ad12fdd-04a8-401a-9019-ed93a6042838','6fe0e4cb-1363-45b8-9886-1349368972a3','process_id','process_id','8'
	union
	select '5e4aa7f1-1c6e-4d35-b446-20a4656b477c','6fe0e4cb-1363-45b8-9886-1349368972a3','has_index','has_index','2'
	union
	select '095b675e-f6d6-468f-9207-58822da0aaf3','6fe0e4cb-1363-45b8-9886-1349368972a3','aux_data','aux_data','25'
	union
	select '359ED193-8209-42B5-92BE-93DFDE9DC05B','6fe0e4cb-1363-45b8-9886-1349368972a3','parent_id','parent_id','14'
	union
	select '5FF3EAD7-B07C-4606-837E-BBA15387C255','6fe0e4cb-1363-45b8-9886-1349368972a3','has_exchange','has_exchange','2'	
	UNION
	SELECT '5eaf2fc2-a47a-4556-a470-746d1c2f3915', '6fe0e4cb-1363-45b8-9886-1349368972a3', 'display_name', 'display_name', '12'
	UNION
	SELECT 'A2525B47-19E3-45E5-94C2-BC14EA230875', '6fe0e4cb-1363-45b8-9886-1349368972a3', 'original_oib_id', 'original_oib_id', '14'

	--70.Folder_Host
	union
	select 'd605e07b-6e34-44cf-bf65-1bbdfa490cfb','caf74948-e076-4841-b07b-22cb02e7c8ff','id','id','14' union 
	select 'b672f4ae-bf84-43a2-9b62-fb8e976c35f0','caf74948-e076-4841-b07b-22cb02e7c8ff','folder_id','folder_id','14'  union 
	select '449d0167-28a2-442e-aac1-3381c1c836ef','caf74948-e076-4841-b07b-22cb02e7c8ff','host_id','host_id','14' union
	--70.ObjectsInJobs
	select 'd410d3b7-285e-4e74-916f-be8fe3b08341','eef2831c-dea1-42f6-8695-2c552e7c438b','id','id','14' union
	select 'a30b4316-e20e-4f5f-ae00-d44a9d26597b','eef2831c-dea1-42f6-8695-2c552e7c438b','job_id','job_id','14' union
	select '04ce17d2-b3d7-48e5-a314-e94ba037d2ba','eef2831c-dea1-42f6-8695-2c552e7c438b','object_id','object_id','14' union
	select '273c3eed-dffd-427c-82f2-aafeffea0116','eef2831c-dea1-42f6-8695-2c552e7c438b','folder_id','folder_id','14' union
	select '3d483139-4700-40f2-bd6e-f7607ba12536','eef2831c-dea1-42f6-8695-2c552e7c438b','vss_options','vss_options','25' union
	select '86ddc659-31a1-4633-81d7-85b432a321fe','eef2831c-dea1-42f6-8695-2c552e7c438b','approx_size','approx_size','0' union
	select '2ed4944f-a91a-400d-b803-33c2b801bdaa','eef2831c-dea1-42f6-8695-2c552e7c438b','location','location','12' union
	select 'fad326dd-f716-42c0-910e-33678bb78751','eef2831c-dea1-42f6-8695-2c552e7c438b','type','type','8' union
	select '01C9B060-C10A-4E8C-B44A-B9169F0C4576','eef2831c-dea1-42f6-8695-2c552e7c438b','order_no','order_no','8' union
	--70.Soap_creds
	select '109ee0c4-dbf1-4c05-944f-fc266b950b75','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','id','id','14' union
	select 'd2491d5b-d50d-4473-895a-72b86ed5d148','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','host_id','host_id','14' union
	select 'b34cf2b6-6e2e-460d-8754-1022f4a5ca56','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','port','port','8' union
	-- select '26528357-cfda-4edc-85e0-80c93a0e436d','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','user','user','12' union
	select 'bb763f0e-e335-4afd-bc7f-357ac3ef034b','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','savepassword','savepassword','2' union
	select '85cf48e8-368f-44f8-9792-2f58a0ed55c6','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','useproxy','useproxy','2' union
	select 'd337e704-72c4-48b8-9453-60be61d58e49','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','proxyip','proxyip','12' union
	select 'cef46bd3-9066-4db9-8798-f6a966f62707','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','proxyport','proxyport','8' union
	select '43933777-a1d8-44f9-837f-166ae7feb6ae','aa3d66b0-70cf-44ce-a487-fa0d01c0645e','enabled','enabled','2' union
	select '05375480-3363-4de5-ac0d-d0add8601c81','aa3d66b0-70cf-44ce-a487-fa0d01c0645e', 'creds', 'creds', '14' union
	--70.BJobs
	select '804770a2-cbe8-46f0-80c7-42326101aaa5','a9bac128-2cd0-4209-9160-7440a032a305','id','id','14' union
	select '4a511954-48d0-41a1-8176-e80a5fb329f9','a9bac128-2cd0-4209-9160-7440a032a305','type','type','8' union
	select 'a672ad50-a461-40f8-9a6f-9d00a730aeb4','a9bac128-2cd0-4209-9160-7440a032a305','name','name','12' union
	select 'e3eeaa18-d208-4c86-9473-6dead9c9ec68','a9bac128-2cd0-4209-9160-7440a032a305','target_host_id','target_host_id','14' union
	select '224efef6-36a3-4ed4-995d-ebe6725ea74c','a9bac128-2cd0-4209-9160-7440a032a305','target_dir','target_dir','12' union
	select 'fa730d81-9b60-495f-870b-81bff5920414','a9bac128-2cd0-4209-9160-7440a032a305','target_file','target_file','12' union
	select '30b25037-932b-4944-8b2c-48f4e09dfccf','a9bac128-2cd0-4209-9160-7440a032a305','options','options','25' union
	select '9e7b2101-d9f6-4de4-b2a4-7831c03dc2c9','a9bac128-2cd0-4209-9160-7440a032a305','schedule','schedule','25' union
	select '9f1583fb-199e-4c3e-852d-4816d8389f65','a9bac128-2cd0-4209-9160-7440a032a305','is_deleted','is_deleted','2' union
	select '4e1ab7dc-61ee-4a3e-b1f2-0d4698cefbfb','a9bac128-2cd0-4209-9160-7440a032a305','latest_result','latest_result','8' union
	-- select '5cddb14c-54ed-4e00-b966-8f7eba1cd016','a9bac128-2cd0-4209-9160-7440a032a305','post_command_run_count','post_command_run_count','8' union
	select '63226132-0CE7-4760-95B1-6223AD1736EC','a9bac128-2cd0-4209-9160-7440a032a305','target_type', 'target_type', '8' union
	select '2BC755CC-0ACC-4477-B1BD-81947B193882','a9bac128-2cd0-4209-9160-7440a032a305','platform', 'platform', '8' union
	select '8CFBFCA5-C589-479D-9310-B6239986200C','a9bac128-2cd0-4209-9160-7440a032a305','vss_options', 'vss_options', '25' union
	select 'F87FCB6F-9C75-4B2B-857B-A9CFCA75C931','a9bac128-2cd0-4209-9160-7440a032a305','vcb_host_id', 'vcb_host_id', '14' union
	select '1220AAEC-A5FB-4708-805C-165F08C7F2FA','a9bac128-2cd0-4209-9160-7440a032a305','description', 'description', '12' union
	select 'D3ADB1F0-C22F-4694-B3EA-9237A3E7F064','a9bac128-2cd0-4209-9160-7440a032a305','schedule_enabled', 'schedule_enabled', '2' union
	select '1CC59396-DDCB-4FA2-B733-714ED8AE6B0D','a9bac128-2cd0-4209-9160-7440a032a305','parent_schedule_id', 'parent_schedule_id', '14' union

	--select '6ed378d4-ff43-485b-9421-5caf024047b5','a9bac128-2cd0-4209-9160-7440a032a305','control','control','8' union
	select '007F725F-DC09-4161-8265-0180B2D4F43A', 'a9bac128-2cd0-4209-9160-7440a032a305', 'repository_id', 'repository_id', '14' union
	--70.BObjects
	select 'ce26fbaf-ef3b-4b6c-9f67-198e70dc6fbe','3b530c7f-d127-4204-a96c-5e795dd94b10','id','id','14' union
	select '40a3b330-cb53-4904-85a6-e725eedb7de6','3b530c7f-d127-4204-a96c-5e795dd94b10','type','type','8' union
	select '6f28ec78-2300-4e62-8320-99c9e8d13c34','3b530c7f-d127-4204-a96c-5e795dd94b10','host_id','host_id','14' union
	select 'c3b8057c-07e8-460f-9583-29d59a205b98','3b530c7f-d127-4204-a96c-5e795dd94b10','object_name','object_name','12' union
	select '1408071e-0df0-4b92-a4cc-c50a23426924','3b530c7f-d127-4204-a96c-5e795dd94b10','object_id','object_id','12' union
	select 'a0fe1e63-2cda-47d3-831a-e4e344d8d929','3b530c7f-d127-4204-a96c-5e795dd94b10','viobject_type','viobject_type','12' union
	select '3f15fede-6eb0-458f-9b13-607c216a685c','3b530c7f-d127-4204-a96c-5e795dd94b10','guest_os','guest_os','25' union
	select 'BC079BC7-D68B-40B1-AF88-384C2C9DE0AE', '3b530c7f-d127-4204-a96c-5e795dd94b10', 'path', 'path', '12' union
	select '190F76F9-0314-4B1B-A168-1BA8FFA865A3', '3b530c7f-d127-4204-a96c-5e795dd94b10', 'platform', 'platform', '8' union
	select 'DEC7E800-9FCE-4098-9325-63FD2FFFBEF7', '3b530c7f-d127-4204-a96c-5e795dd94b10', 'uuid', 'uuid', '12' union
	select '9A68D87C-567E-41AE-B73B-AF6038A9E2E2', '3b530c7f-d127-4204-a96c-5e795dd94b10', 'unique_key_hash', 'unique_key_hash', '21' union
	select '9F1CC3C6-B003-4EF7-888D-40DA4BBBBFE5', '3b530c7f-d127-4204-a96c-5e795dd94b10', 'display_name', 'display_name', '12' union
	--70.Ssh_creds
	select '61845370-eff4-40f4-841f-f9275db9a784','75fb1228-0262-4141-b337-bec9a7ebfa2c','id','id','14' union
	select '7b1dd275-98d3-4935-baa9-b4be8970879b','75fb1228-0262-4141-b337-bec9a7ebfa2c','host_id','host_id','14' union
	-- select '5a2390ce-9133-4c31-a407-6b560ee0958a','75fb1228-0262-4141-b337-bec9a7ebfa2c','user','user','12' union
	select '9d1a561d-41f1-4b2a-be0b-130979826d6d','75fb1228-0262-4141-b337-bec9a7ebfa2c','savepassword','savepassword','2' union
	select '1fda99f8-7ef1-4cc1-8be0-bce05c949650','75fb1228-0262-4141-b337-bec9a7ebfa2c','elevatetoroot','elevatetoroot','2' union
	select '7970ec6d-6855-4f28-9a16-595edfead037','75fb1228-0262-4141-b337-bec9a7ebfa2c','port','port','8' union
	select '2e6776ee-ba23-49fb-9fa6-b947dcb129b3','75fb1228-0262-4141-b337-bec9a7ebfa2c','startftport','startftport','8' union
	select 'bc137a37-4f59-431a-8b69-498e67137ce5','75fb1228-0262-4141-b337-bec9a7ebfa2c','endftport','endftport','8' union
	select '38dc1699-0772-4b90-a7bc-c5c1ed41bb0f','75fb1228-0262-4141-b337-bec9a7ebfa2c','buffersize','buffersize','8' union
	select '0c52d84e-a5d4-48e6-83e8-3b9bc5c54307','75fb1228-0262-4141-b337-bec9a7ebfa2c','isftserver','isftserver','2' union
	select 'c01a27bd-346f-4819-b64c-bc61116f1635','75fb1228-0262-4141-b337-bec9a7ebfa2c','timeout','timeout','8' union
	select '5894b460-a563-46b1-86f5-1f76aa7a2cd9','75fb1228-0262-4141-b337-bec9a7ebfa2c','adjust_firewall','adjust_firewall','2' union
	select '205cc1aa-c8a1-4098-958c-4a857176c1f7','75fb1228-0262-4141-b337-bec9a7ebfa2c','auto_sudo','auto_sudo','2' union
	select 'fbe5b113-335c-4a09-af56-75abd0766bdf','75fb1228-0262-4141-b337-bec9a7ebfa2c','enabled','enabled','2' union	
	select '2de3dc1b-feda-4a48-8ea5-f611f7cc7d99','75fb1228-0262-4141-b337-bec9a7ebfa2c', 'creds', 'creds', '14' union
	--70.LicensedHosts
	select 'a272284e-359b-4a93-abd3-ef283a3f149e','8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','id','id','14' union
	select '4e1fecf1-5a82-4344-98be-99c928a6af20','8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','uuid','uuid','12' union
	select '7d3f3adc-ceeb-4dc7-930b-3c50c1a5fdd9','8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','name','name','12' union
	select 'c96c8116-103d-4155-8626-cfce25d675d4','8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','cpu','cpu','8' union
	select 'd22257c8-e68b-4e59-a78b-6bcc353300d9','8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','type','type','8' union
	select '9C8F1099-6894-4bcb-9737-1FD4DA79B43D','8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','lic_edition','lic_edition','8' union
	select '70896404-020B-49af-8514-4E0E976EB4D3','8a4a893e-f7a9-4142-91e6-8d118e6dbd0c','is_licensed','is_licensed','2' union
	select '8CE278B8-34BC-4900-BCDD-876474B7C124', '8a4a893e-f7a9-4142-91e6-8d118e6dbd0c', 'cores', 'cores', '8' union
	select '0A7A5A8E-8D07-4700-87E6-2F89D01A98AE', '8a4a893e-f7a9-4142-91e6-8d118e6dbd0c', 'lic_tier', 'lic_tier', '8' union
	--70.Hosts
	select '4a69d856-62ee-44fb-9012-c731621ba956','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','id','id','14' union
	select 'f4de5cce-ef39-415e-91bc-8d02a26db86c','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','type','type','8' union
	select 'ed8ed0b2-9dca-4e9d-ae2a-cc194522b46a','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','name','name','12' union
	select '596bde24-da7c-44a2-b4ab-595ecd3c103d','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','ip','ip','12' union
	select 'ab010739-dcb7-46f9-bafe-71f113c7d60d','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','parent_id','parent_id','14' union
	select '0cda18b9-cabb-4e69-b0dd-528c0e54af90','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','info','info','12' union
	select '3436b0a6-73a9-4608-b53a-14dcdd44b7d5','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','description','description','12' union
	select '85ecb569-424b-4f34-bb43-19e2a91dcfb4','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','protocol','protocol','8' union
	select 'b5d28756-a441-4ab8-b3c1-cf3be3683eff','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','reference','reference','12' union
	select '405586fd-225a-4edf-91d8-7ad5492834d3','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','api_version','api_version','8' union
	select 'DF1F97E7-3B66-4c71-BD32-AE26B10938CC','dab7e9e8-af9b-47e6-90c3-eebc6e05a025','win_creds','win_creds','25' union
	select '08715472-9419-4eee-8AB6-BFA4A1CB2626', 'dab7e9e8-af9b-47e6-90c3-eebc6e05a025', 'physical_host_id', 'physical_host_id', '14' union 
	select 'EC49C70A-DF16-4858-833D-1F0851CCD328', 'dab7e9e8-af9b-47e6-90c3-eebc6e05a025', 'host_instance_id', 'host_instance_id', '12' union
	
	--70.Folders
	select '257e33fe-4b87-4519-a635-88195f3e06ef','9c547b18-cca0-42a6-b5ce-e62003468612','id','id','14' union
	select 'cd92d770-b331-45a2-a192-21271f0e13fb','9c547b18-cca0-42a6-b5ce-e62003468612','parent_id','parent_id','14' union
	select '8b02a74a-5d4f-4e2a-99d9-1e50bb1b21fa','9c547b18-cca0-42a6-b5ce-e62003468612','name','name','12' union

	--70.HostsByJobs
	select 'F73C2B71-07C1-4a10-9027-BCA8EA0B43F5','4D698E5F-CE7C-44dd-9588-880E6245C322','id','id','14' union
	select 'BF252188-B42B-40dd-9325-7FE0F41C338B','4D698E5F-CE7C-44dd-9588-880E6245C322','host_id','host_id','14' union
	select 'E384C6E2-3136-414a-9091-4A9138970A89','4D698E5F-CE7C-44dd-9588-880E6245C322','job_id','job_id','14' union
	select '63BD0F4C-474D-4d24-8644-D9C1F059932F','4D698E5F-CE7C-44dd-9588-880E6245C322','uuid','uuid','14' union
	
	--70.VirtualLabs
	select '556bfcf2-2b61-46bb-a861-8b81ce7ba39e','bee28906-9676-407b-b8c4-3892b09f1265','id','id','14'
	union
	select '69f8828b-a6eb-4c39-9573-800925ed1c3d','bee28906-9676-407b-b8c4-3892b09f1265','name','name','12'
	union
	select 'a828d316-7d04-4578-825c-7bcc1933ee48','bee28906-9676-407b-b8c4-3892b09f1265','description','description','12'
	union		
	select '4e5a5fd8-5987-40ff-9eac-1e4edfb0a7a5','bee28906-9676-407b-b8c4-3892b09f1265','host_id','host_id','14'	
	union
	select '22648776-6c8e-4310-aa50-6262c979556e','bee28906-9676-407b-b8c4-3892b09f1265','vm_ref','vm_ref','12'

	--DRObjectsInFolders
	union
	select '4f870698-9ff4-4a8a-a68e-7833e7087a90','67534bb6-4347-473d-a78c-37a7261e5944','id','id','14'
	union
	select 'acef95ea-604a-4409-9bb1-e58bb6322639','67534bb6-4347-473d-a78c-37a7261e5944','folder_id','folder_id','14'
	union
	select '3f6f22b4-dc95-4d69-9449-bef682d5d485','67534bb6-4347-473d-a78c-37a7261e5944','object_id','object_id','14'
	union
	select '0a47953e-939a-4393-8c93-baaff72856ae','67534bb6-4347-473d-a78c-37a7261e5944','order','order','8'
	union
	select '0f2a6b7c-34f2-44a8-9745-5569e497448f','67534bb6-4347-473d-a78c-37a7261e5944','guest_os_info','guest_os_info','25'
	union
	select '618ca478-d1d7-4da0-9919-10659b1779b0','67534bb6-4347-473d-a78c-37a7261e5944','effective_memory','effective_memory','0'
	union
	select 'c67e0b88-3f8e-4750-9d41-5bbbda7e0ac6','67534bb6-4347-473d-a78c-37a7261e5944','options','options','25'	
	--70.DRRoles
	union
	select 'ba3ef157-008e-47b0-b33e-4cf5771bef01','e41fdf30-772b-47cf-8f49-bfa3ebc16997','id','id','14'
	union
	select '2a12f6ac-63ae-436a-a098-e3a98795c774','e41fdf30-772b-47cf-8f49-bfa3ebc16997','name','name','12'
	union
	select '95c1619e-169d-4f9d-a3e8-438a41c5ed3a','e41fdf30-772b-47cf-8f49-bfa3ebc16997','effective_memory','effective_memory','0'
	union
	select '2c9429b8-72c6-4aa0-a254-7e71d316256f','e41fdf30-772b-47cf-8f49-bfa3ebc16997','boot_delay','boot_delay','8'
	union
	select 'd2eafce3-81db-449c-8f44-e3376528c6da','e41fdf30-772b-47cf-8f49-bfa3ebc16997','test_script_file_full_name','test_script_file_full_name','12'
	union
	--70.Backup.Model.SbTaskSessions
	select '18942363-d8a8-4394-aa8c-54224262f798','cb3509b8-37cc-4129-bcc4-0945b14731f1','id','id','14'
	union
	select '7f999f11-11fb-4934-a9e4-3aab4e63278e','cb3509b8-37cc-4129-bcc4-0945b14731f1','drsession_id','drsession_id','14'
	union
	select '20f500d4-65db-435e-b7d4-a9b409a10bee','cb3509b8-37cc-4129-bcc4-0945b14731f1','type','type','8'
	union
	select '2ba52dbc-d1d5-40a0-9219-5347c4a55e87','cb3509b8-37cc-4129-bcc4-0945b14731f1','object_name','object_name','12'
	union
	select 'f581fa45-ea36-4ecf-86e3-054d5267923e','cb3509b8-37cc-4129-bcc4-0945b14731f1','object_id','object_id','14'
	union
	select 'e56e4bef-8d05-4145-8a83-59d834ea4d3f','cb3509b8-37cc-4129-bcc4-0945b14731f1','oib_id','oib_id','14'
	union
	select '9e838839-68cc-48c1-a5eb-826a645f2986','cb3509b8-37cc-4129-bcc4-0945b14731f1','overall_status','overall_status','8'
	union
	select '3429fe67-bf5f-45fe-a66d-089221570d5f','cb3509b8-37cc-4129-bcc4-0945b14731f1','description','description','12'
	union
	select 'eaad5dbf-dcee-4c91-a4a6-2eb446bf152a','cb3509b8-37cc-4129-bcc4-0945b14731f1','start_time','start_time','4'
	union
	select '02846d7b-9c42-4bd5-8486-4e70f35ed65b','cb3509b8-37cc-4129-bcc4-0945b14731f1','finish_time','finish_time','4'
	union
	select 'b55beb94-7f6b-42d8-bbfa-4974060e3dd5','cb3509b8-37cc-4129-bcc4-0945b14731f1','total_steps','total_steps','8'
	union
	select '9ad0bc6b-d91b-40ec-9856-f815b221a706','cb3509b8-37cc-4129-bcc4-0945b14731f1','processed_steps','processed_steps','8'
	union
	select 'a086304e-24a7-49ec-ba76-0d131ccc825c','cb3509b8-37cc-4129-bcc4-0945b14731f1','powerOn_status','powerOn_status','8'
	union
	select 'b346e98f-2db2-4c94-8a53-6d33ff61087b','cb3509b8-37cc-4129-bcc4-0945b14731f1','heartbeat_status','heartbeat_status','8'
	union
	select '7b04a65d-d106-4792-9e60-171921415911','cb3509b8-37cc-4129-bcc4-0945b14731f1','ping_status','ping_status','8'
	union
	select 'f6f6de3c-05d5-4027-a618-e3560714261c','cb3509b8-37cc-4129-bcc4-0945b14731f1','test_script_status','test_script_status','8'
	union
	select '202a128b-5094-46a7-9d78-c1cda882e971','cb3509b8-37cc-4129-bcc4-0945b14731f1','powerOff_status','powerOff_status','8'
	union
	select 'b8508e0b-f4fd-4817-bda8-bb1bbdf2f87e','cb3509b8-37cc-4129-bcc4-0945b14731f1','test_script_error_code','test_script_error_code','8'
	union
	select '6864f9d5-7c62-4bd7-b452-24d99a7f6b5e','cb3509b8-37cc-4129-bcc4-0945b14731f1','vm_ref','vm_ref','12'
	union
	select '09ad84cd-8061-4b21-be07-4999ccd95709','cb3509b8-37cc-4129-bcc4-0945b14731f1','percent','percent','8'
	union
	select '4bb1cb66-80b1-409c-9088-1c8efdb6ceed','cb3509b8-37cc-4129-bcc4-0945b14731f1','appliance_ip','appliance_ip','12'
	union
	select '28cb0aa0-b272-4e42-8e28-1df41f219e19','cb3509b8-37cc-4129-bcc4-0945b14731f1','subnet_ip','subnet_ip','12'
	union
	select '3cf33e3a-0b60-469d-b4bb-21103bea3509','cb3509b8-37cc-4129-bcc4-0945b14731f1','subnet_mask','subnet_mask','12'
	union
	select 'ad79906d-5226-4116-a783-de2bfeb8b4c6','cb3509b8-37cc-4129-bcc4-0945b14731f1','vm_external_ip','vm_external_ip','12'
	union
	select '881e666e-3ceb-43dd-99b0-25b78f6e3456','cb3509b8-37cc-4129-bcc4-0945b14731f1','state','state','8'
	union
	select '57859bd7-7679-4d4a-b3a9-014b4cd28788','cb3509b8-37cc-4129-bcc4-0945b14731f1','order_num','order_num','8'
	union
	select '2ebbcef6-f9f7-455d-a85e-8efb8ef20369','cb3509b8-37cc-4129-bcc4-0945b14731f1','control','control','8'
	union
	select '68dc3088-c62e-438d-a1ef-f8c10d1901fe','cb3509b8-37cc-4129-bcc4-0945b14731f1','leave_powered_on','leave_powered_on','2'
	union
	select 'c21c314a-1443-4c79-b430-f4fca06f42fa','cb3509b8-37cc-4129-bcc4-0945b14731f1','oiag_id','oiag_id','14'
	union
	select '2d1e7fc4-3abc-422f-b288-10d0c87686cc','cb3509b8-37cc-4129-bcc4-0945b14731f1','restore_counter','restore_counter','8'
	union
	select '749a4341-e34d-4d78-9e08-f3d0d18bbea0','cb3509b8-37cc-4129-bcc4-0945b14731f1','test_scripts_results','test_scripts_results','25'
	union
	select '24357646-7DEE-4A6F-B7FF-34C7A09230E3','cb3509b8-37cc-4129-bcc4-0945b14731f1','validation_status','validation_status','8'
	union 
	select '30B19D07-F804-45E1-94FC-F630FED8BFDA','cb3509b8-37cc-4129-bcc4-0945b14731f1','usn','usn','0'
	--70.Backup.Model.JobSessions
	union
	select 'd649568d-cee7-4a07-ae01-a1dbb62f1504','a112794c-ec45-40a1-bc1d-04a4c5727828','id','id','14'
	union
	select '0dded64f-dca7-4c2f-a805-4a3fd50e189d','a112794c-ec45-40a1-bc1d-04a4c5727828','job_id','job_id','14'
	union
	select '041d2350-0584-4da0-bc11-390acf2cd8f6','a112794c-ec45-40a1-bc1d-04a4c5727828','job_name','job_name','12'
	union
	select 'f90c98d5-b6c9-4459-acd6-8746c03615c2','a112794c-ec45-40a1-bc1d-04a4c5727828','job_type','job_type','8'
	union
	select 'c380b6e3-f094-4ec2-924d-895a22052288','a112794c-ec45-40a1-bc1d-04a4c5727828','creation_time','creation_time','4'
	union
	select '21dfaa7e-4d4c-460f-a170-a2a82b2fba09','a112794c-ec45-40a1-bc1d-04a4c5727828','end_time','end_time','4'
	union
	select '70319ed0-357f-46c5-9346-755e35ec23e7','a112794c-ec45-40a1-bc1d-04a4c5727828','state','state','8'
	union
	select '8e19d491-9a2a-4af3-a7d7-4113b992cb4c','a112794c-ec45-40a1-bc1d-04a4c5727828','result','result','8'
	union
	select 'dc1b9831-9129-42a3-9677-d1daa60f3b6c','a112794c-ec45-40a1-bc1d-04a4c5727828','control','control','8'
	union
	select '96af60cd-1d04-4ca7-b95d-d61aadb02b1b','a112794c-ec45-40a1-bc1d-04a4c5727828','description','description','18'
	union
	select '5306ccd2-511e-435a-81f9-c527a4fe2077','a112794c-ec45-40a1-bc1d-04a4c5727828','operation','operation','12'
	union
	select 'fd787f42-b11b-4580-b2d6-29afdadae64b','a112794c-ec45-40a1-bc1d-04a4c5727828','progress','progress','8'
	union
	select '7a90cf3f-7934-4734-9c85-14b8c7c3224e','a112794c-ec45-40a1-bc1d-04a4c5727828','log_xml','log_xml','25'
	union
	select 'D244BF87-F1FD-4310-AE44-B60A3FC73A3D','a112794c-ec45-40a1-bc1d-04a4c5727828','reason','reason','11'
	union
	select '04D3B562-CAFF-412F-9C3C-F2B703F43DB5','a112794c-ec45-40a1-bc1d-04a4c5727828','usn','usn','0'

	--70.Backup.Model.SbSessions
	union
	select 'ce291a20-bbc9-4430-afbe-f4f76deb4790','0cb8315b-ba1c-4e76-b8b9-0e03a156f967','id','id','14'
	union
	select '69a523e5-4152-4761-9749-65ef97fdea18','0cb8315b-ba1c-4e76-b8b9-0e03a156f967','preferred_date','preferred_date','4'
	--70.Backup.Model.BackupJobSessions
	union
	select '4a0a5b7d-980b-4e16-ac8b-dc203a8b68a1','3121a39d-833c-446b-8017-f6f37423425b','id','id','14'
	union
	select '1f8334a5-f178-46b9-84af-38dd1545d10d','3121a39d-833c-446b-8017-f6f37423425b','is_retry','is_retry','2'
	union
	select '961dec2f-5602-4fc1-9c6a-ac480366508f','3121a39d-833c-446b-8017-f6f37423425b','total_objects','total_objects','8'
	union
	select '6b607317-322b-4953-8dc6-246ee614f112','3121a39d-833c-446b-8017-f6f37423425b','processed_objects','processed_objects','8'
	union
	select '9426e67a-7f03-4de1-bf4e-08e75c2156c3','3121a39d-833c-446b-8017-f6f37423425b','total_size','total_size','0'
	union
	select '753b1ef9-913b-4ee7-bf69-b6ff286011ef','3121a39d-833c-446b-8017-f6f37423425b','processed_size','processed_size','0'
	union
	select '1f2bdd4e-1e5f-4caf-a1e3-bd741519387b','3121a39d-833c-446b-8017-f6f37423425b','job_source_type','job_source_type','8'
	union
	select 'a3ff7091-4344-4c72-8fa9-b9c8e003cf81','3121a39d-833c-446b-8017-f6f37423425b','avg_speed','avg_speed','0'
	union
	select 'b4390975-ad12-4fcb-9f0e-0012b7a9744c','3121a39d-833c-446b-8017-f6f37423425b','is_startfull','is_startfull','2'
	union 
	select '6F122186-6EB9-40DE-A7CF-191B027DE8FE', '3121a39d-833c-446b-8017-f6f37423425b','stored_size','stored_size','0'
	union
	select '08AC6555-46E6-4C8D-A8FE-6215D1A40F6D', '3121a39d-833c-446b-8017-f6f37423425b','cur_point_id','cur_point_id','14'
	union
	select '9BF1E44B-07E6-49F2-9981-D0559E358A84', '3121a39d-833c-446b-8017-f6f37423425b','usn','usn','0'
--70.Backup.Model.BackupTaskSessions
	union
	select '89824039-b952-4a92-bd4d-1161da58aa90','13989ab6-d7b7-46ef-a39a-f5f188acfecc','id','id','14'
	union
	select '2e860fe3-3173-4af0-bf94-a73dbd75469b','13989ab6-d7b7-46ef-a39a-f5f188acfecc','session_id','session_id','14'
	union
	select 'f71839ff-4e2b-4fa1-bc77-b48c0bff9cd9','13989ab6-d7b7-46ef-a39a-f5f188acfecc','creation_time','creation_time','4'
	union
	select '7f747409-cc4e-4ea7-ad61-226af26dd603','13989ab6-d7b7-46ef-a39a-f5f188acfecc','object_name','object_name','12'
	union
	select '73fa196f-42f5-4814-ed62-7d66789d14a7', '13989ab6-d7b7-46ef-a39a-f5f188acfecc','log_xml', 'log_xml', 25
	union
	select 'b5f362ad-B03e-44d5-B72c-9658b4ec5B82', '13989ab6-d7b7-46ef-a39a-f5f188acfecc','read_size', 'read_size', 0
	union
	select '3501a6d9-574b-40a2-99f7-e6b37cf6ff14','13989ab6-d7b7-46ef-a39a-f5f188acfecc','status','status','8'
	union
	select 'acd0a145-fa80-4f54-8745-d1724b038919','13989ab6-d7b7-46ef-a39a-f5f188acfecc','reason','reason','11'
	union
	select 'd84b62d5-4759-4027-9c9b-98a53001bdd2','13989ab6-d7b7-46ef-a39a-f5f188acfecc','object_id','object_id','14'
	union
	select '2a12ed84-54fc-4006-8c7e-1dc96328029e','13989ab6-d7b7-46ef-a39a-f5f188acfecc','end_time','end_time','4'
	UNION
	SELECT '4387FF3A-9692-4C8A-8ABB-4E3FE25DC2A5','13989ab6-d7b7-46ef-a39a-f5f188acfecc','stored_size','stored_size', 0
	union
	select 'a2068f3f-2940-4c42-bc3b-1d17bbed0b59','13989ab6-d7b7-46ef-a39a-f5f188acfecc','operation','operation','12'
	union
	select '60069e69-9841-4d10-b482-b814dcadeecc','13989ab6-d7b7-46ef-a39a-f5f188acfecc','total_objects','total_objects','8'
	union
	select 'cffbce44-51a8-418f-badd-a60a866fd117','13989ab6-d7b7-46ef-a39a-f5f188acfecc','processed_objects','processed_objects','8'
	union
	select '1dfe51c8-f6ac-4927-975d-bbc32cc23db2','13989ab6-d7b7-46ef-a39a-f5f188acfecc','total_size','total_size','0'
	union
	select 'e41cc871-f8d5-4a52-b0e2-13271e42eccf','13989ab6-d7b7-46ef-a39a-f5f188acfecc','processed_size','processed_size','0'
	union
	select 'a26691f2-efe4-4604-9c98-b5267573f40a','13989ab6-d7b7-46ef-a39a-f5f188acfecc','mode','mode','8'
	union
	select 'eb855baa-f6da-4e0c-a12a-f29f15b496f1','13989ab6-d7b7-46ef-a39a-f5f188acfecc','avg_speed','avg_speed','0'
	union
	select '264544a7-0dc9-47cb-bb30-d44424dafd18','13989ab6-d7b7-46ef-a39a-f5f188acfecc','change_tracking','change_tracking','2'
	union
	select 'A434822D-5063-4A14-B7CD-33738DAAE406','13989ab6-d7b7-46ef-a39a-f5f188acfecc','usn','usn','0'

	--70.LinkedJobs
	union
	select 'd21fa730-176b-4cf7-a73f-9bc2cfbc110c','4a7c0dbd-f0d0-4b30-9185-2af22bec06db','id','id','14'
	union
	select '9e3f8863-a694-467a-98a2-9312bba2bed4','4a7c0dbd-f0d0-4b30-9185-2af22bec06db','job_id','job_id','14'
	union
	select '902a6836-ab40-4afe-8a5e-b77c7cbb2078','4a7c0dbd-f0d0-4b30-9185-2af22bec06db','linked_job_id','linked_job_id','14'


	--70.Backup.Model.RestoreJobSessions
	union 
	select '041125C7-B468-4D52-9420-53F36A5D32B3', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'id', 'id','14'
	union 
	select '86BB14AF-0721-4628-A18B-0826E891B6FB', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'action',  'action', '8'
	union 
	select '9A6DD810-1934-4497-8140-C40FD0463EF0', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'usn', 'usn', '0'
	union 
	select 'EA4D07F8-50C4-4AB1-8EB9-835522A3FA54', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'options','options', '25'
	union
	select '5F926A7A-7A4C-4507-9D5A-D6EFF3CF43F2', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'initiator_sid', 'initiator_sid', '12'
	union 
	select '867BDD7F-A2F3-4FF5-83F1-BDF8EFC553B0', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'initiator_name','initiator_name',  '12'
	union 
	select 'D247FA22-B6AA-4107-AADA-14AA410507F1', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'files_log_xml', 'files_log_xml','25'
	union 
	select '6351FA43-6F6C-42DA-B024-8269A630399D', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'platform', 'platform', '8'
	union 
	select '9A4C8E9F-8E09-4A2F-B6BA-1C85F2C8AC95', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'multi_restore_id', 'multi_restore_id','14'
	union 
	select '2AE6662B-8515-4710-8905-F547B3433D98', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'restore_type', 'restore_type', '8'
	union 
	select 'C945743F-0EC0-41FE-9F51-7ACE8DD01753', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'oib_id', 'oib_id', '14'
	union 
	select 'B39F4BE1-6FFC-4743-B4B8-BA55AA87C6B5', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'is_internal', 'is_internal', '2'
	union 
	select '94EB32DE-663D-497D-8F6F-B1A77E05E47E', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'oib_display_name', 'oib_display_name', '12'
	union 
	select 'D420E9F8-3561-40D6-A4E5-6E0E75DD7069', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'oib_creation_time', 'oib_creation_time', '4'
	union 
	select '63763DFF-AED8-4C44-9C23-79248AE2C208', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'sub_type', 'sub_type', '8'	
	union
	select 'ee454880-7c70-4f76-a984-266acfea8fc6', '1fafb90e-bc5f-436f-a5c8-4f01055bab0e', 'reason', 'reason', '12'

-- 70.Backup.Model.RestoreTaskSessions
	union 
	select '603261CC-4E59-4ED4-AA61-B3A874F8CC02', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'id', 'id','14'
	union 
	select '59F9032C-EF57-4D49-AF15-9A38984B8CE1', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'session_id', 'session_id','14'
	union 
	select 'C2C68ED2-A434-4808-87B4-37CEFE04CA07', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'object_name', 'object_name','12'
	union 
	select '6ADBFD9B-41D7-482F-9BD1-A7EF314DB175', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'object_id', 'object_id','14'
	union 
	select '11905D3D-4370-4377-9A67-7CBCE6FB09CB', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'status', 'status','8'
	union 
	select 'EFEF1B0E-E34E-440B-8D89-B1AA6A4CB164', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'reason', 'reason','11'
	union 
	select '1C15E554-8D8E-421C-82B4-FB8E96CE4EFD', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'creation_time', 'creation_time','4'
	union 
	select 'FE968CAC-1ECE-48C2-910B-64692771F64C', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'end_time', 'end_time','4'
	union
	select 'F9509FA2-A346-48CE-868B-6CC98AEAC32A', 'C87A3B0B-2062-4364-BDD5-AC561F94C93A', 'operation', 'operation', '12'

-- 70.BackupProxies
	UNION
	SELECT 'd823af7a-cf20-453f-b23c-92178f53f8e5', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'id', 'id', 14
	UNION
	SELECT 'fb21f7ee-caf0-4b32-a36a-a8814eedacc4', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'name', 'name', 12
	UNION
	SELECT '7c543bfe-0a2f-4b45-8adc-1c50e7ffd9df', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'description', 'description', 12
	UNION
	SELECT '2ecb4841-e109-4a8f-800b-d991b2089667', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'type', 'type', 8
	UNION
	SELECT '09f99469-f6a6-4583-ad2e-2b47da9c718f', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'options', 'options', 25
	UNION
	SELECT '6cbfc2ad-4fd2-4ab4-933c-d02e042babbb', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'disabled', 'disabled', 2
	UNION
	SELECT '57c63256-c247-4140-9868-f174825dcd31', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'is_busy', 'is_busy', 2
	UNION
	SELECT '98fd068f-540d-4207-934f-b0c733c878e0', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'is_unavailable', 'is_unavailable', 2
	UNION
	SELECT 'A93F8CED-F074-4CA1-9A85-1E652044C2E7', 'af2a6be4-8fb6-4a00-9f32-12f144c208a4', 'unique_id', 'unique_id', 14
-- 70.BackupRepositories
	UNION
	SELECT '31ce3564-ee0f-4b14-8a70-edb368ff4c36', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'id', 'id', 14
	UNION
	SELECT '62416a15-b4bf-4125-87b2-dbfe1a16137c', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'name', 'name', 12
	UNION
	SELECT 'f8da6a2b-05b3-44c2-9c30-d18b60e96f4d', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'description', 'description', 12
	UNION
	SELECT '5c995a23-89fa-462d-81c8-10605b802e7c', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'type', 'type', 8
	UNION
	SELECT '1eec5a2a-1a92-449c-af86-cab7ccbd09d4', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'host_id', 'host_id', 14
	UNION
	SELECT 'e51fc0bf-96c5-46a5-b4fc-adc389c8b6a7', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'mount_host_id', 'mount_host_id', 14
	UNION
	SELECT 'dc584927-c5d9-4b67-b9bc-d4429153d041', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'path', 'path', 12
	UNION
	SELECT 'dc9697e5-a06b-4497-950d-9b1a51cb7117', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'options', 'options', 25
	UNION
	SELECT 'e90b278f-c22e-4878-b588-42e348c58ad0', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'is_busy', 'is_busy', 2
	UNION
	SELECT 'ecd5a309-6b03-4298-af98-ae7f7e0196b6', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'is_unavailable', 'is_unavailable', 2
	UNION
	SELECT 'df64db8d-b404-4d6c-9b62-4c4a0358e7de', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'is_full', 'is_full', 2
	UNION
	SELECT '8b9711a6-4da0-4901-a1a3-420b0dd6088c', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'total_space', 'total_space', 0
	UNION
	SELECT 'a80d522f-2d82-4294-a883-81b1d2ff5608', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'free_space', 'free_space', 0
	UNION
	SELECT '731A08CA-B0AB-48C7-873D-5D593F844D97', 'a8a5a240-4cb7-4916-bee6-b9f963ed4f97', 'unique_id', 'unique_id', 14


	-- 70.PhysicalHosts
	union 
	select 'F31671C3-A7E3-4d43-B028-D0AB50392335', 'D927D22E-51A1-4fd1-B87E-69B1DD5D24DC', 'id', 'id', '14'
	union 
	select '9806C86E-FB4C-4089-9A43-EC5A33B8BA57', 'D927D22E-51A1-4fd1-B87E-69B1DD5D24DC', 'name', 'name', '11'
	union 
	select '83495EA2-BEEA-4290-9080-42CFE4CFBF0D', 'D927D22E-51A1-4fd1-B87E-69B1DD5D24DC', 'bios_uuid', 'bios_uuid', '12'

	-- 70.Credentials
	UNION
	SELECT 'ae2ad1e1-71f8-43fc-9549-f8bcd6c86b59', '6dcc5fb4-a702-483a-89b4-0f0ffc74ef08', 'id', 'id', 14
	UNION
	SELECT 'd37b49b4-6546-47ae-8c13-82462753bf24', '6dcc5fb4-a702-483a-89b4-0f0ffc74ef08', 'user_name', 'user_name', 12
	-- 70.JobVssCredentials
	UNION 
	SELECT '91D857BF-8543-43F6-AAA6-24547D2EC9A1', '61CEED55-5A94-487D-B85E-266AA1CF4E51', 'id', 'id', 14
	UNION 
	SELECT 'E7C458C2-38D1-49C6-AFF6-C687C3439080', '61CEED55-5A94-487D-B85E-266AA1CF4E51', 'job_id', 'job_id', 14
	UNION 
	SELECT '4A7C8A63-F444-45B0-8D85-BA227295A141', '61CEED55-5A94-487D-B85E-266AA1CF4E51', 'oij_id', 'oij_id', 14
	UNION 
	SELECT '0611363B-0F9E-4C9B-99B2-180B3D234A8A', '61CEED55-5A94-487D-B85E-266AA1CF4E51', 'credentials_id', 'credentials_id', 14

	-- 80. Column bindings
-- 80.Folder_Host
	UNION
	SELECT 'f27c7ddb-4282-4b65-994b-52866c8b7149', '237e5135-4917-443b-9808-a055a77398ee', 'id', 'id', 14
	UNION
	SELECT '142b09f1-f761-456d-9123-55041ce92b2f', '237e5135-4917-443b-9808-a055a77398ee', 'host_id', 'host_id', 14
	UNION
	SELECT '8207860d-9b1e-46b0-8079-189e6a9c4876', '237e5135-4917-443b-9808-a055a77398ee', 'folder_id', 'folder_id', 14
-- 80.ObjectsInJobs
	UNION
	SELECT '387da831-41a8-46a8-9955-43f82eb823dd', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'type', 'type', 8
	UNION
	SELECT '96d50868-92e9-4e28-81d5-d62cc6d34c29', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'location', 'location', 12
	UNION
	SELECT 'eacee41b-db99-4064-8237-5f925b734e21', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'approx_size', 'approx_size', 0
	UNION
	SELECT '0c79c624-9a1a-4ea6-a7f6-63e990a05064', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'folder_id', 'folder_id', 14
	UNION
	SELECT '513a6c90-9150-4618-9526-6c5f9210e1ca', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'id', 'id', 14
	UNION
	SELECT '473123ae-d0fb-43a9-a51a-9c5d3ee502a9', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'job_id', 'job_id', 14
	UNION
	SELECT 'cc91ef7c-c3fe-4591-b26d-c362d8fa3c36', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'object_id', 'object_id', 14
	UNION
	SELECT '9c88ee4d-0343-4ea3-a367-dc050bef2b03', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'vss_options', 'vss_options', 25
	UNION
	SELECT '03105140-83c0-432a-984c-c9435bbf6d97', '49dabcdd-daca-4094-ac31-8c10e73b3143', 'order_no', 'order_no', 8
-- 80.Soap_creds
	UNION
	SELECT 'd7cd442d-092c-4fb4-803e-f7511f6c1bdc', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'port', 'port', 8
	UNION
	SELECT 'f8d7de8b-885a-437a-9d40-9f7200ec7dac', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'enabled', 'enabled', 2
	UNION
	SELECT 'aa8ff765-1b0e-4942-a7a1-6a7161f47ab0', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'useproxy', 'useproxy', 2
	UNION
	SELECT 'dea2d2a4-424b-4543-af52-36d9668d8b89', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'savepassword', 'savepassword', 2
	UNION
	SELECT '3a5a8952-6808-4826-93b0-806f51ddcd8e', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'proxyip', 'proxyip', 12
	UNION
	SELECT '3f5b3504-5c92-4552-8e39-47ea8d18cf69', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'host_id', 'host_id', 14
	UNION
	SELECT 'f14f9294-25fb-440f-b986-328c81f68d22', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'proxyport', 'proxyport', 8
	UNION
	SELECT '39adf070-611a-4e65-93d5-9d50d95b47ba', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'id', 'id', 14
	UNION
	SELECT 'bf7cd8d7-192f-4bd2-bb1f-741878eae566', '99644d75-8c81-4d96-964a-c52dd7f5b073', 'creds', 'creds', 14
-- 80.BJobs
	UNION
	SELECT '53bfd682-e327-4b7e-a474-c01ccc5ff550', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'latest_result', 'latest_result', 8
	UNION
	SELECT 'c18db87d-040b-4bf8-9042-cc82c856c30f', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'target_type', 'target_type', 8
	UNION
	SELECT '28ff8be4-b84f-4583-a498-619f621096ab', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'id', 'id', 14
	UNION
	SELECT 'a7024d99-7976-4c21-94c2-06edebb4e372', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'is_deleted', 'is_deleted', 2
	UNION
	SELECT 'f4b7366e-fffb-46f6-91ef-ff1ea85de251', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'options', 'options', 25
	UNION
	SELECT '2a8aaa13-21bb-4d7f-a3b9-e04c27a0c0ed', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'platform', 'platform', 8
	UNION
	SELECT '7f236268-ec08-4b2c-baee-e66380d6b568', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'target_host_id', 'target_host_id', 14
	UNION
	SELECT 'f8f4de75-9820-4cf4-aaf4-171cbc4dcc88', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'schedule', 'schedule', 25
	UNION
	SELECT 'a633b3e3-f608-4603-b48b-6d9e4fc59073', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'vss_options', 'vss_options', 25
	UNION
	SELECT '9607db20-9e4c-4f87-aad3-f1b8e48f91ba', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'target_file', 'target_file', 12
	UNION
	SELECT '1dcad2be-8af9-438f-9187-dc334fb4ab86', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'vcb_host_id', 'vcb_host_id', 14
	UNION
	SELECT 'ce4afba9-1d52-4d3d-9342-6cc61b3a3546', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'description', 'description', 12
	UNION
	SELECT 'a533131b-e096-4bcc-93dc-7ef973805cc7', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'name', 'name', 12
	UNION
	SELECT '898908f1-6753-4716-86bd-d6d13f8aecad', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'schedule_enabled', 'schedule_enabled', 2
	UNION
	SELECT '00202213-853f-4b40-87b8-12ce3b71e555', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'type', 'type', 8
	UNION
	SELECT '7bc37b3c-c4ba-4306-84e5-72633bbbab74', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'target_dir', 'target_dir', 12
	UNION
	SELECT 'd05a0066-e724-4e22-9661-ce8fd58a6114', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'parent_schedule_id', 'parent_schedule_id', 14
	UNION
	SELECT '563908ce-5ed2-4f8b-b317-4fe66af50731', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'repository_id', 'repository_id', 14
	UNION
	SELECT '8e40b678-eb2f-44f5-aec0-5f70d43b632e', 'c14c5a70-6b80-415b-8c48-81e4bfb5e057', 'pwd_key_id', 'pwd_key_id', 14
-- 80.BObjects
	UNION
	SELECT '4d9c7881-c364-4b01-abbf-d83d868364b1', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'id', 'id', 14
	UNION
	SELECT '677bb80d-9e0c-4560-80d7-4e1d06b9de69', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'object_name', 'object_name', 12
	UNION
	SELECT '135d9fcb-ccbf-45f8-a7d7-bfc9172095c5', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'guest_os', 'guest_os', 25
	UNION
	SELECT '116ccd97-c16a-427d-ae4c-b1b31f63bc4f', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'host_id', 'host_id', 14
	UNION
	SELECT '2a50fb9e-c6f3-484c-81dd-42e24b3aad8b', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'object_id', 'object_id', 12
	UNION
	SELECT '4bddcb14-cee1-475b-8126-9a009da329c8', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'viobject_type', 'viobject_type', 12
	UNION
	SELECT '7f8c58ce-3902-42e5-8643-504285dbfd7b', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'type', 'type', 8
	UNION
	SELECT '774fea95-0663-401c-b2ac-235628f01839', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'unique_key_hash', 'unique_key_hash', 21
	UNION
	SELECT '98f8ec86-3801-4d1b-a8b4-640f70e66d36', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'display_name', 'display_name', 12
	UNION
	SELECT 'd2bc7ba9-00ff-44c1-9dda-4e0a6cec5361', 'd180ef4d-e1f4-4973-804a-0da8c108731c', 'platform', 'platform', 8
-- 80.Backup.Model.Backups
	UNION
	SELECT 'da8a350c-75ac-4adf-a3ec-2e9ecf580f9a', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'job_source_type', 'job_source_type', 8
	UNION
	SELECT '676d418b-ebcc-459e-a1af-516b7d1e70d4', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'id', 'id', 14
	UNION
	SELECT 'e91bc5c3-a28a-42a7-b184-114d71b2fd98', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'job_name', 'job_name', 12
	UNION
	SELECT 'bcb9ec3f-9c6d-4db2-a1b2-aaf58f3fcc87', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'job_target_host_protocol', 'job_target_host_protocol', 8
	UNION
	SELECT '91302c43-018d-4005-b586-75698ea4045c', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'job_target_host_id', 'job_target_host_id', 14
	UNION
	SELECT 'dee4d32f-2e4d-4a9f-a892-1c1fa65f2da5', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'job_target_type', 'job_target_type', 8
	UNION
	SELECT 'eaffc400-b24b-408d-bc98-1a41ceac5c83', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'job_id', 'job_id', 14
	UNION
	SELECT 'a06f8570-8bf5-40f6-a7e8-13eda2571fd1', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'repository_id', 'repository_id', 14
	UNION
	SELECT '4946d309-060f-4767-9044-a4f509316456', 'f205250c-89b8-4bb3-9428-4065a79a785d', 'platform', 'platform', 8
-- 80.Backup.Model.Storages
	UNION
	SELECT 'b9c4d740-02a9-48f3-845d-6af38901f981', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'block_size', 'block_size', 8
	UNION
	SELECT '44ec2427-92e9-495f-9c05-13f4c87e3e71', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'backup_id', 'backup_id', 14
	UNION
	SELECT 'f2276ec3-d78f-4938-be3a-560834ada02c', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'stats', 'stats', 25
	UNION
	SELECT '5eafb161-260b-419f-8f55-a6aa898420f5', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'modification_time', 'modification_time', 4
	UNION
	SELECT '37bfa8fb-ba74-4d6c-b3cd-71c356b9610b', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'version', 'version', 8
	UNION
	SELECT 'cbd58aec-74ba-4398-8d33-1fb081989eaa', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'id', 'id', 14
	UNION
	SELECT 'ab460882-6265-4eb3-babf-08212396c284', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'file_path', 'file_path', 12
	UNION
	SELECT '82f30b54-06bf-4448-88d5-b94cd03f4ee5', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'creation_time', 'creation_time', 4
	UNION
	SELECT '268dfc1b-325e-4d9e-9d8b-e113eb7c8c51', 'f18c93c2-ce09-4773-8898-82e7180b7b5b', 'host_id', 'host_id', 14
-- 80.HostsByJobs
	UNION
	SELECT '59265d43-7c25-4929-8525-f1653c4429a4', 'e4660122-40a4-4123-b028-169f641f152d', 'job_id', 'job_id', 14
	UNION
	SELECT 'b2abf333-74f3-407d-a482-6dd698c77a3d', 'e4660122-40a4-4123-b028-169f641f152d', 'host_id', 'host_id', 14
	UNION
	SELECT '499afca4-809e-4240-af8f-88a752d214f7', 'e4660122-40a4-4123-b028-169f641f152d', 'id', 'id', 14
-- 80.Backup.Model.Points
	UNION
	SELECT 'e2cce4d1-7ab0-4d7b-b80a-977059cedc5e', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'link_id', 'link_id', 14
	UNION
	SELECT '3634c9c0-7745-4279-bd21-c2e15fcc10c7', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'num', 'num', 5
	UNION
	SELECT '7909253a-f854-4323-9e3a-e38ee6f2af00', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'id', 'id', 14
	UNION
	SELECT 'f0c985ae-0650-4218-a55f-6498bb7e97d7', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'alg', 'alg', 8
	UNION
	SELECT 'e6a974f6-9c87-492f-a272-2e6c21921b17', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'backup_id', 'backup_id', 14
	UNION
	SELECT '787b1fc0-cd37-42d5-8459-10ba7fb1633c', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'group_id', 'group_id', 14
	UNION
	SELECT 'd7226403-4283-4316-a5e7-c3fbf4293ac6', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'type', 'type', 8
	UNION
	SELECT '1ca6723b-4f9d-4b1d-9e88-566f31e1588d', '3f7c451b-7919-4102-a1a8-62a4d14d8af6', 'creation_time', 'creation_time', 4
-- 80.Ssh_creds
	UNION
	SELECT 'affbbafa-8a0d-48ab-bffa-eedd1cda67ce', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'adjust_firewall', 'adjust_firewall', 2
	UNION
	SELECT '223d28e7-2b6a-4050-b502-e14af309c542', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'isftserver', 'isftserver', 2
	UNION
	SELECT 'a8d9408c-03e3-40c3-a740-930cae637733', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'endftport', 'endftport', 8
	UNION
	SELECT '8062ae41-0108-4e42-bd36-1d4a9310c2af', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'auto_sudo', 'auto_sudo', 2
	UNION
	SELECT '8e7a3b10-3926-42b4-88f9-c667edf00544', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'port', 'port', 8
	UNION
	SELECT 'b6127124-f748-48bf-ad39-59cc31ace129', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'enabled', 'enabled', 2
	UNION
	SELECT '43427b11-eadd-44c7-8148-c3b36d041b92', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'startftport', 'startftport', 8
	UNION
	SELECT 'a19bd251-3c07-4e06-8fc2-abdd512f5dfb', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'timeout', 'timeout', 8
	UNION
	SELECT '42eca5cd-c65c-43c0-ae19-46e5fef08930', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'elevatetoroot', 'elevatetoroot', 2
	UNION
	SELECT 'eef2c60a-6e26-4874-b40f-891cb784f30a', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'buffersize', 'buffersize', 8
	UNION
	SELECT '06ee1e11-1d3e-400e-ac9d-17b715118dbb', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'id', 'id', 14
	UNION
	SELECT 'e46e633a-b4d4-42d6-bdbb-40ad69a42721', '3a44dfc3-6e09-4f4b-b588-d9d387d23040', 'creds', 'creds', 14
-- 80.Backup.Model.OIBs
	UNION
	SELECT '16dd74a4-24e9-4f6e-9de4-c48e7b301983', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'has_index', 'has_index', 2
	UNION
	SELECT '56a8127f-26f9-42ad-ac42-4fdcb8bb0631', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'has_exchange', 'has_exchange', 2
	UNION
	SELECT 'f408cf78-8e72-459c-9b62-892fafdc571a', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'type', 'type', 8
	UNION
	SELECT '1db4c1e0-1295-4522-ae02-7f0e27ca03f0', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'is_corrupted', 'is_corrupted', 2
	UNION
	SELECT '43346dea-fe7b-44df-bc5e-1175a285f357', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'alg', 'alg', 8
	UNION
	SELECT 'c5458d48-273f-4ada-ab8d-16c14fd95125', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'creation_time', 'creation_time', 4
	UNION
	SELECT 'd585e814-c3bb-46d4-9ddd-1a3295af0f15', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'is_consistent', 'is_consistent', 2
	UNION
	SELECT 'dcf0a759-15c9-4e00-8131-c716ba02395d', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'storage_id', 'storage_id', 14
	UNION
	SELECT '97ad3bec-35ce-414e-9760-37f0ee76c1f6', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'inside_dir', 'inside_dir', 12
	UNION
	SELECT '71852bc9-d26f-4479-928c-7bbd48e53b4b', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'state', 'state', 8
	UNION
	SELECT 'a31e659c-a842-440c-b105-df390239415f', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'id', 'id', 14
	UNION
	SELECT 'd4ee83a9-4cde-49ca-ae33-34cd23a42888', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'guest_os_info', 'guest_os_info', 25
	UNION
	SELECT 'b8c6080e-c384-4458-844a-e0183afc7a9d', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'memory', 'memory', 0
	UNION
	SELECT 'af125a74-c714-4e14-8141-4c2a6419cc81', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'point_id', 'point_id', 14
	UNION
	SELECT '51583a41-80eb-4e42-8edf-0a8803c7ed71', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'link_id', 'link_id', 14
	UNION
	SELECT '1695a4d2-eaf3-42e4-9f37-b28b2722b189', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'approx_size', 'approx_size', 0
	UNION
	SELECT 'ad5bc978-b418-4a90-9091-e685acb66543', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'vmname', 'vmname', 12
	UNION
	SELECT 'c309e126-ceaf-462c-a676-4cffa42697f3', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'process_id', 'process_id', 8
	UNION
	SELECT '3aaad4a5-504d-4c6a-a5e2-b5a505cef7e0', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'object_id', 'object_id', 14
	UNION
	SELECT '2e23e71a-9e93-4bac-b0ff-f27d1c7dc3db', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'aux_data', 'aux_data', 25
	UNION
	SELECT '70abf643-11d7-4c62-a3ab-41e9afbf2bc6', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'display_name', 'display_name', 12
	UNION
	SELECT 'c1269819-30be-4a37-b0a1-12395ef8d837', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'original_oib_id', 'original_oib_id', 14
	UNION
	SELECT 'e79d7b2b-e0b8-466c-86d5-e1780c478f84', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'fqdn', 'fqdn', 12
	UNION
	SELECT '65494ffe-e82f-432d-a122-aaf7238472d8', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'has_sql', 'has_sql', 2
	UNION
	SELECT '95d7afff-1f21-46cc-aff3-2cd423896fda', '8d8379ea-b485-4797-88dd-950fa8e7019c', 'parent_id', 'parent_id', 14
-- 80.LicensedHosts
	UNION
	SELECT '2c7fa777-e1e0-4d07-97f6-c48532f30ea5', '398759f0-ec62-4428-96b1-146e9efe2af1', 'lic_edition', 'lic_edition', 8
	UNION
	SELECT '707d75db-3490-476f-a8bd-819fc45e1145', '398759f0-ec62-4428-96b1-146e9efe2af1', 'is_licensed', 'is_licensed', 2
	UNION
	SELECT 'b3a11546-4d25-4148-a325-6839f0268abe', '398759f0-ec62-4428-96b1-146e9efe2af1', 'type', 'type', 8
	UNION
	SELECT 'cb790405-b454-4583-80dc-3c50c132b3c7', '398759f0-ec62-4428-96b1-146e9efe2af1', 'id', 'id', 14
	UNION
	SELECT '9a24ebfe-b647-4d6a-8320-d1ff659a310c', '398759f0-ec62-4428-96b1-146e9efe2af1', 'physical_host_id', 'physical_host_id', 14
	UNION
	SELECT 'f777f853-ea67-4d6e-ab56-1483d2fda792', '398759f0-ec62-4428-96b1-146e9efe2af1', 'lic_tier', 'lic_tier', 8
-- 80.Hosts
	UNION
	SELECT 'c1136abe-3f54-4239-b5a9-74b6d9534857', '3faba35c-5ebb-4333-9dc7-519267932533', 'description', 'description', 12
	UNION
	SELECT '406a8a3c-50ad-4d6b-8617-b426362efcba', '3faba35c-5ebb-4333-9dc7-519267932533', 'protocol', 'protocol', 8
	UNION
	SELECT '15fc8314-12f6-4972-86a8-6a5ae46ffcdf', '3faba35c-5ebb-4333-9dc7-519267932533', 'info', 'info', 12
	UNION
	SELECT 'f082df37-57d1-44b8-b73f-f46c5f18997d', '3faba35c-5ebb-4333-9dc7-519267932533', 'ip', 'ip', 12
	UNION
	SELECT 'aaad1c6a-c973-4f79-9361-a72e778dc5ff', '3faba35c-5ebb-4333-9dc7-519267932533', 'parent_id', 'parent_id', 14
	UNION
	SELECT 'bfe4f5fa-51d5-4a1f-bbc4-b32f375ec067', '3faba35c-5ebb-4333-9dc7-519267932533', 'api_version', 'api_version', 8
	UNION
	SELECT '1df75c15-19e4-4f44-b570-0e61e127d661', '3faba35c-5ebb-4333-9dc7-519267932533', 'type', 'type', 8
	UNION
	SELECT '305a7a05-7aa1-409a-b757-c182a1c624d6', '3faba35c-5ebb-4333-9dc7-519267932533', 'win_creds', 'win_creds', 25
	UNION
	SELECT '0b33b140-8b29-4a34-8130-a1938cfc0227', '3faba35c-5ebb-4333-9dc7-519267932533', 'id', 'id', 14
	UNION
	SELECT 'fd7ce493-054e-4ebf-8c9b-d0c181a16932', '3faba35c-5ebb-4333-9dc7-519267932533', 'name', 'name', 12
	UNION
	SELECT '24f943aa-8dc6-44e8-aa03-7fcfd4c659c9', '3faba35c-5ebb-4333-9dc7-519267932533', 'reference', 'reference', 12
	UNION
	SELECT '45891ac0-ee98-4e71-b54a-bf7d120054a6', '3faba35c-5ebb-4333-9dc7-519267932533', 'host_instance_id', 'host_instance_id', 22
	UNION
	SELECT '0912975c-113d-414d-b603-c522547f0034', '3faba35c-5ebb-4333-9dc7-519267932533', 'physical_host_id', 'physical_host_id', 14
-- 80.Folders
	UNION
	SELECT 'e806a75a-abb0-4108-93e7-2402f1659abd', '8db93b11-34ef-4403-8a41-ba92e6fed380', 'name', 'name', 12
	UNION
	SELECT '9634f1cc-3fe6-4326-a422-40505b989ce7', '8db93b11-34ef-4403-8a41-ba92e6fed380', 'parent_id', 'parent_id', 14
	UNION
	SELECT 'b0b7b073-4eeb-42dc-948e-4075259f8a03', '8db93b11-34ef-4403-8a41-ba92e6fed380', 'id', 'id', 14
-- 80.VirtualLabs
	UNION
	SELECT '73c4c15d-908b-478a-9dc5-e034917b2de0', '63847daf-ffb9-47eb-9e1e-2e214f0402df', 'host_id', 'host_id', 14
	UNION
	SELECT '7b4e8a2c-0281-4399-ac10-6d63d0b057ae', '63847daf-ffb9-47eb-9e1e-2e214f0402df', 'vm_ref', 'vm_ref', 12
	UNION
	SELECT '5216e9a1-44f5-43cb-a365-564c87a4f022', '63847daf-ffb9-47eb-9e1e-2e214f0402df', 'description', 'description', 12
	UNION
	SELECT '9db73dba-a5d1-4f2f-8f27-0467302a840b', '63847daf-ffb9-47eb-9e1e-2e214f0402df', 'name', 'name', 12
	UNION
	SELECT '6b37174f-2607-48e4-8d0f-44fe6a61904b', '63847daf-ffb9-47eb-9e1e-2e214f0402df', 'id', 'id', 14
-- 80.ObjectsInApplicationGroups
	UNION
	SELECT '48f73c10-181f-4f50-a4cf-05eac0d4cbae', '0ad95260-f574-4d50-9afb-be20bcf294d4', 'effective_memory', 'effective_memory', 0
	UNION
	SELECT '8eec6fb6-9690-4782-8067-353c419f8240', '0ad95260-f574-4d50-9afb-be20bcf294d4', 'guest_os_info', 'guest_os_info', 25
	UNION
	SELECT 'b1ccdc3a-7e2a-45cb-a6c4-324e939ff468', '0ad95260-f574-4d50-9afb-be20bcf294d4', 'options', 'options', 25
	UNION
	SELECT '578000f0-6069-4f55-bb2f-d4bf5b7a7650', '0ad95260-f574-4d50-9afb-be20bcf294d4', 'id', 'id', 14
	UNION
	SELECT 'c88585c8-1af0-4fc1-bc73-06af4b535ab5', '0ad95260-f574-4d50-9afb-be20bcf294d4', 'order', 'order', 8
	UNION
	SELECT '1254a87d-32cb-4a2e-ac39-902bff6c46d5', '0ad95260-f574-4d50-9afb-be20bcf294d4', 'object_id', 'object_id', 14
	UNION
	SELECT '51c1e24d-e946-4298-a713-983774b60a91', '0ad95260-f574-4d50-9afb-be20bcf294d4', 'folder_id', 'folder_id', 14
-- 80.DRRoles
	UNION
	SELECT 'd5c44089-37ea-4816-bd42-a6a800293669', '2a5345b7-74a5-4277-b778-3df1f4d7452a', 'effective_memory', 'effective_memory', 0
	UNION
	SELECT 'cc0ee6ec-130d-4032-a2e6-51431dc4371b', '2a5345b7-74a5-4277-b778-3df1f4d7452a', 'id', 'id', 14
	UNION
	SELECT '596eb569-be87-46dc-bc8d-8e919afba530', '2a5345b7-74a5-4277-b778-3df1f4d7452a', 'boot_delay', 'boot_delay', 8
	UNION
	SELECT '3c19436c-03c7-4650-b83c-b28fd7f7d924', '2a5345b7-74a5-4277-b778-3df1f4d7452a', 'test_script_file_full_name', 'test_script_file_full_name', 12
	UNION
	SELECT '98527334-8104-4c42-b49e-e42a57ff7030', '2a5345b7-74a5-4277-b778-3df1f4d7452a', 'name', 'name', 12
-- 80.Backup.Model.JobSessions
	UNION
	SELECT 'acebfb4a-fa18-4ad4-a9b7-a4725eb74d1d', '1317b265-8218-4580-bc90-16339cee82ef', 'log_xml', 'log_xml', 25
	UNION
	SELECT 'e96cc26e-d278-45b0-b937-88bb291b3bb7', '1317b265-8218-4580-bc90-16339cee82ef', 'progress', 'progress', 8
	UNION
	SELECT 'a0f48c5b-0fe6-47c3-bb7c-5dac3881b53e', '1317b265-8218-4580-bc90-16339cee82ef', 'job_name', 'job_name', 12
	UNION
	SELECT '9d0e547e-f1c0-4bc2-8362-ea84e4b8721e', '1317b265-8218-4580-bc90-16339cee82ef', 'result', 'result', 8
	UNION
	SELECT '6fd8fe98-d95e-4959-bbae-fca4c78ae1b8', '1317b265-8218-4580-bc90-16339cee82ef', 'job_id', 'job_id', 14
	UNION
	SELECT '4e2ef43d-1475-448d-ae10-8a90687d82a6', '1317b265-8218-4580-bc90-16339cee82ef', 'state', 'state', 8
	UNION
	SELECT '52bd84fc-f147-4dd5-b699-52c58acce07f', '1317b265-8218-4580-bc90-16339cee82ef', 'job_type', 'job_type', 8
	UNION
	SELECT '2382092e-f4fc-4eb6-8f4a-850f70ff7cf9', '1317b265-8218-4580-bc90-16339cee82ef', 'creation_time', 'creation_time', 4
	UNION
	SELECT '77eae3c7-7e6a-430f-a99b-f538cc444684', '1317b265-8218-4580-bc90-16339cee82ef', 'id', 'id', 14
	UNION
	SELECT 'e70bfb81-5205-4bb7-a6a7-f44ff825267c', '1317b265-8218-4580-bc90-16339cee82ef', 'end_time', 'end_time', 4
	UNION
	SELECT '2b13a1af-d66b-4d0a-bc8c-aee37f3f38ed', '1317b265-8218-4580-bc90-16339cee82ef', 'operation', 'operation', 12
	UNION
	SELECT 'f5a9c635-c53c-421c-97c9-f8b7edd4421e', '1317b265-8218-4580-bc90-16339cee82ef', 'control', 'control', 8
	UNION
	SELECT 'b0aba127-fcd8-4322-a08c-8995bdef9969', '1317b265-8218-4580-bc90-16339cee82ef', 'description', 'description', 18
	UNION
	SELECT '19184855-f910-4ec5-b1e5-5888bf5944cf', '1317b265-8218-4580-bc90-16339cee82ef', 'usn', 'usn', 0
-- 80.Backup.Model.SbTaskSessions
	UNION
	SELECT '6cefd8dd-11ec-485b-a4a7-affad517f57f', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'order_num', 'order_num', 8
	UNION
	SELECT '8c952515-5bce-4c60-8d86-600f5ed43a6b', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'object_id', 'object_id', 14
	UNION
	SELECT '53fd5e1e-76aa-44b5-9c43-af2bab0726b3', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'description', 'description', 12
	UNION
	SELECT '061ee0f0-8a7a-4e9c-a302-e8c9a2edb630', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'powerOn_status', 'powerOn_status', 8
	UNION
	SELECT 'cd76c156-4b6d-4dfd-b363-96d2a70f9d3c', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'restore_counter', 'restore_counter', 8
	UNION
	SELECT 'cac027bb-5004-48d1-9d62-1f9d0ee736c7', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'ping_status', 'ping_status', 8
	UNION
	SELECT '7642bd30-5816-466c-aeb1-60702de24f85', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'appliance_ip', 'appliance_ip', 12
	UNION
	SELECT '6d8bb69c-9250-40de-9fdc-f267de790823', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'subnet_ip', 'subnet_ip', 12
	UNION
	SELECT '465572c3-2ff5-40ad-884a-982a4e3cb232', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'subnet_mask', 'subnet_mask', 12
	UNION
	SELECT 'edd0f6ef-be4a-4bb0-878b-a250c24a6517', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'vm_ref', 'vm_ref', 12
	UNION
	SELECT 'caff1b70-df7c-4cc0-9634-6f769f224a97', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'state', 'state', 8
	UNION
	SELECT 'e93b2cdb-6c39-4267-b486-85bae696ff2e', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'start_time', 'start_time', 4
	UNION
	SELECT 'fc591ae6-4c32-46fb-af69-fb061c233ee2', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'drsession_id', 'drsession_id', 14
	UNION
	SELECT '6fd33f5d-2c01-41cc-8901-1641f2d3397c', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'total_steps', 'total_steps', 8
	UNION
	SELECT '7e5a04ab-dc7b-47ee-974e-6869a681176d', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'percent', 'percent', 8
	UNION
	SELECT '93af2d0e-9506-49fe-9071-d26270c3d7cc', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'finish_time', 'finish_time', 4
	UNION
	SELECT '63ed5ab4-60d8-4d85-ad4f-ec8d3b9225a1', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'object_name', 'object_name', 12
	UNION
	SELECT '3bc9e8b9-44f4-4660-b1a9-43c6159c5fc3', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'id', 'id', 14
	UNION
	SELECT 'bead2c69-b6f9-4a62-98ac-0b8b318fd1e9', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'oib_id', 'oib_id', 14
	UNION
	SELECT 'b3bebfef-1856-49dd-86f7-590b1ec7b407', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'heartbeat_status', 'heartbeat_status', 8
	UNION
	SELECT '4df6ddce-4bdf-4c36-b80d-f65b0c76344c', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'overall_status', 'overall_status', 8
	UNION
	SELECT 'f393dfc1-e1d7-484a-898b-52ee25d5da4f', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'control', 'control', 8
	UNION
	SELECT 'c81ae028-c4fc-4a89-b26d-2348a587e7a1', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'type', 'type', 8
	UNION
	SELECT '0f7843dc-bfd7-408e-9fad-ede5748e2f9d', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'test_script_error_code', 'test_script_error_code', 8
	UNION
	SELECT 'df8675e1-afad-48d5-a83f-328c8bc8bc7f', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'powerOff_status', 'powerOff_status', 8
	UNION
	SELECT '11861f11-b86a-4e47-84c8-3e7397085230', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'vm_external_ip', 'vm_external_ip', 12
	UNION
	SELECT 'b3599ed9-7679-4da7-b637-9b9216f0dccc', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'test_script_status', 'test_script_status', 8
	UNION
	SELECT '91b14878-e607-41b1-b555-9feba24ab230', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'test_scripts_results', 'test_scripts_results', 25
	UNION
	SELECT 'e854cf20-2199-4115-a084-5ce8bf386d31', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'oiag_id', 'oiag_id', 14
	UNION
	SELECT 'c6852e44-fbba-43a1-bfe8-2e9c727b2ae4', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'processed_steps', 'processed_steps', 8
	UNION
	SELECT '6071f6cf-8ed6-4851-b4f5-5a2b104a72c8', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'leave_powered_on', 'leave_powered_on', 2
	UNION
	SELECT '571340f4-0b64-4cf9-a481-c935af6d9a07', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'validation_status', 'validation_status', 8
	UNION
	SELECT '1cc4787e-de4d-4480-ac70-4c0bce21f50d', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'log_xml', 'log_xml', 25
	UNION
	SELECT 'b35e08f4-4ba9-400c-b0e2-c3750ec345fd', '3d9919f8-ba39-4ccd-9ee0-9d8f6d44fd0f', 'usn', 'usn', 0
-- 80.Backup.Model.SbSessions
	UNION
	SELECT 'fa58beaa-9dd0-4581-8865-ff1645230198', '05a7d244-a0b3-463c-a246-14a79085a198', 'preferred_date', 'preferred_date', 4
	UNION
	SELECT 'a7bbfc73-9c32-4b74-8cc6-29a2b1e89230', '05a7d244-a0b3-463c-a246-14a79085a198', 'id', 'id', 14
-- 80.Backup.Model.BackupJobSessions
	UNION
	SELECT 'e632d900-5e07-44cb-935e-84b0bd9ef05b', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'is_full', 'is_full', 2
	UNION
	SELECT '0b806eed-ff8e-419f-a818-ff474d028d94', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'total_size', 'total_size', 0
	UNION
	SELECT 'ee3b338b-8312-4c31-8ab2-b1d93032155d', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'processed_objects', 'processed_objects', 8
	UNION
	SELECT '01d29b5f-c385-4932-ab0f-79796d9e4169', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'is_retry', 'is_retry', 2
	UNION
	SELECT 'a76f2e34-e830-477a-b984-6085ffcdcd8a', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'total_objects', 'total_objects', 8
	UNION
	SELECT '6cfdbf02-085f-4521-b94c-9c2de09d183f', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'processed_size', 'processed_size', 0
	UNION
	SELECT '2aab0cb1-2a42-4a67-82ad-fdac4460f42c', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'avg_speed', 'avg_speed', 0
	UNION
	SELECT '7f87427d-83c1-44da-a452-1fecd3897887', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'job_source_type', 'job_source_type', 8
	UNION
	SELECT 'd8fcd339-de08-4783-89be-d14e08328c46', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'id', 'id', 14
	UNION
	SELECT 'e469df77-23ef-451c-a7e0-be173784d712', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'stored_size', 'stored_size', 0
	UNION
	SELECT 'a4dc2ec7-ea10-4bf7-a293-a9f7fea605f9', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'is_active_full', 'is_active_full', 2
	UNION
	SELECT '1aa7584c-7d06-4afb-9784-89055c692c9d', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'cur_point_id', 'cur_point_id', 14
	UNION
	SELECT 'a47cdbce-a1b7-401d-9a1f-e4399fb407f8', 'd5f7c67f-9d70-48aa-82a8-7029030f225d', 'usn', 'usn', 0
-- 80.Backup.Model.BackupTaskSessions
	UNION
	SELECT '140eb8bb-71a0-4e4a-8df7-c66c56b7be20', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'id', 'id', 14
	UNION
	SELECT '09aa8ee1-762b-4093-8cec-67ef097bdaaf', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'processed_size', 'processed_size', 0
	UNION
	SELECT '4e1a36ff-f8cd-4b0b-b950-4f7c03848bca', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'operation', 'operation', 12
	UNION
	SELECT '7c505262-e5ac-4643-8106-67cbb4202dee', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'end_time', 'end_time', 4
	UNION
	SELECT '8fd46be4-b2f9-4690-8971-c1e168c9ec8d', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'object_name', 'object_name', 12
	UNION
	SELECT 'b2895945-d1d9-4e2e-b356-5f8317eae71a', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'log_xml', 'log_xml', 25
	UNION
	SELECT 'bc831737-5370-49dd-821a-3ef946e5527d', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'read_size', 'read_size', 0
	UNION
	SELECT '49b2877b-e0a8-4cfe-8203-ce4e36dafe77', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'stored_size', 'stored_size', 0
	UNION
	SELECT 'a705b11a-4b8d-4168-b805-f60d40dd8f2f', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'object_id', 'object_id', 14
	UNION
	SELECT 'fd42c8f2-a41a-4d69-8e58-141e6853781c', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'processed_objects', 'processed_objects', 8
	UNION
	SELECT '4b9b6d01-5546-46ad-bf19-b0b7d0db2008', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'session_id', 'session_id', 14
	UNION
	SELECT '56e5d9a7-9047-442a-a9f3-f5a1885fe993', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'creation_time', 'creation_time', 4
	UNION
	SELECT '58a5d607-05e0-48b1-931f-54e18367cb21', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'mode', 'mode', 8
	UNION
	SELECT '2b512707-6a4a-456d-855a-9f6bd62caecc', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'total_objects', 'total_objects', 8
	UNION
	SELECT '868063e2-50ef-466f-914e-d32ead3fe2dd', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'total_size', 'total_size', 0
	UNION
	SELECT '9bae392b-863a-475e-8ceb-7677f7b48b61', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'reason', 'reason', 11
	UNION
	SELECT '8e59b676-fff7-4a5f-ac1f-a502c8521974', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'change_tracking', 'change_tracking', 2
	UNION
	SELECT 'e0cfb302-ad82-4008-8d3e-2aa8db851b1f', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'status', 'status', 8
	UNION
	SELECT 'bb9e2167-e9d2-42c7-b0b9-6fd9812d1712', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'avg_speed', 'avg_speed', 0
	UNION
	SELECT '72f114b4-bd8f-42f1-93d2-abbdd3f578e7', 'c21aeaf3-ed99-41e4-a974-9c9698cc66a9', 'usn', 'usn', 0
-- 80.LinkedJobs
	UNION
	SELECT '20db548e-53fa-4d2d-a52c-ccc91e802360', '556527d7-ca77-418a-8708-77fc740dde4b', 'linked_job_id', 'linked_job_id', 14
	UNION
	SELECT 'f3a20069-7c37-4b95-8341-0a41a8e7cba9', '556527d7-ca77-418a-8708-77fc740dde4b', 'id', 'id', 14
	UNION
	SELECT 'beebfd58-2f19-486e-9914-aa31f0f49548', '556527d7-ca77-418a-8708-77fc740dde4b', 'job_id', 'job_id', 14
-- 80.SbVerificationRules
	UNION
	SELECT 'c2de7db3-c9e5-489f-91b5-b4bedd93364c', '976472bd-4208-42bc-a941-57bc66cad016', 'id', 'id', 14
	UNION
	SELECT 'd27b6d06-3cb3-4c0e-a2f9-ac3c3eda3bf9', '976472bd-4208-42bc-a941-57bc66cad016', 'options', 'options', 25
	UNION
	SELECT '1820d96f-8fa0-4797-9b30-97fefa4387f8', '976472bd-4208-42bc-a941-57bc66cad016', 'job_id', 'job_id', 14
	UNION
	SELECT '33285cfa-68d9-491a-8ed0-609184b11aab', '976472bd-4208-42bc-a941-57bc66cad016', 'object_type', 'object_type', 8
	UNION
	SELECT '5ca74905-aa2c-46fc-8fd4-cc36709ac635', '976472bd-4208-42bc-a941-57bc66cad016', 'object_id', 'object_id', 14
-- 80.BackupProxies
	UNION
	SELECT '74ee9758-6ada-490c-8d66-dae67ac20bb9', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'id', 'id', 14
	UNION
	SELECT 'b3e5e45a-523f-485c-b581-07a1e1878cf1', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'name', 'name', 12
	UNION
	SELECT '36d02ddd-71d8-4c58-b740-bb6f3da9f301', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'description', 'description', 12
	UNION
	SELECT '758d64c7-c074-4dd6-99b8-a2a993091006', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'type', 'type', 8
	UNION
	SELECT '876714e4-16db-4202-886b-55f88037c366', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'options', 'options', 25
	UNION
	SELECT 'afb887ed-5ba8-4d92-9c13-4f91a52c3e77', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'disabled', 'disabled', 2
	UNION
	SELECT '60c9db9a-b9f9-4ed0-8002-e68ad12b3f9d', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'is_busy', 'is_busy', 2
	UNION
	SELECT '9218197c-36d7-47ca-9454-cd9654e7f9c1', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'is_unavailable', 'is_unavailable', 2
	UNION
	SELECT '1d414295-228a-4249-8d2f-3cd3ff6c8ca9', '62c0f9ed-c365-4d4d-a7a3-e0401a4e2767', 'unique_id', 'unique_id', 14
-- 80.BackupRepositories
	UNION
	SELECT '55c8c328-c4e5-457d-99d3-2c2b4c515aac', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'id', 'id', 14
	UNION
	SELECT 'f222a321-51af-4116-b391-fc06e7356576', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'name', 'name', 12
	UNION
	SELECT '16687a90-4ed1-43e9-9590-163f454585fd', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'description', 'description', 12
	UNION
	SELECT 'ec69ce55-b067-4130-ba18-70552ff08616', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'type', 'type', 8
	UNION
	SELECT 'a00bea52-a5ca-4fa4-a938-ba2bdd19f887', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'host_id', 'host_id', 14
	UNION
	SELECT '8a3effc0-a874-4fdb-9329-279c99cfd414', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'mount_host_id', 'mount_host_id', 14
	UNION
	SELECT 'd7c36269-f6b0-4394-840e-5747795c9f92', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'path', 'path', 12
	UNION
	SELECT '4588c9b2-245c-40ab-b06b-d272ed020090', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'options', 'options', 25
	UNION
	SELECT 'fec23bc3-e829-4905-9209-511cb87d3992', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'is_busy', 'is_busy', 2
	UNION
	SELECT '98e383ac-ffbc-4abc-995e-b68f7acd8081', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'is_unavailable', 'is_unavailable', 2
	UNION
	SELECT '9f140934-8359-421b-ab65-2a3dd4efc1eb', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'is_full', 'is_full', 2
	UNION
	SELECT '991da927-219e-4a41-b9f7-aa4bb2b28a9e', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'total_space', 'total_space', 0
	UNION
	SELECT 'f8aad29e-0923-4c9e-8136-c1aa235af196', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'free_space', 'free_space', 0
	UNION
	SELECT 'f435cd87-32a7-44d7-a50b-0198476f3cd9', 'e7ab8e28-ded7-4d32-abfb-50d87db757e0', 'unique_id', 'unique_id', 14
-- 80.Credentials
	UNION
	SELECT 'e49e2966-3040-4d05-be7c-0b0c4dbd4862', 'f87e7fbb-cae3-4b33-97a0-fee43e6fbc6e', 'id', 'id', 14
	UNION
	SELECT 'cb5ec019-dfdc-42f7-a835-3b8d945d1997', 'f87e7fbb-cae3-4b33-97a0-fee43e6fbc6e', 'user_name', 'user_name', 12
-- 80.Backup.Model.RestoreJobSessions
	UNION
	SELECT 'e4bdf15b-06af-4878-a49e-4155c618d522', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'id', 'id', 14
	UNION
	SELECT '81092f8a-b04b-4b66-ad8c-f39e5df31a27', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'action', 'action', 8
	UNION
	SELECT 'a8fbd973-87f3-431a-84c6-c80ab45a4561', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'usn', 'usn', 0
	UNION
	SELECT 'cca8027d-3e86-442d-bbf4-1425a1e778bb', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'options', 'options', 25
	UNION
	SELECT '08e5e71d-9a22-4249-b631-066c565dc42a', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'initiator_sid', 'initiator_sid', 12
	UNION
	SELECT '6a440ee5-1665-40e5-87c0-fca703534573', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'initiator_name', 'initiator_name', 12
	UNION
	SELECT 'c1747b22-08a6-4d96-82cf-9a1bf84d0425', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'reason', 'reason', 12
	UNION
	SELECT '0265330a-aeab-436f-9d73-88e78a208409', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'files_log_xml', 'files_log_xml', 25
	UNION
	SELECT 'd13ba198-dea3-49c7-ba6d-233b2def5db6', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'platform', 'platform', 8
	UNION
	SELECT '5d123fee-e22a-4c22-8521-9de913b1bcde', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'multi_restore_id', 'multi_restore_id', 14
	UNION
	SELECT 'd7091916-0afd-45c4-beef-0b1f9ec3e8f8', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'restore_type', 'restore_type', 8
	UNION
	SELECT 'b3b749d9-bac9-45c8-a615-4889af00f1d1', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'oib_id', 'oib_id', 14
	UNION
	SELECT '4fdd3a63-ddc1-48f1-a313-0876bba1e780', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'is_internal', 'is_internal', 2
	UNION
	SELECT '6bee4d3c-36d2-420b-a3b6-bdf3bb413709', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'oib_display_name', 'oib_display_name', 12
	UNION
	SELECT '2a132253-a421-434b-8661-03a634e9b088', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'oib_creation_time', 'oib_creation_time', 4
	UNION
	SELECT '31e13aa4-b061-4f33-af92-c4d0ebe7e05a', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'sub_type', 'sub_type', 8
	UNION
	SELECT '5fbaa138-382d-4ae5-bec2-9643bb1e0caf', '4adc8fb6-1976-4403-86c4-e51f425922dc', 'restored_obj_id', 'restored_obj_id', 14
-- 80.JobVssCredentials
	UNION
	SELECT '34515284-7d18-4f14-b99b-91ab7372ac36', 'd1c32ef0-f453-44f9-85b2-3005105836d7', 'id', 'id', 14
	UNION
	SELECT 'c1c147b1-6f1b-4171-8fbf-e63ef2b72885', 'd1c32ef0-f453-44f9-85b2-3005105836d7', 'job_id', 'job_id', 14
	UNION
	SELECT 'efa1dc8f-f7a2-4f6a-ab83-d053541ef44f', 'd1c32ef0-f453-44f9-85b2-3005105836d7', 'oij_id', 'oij_id', 14
	UNION
	SELECT 'b90efb3a-6898-4796-b276-e0009bbf44ce', 'd1c32ef0-f453-44f9-85b2-3005105836d7', 'win_creds_id', 'win_creds_id', 14
-- 80.PhysicalHosts
	UNION
	SELECT 'be5c95b8-12e6-447f-9c1d-e390a1508a9b', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'id', 'id', 14
	UNION
	SELECT 'a350518f-340b-4deb-9877-4d259d1a5349', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'name', 'name', 12
	UNION
	SELECT '1fb229b5-99ae-45ec-af34-c99aaf0a5ecd', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'bios_uuid', 'bios_uuid', 12
	UNION
	SELECT '51536939-c19f-44e8-99ee-22e6c1ecac00', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'chassis_type', 'chassis_type', 8
	UNION
	SELECT '055fa170-4a94-4de3-8ea1-4ec74e0374be', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'hardware_info', 'hardware_info', 25
	UNION
	SELECT '068d5bc9-cbdf-498c-b378-a961faac96be', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'net_info', 'net_info', 25
	UNION
	SELECT '768dbe90-48fb-432b-bd07-8e85c0bab065', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'os_type', 'os_type', 8
	UNION
	SELECT 'a3230d4b-7592-4742-ba88-c07c077ddace', '17b68fd5-6494-409e-a904-ed15c9710a2a', 'os_platform', 'os_platform', 8
-- 80.Backup.Model.RestoreTaskSessions
	UNION
	SELECT 'adc1f13d-8e3e-4a04-9315-ccb7f5f613a3', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'id', 'id', 14
	UNION
	SELECT 'd348862f-69eb-4cdc-845e-da7a0c1f0383', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'session_id', 'session_id', 14
	UNION
	SELECT '2e28c411-87f8-439a-bcb3-159065edd8f7', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'object_name', 'object_name', 12
	UNION
	SELECT '3a1701ca-d09e-44b8-9109-4173cd4120d3', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'object_id', 'object_id', 14
	UNION
	SELECT '692e95ef-2c37-4373-b537-9b367f39a90d', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'status', 'status', 8
	UNION
	SELECT 'eb5f8a7d-27c4-4e97-b9df-eabda921e976', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'reason', 'reason', 11
	UNION
	SELECT 'dec58167-d2b5-4cad-85b1-83f4a88caa48', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'creation_time', 'creation_time', 4
	UNION
	SELECT '3748d373-47e8-4f71-825d-a81a56eea718', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'end_time', 'end_time', 4
	UNION
	SELECT '01076209-0511-40cf-96c8-fa095439290e', '74148e3b-9de8-49cd-bb6f-42f037967ac0', 'operation', 'operation', 12
-- 80.OibAdminAccounts
	UNION
	SELECT 'c693afab-5a64-4882-a0fd-5684cb1cb814', '2497bafe-acf0-439b-b405-90cce32c309b', 'id', 'id', 14
	UNION
	SELECT '10f5653c-6b6d-41a4-86de-ee9c164165a5', '2497bafe-acf0-439b-b405-90cce32c309b', 'sid', 'sid', 12
	UNION
	SELECT 'cf264b94-c5ff-4bc9-8aff-7e38f92246e3', '2497bafe-acf0-439b-b405-90cce32c309b', 'oib_id', 'oib_id', 14
	UNION
	SELECT '743a4e39-3e86-4131-8a46-3ca3c5b871ce', '2497bafe-acf0-439b-b405-90cce32c309b', 'account_type', 'account_type', 8
-- 80.Backup.Model.GuestDatabase
	UNION
	SELECT '29c87c48-3186-4c45-8e58-4e235e5939cc', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'id', 'id', 14
	UNION
	SELECT 'd655ca46-793e-42e3-858b-63b1a2bb891c', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'obj_id', 'obj_id', 14
	UNION
	SELECT '9b8c0343-78ec-4c5b-81c3-1e6c4ad363cc', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'server_name', 'server_name', 12
	UNION
	SELECT 'd2dcb50b-400e-4db1-919d-b461c91995f7', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'db_instance', 'db_instance', 12
	UNION
	SELECT 'b723c8bb-48bc-4b5b-be3a-b88282f14af3', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'db_name', 'db_name', 12
	UNION
	SELECT 'f8c32650-f6d2-4e4f-a9b0-7f5320d9909b', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'creation_time', 'creation_time', 4
	UNION
	SELECT 'aae33963-0244-450a-b5ea-9d2fb69399b5', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'is_system', 'is_system', 2
	UNION
	SELECT 'b93dbf7f-0a8b-4dba-a5d4-76df5ef0fb8a', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'db_id', 'db_id', 8
	UNION
	SELECT '658f77f3-527a-4df4-8f97-6d6392e54c60', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'compatibility', 'compatibility', 8
	UNION
	SELECT '31c474c6-53fd-4378-8de8-5ff9033d61d2', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'family_guid', 'family_guid', 14
	UNION
	SELECT '050644fd-b218-4ed9-be66-6289a47d0388', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'local_creation_time', 'local_creation_time', 4
-- 80.WanAccelerators
	UNION
	SELECT '70a81c18-ca9a-4e98-8fa4-3dfcee84abd0', '00917a71-9d27-4ce5-ac7c-687735e1c623', 'id', 'id', 14
	UNION
	SELECT 'd3e333f1-2bcb-4de2-9cd7-4e27c4b8072f', '00917a71-9d27-4ce5-ac7c-687735e1c623', 'host_id', 'host_id', 14
	UNION
	SELECT '5f541ca6-e697-4ca2-acc7-3ae3572f64a5', '00917a71-9d27-4ce5-ac7c-687735e1c623', 'name', 'name', 12
	UNION
	SELECT '1981fdba-9582-4467-b404-60216c92ca7a', '00917a71-9d27-4ce5-ac7c-687735e1c623', 'description', 'description', 12
	UNION
	SELECT 'dda5ff3b-4040-4952-b974-1d8eccd3a03d', '00917a71-9d27-4ce5-ac7c-687735e1c623', 'is_unavailable', 'is_unavailable', 2
-- 80.HostComponents
	UNION
	SELECT '905495c4-3b88-45ab-af7e-7e9d749410bf', 'e3ec5e82-306f-46ef-b3ab-6ec8f627b2e8', 'id', 'id', 14
	UNION
	SELECT '48e38aa7-8eef-4c11-b3f6-1bb0a32ff2f8', 'e3ec5e82-306f-46ef-b3ab-6ec8f627b2e8', 'physical_host_id', 'physical_host_id', 14
	UNION
	SELECT '1009486e-86ff-423e-96e1-2e3be72fb906', 'e3ec5e82-306f-46ef-b3ab-6ec8f627b2e8', 'type', 'type', 8
	UNION
	SELECT 'cda2fd47-841b-4654-9034-5690789e52dc', 'e3ec5e82-306f-46ef-b3ab-6ec8f627b2e8', 'version', 'version', 12
	UNION
	SELECT '7cbdaf7f-21a6-4e45-bf6e-49aa2bc858f0', 'e3ec5e82-306f-46ef-b3ab-6ec8f627b2e8', 'options', 'options', 25
	UNION
	SELECT '33510cfe-38ae-4b6b-b3ed-6c27eda51aa7', 'e3ec5e82-306f-46ef-b3ab-6ec8f627b2e8', 'is_up_to_date', 'is_up_to_date', 2
-- 80.Backup.Model.CloudGates
	UNION
	SELECT 'e1c8c28b-af65-42c7-ac4e-25bf4721a4b3', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'id', 'id', 14
	UNION
	SELECT '77138f8a-0dbc-4362-8d02-d0c7b4a3c3fb', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'name', 'name', 12
	UNION
	SELECT '23f730b3-45a5-48b2-8309-3d59b33a2918', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'description', 'description', 12
	UNION
	SELECT 'a6767228-7501-447f-b9ed-1632942263a9', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'creds_id', 'creds_id', 14
	UNION
	SELECT 'db68bd60-745a-4388-8d3c-81508d8f8457', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'options', 'options', 25
	UNION
	SELECT 'c869d8ff-1084-4d18-84a1-842994a0925e', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'host_id', 'host_id', 14
	UNION
	SELECT '21780ed5-82ab-4ee2-9225-52fdf5e89631', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'disabled', 'disabled', 2
	UNION
	SELECT '318b1efa-b776-4d15-929f-d83d3d0f3bc1', '81f6a099-8ee8-41a6-8d59-87a6e059e553', 'is_available', 'is_available', 2
-- 80.Tenants
	UNION
	SELECT 'f09aeeab-1d09-411d-892b-e9a414356239', '04302e40-2287-4446-8357-d09a25ca2866', 'id', 'id', 14
	UNION
	SELECT '89c20101-17a8-4c34-abd6-c362dc1dedf2', '04302e40-2287-4446-8357-d09a25ca2866', 'name', 'name', 12
	UNION
	SELECT 'ce673f22-a81f-4621-bf6e-8d2588e4397b', '04302e40-2287-4446-8357-d09a25ca2866', 'description', 'description', 12
	UNION
	SELECT 'ebf7a6b3-b7d9-4d40-ab62-1eb1ef31bf94', '04302e40-2287-4446-8357-d09a25ca2866', 'expire_time', 'expire_time', 4
	UNION
	SELECT '74a4780b-491d-4a83-a6e1-1acdc1292aba', '04302e40-2287-4446-8357-d09a25ca2866', 'disabled', 'disabled', 2
-- 80.TenantsResourcesQuota
	UNION
	SELECT '1f9be39d-cfb6-4c18-8b52-b34743a62480', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'id', 'id', 14
	UNION
	SELECT '6416352f-02c7-4d9d-b8da-11972eac2812', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'tenant_id', 'tenant_id', 14
	UNION
	SELECT 'f51ecff7-24b6-4333-93ac-ab08b15eff72', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'repository_id', 'repository_id', 14
	UNION
	SELECT '413a0dbb-1b78-4852-b2ce-95e3b11a1be3', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'folder', 'folder', 12
	UNION
	SELECT '1525e1ec-7bc7-4716-830c-cc59abddbad8', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'wan_id', 'wan_id', 14
	UNION
	SELECT '09af6079-dbe9-4730-b325-d275f737e3e7', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'quota_mb', 'quota_mb', 8
	UNION
	SELECT '228a272c-026b-49ef-9762-c818cf743279', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'used_quota_mb', 'used_quota_mb', 8
	UNION
	SELECT '2becda74-0df0-4411-9539-ff520ed0458e', '9282b002-c6af-45d2-8d44-c3c3e0d611fa', 'friendly_name', 'friendly_name', 12


	RETURN 
END
GO
-----------------------------------------------------




-----------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MarkColumnsBindingsAsNew_v7]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MarkColumnsBindingsAsNew_v7]
GO
CREATE PROCEDURE [dbo].[MarkColumnsBindingsAsNew_v7]
AS
BEGIN
	DECLARE @tableObjectIdField nvarchar(50)
	SET @tableObjectIdField = 'id'

	UPDATE [dbo].[Repl.Scheme.ColumnsBindings]
		SET [dbo].[Repl.Scheme.ColumnsBindings].[is_new] = 1
	FROM [dbo].[Repl.Scheme.ColumnsBindings] cb INNER JOIN 
	(
		SELECT cb.id as binding_id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE source_table = 'Backup.Model.RestoreJobSessions' AND (vbsrv_version_major = 0 OR vbsrv_version_major >= 7)
		AND cb.source_field <> 'id'
		UNION
		SELECT cb.id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE source_table = 'Backup.Model.RestoreTaskSessions' AND (vbsrv_version_major = 0 OR vbsrv_version_major >= 7)
		AND cb.source_field <> 'id'
		UNION
		SELECT cb.id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE source_table = 'PhysicalHosts' AND (vbsrv_version_major = 0 OR vbsrv_version_major >= 7)		
		AND cb.source_field <> 'id'
		UNION
		SELECT cb.id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE source_table = 'BackupProxies' AND (vbsrv_version_major = 0 OR vbsrv_version_major >= 7)
		AND cb.source_field <> 'id'
		UNION
		SELECT cb.id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE source_table = 'BackupRepositories' AND (vbsrv_version_major = 0 OR vbsrv_version_major >= 7)
		AND cb.source_field <> 'id'
		UNION
		SELECT cb.id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE source_table = 'JobVssCredentials' AND (vbsrv_version_major = 0 OR vbsrv_version_major >= 7)
		AND cb.source_field <> 'id'
		UNION
		SELECT cb.id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE source_table = 'Ssh_creds' AND (vbsrv_version_major = 0 OR vbsrv_version_major >= 7)
		AND cb.source_field <> 'id'
		UNION

		SELECT cb.id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE (vbsrv_version_major = 0 OR vbsrv_version_major >= 7) AND
		(
			(source_table = 'Backup.Model.OIBs' AND source_field = 'parent_id') OR
			(source_table = 'Backup.Model.OIBs' AND source_field = 'display_name') OR
			(source_table = 'Backup.Model.OIBs' AND source_field = 'original_oib_id') OR
			(source_table = 'BObjects' AND source_field = 'path') OR
			(source_table = 'BObjects' AND source_field = 'platform') OR
			(source_table = 'BObjects' AND source_field = 'uuid') OR
			(source_table = 'BObjects' AND source_field = 'unique_key_hash') OR
			(source_table = 'BObjects' AND source_field = 'display_name') OR
			(source_table = 'Host' AND source_field = 'physical_host_id') OR
			(source_table = 'Host' AND source_field = 'host_instance_id') OR
			(source_table = 'LicensedHosts' AND source_field = 'lic_tier') OR
			(source_table = 'Backup.Model.Backups' AND source_field = 'repository_id') OR			
			(source_table = 'ObjectsInJobs' AND source_field = 'order_no') OR
			(source_table = 'Backup.Model.SbTaskSessions' AND source_field = 'validation_status') OR
			(source_table = 'BackupProxies' AND source_field = 'unique_id') OR
			(source_table = 'BackupRepositories' AND source_field = 'unique_id') OR
			(source_table = 'BJobs' AND source_field = 'repository_id')
		)
	) as q  ON cb.[id] = q.binding_id

END
GO
-----------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MarkColumnsBindingsAsNew_v80]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MarkColumnsBindingsAsNew_v80]
GO
CREATE PROCEDURE [dbo].[MarkColumnsBindingsAsNew_v80]
AS
BEGIN
	DECLARE @tableObjectIdField nvarchar(50)
	SET @tableObjectIdField = 'id'
		
	UPDATE [dbo].[Repl.Scheme.Collect]
		SET [dbo].[Repl.Scheme.Collect].[collect_new_columns] = 1
	FROM [dbo].[Repl.Scheme.Collect] sc
	INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON sc.[db_instance_id] = bs.[current_db_id]
	WHERE bs.[version] like '8.0.%'
	
	UPDATE [dbo].[Repl.Scheme.ColumnsBindings]
		SET [dbo].[Repl.Scheme.ColumnsBindings].[is_new] = 1		
	FROM [dbo].[Repl.Scheme.ColumnsBindings] cb INNER JOIN 
	(
		SELECT cb.id as binding_id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE (vbsrv_version_major = 0 OR vbsrv_version_major >= 8) AND
		(		
			(source_table = 'PhysicalHosts') OR
			(source_table = 'LicensedHost' AND source_field = 'physical_host_id') OR
			(source_table = 'Backup.Model.OIBs' AND source_field = 'fqdn') OR			
			(source_table = 'BJobs' AND source_field = 'pwd_key_id') OR
			(source_table = 'LicensedHost') OR
			(source_table = 'Backup.Model.OIBs' AND source_field = 'has_sql') OR
			(source_table = 'Backup.Model.OIBs' AND source_field = 'parent_id') OR
			(source_table = 'Backup.Model.RestoreJobSessions' AND source_field = 'restored_obj_id') OR
			(source_table = 'Backup.Model.BackupJobSessions' AND source_field = 'cur_point_id')
		)
	) AS q ON cb.id = q.binding_id

END
GO
-----------------------------------------------------

-----------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MarkColumnsBindingsAsNew_v90]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[MarkColumnsBindingsAsNew_v90]
GO
CREATE PROCEDURE [dbo].[MarkColumnsBindingsAsNew_v90]
AS
BEGIN
	DECLARE @tableObjectIdField nvarchar(50)
	SET @tableObjectIdField = 'id'
		
	UPDATE [dbo].[Repl.Scheme.Collect]
		SET [dbo].[Repl.Scheme.Collect].[collect_new_columns] = 1
	FROM [dbo].[Repl.Scheme.Collect] sc
	INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON sc.[db_instance_id] = bs.[current_db_id]
	WHERE bs.[version] like '9.0.%'
	
	UPDATE [dbo].[Repl.Scheme.ColumnsBindings]
		SET [dbo].[Repl.Scheme.ColumnsBindings].[is_new] = 1		
	FROM [dbo].[Repl.Scheme.ColumnsBindings] cb INNER JOIN 
	(
		SELECT cb.id as binding_id FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			INNER JOIN [Repl.Scheme.TablesBindings] tb ON cb.tables_binding = tb.id
		WHERE (vbsrv_version_major = 0 OR vbsrv_version_major >= 9) AND
		(
			(source_table = 'Backup.Model.Backups' AND source_field = 'target_type') OR
			(source_table = 'Tenants' AND source_field = 'password') OR
			(source_table = 'Backup.Model.Storages' AND source_field = 'availability') OR
			(source_table = 'Backup.Model.OIBs' AND source_field = 'is_recheck_corrupted')
		)
	) AS q ON cb.id = q.binding_id

END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.List_ComputeColumnsBindings]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn.List_ComputeColumnsBindings]
GO
CREATE FUNCTION [dbo].[fn.List_ComputeColumnsBindings] ()
RETURNS 
@Result TABLE 
(
	[id] [uniqueidentifier],
    [tables_binding] [uniqueidentifier],
    [compute_field] [nvarchar](50),
    [target_field] [nvarchar](50),
    [column_sql_type] [int]
)
AS
BEGIN

	INSERT INTO @Result

	--C.BJobs
	select '0E415B79-6D51-43A3-B280-E9EAB49B7905','085ffc12-17e4-494f-9c4b-13cede5c8b29','next_run_time','next_run_time','4'
	--C.PhysicalHosts
	union
	select '97684FD7-F6FD-4627-8191-F40C7D2A4A4A','d0555593-dff4-49f2-90c0-f8afc4264561','cpu','cpu','8'
	union
	select '8ED904E6-AA6A-4C7F-BA86-6306521EBE57','d0555593-dff4-49f2-90c0-f8afc4264561','cores','cores','8'
	--C.Backup.Model.GuestDatabase
	UNION 
	SELECT 'EF5444F0-A24E-433D-B7BD-A1E6DFC21C79', 'f7d8cf5a-263e-49d9-8f22-1bef38a33869', 'local_creation_time_str', 'local_creation_time_str', 12
	--C.Tenants
	UNION
	SELECT '29bb69f9-20ec-486b-8e6d-94da7b8e970c', 'd0011aff-32e7-43ef-9f36-c0f0b236b507', 'password', 'password', 12
	
	--80.BJobs
	UNION
	select '3E17F04B-B307-4463-A7DD-14A19CE87517','c14c5a70-6b80-415b-8c48-81e4bfb5e057','next_run_time','next_run_time','4'
	--80.PhysicalHosts
	union
	select 'D79FBF3C-CC4C-45B1-8CC2-81E004994928','17b68fd5-6494-409e-a904-ed15c9710a2a','cpu','cpu','8'
	union
	select 'BD61E6AA-99A9-4066-B856-BD3AB7B91D14','17b68fd5-6494-409e-a904-ed15c9710a2a','cores','cores','8'
	--80.Backup.Model.GuestDatabase
	UNION 
	SELECT 'EA34EC1F-B2FA-4001-A978-0787E4344B74', '7422f2fd-4da1-4cff-938f-0d8bb468c82b', 'local_creation_time_str', 'local_creation_time_str', 12


	--70.BJobs
	union
	select '58620022-B54E-4b90-9CA0-F929303595C8','a9bac128-2cd0-4209-9160-7440a032a305','next_run_time','next_run_time','4'

	RETURN 
END
GO
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Fill_TablesBindings]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Fill_TablesBindings]
GO
CREATE PROCEDURE [dbo].[Fill_TablesBindings]
AS
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Scheme.TablesBindings]') AND type in (N'U'))
	BEGIN

		--SET IDENTITY_INSERT [dbo].[Repl.Scheme.TablesBindings] ON
		
		--update existing rows
		UPDATE tb
		set tb.id = ltb.id, tb.source_table = ltb.source_table, tb.source_id_field = ltb.source_id_field, tb.target_table = ltb.target_table, tb.target_id_field = ltb.target_id_field, tb.import_updates_procedure = ltb.import_updates_procedure, tb.import_dels_procedure = ltb.import_dels_procedure,
			tb.vbsrv_version_major = ltb.vbsrv_version_major, tb.vbsrv_version_minor = ltb.vbsrv_version_minor
		from [dbo].[Repl.Scheme.TablesBindings] tb, [dbo].[fn.List_TablesBindings] () ltb
		where ltb.id = tb.id
		
		--insert new rows
		INSERT [dbo].[Repl.Scheme.TablesBindings]([id], [source_table], [source_id_field], [target_table], [target_id_field], [import_updates_procedure], [import_dels_procedure], [vbsrv_version_major], [vbsrv_version_minor])
		SELECT ltb.*
		FROM [dbo].[fn.List_TablesBindings] () ltb
		LEFT JOIN [dbo].[Repl.Scheme.TablesBindings] tb
		ON ltb.id = tb.id
		WHERE tb.id IS NULL
		
		--delete old rows
		DELETE [dbo].[Repl.Scheme.TablesBindings]
		WHERE id in
		(
			SELECT cb.id
			FROM [dbo].[Repl.Scheme.TablesBindings] cb
			LEFT JOIN [dbo].[fn.List_TablesBindings] () lcb
			ON lcb.id = cb.id
			WHERE lcb.id IS NULL
		)

		RETURN
	END
END
GO
-----------------------------------------------------



-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Fill_ColumnsBindings]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Fill_ColumnsBindings]
GO
CREATE PROCEDURE [dbo].[Fill_ColumnsBindings]
AS
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Scheme.ColumnsBindings]') AND type in (N'U'))
	BEGIN

		--SET IDENTITY_INSERT [dbo].[Repl.Scheme.ColumnsBindings] ON
		
		--update existing rows
		UPDATE cb
		set cb.id = lcb.id, cb.tables_binding = lcb.tables_binding, cb.source_field = lcb.source_field, cb.target_field = lcb.target_field, cb.column_sql_type = lcb.column_sql_type
		from [dbo].[Repl.Scheme.ColumnsBindings] cb, [dbo].[fn.List_ColumnsBindings] () lcb

		where lcb.id = cb.id
		
		--insert new rows
		INSERT [dbo].[Repl.Scheme.ColumnsBindings]([id], [tables_binding], [source_field], [target_field], [column_sql_type])
		SELECT lcb.*
		FROM [dbo].[fn.List_ColumnsBindings] () lcb
		LEFT JOIN [dbo].[Repl.Scheme.ColumnsBindings] cb
		ON lcb.id = cb.id
		WHERE cb.id IS NULL
		
		
		--delete old rows
		DELETE [dbo].[Repl.Scheme.ColumnsBindings]
		WHERE id in
		(
			SELECT cb.id
			FROM [dbo].[Repl.Scheme.ColumnsBindings] cb
			LEFT JOIN [dbo].[fn.List_ColumnsBindings] () lcb
			ON lcb.id = cb.id
			WHERE lcb.id IS NULL
		)
		
		RETURN
	END
END
GO
-----------------------------------------------------


-----------------------------------------------------
--
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Fill_ComputeColumnsBindings]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Fill_ComputeColumnsBindings]
GO
CREATE PROCEDURE [dbo].[Fill_ComputeColumnsBindings]
AS
BEGIN
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Repl.Scheme.ComputeColumnsBindings]') AND type in (N'U'))
	BEGIN

		--SET IDENTITY_INSERT [dbo].[Repl.Scheme.ComputeColumnsBindings] ON
		
		--update existing rows
		UPDATE cb
		set cb.id = lcb.id, cb.tables_binding = lcb.tables_binding, cb.compute_field = lcb.compute_field, cb.target_field = lcb.target_field, cb.column_sql_type = lcb.column_sql_type
		from [dbo].[Repl.Scheme.ComputeColumnsBindings] cb, [dbo].[fn.List_ComputeColumnsBindings] () lcb
		where lcb.id = cb.id
		
		--insert new rows
		INSERT [dbo].[Repl.Scheme.ComputeColumnsBindings]([id], [tables_binding], [compute_field], [target_field], [column_sql_type])
		SELECT lcb.*
		FROM [dbo].[fn.List_ComputeColumnsBindings] () lcb
		LEFT JOIN [dbo].[Repl.Scheme.ComputeColumnsBindings] cb
		ON lcb.id = cb.id
		WHERE cb.id IS NULL
		
		
		--delete old rows
		DELETE [dbo].[Repl.Scheme.ComputeColumnsBindings]
		WHERE id in
		(
			SELECT cb.id
			FROM [dbo].[Repl.Scheme.ComputeColumnsBindings] cb
			LEFT JOIN [dbo].[fn.List_ComputeColumnsBindings] () lcb
			ON lcb.id = cb.id
			WHERE lcb.id IS NULL
		)
		
		RETURN
	END
END
GO
-----------------------------------------------------


---------------------------------------------------
BEGIN TRANSACTION;
---------------------------------------------------
	EXEC [dbo].[Fill_TablesBindings]
	IF @@Error <> 0 BEGIN ROLLBACK TRANSACTION;	RETURN; END	
	EXEC [dbo].[Fill_ColumnsBindings]
	IF @@Error <> 0 BEGIN ROLLBACK TRANSACTION;	RETURN; END	
	EXEC [dbo].[Fill_ComputeColumnsBindings]
	IF @@Error <> 0 BEGIN ROLLBACK TRANSACTION;	RETURN; END	
---------------------------------------------------
COMMIT TRANSACTION;
GO
---------------------------------------------------
DROP PROCEDURE [dbo].[Fill_ColumnsBindings]
DROP PROCEDURE [dbo].[Fill_TablesBindings]
GO
---------------------------------------------------




-----------------------------------------------------
--1
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 1)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		IF NOT EXISTS (SELECT * FROM [dbo].[Config.Scheduler.CatSyncSettings] WHERE [dbo].[Config.Scheduler.CatSyncSettings].[id]=''1B38ECD6-76D2-418e-9F21-D4B292553811'')
		EXEC [dbo].[usp.Config.Scheduler.CreateCatSyncSettings] ''1B38ECD6-76D2-418e-9F21-D4B292553811'', 1

		--------------------------
		DECLARE @statuses_img_folder_id as uniqueidentifier
		DECLARE @collect_statuses_enum_id as uniqueidentifier
				   
		SELECT @statuses_img_folder_id = ''FBB0BD0E-9274-4cda-BEFF-653785C89082'',
			   @collect_statuses_enum_id = ''5E3149C0-3BC9-4395-9F04-035EE85B1F55''
			
		-- Change enumeration value 0   
		UPDATE [dbo].[Report.Shared.EnumerationValues]
		SET [text_value] = ''In Progress...''
		WHERE [enumeration_id] = @collect_statuses_enum_id AND [ordinal_number] = 0

		-- Add enumeration values
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @collect_statuses_enum_id, @statuses_img_folder_id, 4, ''Success'', ''SuccessSmall'', null
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 1; END	
END
GO
--1
-----------------------------------------------------



-----------------------------------------------------
--2 
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 2)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		/* CONTAINERS */
		DECLARE @WindowContainerType as int
		DECLARE @TabContainerType as int
		DECLARE @SameContainerType as int

		SELECT  @SameContainerType = 0,
		@WindowContainerType = 1,
		@TabContainerType = 2

		/* FILES TAB */
		DECLARE @search_tab_id as uniqueidentifier
		SELECT @search_tab_id = ''036C46DE-7784-4521-97CB-ACEE20AAB097''
		
		IF NOT EXISTS (SELECT id FROM [dbo].[Rendering.Containers] WHERE [id]=@search_tab_id)
		BEGIN
			INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
			VALUES( @search_tab_id, ''Files'', @TabContainerType, 0 )
		END
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 2; END	
END
GO
--2
-----------------------------------------------------



-----------------------------------------------------
--3
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 3)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		/* SEARCH REPORT */
		DECLARE @search_rep_id as uniqueidentifier
		DECLARE @naviname_builder_id as uniqueidentifier
		
		SELECT @search_rep_id = ''BA84E0FF-E5AC-44c5-B1F6-FF72502B3ED8'', @naviname_builder_id = NEWID()

		IF NOT EXISTS (SELECT id FROM [dbo].[Reports] WHERE [id]=@search_rep_id)
		BEGIN

			EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
			@builder_id = @naviname_builder_id,
			@format_str = N''Files''

			INSERT INTO [dbo].[Reports]([id],[unique_name],[display_name], [naviname_builder_id])
			VALUES( @search_rep_id, ''cat_search'', ''Files'', @naviname_builder_id)

		END
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 3; END	
END
GO
--3
-----------------------------------------------------



-----------------------------------------------------
--4
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 4)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		/* ENTERPRISE JOB TYPES */
		DECLARE @statuses_img_folder_id as uniqueidentifier
		DECLARE @ent_job_types_enum_id as uniqueidentifier
		
		SELECT @statuses_img_folder_id = ''FBB0BD0E-9274-4cda-BEFF-653785C89082'',
			   @ent_job_types_enum_id = ''6E7CC1EE-6C31-449f-BB98-27A2D6064781''
		
		IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.Enumerations] WHERE [id]=@ent_job_types_enum_id)
		BEGIN
			INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
			VALUES( @ent_job_types_enum_id, ''EntJobTypes'')	
													
			EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @ent_job_types_enum_id, @statuses_img_folder_id, 3, ''Database Replication'', null, null
			EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @ent_job_types_enum_id, @statuses_img_folder_id, 2, ''Catalog Replication'', null, null
			EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @ent_job_types_enum_id, @statuses_img_folder_id, 1, ''Catalog Indexing'', null, null
		END	
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 4; END	
END
GO
--4
-----------------------------------------------------



-----------------------------------------------------
--5
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 5)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		/* CONFIGURATION - COLLECT SESSIONS REPORT */
		DECLARE @repid as uniqueidentifier
		DECLARE @grid_repid as uniqueidentifier
		DECLARE @naviname_builder_id as uniqueidentifier

		SELECT @repid = ''D6FB5F10-D723-414d-8674-122DDD4D66C1''
		SELECT @grid_repid = [dbo].[Report.GridReports].[id] FROM [dbo].[Report.GridReports] WHERE [dbo].[Report.GridReports].[report_id]=@repid
			
		DECLARE @order_cfg_sessions_type uniqueidentifier

		IF NOT EXISTS (SELECT id FROM [dbo].[Report.GridReport.Columns] WHERE [dbo].[Report.GridReport.Columns].[unique_name]=''cfg_sessions_type'')
		BEGIN
			/****************** ORDERS ********************************************************/
			SELECT @order_cfg_sessions_type = NEWID()	
			EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_sessions_type, @grid_repid, ''cfg_sessions_type''
		
			/****************** COLUMNS ********************************************************/	
			-- ADD NEW COLUMN (TYPE)		
			DECLARE @ent_job_types_enum_id as uniqueidentifier	
			SELECT @ent_job_types_enum_id = ''6E7CC1EE-6C31-449f-BB98-27A2D6064781''
		
			/*  ENTERPRISE SESSION TYPE */
			EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
				@grid_report_id = @grid_repid,
				@col_display_name = ''Type'',
				@col_unique_name = ''cfg_sessions_type'',
				@col_width = 70,
				@col_number  = 1,
				@is_sortable = 1,
				@datasrc_col_name = ''cfg_sessions_type'',
				@enumeration_id = @ent_job_types_enum_id,
				@order_id = @order_cfg_sessions_type	
		END	
		
		-- UPDATE COLUMN (LOG) --------------------------------------
		DECLARE @collect_log_repid uniqueidentifier
		SELECT @collect_log_repid  = ''68ACF7B6-A35B-4d12-86D7-7A8C1F075EBE''
		
		DECLARE @dyn_attr2_name nvarchar( 100 ), @datasrc_dynattr2_colname nvarchar( 100 )
		SELECT @dyn_attr2_name = N''job_type'', @datasrc_dynattr2_colname = N''job_type''

		DECLARE @href_binding_id uniqueidentifier
		SET @href_binding_id = (SELECT id FROM [dbo].[Report.GridReport.Binding.HrefColBindings] WHERE [target_report_id]=@collect_log_repid)

		IF NOT EXISTS (SELECT id FROM [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]	WHERE [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs].[href_binding_id]=@href_binding_id AND [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs].[attr_name]=@dyn_attr2_name)
		BEGIN
			INSERT INTO [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs]( [id],[href_binding_id],[attr_name],[datasrc_column], [is_mandatory_attr])
			VALUES( NEWID(), @href_binding_id, @dyn_attr2_name, @datasrc_dynattr2_colname, 1 )
		END	
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 5; END	
END
GO
--5
-----------------------------------------------------



-----------------------------------------------------
--6
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 6)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		/* CONFIGURATION - SEARCH SERVERS REPORT */
		
		DECLARE @repid as uniqueidentifier
		DECLARE @grid_repid as uniqueidentifier
		DECLARE @naviname_builder_id as uniqueidentifier

		SELECT @repid = ''D25A1783-4B9D-4bca-8A17-AE2B89C8940F'', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

		IF NOT EXISTS (SELECT id FROM [dbo].[Reports] WHERE [id]=@repid)
		BEGIN
		
			EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
				@builder_id = @naviname_builder_id,
				@format_str = N''Search Servers''

			EXEC [dbo].[usp.GridReport.Config.RegGridReport]
					@report_id = @repid,
					@unique_name = N''cfg_search_servers'',
					@display_name = N''Search Servers'',
					@datasrc_proc = N''usp.GridReport.DataSrc.Cfg.SearchServers'',
					@grid_report_id = @grid_repid,
					@naviname_builder_id = @naviname_builder_id

			/****************** ORDERS ********************************************************/					
			DECLARE @order_cfg_ss_name uniqueidentifier,
				@order_cfg_ss_user uniqueidentifier,
				@order_cfg_ss_state uniqueidentifier,
				@order_cfg_ss_usage uniqueidentifier
			SELECT @order_cfg_ss_name = NEWID(),
				@order_cfg_ss_user = NEWID(),
				@order_cfg_ss_state = NEWID(),
				@order_cfg_ss_usage = NEWID()

			EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_ss_name, @grid_repid,  ''cfg_search_srv_name''
			EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_ss_user, @grid_repid,  ''cfg_search_srv_user''
			EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_ss_state, @grid_repid, ''cfg_search_srv_state''
			EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_ss_usage, @grid_repid, ''cfg_search_srv_usage''

			/******************  COLUMNS ********************************************************/					
			/* Name */
			EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
				@grid_report_id = @grid_repid,
				@col_display_name = N''Name'',
				@col_unique_name = N''cfg_search_srv_name'',
				@col_width  = 100,
				@col_number = 1,
				@is_sortable = 1,
				@datasrc_col_name = N''cfg_search_srv_name'',
				@datasrc_col_type = 12,  --SqlDbType - nvarchar
				@format = 0, --text
				@order_id = @order_cfg_ss_name
				
			/* LOGIN */
			EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
				@grid_report_id = @grid_repid,
				@col_display_name = N''Login'',
				@col_unique_name = N''cfg_search_srv_user'',
				@col_width  = 100,
				@col_number = 2,
				@is_sortable = 1,
				@datasrc_col_name = N''cfg_search_srv_user'',
				@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
				@format = 0, --text
				@order_id = @order_cfg_ss_user

			/* SERVER STATE */
			EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
				@grid_report_id = @grid_repid,
				@col_display_name = N''State'',
				@col_unique_name = N''cfg_search_srv_state'',
				@col_width  = 80,
				@col_number = 3,
				@is_sortable = 1,
				@datasrc_col_name = N''cfg_search_srv_state'',
				@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
				@format = 0, --text
				@order_id = @order_cfg_ss_state
				
			/* OIBS QUOTA USAGE */
			EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
				@grid_report_id = @grid_repid,
				@col_display_name = N''Usage'',
				@col_unique_name = N''cfg_search_srv_usage'',
				@col_width  = 80,
				@col_number = 4,
				@is_sortable = 1,
				@datasrc_col_name = N''cfg_search_srv_usage'',
				@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
				@format = 0, --text
				@order_id = @order_cfg_ss_usage			
			
			/* DESCRIPTION */
			EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
				@grid_report_id = @grid_repid,
				@col_display_name = N''Server Description'',
				@col_unique_name = N''cfg_search_srv_desc'',
				@col_width  = 200,
				@col_number = 5,
				@is_sortable = 0,
				@datasrc_col_name = N''cfg_search_srv_desc'',
				@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
				@format = 0 --text
				
			/************************* TASKS ****************************************************/
			/*   ADD SERVER  */
			DECLARE @add_server_task_id uniqueidentifier
			SELECT @add_server_task_id = ''88DF1470-2F29-4404-B1E7-6B2B78CD257A''
				
			EXEC [dbo].[Report.Shared.RegisterTaskType]
				@task_id = @add_server_task_id,
				@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
				@img_name = N''AddServer'',
				@description = N''Add...'',
				@req_lines_selection = false,
				@invoke_type = 2
			EXEC [usp.GridReport.Config.RegTask]
				@grid_id = @grid_repid,
				@task_type_id = @add_server_task_id,
				@ordinal_number = 0
				
			/*   EDIT SERVER  */
			DECLARE @edit_server_task_id uniqueidentifier
			SELECT @edit_server_task_id = ''769C57F5-4286-4e94-93E9-B7CBDEB0B73D''
				
			EXEC [dbo].[Report.Shared.RegisterTaskType]
				@task_id = @edit_server_task_id,
				@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
				@img_name = N''EditServer'',
				@description = N''Edit...'',
				@req_lines_selection = true,
				@invoke_type = 2
			EXEC [usp.GridReport.Config.RegTask]
				@grid_id = @grid_repid,
				@task_type_id = @edit_server_task_id,
				@ordinal_number = 1

			/*   REMOVE SERVER  */
			DECLARE @remove_server_task_id uniqueidentifier
			SELECT @remove_server_task_id = ''FAFBE9F3-2BD6-4b01-857B-7C5DA04C7BC6''
				
			EXEC [dbo].[Report.Shared.RegisterTaskType]
				@task_id = @remove_server_task_id,
				@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
				@img_name = N''RemoveServer'',
				@description = N''Remove'',
				@req_lines_selection = true,
				@invoke_type = 2
			EXEC [usp.GridReport.Config.RegTask]
				@grid_id = @grid_repid,
				@task_type_id = @remove_server_task_id,
				@ordinal_number = 2
									
			/*   SCHEDULE  */
			DECLARE @cat_sync_schedule_task_id uniqueidentifier
			SELECT @cat_sync_schedule_task_id = ''F74267BF-EA0F-472e-B316-C69149889300''
				
			EXEC [dbo].[Report.Shared.RegisterTaskType]
				@task_id = @cat_sync_schedule_task_id,
				@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
				@img_name = N''CollectSchedule'',
				@description = N''Schedule...'',
				@req_lines_selection = false,
				@invoke_type = 2
			EXEC [usp.GridReport.Config.RegTask]
				@grid_id = @grid_repid,
				@task_type_id = @cat_sync_schedule_task_id,
				@ordinal_number = 3
				
			/*   START CATALOG SYNC  */
			DECLARE @start_catsync_task_id uniqueidentifier
			SELECT @start_catsync_task_id = ''7E7B52D3-250A-4ee0-B382-F9B8CEFCE7EF''
				
			EXEC [dbo].[Report.Shared.RegisterTaskType]
				@task_id = @start_catsync_task_id,
				@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
				@img_name = N''CollectNow'',
				@description = N''Sync Catalog Now'',--Starting catalog crawl after replication
				@req_lines_selection = false,
				@invoke_type = 1
			EXEC [usp.GridReport.Config.RegTask]
				@grid_id = @grid_repid,
				@task_type_id = @start_catsync_task_id,
				@ordinal_number = 4
				
			/*   STOP CATALOG SYNC  */
			DECLARE @stop_catsync_task_id uniqueidentifier
			SELECT @stop_catsync_task_id = ''D925F3A0-41E7-427c-AFDF-CC64F1C36D34''
				
			EXEC [dbo].[Report.Shared.RegisterTaskType]
				@task_id = @stop_catsync_task_id,
				@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
				@img_name = N''CollectNow'',
				@description = N''Stop Sync'',
				@req_lines_selection = false,
				@invoke_type = 1
			EXEC [usp.GridReport.Config.RegTask]
				@grid_id = @grid_repid,
				@task_type_id = @stop_catsync_task_id,
				@ordinal_number = 5
		END
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 6; END	
END
GO
--6
-----------------------------------------------------




-----------------------------------------------------
--7
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 7)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		/* REGISTRATION */
		/*   PAGES  */
		DECLARE @search_tab_id as uniqueidentifier
		SELECT @search_tab_id = ''036C46DE-7784-4521-97CB-ACEE20AAB097''

		/* REPORTS */
		DECLARE @search_rep_id as uniqueidentifier
		SELECT @search_rep_id = ''BA84E0FF-E5AC-44c5-B1F6-FF72502B3ED8''
		
		/* REG SEARCH  */	
		IF NOT EXISTS (SELECT id FROM [dbo].[Startup.InitialReportPages] WHERE [container_id]=@search_tab_id)
		BEGIN
		
			EXEC [dbo].[usp.Startup.RegInitialReportPage]
				@page_id = @search_tab_id,
				@report_id = @search_rep_id,
				@ordinal_number = 6
		END
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 7; END	
END
GO
--7
-----------------------------------------------------


-----------------------------------------------------
--8
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 8)
BEGIN
	------------------------------------------------------------------
	/*   LICENSING STATUSES ( IS ESX LICENSED )                          */

	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @esx_licensing_status_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		       @esx_licensing_status_enum_id = '98CA9026-F591-41e5-8A10-0309FD9DEFE7'
		   
	-- Register images folder			
	IF NOT EXISTS( SELECT * FROM [dbo].[Rendering.ImageFolders] WHERE [id] = @statuses_img_folder_id )
		BEGIN
			INSERT INTO [dbo].[Rendering.ImageFolders]([id],[folder_name])
			VALUES( @statuses_img_folder_id, 'Statuses')
		END
		
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @esx_licensing_status_enum_id, 'ESXLicensingStatuses')
												
	-- Register enumeration values
	--  Never collected
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @esx_licensing_status_enum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 1,
			@display_value  = N'Licensed',
			@small_icon_name = null,
			@large_icon_name = null
												
	
	
	--  Error
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @esx_licensing_status_enum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 0,
			@display_value  = N'Is not licensed',
			@small_icon_name = N'FailedSmall',
			@large_icon_name = null			
					


IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 8; END	
END
GO
--8


--9
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 9)
BEGIN

/********************************************************************************************************
*
*	BJOBS REFERRING TO ESX
*
*********************************************************************************************************/

	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = 'D44A0677-8B2F-4a12-AF3C-4C0E3ED6A02C', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'Backup jobs referring to ESX'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
			@report_id = @repid,
			@unique_name = N'bjobs_referring_esx',
			@display_name = N'Backup jos referreing to ESX',
			@datasrc_proc = N'usp.GridReport.DataSrc.Cfg.BJobsReferringESX',
			@grid_report_id = @grid_repid,
			@naviname_builder_id = @naviname_builder_id

	/****************** ORDERS ********************************************************/					
	DECLARE @order_bhost_name uniqueidentifier,
				 @order_bjob_name uniqueidentifier,
				 @order_is_licensed uniqueidentifier
			
	SELECT @order_bhost_name = NEWID(),
			   @order_bjob_name = NEWID(),
			   @order_is_licensed = NEWID() 

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_bhost_name, @grid_repid, 'cfg_bhost_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_bjob_name, @grid_repid, 'cfg_bjob_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_is_licensed, @grid_repid, 'cfg_bjob_is_licensed'

				
	/******************  COLUMNS ********************************************************/	
	DECLARE @esx_licensing_status_enum_id as uniqueidentifier	
	SELECT  @esx_licensing_status_enum_id = '98CA9026-F591-41e5-8A10-0309FD9DEFE7'
	
	/*  Licensing status icon */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,
	@col_unique_name = 'cfg_esx_is_licensed_icon',
	@col_number  = 0,
	@datasrc_col_name = 'esx_is_licensed',
	@enumeration_id = @esx_licensing_status_enum_id
	
					
	/* Backup host name */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Backup host',
		@col_unique_name = N'cfg_bhost_name',
		@col_width  = 100,
		@col_number = 1,
		@is_sortable = 1,
		@datasrc_col_name = N'bhost_name',
		@datasrc_col_type = 12,  --SqlDbType - nvarchar
		@format = 0, --text
		@order_id = @order_bhost_name
		
		
	/* Backup job name */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Job name',
		@col_unique_name = N'cfg_bjob_name',
		@col_width  = 200,
		@col_number = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'bjob_name',
		@datasrc_col_type = 12,  --SqlDbType - nvarchar
		@format = 0, --text
		@order_id = @order_bjob_name		
		
	
		
	/* Is licensed*/									
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = 'Is licensed',
		@col_unique_name = 'cfg_esx_licensed_in_bjob',
		@col_width = 50,
		@col_number  = 3,
		@is_sortable = 1,
		@datasrc_col_name = 'esx_is_licensed',
		@enumeration_id = @esx_licensing_status_enum_id,
		@order_id = @order_is_licensed					
			
			
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 9; END	
END
GO
--9


--10
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 10)
BEGIN

/********************************************************************************************************
*
*	CONFIGURATION - ESX LICENSING REPORT
*
*********************************************************************************************************/

	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '10B4CAD6-FF05-4882-A79D-6D5957608D35', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
		@builder_id = @naviname_builder_id,
		@format_str = N'Licensed ESXs'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
			@report_id = @repid,
			@unique_name = N'cfg_licensed_esxs',
			@display_name = N'Licensed ESXs',
			@datasrc_proc = N'usp.GridReport.DataSrc.Cfg.LicensedESXs',
			@grid_report_id = @grid_repid,
			@naviname_builder_id = @naviname_builder_id

	/****************** ORDERS ********************************************************/					
	DECLARE @order_esx_name uniqueidentifier,
			@order_esx_cpu_num uniqueidentifier,

			@order_is_licensed uniqueidentifier
			
	SELECT @order_esx_name = NEWID(),
			   @order_esx_cpu_num = NEWID(),

			   @order_is_licensed = NEWID() 

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_esx_name, @grid_repid, 'cfg_esx_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_esx_cpu_num, @grid_repid, 'cfg_esx_cpu_num'

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_is_licensed, @grid_repid, 'cfg_esx_is_licensed'

	/****************** CHILD WINDOWS *****************************************************/		
	DECLARE @esx_licensing_container_id uniqueidentifier		
	SELECT  @esx_licensing_container_id = '5FCA6C57-B46F-45c2-BE7E-90C91DBFF0D9'
	
	DECLARE @WindowContainerType as int
	SELECT   @WindowContainerType = 1
	
	DECLARE @esx_licdetails_wnd_id as uniqueidentifier
	SELECT  @esx_licdetails_wnd_id = 'A628F106-582E-46a1-8531-C6B7F4CB2B8D'

	INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
	VALUES( @esx_licdetails_wnd_id, 'Details', @WindowContainerType, 0 )


	/******************  TRANSITION ********************************************************/	
	/*      ESX -> JOBs                                                                                                                              */
	DECLARE @esx_2_bjobs_hrefid uniqueidentifier		
	SELECT @esx_2_bjobs_hrefid = '545D698D-9FC0-4ff1-A3BD-50331058DB1F'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @esx_licensing_container_id, @esx_2_bjobs_hrefid, @esx_licdetails_wnd_id )
	
	
	/******************  COLUMNS ********************************************************/	
	DECLARE @esx_licensing_status_enum_id as uniqueidentifier	
	SELECT  @esx_licensing_status_enum_id = '98CA9026-F591-41e5-8A10-0309FD9DEFE7'
	





	/*  Licensing status icon */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,
	@col_unique_name = 'cfg_esx_is_licensed_icon',
	@col_number  = 0,
	@datasrc_col_name = 'esx_is_licensed',
	@enumeration_id = @esx_licensing_status_enum_id
	
					
	/* ESX Name */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'ESX name',
		@col_unique_name = N'cfg_esx_name',
		@col_width  = 100,
		@col_number = 1,
		@is_sortable = 1,
		@datasrc_col_name = N'esx_name',
		@datasrc_col_type = 12,  --SqlDbType - nvarchar
		@format = 0, --text
		@order_id = @order_esx_name


	
	/* Sockets number */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'CPU number',
		@col_unique_name = N'cfg_esx_cpu_num',
		@col_width  = 50,
		@col_number = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'esx_cpu_num',
		@datasrc_col_type = 8,  /*SqlDbType.Int*/
		@format = 0, --text		
		@order_id = @order_esx_cpu_num
		
	/* Is licensed*/									
	EXEC [dbo].[usp.GridReport.Config.RegColWithEnumHrefDynBinding]
	    @grid_report_id = @grid_repid,
 	    @col_display_name = N'Is licensed',
	    @col_unique_name = N'cfg_esx_is_licensed',
	    @col_width  = 50,
	    @col_number = 3,
	    @is_sortable = 1,						
	    @trg_report_id = 'D44A0677-8B2F-4a12-AF3C-4C0E3ED6A02C',  /*BJOBS referring to ESX*/
	    @href_id = @esx_2_bjobs_hrefid,	
	    @datasrc_enumcol_name = N'esx_is_licensed',
	    @datasrc_enum_type = @esx_licensing_status_enum_id,
	    @dyn_attr1_name = N'esx_uuid_string',
	    @datasrc_dynattr1_colname = N'esx_uuid_string',	
	    @order_id = @order_is_licensed
	
				      		       			
	/************************* TASKS ****************************************************/						
	/*   Revoke licenses  */
	DECLARE @revoke_lic_task_id uniqueidentifier
	SELECT   @revoke_lic_task_id = '80AC5B3F-18AC-4468-ADB9-2015837032E2'
		
	EXEC [dbo].[Report.Shared.RegisterTaskType]
		@task_id = @revoke_lic_task_id,
		@img_folder_id = '01E6F41B-E0E4-4866-A9D1-124BD06B125D',
		@img_name = N'RevokeLicense',
		@description = N'Revoke...',
		@req_lines_selection = true,
		@invoke_type = 2
	EXEC [usp.GridReport.Config.RegTask]
		@grid_id = @grid_repid,
		@task_type_id = @revoke_lic_task_id,
		@ordinal_number = 0

	
		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 10; END	
END
GO
--10

-----------------------------------------------------
--11 Lab Requests Report
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 11)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	
		/* CONTAINERS */
		DECLARE @TabContainerType as int
		SELECT  @TabContainerType = 2

		/* LAB REQUESTS TAB */
		DECLARE @labrequests_tab_id as uniqueidentifier
		SELECT @labrequests_tab_id = ''80DC608D-7445-44d2-89CC-A4316C88B6A9''
		
		IF NOT EXISTS (SELECT id FROM [dbo].[Rendering.Containers] WHERE [id]=@labrequests_tab_id)
		BEGIN
			INSERT INTO [dbo].[Rendering.Containers]( [id], [display_name], [type], [is_history_bar_required])
			VALUES( @labrequests_tab_id, ''Requests'', @TabContainerType, 0 )
		END
		
	'
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 11; END	
END
GO
--11
-----------------------------------------------------


-----------------------------------------------------
--13
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 13)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		/* LABREQUESTS INITIALPAGE */
		DECLARE @labrequests_tab_id as uniqueidentifier
		SELECT @labrequests_tab_id = ''80DC608D-7445-44d2-89CC-A4316C88B6A9''

		/* REPORTS */
		DECLARE @labrequests_rep_id as uniqueidentifier
		SELECT @labrequests_rep_id = ''7D533175-1981-4632-9F15-8D098FF6BC61''
		
		/* REG LABREQUESTS  */	
		IF NOT EXISTS (SELECT id FROM [dbo].[Startup.InitialReportPages] WHERE [container_id]=@labrequests_tab_id)
		BEGIN
		
			EXEC [dbo].[usp.Startup.RegInitialReportPage]
				@page_id = @labrequests_tab_id,
				@report_id = @labrequests_rep_id,
				@ordinal_number = 12
		END		
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 13; END	
END
GO
--13
-----------------------------------------------------


-----------------------------------------------------
--14
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 14)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
	
		/* LABREQUESTS GRID REPORT */		
		DECLARE @repid as uniqueidentifier
		DECLARE @naviname_builder_id as uniqueidentifier

		SELECT @repid = ''7D533175-1981-4632-9F15-8D098FF6BC61'', @naviname_builder_id = NEWID()

		IF NOT EXISTS (SELECT id FROM [dbo].[Reports] WHERE [id]=@repid)
		BEGIN
		
			EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
				@builder_id = @naviname_builder_id,
				@format_str = N''Requests''

			INSERT INTO [dbo].[Reports]([id],[unique_name],[display_name], [naviname_builder_id])
			VALUES( @repid, ''cat_lab_requests'', ''Requests'', @naviname_builder_id)
		END
			
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 14; END	
END
GO
--14
-----------------------------------------------------



-----------------------------------------------------
--16
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 16)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'	
		EXEC [dbo].[usp.Startup.ChangeInitialPageOrders]			
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 16; END	
END
GO
--16
-----------------------------------------------------



-----------------------------------------------------
--17
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version < 17)
BEGIN
	---------------------------------------------------
	exec sp_executesql @stat = N'
		
		DECLARE @repid as uniqueidentifier
		DECLARE @grid_repid as uniqueidentifier
		DECLARE @naviname_builder_id as uniqueidentifier

		SELECT @repid = ''33A81C44-4626-4090-9C18-F896E623E635'', @grid_repid = ''6BE07D21-8B82-4748-9E9E-2C92B4193079'', @naviname_builder_id = NEWID()

		EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder]
			@builder_id = @naviname_builder_id,
			@format_str = N''Requests''

		EXEC [dbo].[usp.GridReport.Config.RegGridReport]
				@report_id = @repid,
				@unique_name = N''cfg_lab_requests'',
				@display_name = N''Requests'',
				@datasrc_proc = N''usp.GridReport.DataSrc.Cfg.LabRequests'',
				@grid_report_id = @grid_repid,
				@naviname_builder_id = @naviname_builder_id,
				@view_type = 1

		
		/* LABREQUESTS REPORT COLUMNS ORDERS */
		declare @order_cfg_labrequests_username uniqueidentifier
		declare @order_cfg_labrequests_vm uniqueidentifier
		declare @order_cfg_labrequests_description uniqueidentifier
		declare @order_cfg_labrequests_duration uniqueidentifier
		declare @order_cfg_labrequests_date uniqueidentifier
		declare @order_cfg_labrequests_state uniqueidentifier
		
		select @order_cfg_labrequests_username = NEWID(),
		@order_cfg_labrequests_vm = NEWID(),
		@order_cfg_labrequests_description = NEWID(),
		@order_cfg_labrequests_duration = NEWID(),
		@order_cfg_labrequests_date = NEWID(),
		@order_cfg_labrequests_state = NEWID()

		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_labrequests_username, @grid_repid,  ''cfg_labrequests_username''
		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_labrequests_vm, @grid_repid,  ''cfg_labrequests_vm''
		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_labrequests_description, @grid_repid,  ''cfg_labrequests_description''
		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_labrequests_duration, @grid_repid,  ''cfg_labrequests_duration''
		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_labrequests_date, @grid_repid,  ''cfg_labrequests_date''
		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cfg_labrequests_state, @grid_repid,  ''cfg_labrequests_state''
			
			
			
				
		/* LABREQUESTS REPORT COLUMNS */					
		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
			@grid_report_id = @grid_repid,
			@col_display_name = N''User name'',
			@col_unique_name = N''cfg_labrequests_username'',
			@col_width  = 100,
			@col_number = 1,
			@is_sortable = 1,
			@datasrc_col_name = N''cfg_labrequests_username'',
			@datasrc_col_type = 12,  --SqlDbType - nvarchar
			@format = 0, --text
			@order_id = @order_cfg_labrequests_username
			
		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
			@grid_report_id = @grid_repid,
			@col_display_name = N''VM'',
			@col_unique_name = N''cfg_labrequests_vm'',
			@col_width  = 100,
			@col_number = 2,
			@is_sortable = 1,
			@datasrc_col_name = N''cfg_labrequests_vm'',
			@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
			@format = 0, --text
			@order_id = @order_cfg_labrequests_vm

		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
			@grid_report_id = @grid_repid,
			@col_display_name = N''Description'',
			@col_unique_name = N''cfg_labrequests_description'',
			@col_width  = 80,
			@col_number = 3,
			@is_sortable = 1,
			@datasrc_col_name = N''cfg_labrequests_description'',
			@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
			@format = 0, --text
			@order_id = @order_cfg_labrequests_description
			
		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
			@grid_report_id = @grid_repid,
			@col_display_name = N''Duration'',
			@col_unique_name = N''cfg_labrequests_duration'',
			@col_width  = 80,
			@col_number = 4,
			@is_sortable = 1,
			@datasrc_col_name = N''cfg_labrequests_duration'',
			@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
			@format = 0, --text
			@order_id = @order_cfg_labrequests_duration			
		
		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
			@grid_report_id = @grid_repid,
			@col_display_name = N''Date'',
			@col_unique_name = N''cfg_labrequests_date'',
			@col_width  = 200,
			@col_number = 5,
			@is_sortable = 1,
			@datasrc_col_name = N''cfg_labrequests_date'',
			@datasrc_col_type = 4,  /*SqlDbType - datetime*/
			@format = 1, --date
			@order_id = @order_cfg_labrequests_date

		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
			@grid_report_id = @grid_repid,
			@col_display_name = N''State'',
			@col_unique_name = N''cfg_labrequests_state'',
			@col_width  = 200,
			@col_number = 5,
			@is_sortable = 1,
			@datasrc_col_name = N''cfg_labrequests_state'',
			@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
			@format = 0, --text	
			@order_id = @order_cfg_labrequests_state
		
		
		/******* FILTERS *******************************************************************************/	
					
		/*  STATE FILTER */
		DECLARE @lrstate_filter_type_id as uniqueidentifier
		SELECT @lrstate_filter_type_id = ''839E9CC1-E6A1-41d3-B64F-3C4863509BA9''
		INSERT INTO [dbo].[Report.GridReport.Filters]( [id], [grid_report_id], [filter_type_id], [display_name], [unique_name], [ordinal_number], [width], [prefval_object_id])
		VALUES( NEWID(), @grid_repid, @lrstate_filter_type_id, ''State'', ''lr_state'', 0, 100, ''f0c46dea-14aa-4ba4-99c9-70274e811c77'' )

		/*  VM NAME FILTER */
		DECLARE @jobname_filter_type_id as uniqueidentifier
		SELECT @jobname_filter_type_id = ''D7F9A519-3782-48d1-833F-68868B7E61C9''
		INSERT INTO [dbo].[Report.GridReport.Filters]( [id], [grid_report_id], [filter_type_id], [display_name], [unique_name], [ordinal_number], [width])
		VALUES( NEWID(), @grid_repid, @jobname_filter_type_id, ''VM name'',''lr_vm_name'', 2, 100 )

			
		/* LABREQUESTS REPORT TASKS */
				
		/*   CREATE  REQUEST  */
		DECLARE @create_request_task_id uniqueidentifier
		SELECT @create_request_task_id = ''208B6589-5E8B-4c1a-8376-52E18A351C7E''
			
		EXEC [dbo].[Report.Shared.RegisterTaskType]
			@task_id = @create_request_task_id,
			@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
			@img_name = N''AddServer'',
			@description = N''Create...'',
			@req_lines_selection = true,
			@invoke_type = 2
		EXEC [usp.GridReport.Config.RegTask]
			@grid_id = @grid_repid,
			@task_type_id = @create_request_task_id,
			@ordinal_number = 0
			
		/*   APPROVE  REQUEST  */
		DECLARE @approve_request_task_id uniqueidentifier
		SELECT @approve_request_task_id = ''5B644663-24E8-45a3-9A66-D4B5F950DA23''
			
		EXEC [dbo].[Report.Shared.RegisterTaskType]
			@task_id = @approve_request_task_id,
			@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
			@img_name = N''StartJob'',
			@description = N''Approve...'',
			@req_lines_selection = true,
			@invoke_type = 2
		EXEC [usp.GridReport.Config.RegTask]
			@grid_id = @grid_repid,
			@task_type_id = @approve_request_task_id,
			@ordinal_number = 1
			
		
		/*   REJECT  REQUEST  */
		DECLARE @reject_request_task_id uniqueidentifier
		SELECT @reject_request_task_id = ''CC458B1D-F57A-47f1-9829-0BF83D07316E''
			
		EXEC [dbo].[Report.Shared.RegisterTaskType]
			@task_id = @reject_request_task_id,
			@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
			@img_name = N''StopJob'',
			@description = N''Reject...'',
			@req_lines_selection = true,
			@invoke_type = 2
		EXEC [usp.GridReport.Config.RegTask]
			@grid_id = @grid_repid,
			@task_type_id = @reject_request_task_id,
			@ordinal_number = 2
			
		/*   PROLONG  REQUEST  */
		DECLARE @prolong_request_task_id uniqueidentifier
		SELECT @prolong_request_task_id = ''22071672-F3C7-4efe-98A5-886CCDDE2AB2''
			
		EXEC [dbo].[Report.Shared.RegisterTaskType]
			@task_id = @prolong_request_task_id,
			@img_folder_id = ''01E6F41B-E0E4-4866-A9D1-124BD06B125D'',
			@img_name = N''RetryJob'',
			@description = N''Prolong...'',
			@req_lines_selection = true,
			@invoke_type = 2
		EXEC [usp.GridReport.Config.RegTask]
			@grid_id = @grid_repid,
			@task_type_id = @prolong_request_task_id,
			@ordinal_number = 3
			
	'	
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 17; END	
END
GO
--17
-----------------------------------------------------



----------------------------------------------------
--18
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 17)
BEGIN

/********************************************************************************************************
*
*	SUREBACKUP SESSION DETAILS REPORT
*
*********************************************************************************************************/		
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '79B78F18-4E61-46a4-BE5E-35DEAA8ED41B', @grid_repid = NEWID(), @naviname_builder_id = NEWID()
		
	/******************* NAVINAME BUILDER **********************************************/
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
	@builder_id = @naviname_builder_id,
	@format_str = N'Session {0}',
	@query_attr_name = N'navi_name_attr'

	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
		@report_id = @repid,
		@unique_name = N'sb_session_details',
		@display_name = N'SureBackup session details',
		@datasrc_proc = N'usp.GridReport.DataSrc.SbSessionDetails',
		@grid_report_id = @grid_repid,
		@naviname_builder_id = @naviname_builder_id
		
	INSERT INTO [dbo].[Report.Headers] ([id], [unique_name], [report_id], [datasrc_proc])
	VALUES('89AA0FF5-49A1-4306-BF28-A56B0266636C', N'SbJobSessionHeader', @repid, N'usp.GridReport.DataSrc.SbJobSessionsHeader')

	/******************  HYPERLINKS *****************************************************/
	/*   VM -> ALL VM SESSIONS  */
	DECLARE @vm_2_vmsessions_hyperlink_id as uniqueidentifier
	SELECT @vm_2_vmsessions_hyperlink_id = 'DB20115E-2743-4756-9137-13AECBF7ACC8'

	/************************* ORDERS ****************************************************/
	DECLARE @order_vm_name uniqueidentifier,
		@order_vm_processing_start_time uniqueidentifier,
		@order_vm_processing_end_time uniqueidentifier,
		@order_vm_processing_status uniqueidentifier,
		@order_sb_test_status uniqueidentifier,
		@order_sb_heartbeat_status uniqueidentifier,
		@order_sb_ping_status uniqueidentifier
		
	SELECT @order_vm_name = NEWID(),
		@order_vm_processing_start_time = NEWID(),
		@order_vm_processing_end_time = NEWID(),
		@order_vm_processing_status = NEWID(),
		@order_sb_test_status = NEWID(),
		@order_sb_heartbeat_status = NEWID(),
		@order_sb_ping_status = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_name, @grid_repid, 'vm_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_start_time, @grid_repid, 'vm_processing_start_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_end_time, @grid_repid, 'vm_processing_end_time'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vm_processing_status, @grid_repid, 'vm_processing_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_sb_test_status, @grid_repid, 'sb_test_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_sb_heartbeat_status, @grid_repid, 'sb_heartbeat_status'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_sb_ping_status, @grid_repid, 'sb_ping_status'

	/******************  ENUMERATIONS ***************************************************/
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @sb_oper_status_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @sb_oper_status_enum_id = '98DDA4C5-17E6-4d38-9945-9631BE717DA7'
	
	-----------------------------------------
	--SureBackup operation status
		   
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @sb_oper_status_enum_id, 'SbOperationStatusEnum')
												
	-- Register enumeration values
	--  Pending
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
		@sb_oper_status_enum_id, @statuses_img_folder_id, 0, N'Pending', null, null
	--  InProgress
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
		@sb_oper_status_enum_id, @statuses_img_folder_id, 2, N'In progress', null, null
	--  Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
		@sb_oper_status_enum_id, @statuses_img_folder_id, 3, N'Success', null, null
	--  Failed
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
		@sb_oper_status_enum_id, @statuses_img_folder_id, 4, N'Failed', null, null
	--  Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
		@sb_oper_status_enum_id, @statuses_img_folder_id, 5, N'Warning', null, null
	--  NotRunned
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
		@sb_oper_status_enum_id, @statuses_img_folder_id, 6, N'Not runned', null, null
	--  Disabled
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
		@sb_oper_status_enum_id, @statuses_img_folder_id, 7, N'Disabled', null, null
				
	--
	-----------------------------------------





	-----------------------------------------
	--SureBackup Task Session Result (i.e. overall_status)
	DECLARE @si_overallstatus_enum_id as uniqueidentifier	
	SELECT @si_overallstatus_enum_id = '78001031-9FD4-4a01-9D83-3BE65077B1A1'
	
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @si_overallstatus_enum_id, 'ObjectStatuses')
												
	-- Register enumeration values	
	--  0 - NotRunning	
	--  1 - Success
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @si_overallstatus_enum_id, @statuses_img_folder_id, 1, 'Success', 'SuccessSmall', null
	--  2 - Failed
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @si_overallstatus_enum_id, @statuses_img_folder_id, 2, 'Failed', 'FailedSmall', null
	--  3 - Warning
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @si_overallstatus_enum_id, @statuses_img_folder_id, 3, 'Warning', 'WarningSmall', null 
	--
	-----------------------------------------




		   
	/******************  COLUMNS ********************************************************/					
			
	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,				
	@col_unique_name = 'vm_processing_status_icon',				
	@col_number  = 0,				
	@datasrc_col_name = 'vm_processing_status',
	@enumeration_id = @si_overallstatus_enum_id

	/* VM NAME   */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'VM',
	@col_unique_name = N'vm_2_vmsessions_href',
	@col_width  = 100,
	@col_number = 1,
	@is_sortable = 1,
	@trg_report_id = '3644428A-D5DD-410d-976C-34C13A76F047',  /*SESSIONS HISTORY*/
	@href_id = @vm_2_vmsessions_hyperlink_id,
	@datasrc_textcol_name = N'vm_name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'vm_id',
	@dyn_attr2_name = 'vm_name',
	@datasrc_dynattr2_colname = 'vm_name',
	@format = 0, --text
	@order_id = @order_vm_name

	/* START TIME */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Start Time',
	@col_unique_name = N'vm_processing_start_time',
	@col_width  = 100,
	@col_number = 2,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processing_start_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_vm_processing_start_time

	/* END TIME */			
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'End Time',
	@col_unique_name = N'vm_processing_end_time',
	@col_width  = 100,
	@col_number = 3,
	@is_sortable = 1,
	@datasrc_col_name = N'vm_processing_end_time',				
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/	
	@format = 1, --datetime
	@order_id = @order_vm_processing_end_time

	/* RESULT */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Result',
	@col_unique_name = 'vm_processing_status_text',
	@col_width = 80,
	@col_number  = 4,
	@is_sortable = 1,
	@datasrc_col_name = 'vm_processing_status',
	@enumeration_id = @si_overallstatus_enum_id,
	@order_id = @order_vm_processing_status											


	/* TEST STATUS */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Test',
	@col_unique_name = 'sb_test_status',
	@col_width = 50,
	@col_number  = 5,
	@is_sortable = 1,
	@datasrc_col_name = 'sb_test_status',
	@enumeration_id = @sb_oper_status_enum_id,
	@order_id = @order_sb_test_status
	
	/* HEARTBEAT */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Heartbeat',
	@col_unique_name = 'sb_heartbeat_status',
	@col_width = 50,
	@col_number  = 6,
	@is_sortable = 1,
	@datasrc_col_name = 'sb_heartbeat_status',
	@enumeration_id = @sb_oper_status_enum_id,
	@order_id = @order_sb_heartbeat_status
	
	/* PING */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Ping',
	@col_unique_name = 'sb_ping_status',
	@col_width = 50,
	@col_number  = 7,
	@is_sortable = 1,
	@datasrc_col_name = 'sb_ping_status',
	@enumeration_id = @sb_oper_status_enum_id,
	@order_id = @order_sb_ping_status
	
	/*  ERROR DETAILS  */
	EXEC [dbo].[usp.GridReport.Config.RegDetailsPanelWithDirectColBinding]
	@grid_report_id = @grid_repid,
	@src_col_name = N'vm_processing_details',
	@panel_width = 200,
	@title = N'Details',
	@format = 0, --text
	@default_text = N''
		
    ----------------------------------------------------
    
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 18; END	
END
GO
--18
-----------------------------------------------------


----------------------------------------------------
--19
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 18)
BEGIN

	/*    JOBS MGMT -> LAST SUREBACKUP SESSION */
	DECLARE 
		@jobs_tab_id as uniqueidentifier,
		@reports_tab_id as uniqueidentifier
	SELECT 
		@jobs_tab_id = '7FFD1688-B14C-4692-8EFB-45A3E9F1E45A',
		@reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'

	DECLARE @bjob_2_last_sb_session_hrefid uniqueidentifier		
	SELECT @bjob_2_last_sb_session_hrefid = '087B258B-4174-470d-89FB-0DE8CBF45569'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @jobs_tab_id, @bjob_2_last_sb_session_hrefid, @reports_tab_id )

	DECLARE 
		@dynHrefBind_Jobs_CurrentState uniqueidentifier,
		@hrefBind_2_joblog uniqueidentifier

	SELECT
		@dynHrefBind_Jobs_CurrentState = [dbo].[Report.GridReport.Columns].[href_binding_id] 
	FROM [dbo].[Report.GridReport.Columns] 
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Report.GridReport.Columns].[grid_report_id] = [dbo].[Report.GridReports].[id]
		INNER JOIN [dbo].[Reports] ON [dbo].[Report.GridReports].[report_id] = [dbo].[Reports].[id]
	WHERE 
		[dbo].[Reports].[unique_name] = N'current_jobs' AND 
		[dbo].[Report.GridReport.Columns].[unique_name] = N'job_status'

	SELECT
		@hrefBind_2_joblog = [dbo].[Report.GridReport.Binding.DynHrefColBindings].[href_binding2_id]
		FROM [dbo].[Report.GridReport.Binding.DynHrefColBindings]
		WHERE [dbo].[Report.GridReport.Binding.DynHrefColBindings].[id] = @dynHrefBind_Jobs_CurrentState

	DECLARE 
		@sb_session_details_repid uniqueidentifier,
		@bjob_2_joblog_hrefid uniqueidentifier
	SELECT 
		@sb_session_details_repid = '79B78F18-4E61-46a4-BE5E-35DEAA8ED41B',
		@bjob_2_joblog_hrefid = '27686973-22FF-4875-8023-F591A19DC6EA'

	EXEC [dbo].[usp.GridReport.Config.ReRegHrefBinding]
		@trg_report_id				= @sb_session_details_repid,
		@href_id					= @bjob_2_last_sb_session_hrefid,
		@href_binding_id			= @hrefBind_2_joblog,
		@dyn_attr1_name				= 'id',
		@datasrc_dynattr1_colname	= 'session_id',
		@dyn_attr2_name				= 'navi_name_attr',
		@datasrc_dynattr2_colname	= 'session_creation_time'

    
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 19; END	
END
GO
--19
-----------------------------------------------------


------------------------------------------------------------------
--20
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 19)
BEGIN
    ---------------------------------------------------
    --   JOB TYPES - enumeration extensions                                                                                                                                               
    ---------------------------------------------------
    exec sp_executesql @stat = N'
                    DECLARE @statuses_img_folder_id as uniqueidentifier
                    DECLARE @job_types_enum_id as uniqueidentifier
    
                    SELECT @statuses_img_folder_id = ''FBB0BD0E-9274-4cda-BEFF-653785C89082'',
                                       @job_types_enum_id = ''2ED2AF5B-041A-4e8b-B467-F960B894EF7F''
                                                                                                                                                                                                                    
                    --  Register enumeration values
                    --  SureBackup
                    EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @job_types_enum_id, @statuses_img_folder_id, 3, ''SureBackup'', null, null

    '
    ----------------------------------------------------
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 20; END              
END
GO
--20
-----------------------------------------------------




----------------------------------------------------
--21
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 20)
BEGIN

	DECLARE 
		@jobs_tab_id as uniqueidentifier,
		@reports_tab_id as uniqueidentifier
	SELECT 
		@jobs_tab_id = '7FFD1688-B14C-4692-8EFB-45A3E9F1E45A',
		@reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'

	/*    SUREBACKUP JOBS -> LAST SESSION*/
	DECLARE @sbjob2last_session_href_id as uniqueidentifier
	SELECT @sbjob2last_session_href_id = '538AE593-F61C-4757-9FB7-FEA65D8723F0'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @sbjob2last_session_href_id, @reports_tab_id )

	/*    JOBS -> ALL SESSIONS*/
	DECLARE @sbjob2all_sessions_href_id as uniqueidentifier
	SELECT @sbjob2all_sessions_href_id = '34F60C1B-9005-41e8-8845-1BDDB3B0D270'
			
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @sbjob2all_sessions_href_id, @reports_tab_id )



/********************************************************************************************************
*
*	SUREBACKUP JOBS PER SERVER REPORT
*
*********************************************************************************************************/		
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier
	DECLARE @naviname_builder_id as uniqueidentifier

	SELECT @repid = '51BD6D3E-1F39-4fa7-9E5C-13C33A14DD1B', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

	/******************* NAVINAME BUILDER **********************************************/
	EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
	@builder_id = @naviname_builder_id,
	@format_str = N'{0}',
	@query_attr_name = N'srv_display_name'

		
	EXEC [dbo].[usp.GridReport.Config.RegGridReport]
		@report_id = @repid,
		@unique_name = N'sb_jobs_per_server',
		@display_name = N'SureBackup Jobs',
		@datasrc_proc = N'usp.GridReport.DataSrc.SbJobsPerServer',
		@grid_report_id = @grid_repid,
		@naviname_builder_id = @naviname_builder_id

	/******************  HYPERLINKS *****************************************************/
	/*   JOB -> LAST SESSION  */		
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @sbjob2last_session_href_id,
	 @hyperlink_unique_name = N'sbjob2last_session'
	 
	/*   JOB -> ALL SESSIONS  */
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
	 @hyperlink_id = @sbjob2all_sessions_href_id,
	 @hyperlink_unique_name = N'sbjob2all_sessions'

	/************************* ORDERS ****************************************************/
	DECLARE @order_job_name uniqueidentifier,
	@order_esx_host_name uniqueidentifier,
	@order_vlab_name uniqueidentifier,
	@order_cur_state uniqueidentifier,
	@order_last_result uniqueidentifier,
	@order_last_success uniqueidentifier

	SELECT @order_job_name = NEWID(),
	@order_esx_host_name = NEWID(),
	@order_vlab_name = NEWID(),
	@order_cur_state = NEWID(),
	@order_last_result = NEWID(),
	@order_last_success = NEWID()

	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_name, @grid_repid, 'job_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_esx_host_name, @grid_repid, 'esx_host_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_vlab_name, @grid_repid, 'vlab_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_cur_state, @grid_repid, 'cur_state'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_last_result, @grid_repid, 'last_result'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_last_success, @grid_repid, 'last_success'

	/******************  COLUMNS ********************************************************/					
	DECLARE 
	@jobstatuses_enum_id as uniqueidentifier,
	@joblastres_enum_id as uniqueidentifier,
	@jobtypes_enum_id as uniqueidentifier
		
	SELECT  
	@jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E',
	@joblastres_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3',
	@jobtypes_enum_id = '2ED2AF5B-041A-4e8b-B467-F960B894EF7F'

	/* STATUS ICON */
	EXEC [dbo].[usp.GridReport.Config.RegIconCol]
	@grid_report_id = @grid_repid,
	@col_unique_name = 'job_cur_state_icon',
	@col_number  = 0,
	@datasrc_col_name = 'job_cur_state',
	@enumeration_id = @joblastres_enum_id

	/* JOB NAME */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Job Name',
	@col_unique_name = N'job_name',
	@col_width  = 100,
	@col_number = 1,
	@is_sortable = 1,
	@trg_report_id = '8BC0EDA7-AAD8-4d7c-96FE-2B671CA1EDDF',  /*sessions per SureBackup job*/
	@href_id = @sbjob2all_sessions_href_id,
	@datasrc_textcol_name = N'job_name',
	@datasrc_textcol_type = 12, -- nvarchar
	@dyn_attr1_name = 'id',
	@datasrc_dynattr1_colname = 'id',
	@dyn_attr2_name = 'job_name',
	@datasrc_dynattr2_colname = 'job_name',
	@format = 0, --text
	@order_id = @order_job_name

	/* ESX Host */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'ESX Host',
	@col_unique_name = N'esx_host_name',
	@col_width  = 60,
	@col_number = 2,
	@is_sortable = 1,
	@datasrc_col_name = N'esx_host_name',
	@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
	@format = 0, --text
	@order_id = @order_esx_host_name

	/* VLab Name */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'VLab Name',
	@col_unique_name = N'vlab_name',
	@col_width  = 60,
	@col_number = 3,
	@is_sortable = 1,
	@datasrc_col_name = N'vlab_name',
	@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
	@format = 0, --text
	@order_id = @order_vlab_name

	/* CURRENT STATE */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Current State',
	@col_unique_name = 'job_cur_state',
	@col_width = 50,
	@col_number  = 4,
	@is_sortable = 1,
	@datasrc_col_name = 'job_cur_state',
	@enumeration_id = @jobstatuses_enum_id,
	@order_id = @order_cur_state
		
	/* LAST RESULT */
	EXEC [dbo].[usp.GridReport.Config.RegColWithEnumHrefDynBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Last Result',
	@col_unique_name = N'job_last_result',
	@col_width  = 50,
	@col_number = 5,
	@is_sortable = 1,
	@trg_report_id = '79B78F18-4E61-46a4-BE5E-35DEAA8ED41B',  /*SureBackup session details*/
	@href_id = @sbjob2last_session_href_id,
	@datasrc_enumcol_name = N'last_result',
	@datasrc_enum_type = @joblastres_enum_id, 
	@dyn_attr1_name = N'id',
	@datasrc_dynattr1_colname = N'job_last_session_id',
	@dyn_attr2_name = 'navi_name_attr',
	@datasrc_dynattr2_colname = 'session_creation_time',
	@order_id = @order_last_result

	/* LAST SUCCESS */							
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Last Success',
	@col_unique_name = 'last_success_time',
	@col_width = 60,
	@col_number  = 6,
	@is_sortable = 1,
	@datasrc_col_name = 'last_success',
	@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
	@format = 1, --datetime
	@order_id = @order_last_success

	/* DESCRIPTION */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = N'Job Description',
	@col_unique_name = N'job_description',
	@col_width  = 200,
	@col_number = 7,
	@is_sortable = 0,
	@datasrc_col_name = N'job_description',
	@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
	@format = 0 --text		


IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 21; END	
END
GO
--21
-----------------------------------------------------

----------------------------------------------------
--22
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 21)
BEGIN

	DECLARE 
		@reports_tab_id as uniqueidentifier
	SELECT 
		@reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'

	/*   SUREBACKUP JOBS SESSIONS -> CONCRETE SESSION */
	DECLARE @sb_sessions_2_session_href_id as uniqueidentifier
	SELECT @sb_sessions_2_session_href_id = 'BF3C5F0B-21A9-4a3b-8068-FB3118F9A263'
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @sb_sessions_2_session_href_id, @reports_tab_id )


	/****************************************************************************************
	*
	*		SUREBACKUP SESSIONS PER JOB REPORT
	*
	*****************************************************************************************/
		DECLARE @repid as uniqueidentifier
		DECLARE @grid_repid as uniqueidentifier
		DECLARE @naviname_builder_id as uniqueidentifier
		SELECT @repid = '8BC0EDA7-AAD8-4d7c-96FE-2B671CA1EDDF', @grid_repid = NEWID(), @naviname_builder_id = NEWID()

		EXEC [dbo].[usp.Report.Shared.RegisterNaviNameBuilder1]
		@builder_id = @naviname_builder_id,
		@format_str = N'{0}',
		@query_attr_name = N'job_name'

		EXEC [dbo].[usp.GridReport.Config.RegGridReport]
			@report_id = @repid,
			@unique_name = N'sb_sessions_per_job',				
			@display_name = N'SureBackup Job Sessions',
			@datasrc_proc = N'usp.GridReport.DataSrc.SbSessionsPerJob',
			@grid_report_id = @grid_repid,
			@naviname_builder_id = @naviname_builder_id			

		/******************  HYPERLINKS *****************************************************/
		/*   SB SESSIONS -> SB SESSION  */
		EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
		 @hyperlink_id = @sb_sessions_2_session_href_id,
		 @hyperlink_unique_name = N'sb_sessions_2_sb_session'
		 					
		/************************* ORDERS ****************************************************/
		DECLARE @order_job_start_time uniqueidentifier,
		@order_job_end_time uniqueidentifier,
		@order_job_result uniqueidentifier

		SELECT @order_job_start_time = NEWID(),
		@order_job_end_time = NEWID(),
		@order_job_result = NEWID()

		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_start_time, @grid_repid, 'job_start_time'
		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_end_time, @grid_repid, 'job_end_time'
		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_job_result, @grid_repid, 'job_result'

		/******************  COLUMNS ********************************************************/					
		DECLARE @jobstatuses_enum_id as uniqueidentifier
		SELECT  @jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E'

		/* STATUS ICON */
		EXEC [dbo].[usp.GridReport.Config.RegIconCol]
		@grid_report_id = @grid_repid,				
		@col_unique_name = 'job_status_icon',
		@col_number  = 0,				
		@datasrc_col_name = 'job_status',
		@enumeration_id = @jobstatuses_enum_id

		/* START TIME */
		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Start Time',
		@col_unique_name = N'job_start_time',
		@col_width  = 70,
		@col_number = 1,
		@is_sortable = 1,
		@datasrc_col_name = N'job_start_time',
		@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
		@format = 1, --datetime
		@order_id = @order_job_start_time

		/* END TIME */
		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'End Time',
		@col_unique_name = N'job_end_time',
		@col_width  = 70,
		@col_number = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'job_end_time',
		@datasrc_col_type = 4,  /*SqlDbType - DateTime*/
		@format = 1, --datetime
		@order_id = @order_job_end_time

		/* RESULT */
		EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Result',
		@col_unique_name = N'session_href',
		@col_width  = 50,
		@col_number = 3,
		@is_sortable = 1,
		@trg_report_id = '79B78F18-4E61-46a4-BE5E-35DEAA8ED41B',  /*SureBackup session details*/
		@href_id = @sb_sessions_2_session_href_id,
		@datasrc_textcol_name = N'job_status_text',
		@datasrc_textcol_type = 12, -- nvarchar
		@dyn_attr1_name = 'id',
		@datasrc_dynattr1_colname = 'id',
		@dyn_attr2_name = 'navi_name_attr',
		@datasrc_dynattr2_colname = 'job_start_time',
		@format = 0, --text
		@order_id = @order_job_result

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 22; END	
END
GO
--22
-----------------------------------------------------




----------------------------------------------------
--23
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 22)
BEGIN

	DECLARE @backup_servers_grid_repid uniqueidentifier

	SELECT @backup_servers_grid_repid = [dbo].[Report.GridReports].[id]
	FROM 
		[dbo].[Report.GridReports] 
		INNER JOIN [dbo].[Reports] ON [dbo].[Report.GridReports].[report_id] = [dbo].[Reports].[id]
	WHERE 
		[dbo].[Reports].[id] = 'ED83A1E2-632E-4d81-B112-7FFE60336F10'

	EXEC [dbo].[usp.GridReport.Config.UnRegColWithBinding] @backup_servers_grid_repid, N'jobs_count'

	DECLARE @reports_tab_id as uniqueidentifier
	SELECT @reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'

	-- HYPERLINKS
	/*    SERVERS -> SUREBACKUP JOBS */
	DECLARE @srv2sbjobs_href_id as uniqueidentifier
	SELECT @srv2sbjobs_href_id = 'E5200D48-82DD-498c-82F3-D11C13EC9C6A'

	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @reports_tab_id, @srv2sbjobs_href_id, @reports_tab_id )
	
	/*    SERVERS -> JOBS */
	DECLARE @srv2jobs_href_id as uniqueidentifier
	SELECT @srv2jobs_href_id = 'CB7499CE-DD2A-4e25-9F8B-3FCB4B8DE0D7'
	
	-- ORDERS
	DECLARE 
		@order_jobs_count uniqueidentifier,
		@order_sb_jobs_count uniqueidentifier
	SELECT 
		@order_jobs_count = NEWID(),
		@order_sb_jobs_count = NEWID()
		
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_jobs_count, @backup_servers_grid_repid, 'jobs_count'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_sb_jobs_count, @backup_servers_grid_repid, 'sb_jobs_count'
	
	-- COLUMNS
	/* JOBS COUNT */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
		@grid_report_id = @backup_servers_grid_repid,
		@col_display_name = N'Jobs Count',
		@col_unique_name = N'jobs_count',
		@col_width  = 40,
		@col_number = 3,
		@is_sortable = 1,
		@trg_report_id = 'E3FB504E-DCBD-4d26-993E-E1A1D62095B1',  /* jobs per server*/
		@href_id = @srv2jobs_href_id,
		@datasrc_textcol_name = 'jobs_count',
		@datasrc_textcol_type = 8, --int --12, -- nvarchar
		@dyn_attr1_name = 'id',
		@datasrc_dynattr1_colname = 'id',
		@dyn_attr2_name = 'srv_display_name',
		@datasrc_dynattr2_colname = 'display_name',
		@format = 0, --text
		@order_id = @order_jobs_count

	/* VERIFICATION JOBS COUNT */
	EXEC [dbo].[usp.GridReport.Config.RegColWithHrefDDBinding]
		@grid_report_id = @backup_servers_grid_repid,
		@col_display_name = N'Verification Jobs Count',
		@col_unique_name = N'sb_jobs_count',
		@col_width  = 80,
		@col_number = 4,
		@is_sortable = 1,
		@trg_report_id = '51BD6D3E-1F39-4fa7-9E5C-13C33A14DD1B',  /*SureBackup jobs per server*/
		@href_id = @srv2sbjobs_href_id,
		@datasrc_textcol_name = 'sb_jobs_count',
		@datasrc_textcol_type = 8, --int --12, -- nvarchar
		@dyn_attr1_name = 'id',
		@datasrc_dynattr1_colname = 'id',
		@dyn_attr2_name = 'srv_display_name',
		@datasrc_dynattr2_colname = 'display_name',
		@format = 0, --text
		@order_id = @order_sb_jobs_count


IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 23; END	
END
GO
--23
-----------------------------------------------------



----------------------------------------------------
--24
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 23)
BEGIN

	DECLARE @cur_jobs_grid_repid uniqueidentifier

	SELECT @cur_jobs_grid_repid = [dbo].[Report.GridReports].[id]
	FROM 
		[dbo].[Report.GridReports] 
		INNER JOIN [dbo].[Reports] ON [dbo].[Report.GridReports].[report_id] = [dbo].[Reports].[id]
	WHERE 
		[dbo].[Reports].[id] = '923fa20c-e6f7-4de7-ab69-ba006707af78'

	DECLARE 
		@jobs_tab_id as uniqueidentifier,
		@reports_tab_id as uniqueidentifier
	SELECT 
		@jobs_tab_id = '7FFD1688-B14C-4692-8EFB-45A3E9F1E45A',
		@reports_tab_id = '0BA048E2-E260-48f4-A1D9-395471DEA5D8'
		
	-- HYPERLINKS
	/*    JOBS -> ALL SESSIONS*/
	DECLARE 
		@cur_jobs_2_sessions_href_id as uniqueidentifier,
		@cur_jobs_2_sb_sessions_href_id as uniqueidentifier		
	SELECT 
		@cur_jobs_2_sessions_href_id = 'DDA425A3-B6C0-4cde-B7D9-D167DE0BD031',
		@cur_jobs_2_sb_sessions_href_id = 'E4874F3F-9D63-41c1-9601-4D8ECC70070A'
				
	EXEC [dbo].[usp.GridReport.Config.RegHyperlink]
		@hyperlink_id = @cur_jobs_2_sb_sessions_href_id,
		@hyperlink_unique_name = N'cur_jobs_2_sb_sessions'
			
	INSERT INTO [dbo].[Rendering.HyperlinkTransitions]( [id], [source_container_id], [hyperlink_id], [target_container_id])
	VALUES( NEWID(), @jobs_tab_id, @cur_jobs_2_sb_sessions_href_id, @reports_tab_id )	
	
	-- ORDERS
	DECLARE @order_name uniqueidentifier
	SELECT @order_name = NEWID()
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_name, @cur_jobs_grid_repid, 'name' 
	
	--COLUMNS
	/* NAME */
	EXEC [dbo].[usp.GridReport.Config.UnRegColWithBinding] @cur_jobs_grid_repid, N'job_name'
	
	DECLARE 
		@sessions_per_job_repid uniqueidentifier,
		@sb_sessions_per_job_repid uniqueidentifier	
	SELECT 
		@sessions_per_job_repid  = '56D6E095-69A1-403f-BF77-422E303FE31A',
		@sb_sessions_per_job_repid  = '8BC0EDA7-AAD8-4d7c-96FE-2B671CA1EDDF'

	DECLARE			
		@href_binding1_id uniqueidentifier, 
		@href_binding2_id uniqueidentifier,
		@dyn_href_binding_id uniqueidentifier			

	EXEC [dbo].[usp.GridReport.Config.RegHrefBinding]
		@trg_report_id				= @sessions_per_job_repid,
		@href_id					= @cur_jobs_2_sessions_href_id,
		@href_binding_id			= @href_binding1_id OUTPUT,
		@dyn_attr1_name = 'id',
		@datasrc_dynattr1_colname = 'id',
		@dyn_attr2_name = 'job_name',
		@datasrc_dynattr2_colname = 'name'

	EXEC [dbo].[usp.GridReport.Config.RegHrefBinding]
		@trg_report_id				= @sb_sessions_per_job_repid,
		@href_id					= @cur_jobs_2_sb_sessions_href_id,
		@href_binding_id			= @href_binding2_id OUTPUT,
		@dyn_attr1_name = 'id',
		@datasrc_dynattr1_colname = 'id',
		@dyn_attr2_name = 'job_name',
		@datasrc_dynattr2_colname = 'name'
	
	EXEC [dbo].[usp.GridReport.Config.RegDynHrefBinding]
		@href_binding1_id,
		@href_binding2_id,
		N'[usp.GridReport.HrefResolveProc.Jobs_Name]',
		@dyn_href_binding_id OUTPUT,
		@dyn_attr1_name				= 'job_id',
		@datasrc_dynattr1_colname	= 'id'

	EXEC [dbo].[usp.GridReport.Config.RegColWithDynamicHrefBinding]
		@grid_report_id = @cur_jobs_grid_repid,
		@col_display_name = N'Name',
		@col_unique_name = N'job_name',
		@col_width  = 100,
		@col_number = 1,
		@is_sortable = 1,
		@dyn_href_binding_id = @dyn_href_binding_id,
		@datasrc_textcol_name = N'name',
		@datasrc_textcol_type = 12, -- nvarchar
		@format = 0, --text
		@order_id = @order_name


IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 24; END	
END
GO
--24
-----------------------------------------------------


----------------------------------------------------
--25
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 24)
BEGIN

	DECLARE @dynHrefBind_Jobs_CurrentState uniqueidentifier
	DECLARE @href_binding1_id uniqueidentifier
	DECLARE @href_binding2_id uniqueidentifier
	
	SELECT
		@dynHrefBind_Jobs_CurrentState = [dbo].[Report.GridReport.Columns].[href_binding_id] 
	FROM [dbo].[Report.GridReport.Columns] 
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Report.GridReport.Columns].[grid_report_id] = [dbo].[Report.GridReports].[id]
		INNER JOIN [dbo].[Reports] ON [dbo].[Report.GridReports].[report_id] = [dbo].[Reports].[id]
	WHERE 
		[dbo].[Reports].[unique_name] = N'current_jobs' AND 
		[dbo].[Report.GridReport.Columns].[unique_name] = N'job_status'

	SELECT
		@href_binding1_id = [href_binding1_id],
		@href_binding2_id = [href_binding2_id]
	FROM [dbo].[Report.GridReport.Binding.DynHrefColBindings]
	WHERE [id] = @dynHrefBind_Jobs_CurrentState


	DECLARE @session_details_repid uniqueidentifier
	SELECT @session_details_repid  = '0F8FDA6D-25D6-4f03-835E-A6EC971BE62F'
	
	DECLARE @bjob_2_last_completesession_hrefid uniqueidentifier
	SELECT @bjob_2_last_completesession_hrefid = '153B2A2B-6BBD-4080-B203-6B96A6605BFB'

	EXEC [dbo].[usp.GridReport.Config.ReRegHrefBinding]
		@trg_report_id				= @session_details_repid,
		@href_id					= @bjob_2_last_completesession_hrefid,
		@href_binding_id			= @href_binding1_id,
		@dyn_attr1_name				= N'id',
		@datasrc_dynattr1_colname	= N'session_id',
		@dyn_attr2_name				= 'navi_name_attr',
		@datasrc_dynattr2_colname	= 'session_creation_time',
		@dyn_attr3_name				= 'navi_name_attr2',
		@datasrc_dynattr3_colname	= 'retry_text'
		
	EXEC [dbo].[usp.GridReport.Config.ReRegDynHrefBinding]
		@href_binding1_id,
		@href_binding2_id,
		N'[usp.GridReport.HrefResolveProc.Jobs_CurrentState]',
		@dynHrefBind_Jobs_CurrentState,
		@dyn_attr1_name				= 'session_id',
		@datasrc_dynattr1_colname	= 'session_id'
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 25; END	
END
GO
--25
-----------------------------------------------------



----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 25)
BEGIN

-- fix 'VMs' report

	DECLARE @grid_repid uniqueidentifier
	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'vm_in_backups'

	DECLARE @root_backup_id_href_binding_id uniqueidentifier
	SELECT 		
		@root_backup_id_href_binding_id = [dbo].[Report.GridReport.Columns].[href_binding_id]
	FROM [dbo].[Report.GridReport.Columns]
	WHERE 
		[dbo].[Report.GridReport.Columns].[grid_report_id] = @grid_repid AND
		[dbo].[Report.GridReport.Columns].[unique_name] = N'restore_points_href'

	UPDATE [dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs] SET
		[dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs].[attr_name] = N'point_id',
		[dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs].[datasrc_column] = N'point_id'
	WHERE 
		[dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs].[href_binding_id] = @root_backup_id_href_binding_id AND
		[dbo].[Report.GridReport.Binding.HrefColBindingDynAttrs].[attr_name] = N'root_backup_id'

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 26; END	
END
GO

--
-----------------------------------------------------

--100 - Starting version number for 6.0
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 26 AND fill_version < 105)
	UPDATE [dbo].[Version] SET fill_version = 105;

GO

----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 105)
BEGIN

-- add 'platform' column to jobs report

-- add 'platform' column to jobs report

	DECLARE @grid_repid uniqueidentifier
	
	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'current_jobs'
	
	
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @platform_emum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082'
	SELECT @platform_emum_id = '3E1FCBF0-F9C6-49A3-87B6-C0685F8D0182'
		   
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @platform_emum_id, 'JobPlatforms')
												
	-- Register enumeration values
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @platform_emum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 0,
			@display_value  = N'VMware',
			@small_icon_name = null,
			@large_icon_name = null
	
		
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @platform_emum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 1,
			@display_value  = N'Hyper-V',
			@small_icon_name = null,
			@large_icon_name = null
			
	--- ORDER ---
	DECLARE @order_platform uniqueidentifier
	SELECT @order_platform = NEWID()
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_platform, @grid_repid, 'platform' 
	
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]
	@grid_report_id = @grid_repid,
	@col_display_name = 'Platform',
	@col_unique_name = 'job_platform',
	@col_width = 40,
	@col_number  = 3,
	@is_sortable = 1,
	@datasrc_col_name = 'platform',
	@enumeration_id = @platform_emum_id,
	@order_id = @order_platform
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 106; END	
END
GO

----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 106)
BEGIN
	--  Permission types
	DECLARE @perm_restore int, @perm_view int
	SELECT @perm_restore = 8,  @perm_view = 1


	--  Roles
	DECLARE @restore_operator_role uniqueidentifier, @admin_role_id uniqueidentifier, @viewer_role_id uniqueidentifier
	SELECT 
		@restore_operator_role = 'F84A8B62-49B8-4D0C-B25B-92321B52BAB6',
		@viewer_role_id = 'D19A3D33-CB77-4ffe-94E6-001432483A4E',
		@admin_role_id = '5F37A46B-9CE2-40f4-8A62-B45B079257FC'
	
	INSERT INTO [dbo].[Security.Roles]( [id], [number], [name] )
		SELECT @restore_operator_role, 3, 'File Restore Operator'

	-- Permissions
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @restore_operator_role, @perm_restore
	
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @admin_role_id, @perm_restore

	
	-- enum values
			
	DECLARE @roles_enum_id as uniqueidentifier
	SELECT @roles_enum_id = '795239D9-EE07-4c7c-A4BD-AD17D4F2478C'
	
	-- Register enumeration values
	--  Restore operator
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @roles_enum_id, null, 3, 'File Restore Operator', null, null
	

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 108; END	
END
GO
-----------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 108)
BEGIN
--Add sorting to Roles report
	DECLARE @grid_repid uniqueidentifier,
			@order_roles_name uniqueidentifier,
			@order_roles_account uniqueidentifier
		
	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'cfg_roles'
	
	SELECT @order_roles_name = NEWID(),
		@order_roles_account = NEWID()
		
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_roles_name, @grid_repid, 'roles_name'
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_roles_account, @grid_repid, 'roles_account'
	
	
	UPDATE 	[Report.GridReport.Columns] SET [order_id] = @order_roles_name WHERE [grid_report_id] = @grid_repid AND [unique_name] = 'roles_name'
	UPDATE  [Report.GridReport.Columns] SET [order_id] = @order_roles_account WHERE [grid_report_id] = @grid_repid AND [unique_name] = 'roles_account'


IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 109; END	
END
GO

----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 109)
BEGIN

	-- enum values
	DECLARE @joblastres_enum_id as uniqueidentifier
	SELECT @joblastres_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3'
	
	-- Remove duplicate filter
	DELETE FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id] = @joblastres_enum_id
	AND	[text_value] = 'File Restore Operator'	
	
	-- Add 'running' filter option
	UPDATE [dbo].[Report.Shared.EnumerationValues]
	SET [text_value] = 'Running/Never started' 
	WHERE [enumeration_id] = @joblastres_enum_id AND 
	[text_value] = 'Never started'
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 110; END	
END
GO

----------------------------------------------------

--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version > 109 AND  fill_version <= 114 )
BEGIN
DECLARE 
	@joblastres_enum_id as uniqueidentifier,
	@jobstatuses_enum_id as uniqueidentifier
		
	SELECT  
	@jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E',
	@joblastres_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3'
	
	UPDATE [dbo].[Report.GridReport.Binding.IconColBindings]
	SET [enumeration_id] = @jobstatuses_enum_id
	WHERE [datasrc_column] = N'job_status'
	AND [enumeration_id] = @joblastres_enum_id
	
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 115; END	
END
GO

----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 115)
BEGIN

	DECLARE 
	@statuses_img_folder_id as uniqueidentifier,
	@si_statuses_enum_id as uniqueidentifier,
	@running_img_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @si_statuses_enum_id = '806747C3-873B-4027-B053-223B6A4BE1ED'
	
	SELECT 
		@running_img_id = [id]
	FROM 
		[dbo].[Rendering.ImageFiles]
	WHERE 
		[folder_id] = @statuses_img_folder_id
		AND [file_name] = N'RunSmall'
	
	
	
	UPDATE [dbo].[Report.Shared.EnumerationValues]
	SET [small_image_id] = @running_img_id
	WHERE [text_value] = N'In progress...'
	AND [enumeration_id] = @si_statuses_enum_id
	
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 116; END	
END
GO
------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 116)
BEGIN

	/*   Licensing host type                     */
	/*   Licensing host type                     */
IF NOT EXISTS (SELECT [id] FROM [dbo].[Report.Shared.Enumerations] WHERE [unique_name] = N'LicensingHostTypes')
BEGIN
	DECLARE @statuses_img_folder_id as uniqueidentifier
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082'
	
	DECLARE @licensing_host_type_enum_id as uniqueidentifier
	SELECT @licensing_host_type_enum_id = '9C789364-3A76-484F-A238-286019490093'
		   
	-- Register enumeration
	INSERT INTO [dbo].[Report.Shared.Enumerations]( [id], [unique_name])
	VALUES( @licensing_host_type_enum_id, 'LicensingHostTypes')
												
	-- Register enumeration values
	--  vSphere
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @licensing_host_type_enum_id,
			@image_folder_id = @statuses_img_folder_id ,					
			@int_value = 0,
			@display_value  = N'vSphere',
			@small_icon_name = null,
			@large_icon_name = null
												
	
	
	--  Hyper-V
	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @licensing_host_type_enum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 10,
			@display_value  = N'Hyper-V',
			@small_icon_name = null,
			@large_icon_name = null			
						

END


	--- Update cfg_licensed_esx report
	DECLARE @repid as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier


	SELECT @repid = '10B4CAD6-FF05-4882-A79D-6D5957608D35';
	SELECT @grid_repid = [dbo].[Report.GridReports].[id] FROM [dbo].[Report.GridReports] WHERE [report_id] = @repid;


IF NOT EXISTS (SELECT [id] FROM [dbo].[Reports] WHERE [unique_name] = N'cfg_licensed_hosts')	
BEGIN
	-- Rename 
	UPDATE [dbo].[Report.Shared.Builders.NaviName] SET [format] = N'Licensed hosts' WHERE [format] = N'Licensed ESXs'
	
	UPDATE [dbo].[Reports] SET 
		[unique_name] = N'cfg_licensed_hosts',
		[display_name] = N'Licensed hosts'
	WHERE [id] = @repid
	
	UPDATE [dbo].[Report.GridReports] 
	SET
		[datasrc_proc] = N'usp.GridReport.DataSrc.Cfg.LicensedHosts'
	WHERE [id] = @grid_repid
	
	
	UPDATE [dbo].[Report.GridReport.Orders] 
		SET [column_name] = N'cfg_host_name'
	WHERE [grid_report_id] = @grid_repid AND [column_name] = N'cfg_esx_name'	
		
	UPDATE [dbo].[Report.GridReport.Orders] 
		SET [column_name] = N'cfg_host_cpu_num'
	WHERE [grid_report_id] = @grid_repid AND [column_name] = N'cfg_esx_cpu_num'	
		
		 
	UPDATE [dbo].[Report.GridReport.Columns]
		SET 
			[unique_name] = N'cfg_host_name',
			[display_name] = N'Host name'
		WHERE [grid_report_id] = @grid_repid AND [unique_name] = N'cfg_esx_name'
		
	UPDATE [Report.GridReport.Binding.TextColBindings]
		SET [datasrc_column] = N'host_name'
		WHERE [datasrc_column] = N'esx_name'
		
		
	UPDATE [dbo].[Report.GridReport.Columns]
		SET [unique_name] = N'cfg_host_cpu_num',
			[ordinal_number] = 3
		WHERE [grid_report_id] = @grid_repid AND [unique_name] = N'cfg_esx_cpu_num'	
		
	UPDATE [Report.GridReport.Binding.TextColBindings]
		SET [datasrc_column] = N'host_cpu_num'
		WHERE [datasrc_column] = N'esx_cpu_num'
		
		
	UPDATE [dbo].[Report.GridReport.Columns]
		SET [ordinal_number] = 4
	WHERE [grid_report_id] = @grid_repid AND [unique_name] = N'cfg_esx_is_licensed'	
	
	
		
	DECLARE @host_type_enum_id as uniqueidentifier
	SELECT @host_type_enum_id = '9C789364-3A76-484F-A238-286019490093'
	
	DECLARE @order_host_type uniqueidentifier
			
	SELECT @order_host_type = NEWID()
			
	EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_host_type, @grid_repid, 'cfg_host_type'
	
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithEnumBinding]	
		@grid_report_id = @grid_repid,
		@col_display_name = N'Host type',
		@col_unique_name  = N'cfg_host_type',
		@col_width = 50,
		@col_number = 2,
		@is_sortable = 1,
		@datasrc_col_name = N'host_type',
		@enumeration_id = @host_type_enum_id,
		@order_id = @order_host_type
END


IF NOT EXISTS (SELECT [id] FROM [dbo].[Reports] WHERE [unique_name]= N'bjobs_referring_host')
BEGIN
--- Detailed report
	
	DECLARE @ref_report_id as uniqueidentifier
	DECLARE @ref_grid_repid as uniqueidentifier
	
	SELECT @ref_report_id = 'D44A0677-8B2F-4a12-AF3C-4C0E3ED6A02C'
	SELECT @ref_grid_repid = [dbo].[Report.GridReports].[id] FROM [dbo].[Report.GridReports] WHERE [report_id] = @ref_report_id
	
	-- Rename 
	UPDATE [dbo].[Report.Shared.Builders.NaviName] SET [format] = N'Backup jobs referring to host' WHERE [format] = N'Backup jobs referring to ESX'
	
	UPDATE [dbo].[Reports] SET 
		[unique_name] = N'bjobs_referring_host',
		[display_name] = N'Backup jos referreing to host'
	WHERE [id] = @ref_report_id
	
	UPDATE [dbo].[Report.GridReports] 
	SET
		[datasrc_proc] = N'usp.GridReport.DataSrc.Cfg.BJobsReferringHost'
	WHERE [id] = @ref_grid_repid
	
END

	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 117; END	
END
GO
----------------------------------------------------



----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 117)
BEGIN
-- add 'bs_version' column to jobs report
IF NOT EXISTS (SELECT [id] FROM [Report.GridReport.HiddenColumns] WHERE [unique_name]= N'bs_version')
BEGIN

	DECLARE @grid_repid uniqueidentifier

	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'current_jobs'
	
	
	EXEC [dbo].[usp.GridReport.Config.RegHiddenCol]
		@grid_report_id = @grid_repid,
		@col_unique_name = N'bs_version',
		@datasrc_col_name = N'bs_version',
		@datasrc_col_type = 12
END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 118; END	
END
GO
----------------------------------------------------


----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 118)
BEGIN
-- rename buttons
	DECLARE @img_folder_id AS uniqueidentifier
	SELECT @img_folder_id = N'01E6F41B-E0E4-4866-A9D1-124BD06B125D'

IF NOT EXISTS (SELECT [id] FROM [dbo].[Rendering.ImageFiles] WHERE [file_name] = N'SyncCat')
BEGIN
	DECLARE @sync_img_id AS uniqueidentifier
	EXEC  [dbo].[usp.Rendering.FindOrCreateImage] 
		@image_folder_id = @img_folder_id, 
		@image_name = N'SyncCat',
		@image_id = @sync_img_id OUTPUT
	
	UPDATE [Report.Shared.TaskTypes] 
	SET [image_id] = @sync_img_id
	WHERE [display_name] = N'Sync Catalog Now'
END


IF NOT EXISTS (SELECT [id] FROM [dbo].[Rendering.ImageFiles] WHERE [file_name] = N'StopSync')
BEGIN
	DECLARE @stop_img_id AS uniqueidentifier
	EXEC  [dbo].[usp.Rendering.FindOrCreateImage] 
		@image_folder_id = @img_folder_id, 
		@image_name = N'StopSync',
		@image_id = @stop_img_id OUTPUT
	
	UPDATE [Report.Shared.TaskTypes] 
	SET [image_id] = @stop_img_id
	WHERE [display_name] = N'Stop Sync'
END


-- Update current_jobs report status icon


	DECLARE 
	@jobstatuses_enum_id as uniqueidentifier, 
	@job_last_res_enum_id as uniqueidentifier,
	@grid_repid uniqueidentifier
	
	SELECT 
	@jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E',
	@job_last_res_enum_id = 'FCA2766E-2AEA-4331-BF1E-BBB2ECCDA7E3'
	

	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'current_jobs'
	
	DECLARE @binding_id AS uniqueidentifier
	SELECT @binding_id = [icon_binding_id]
	FROM [Report.GridReport.Columns]
	WHERE [grid_report_id]=@grid_repid
	AND [unique_name] = N'job_status_icon'
		
	UPDATE [Report.GridReport.Binding.IconColBindings]
	SET [enumeration_id] = @jobstatuses_enum_id
	WHERE [id] = @binding_id
		 
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 119; END	
END
GO

----------------------------------------------------
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 119 and fill_version < 125)
BEGIN
-- Update CollectSession report status icon

	DECLARE 
	@collect_statuses_enum_id as uniqueidentifier, 
	@running_img_id as uniqueidentifier,
	@statuses_img_folder_id as uniqueidentifier
	
	SELECT 
	@collect_statuses_enum_id = '5E3149C0-3BC9-4395-9F04-035EE85B1F55',	
	@statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082'


	SELECT 
		@running_img_id = [id]
	FROM 
		[dbo].[Rendering.ImageFiles]
	WHERE 
		[folder_id] = @statuses_img_folder_id
		AND [file_name] = N'RunSmall'
	
	
	
	UPDATE [dbo].[Report.Shared.EnumerationValues]
	SET [small_image_id] = @running_img_id
	WHERE [text_value] = N'In Progress...'
	AND [enumeration_id] = @collect_statuses_enum_id
		 
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 125; END	
END
GO

----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 125)
BEGIN

	DECLARE @ProductUID NVARCHAR(38);
	DECLARE @ProductVersion NVARCHAR(16);

	SET @ProductUID = '1A2BAC31-7B61-456f-ACF9-643F7B17DC0E'
	/*AUTOGENERATED*/SET @ProductVersion = '9.0.0.902'/*AUTOGENERATED*/

	UPDATE dbo.VeeamProductVersion
	SET VeeamProductVersion = @ProductVersion
	WHERE [VeeamProductID] = @ProductUID

	IF @@ROWCOUNT = 0
	INSERT INTO dbo.VeeamProductVersion (VeeamProductID, VeeamProductVersion)
	VALUES (@ProductUID, @ProductVersion)

END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 125 AND fill_version < 128)
	UPDATE [dbo].[Version] SET fill_version = 128;


-----------------------------------------------------

/*             END OF DATA UPGRADE 60-61				*/
/********************************************************/


----------------------------------------------------
--
IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 128 AND fill_version < 134)
BEGIN
	DECLARE @cfg_bservers_report_id uniqueidentifier

	SELECT @cfg_bservers_report_id = [dbo].[Report.GridReports].[id]
	FROM 
		[dbo].[Report.GridReports] 
		INNER JOIN [dbo].[Reports] ON [dbo].[Report.GridReports].[report_id] = [dbo].[Reports].[id]
	WHERE 
		[dbo].[Reports].[id] = '955DF1AA-2501-451d-A4FE-FE877731D192'


	/* DESCRIPTION */
	EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
	@grid_report_id = @cfg_bservers_report_id,
	@col_display_name = N'Version',
	@col_unique_name = N'cfg_bs_version',
	@col_width  = 200,
	@col_number = 5,
	@is_sortable = 0,
	@datasrc_col_name = N'cfg_bs_version',
	@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
	@format = 0 --text		
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 135; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 135 AND fill_version < 141)
	UPDATE [dbo].[Version] SET fill_version = 141;
-----------------------------------------------------

/*             END OF DATA UPGRADE 61-65				*/
/********************************************************/


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 141 AND fill_version < 191)
BEGIN
	UPDATE [dbo].[Version] SET fill_version = 191;
END
GO
-----------------------------------------------------


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 191)
BEGIN
--  Permission types
	DECLARE @perm_vm_restore int, @perm_view int
	SELECT @perm_vm_restore = 32,  @perm_view = 1


	--  Roles
	DECLARE @vm_restore_operator_role uniqueidentifier, @admin_role_id uniqueidentifier, @viewer_role_id uniqueidentifier
	SELECT 
		@vm_restore_operator_role = 'C11C0C38-BA8B-49c7-BF70-FC2058FFF1E2',
		@viewer_role_id = 'D19A3D33-CB77-4ffe-94E6-001432483A4E',
		@admin_role_id = '5F37A46B-9CE2-40f4-8A62-B45B079257FC'
	
	INSERT INTO [dbo].[Security.Roles]( [id], [number], [name] )
		SELECT @vm_restore_operator_role, 4, 'VM Restore Operator'

	-- Permissions
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @vm_restore_operator_role, @perm_vm_restore
	
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @admin_role_id, @perm_vm_restore

	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 192; END	
END
GO
------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 192)
BEGIN
IF NOT EXISTS (SELECT [id] FROM [Report.GridReport.Columns] WHERE [unique_name]= N'server_version')
	BEGIN
	/* 
 	 *	Add column 'Version' to 'Backup servers' report
	 */
		DECLARE @grid_repid uniqueidentifier;

		SELECT 
			@grid_repid = [dbo].[Report.GridReports].[id]
		FROM [dbo].[Reports]
			INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
		WHERE [dbo].[Reports].[unique_name] = N'backup_servers';
	
	
	   /************************* ORDERS ****************************************************/
		DECLARE @order_version uniqueidentifier;

		SELECT @order_version = NEWID();

		EXEC [dbo].[usp.GridReport.Config.AttachOrder2Rep] @order_version, @grid_repid, 'server_version';


		/******************  COLUMNS ********************************************************/					

		/* server_versiion */
		EXEC [dbo].[usp.GridReport.Config.RegTextColWithDirectBinding]
		@grid_report_id = @grid_repid,
		@col_display_name = N'Version',
		@col_unique_name = N'server_version',
		@col_width  = 60,
		@col_number = 5,
		@is_sortable = 1,
		@datasrc_col_name = N'server_version',
		@datasrc_col_type = 12,  /*SqlDbType - nvarchar*/
		@format = 0, --text
		@order_id = @order_version;
	
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 193; END 
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 193)
BEGIN
	--  Update roles
	DECLARE 
		@viewer_role_id uniqueidentifier,
		@file_restore_op_role_id uniqueidentifier
			
	SELECT @viewer_role_id = 'D19A3D33-CB77-4ffe-94E6-001432483A4E',
		   @file_restore_op_role_id = 'F84A8B62-49B8-4D0C-B25B-92321B52BAB6';
		
	
	UPDATE [dbo].[Security.Roles] 
	SET [name] = 'Portal User' WHERE id=@viewer_role_id;

	UPDATE [dbo].[Security.Roles]
	SET [name] = 'File Restore Operator' WHERE id=@file_restore_op_role_id;

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 194;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 194)
BEGIN
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @platform_emum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082'
	SELECT @platform_emum_id = '3E1FCBF0-F9C6-49A3-87B6-C0685F8D0182'	


	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @platform_emum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 3,
			@display_value  = N'vCloud',
			@small_icon_name = null,
			@large_icon_name = null
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 195;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 195)
BEGIN
	DECLARE @roles_enum_id as uniqueidentifier;
	SELECT @roles_enum_id = '795239D9-EE07-4c7c-A4BD-AD17D4F2478C';


	UPDATE [dbo].[Report.Shared.EnumerationValues] SET [text_value] = 'Portal User' 
	WHERE [enumeration_id] = @roles_enum_id AND [text_value] = 'Portal Viewer';

	UPDATE [dbo].[Report.Shared.EnumerationValues] SET [text_value] = 'Restore Operator' 
	WHERE [enumeration_id] = @roles_enum_id AND [text_value] = 'File Restore Operator';
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 196;  END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 196)
BEGIN
	/* ENTERPRISE JOB TYPES */
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @ent_job_types_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @ent_job_types_enum_id = '6E7CC1EE-6C31-449f-BB98-27A2D6064781'
	
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@ent_job_types_enum_id AND [text_value] = 'Security Scopes Rebuild')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @ent_job_types_enum_id, @statuses_img_folder_id, 4, 'Security Scopes Rebuild', null, null
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 198;  END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 198 AND fill_version < 205)
BEGIN

	DECLARE @rowId uniqueidentifier
	DECLARE @value nvarchar(max)
	DECLARE entSessionCursor CURSOR FOR
			SELECT id, config FROM [dbo].[Enterprise.Sessions]

	OPEN entSessionCursor;
	FETCH NEXT FROM entSessionCursor INTO @rowId, @value

	WHILE (@@FETCH_STATUS = 0)
	BEGIN   
		UPDATE [dbo].[Enterprise.Sessions] SET job_spec = @value
		WHERE id = @rowId
    
		FETCH NEXT FROM entSessionCursor INTO @rowId, @value
	END

	CLOSE entSessionCursor
	DEALLOCATE entSessionCursor

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 205;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 205)
BEGIN

	DECLARE @todayUTC datetime 
	SET @todayUTC = [dbo].[fn.Common.GetTodayDateUTC]()

	INSERT INTO [dbo].[Enterprise.JobSettings] (id, job_type, settings, scheduled_first_start_time, scheduled_period_mins)
	VALUES ('14F87835-98EE-48BF-B1C9-171FD19117D2', 4, '<JobSettings/>', DATEADD(hour, 6, @todayUTC), 24*60) --rebuild roles

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 206;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 206 AND fill_version < 208)
BEGIN

	UPDATE [dbo].[C.BObjects]
		SET [dbo].[C.BObjects].display_name = [dbo].[C.BObjects].object_name
	WHERE [dbo].[C.BObjects].display_name = ''

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 208;  END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 208 AND fill_version < 218)
BEGIN
	/* ENTERPRISE JOB TYPES */
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @ent_job_types_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @ent_job_types_enum_id = '6E7CC1EE-6C31-449f-BB98-27A2D6064781'
	
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@ent_job_types_enum_id AND [text_value] = 'vSphere Web Client Plugin')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @ent_job_types_enum_id, @statuses_img_folder_id, 5, 'vSphere Web Client Plugin', null, null
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 218;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 218 AND  fill_version < 224)
BEGIN
	DECLARE @platform_emum_id as uniqueidentifier
	SELECT @platform_emum_id = '3E1FCBF0-F9C6-49A3-87B6-C0685F8D0182'	

	UPDATE [dbo].[Report.Shared.EnumerationValues]
	SET [ordinal_number] = 4
	WHERE [enumeration_id] = @platform_emum_id
	AND [text_value] = 'vCloud'
	AND [ordinal_number] = 3
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 224;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=224 AND fill_version < 229)
BEGIN
	--  Permission types
	DECLARE @lookup_perm int
	SET @lookup_perm = 64

	--  Roles
	DECLARE @admin_role_id uniqueidentifier, @viewer_role_id uniqueidentifier
	SELECT 
		@viewer_role_id = 'D19A3D33-CB77-4ffe-94E6-001432483A4E',
		@admin_role_id = '5F37A46B-9CE2-40f4-8A62-B45B079257FC'

	-- Permissions
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @viewer_role_id, @lookup_perm
	
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @admin_role_id, @lookup_perm

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 229;  END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=229 AND fill_version < 249)
BEGIN
	
	EXEC [dbo].[Fill_RolePermissions]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 249;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=249 AND fill_version < 252)
BEGIN
	
	EXEC [dbo].[MarkColumnsBindingsAsNew_v7]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 252;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=252 AND fill_version < 257)
BEGIN
	
	UPDATE [dbo].[C.Backup.Model.OIBs]
		SET [dbo].[C.Backup.Model.OIBs].[original_oib_id] = [dbo].[C.Backup.Model.OIBs].[id]
	WHERE [dbo].[C.Backup.Model.OIBs].[original_oib_id] IS NULL

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 257;  END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 257 AND fill_version < 259)
BEGIN

	UPDATE [dbo].[C.Backup.Model.OIBs]
		SET [dbo].[C.Backup.Model.OIBs].[original_oib_id] = [dbo].[C.Backup.Model.OIBs].[id]
	WHERE [dbo].[C.Backup.Model.OIBs].[original_oib_id] IS NULL

 	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 259; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 259 AND fill_version < 274)
BEGIN
	
	EXEC [dbo].[MarkColumnsBindingsAsNew_v7]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 274;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=274 AND fill_version < 279)
BEGIN
	
	EXEC [dbo].[Fill_RolePermissions]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 279;  END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=279 AND fill_version < 282)
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @job_types_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @job_types_enum_id = '2ED2AF5B-041A-4e8b-B467-F960B894EF7F'
	
	--  BackupCopy
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@job_types_enum_id AND [text_value] = 'Backup Copy')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @job_types_enum_id, @statuses_img_folder_id, 51, 'Backup Copy', null, null
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 282;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=282 AND fill_version < 283)
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @job_types_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @job_types_enum_id = '2ED2AF5B-041A-4e8b-B467-F960B894EF7F'


	DECLARE @platform_emum_id as uniqueidentifier
	SELECT @platform_emum_id = '3E1FCBF0-F9C6-49A3-87B6-C0685F8D0182'	

	EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
			@enum_id = @platform_emum_id,
			@image_folder_id = @statuses_img_folder_id,					
			@int_value = 5,
			@display_value  = N'Tape',
			@small_icon_name = null,
			@large_icon_name = null
	
	--  File tape backup
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@job_types_enum_id AND [text_value] = 'File to Tape')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @job_types_enum_id, @statuses_img_folder_id, 24, 'File to Tape', null, null
	END

	--  VM tape backup
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@job_types_enum_id AND [text_value] = 'Backup to Tape')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @job_types_enum_id, @statuses_img_folder_id, 28, 'Backup to Tape', null, null
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 283;  END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=283 AND fill_version < 295)
BEGIN
	
	EXEC [dbo].[Fill_RolePermissions]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 295;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=295 AND fill_version < 306)
BEGIN			
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @jobstatuses_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @jobstatuses_enum_id = '1AFE6873-51F7-4422-BFE6-24EC742C9B4E'
   
	-- Register enumeration values									
	--  Waiting Tape
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@jobstatuses_enum_id AND [text_value] = 'Waiting tape')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 8, 'Waiting tape', 'RunSmall', null 
	END

	--  Idle
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@jobstatuses_enum_id AND [text_value] = 'Idle')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @jobstatuses_enum_id, @statuses_img_folder_id, 9, 'Idle', 'RunSmall', null 
	END
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 306;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=306 AND fill_version < 322)
BEGIN
	
	EXEC [dbo].[Fill_RolePermissions]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 322;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 322 AND fill_version < 341)
BEGIN
	DECLARE @file_restorer_role_id uniqueidentifier 
	DECLARE @importFlrSettings65to70 xml, @flrSettingsDefault xml
	SET @file_restorer_role_id = 'F84A8B62-49B8-4D0C-B25B-92321B52BAB6'
	SET @flrSettingsDefault = '<RoleAccountSettings/>'
	SET @importFlrSettings65to70 =	
	(
		SELECT TOP 1
			CASE
				WHEN [no_file_restore_downloads] = 1 THEN 'True'
				ELSE 'False'
			END AS '@FLRInplaceOnly',
			CASE 
				WHEN flr_restricted_by_ext = 1 THEN [flr_ext_restrictions]
				ELSE ''
			END	AS '@FLRExtentionRestrictions' 
		FROM [dbo].[DashboardSettings] 
		FOR XML PATH('FileRestoreOperator'), ROOT('RoleAccountSettings')
	)
	SET @importFlrSettings65to70 = ISNULL(@importFlrSettings65to70, @flrSettingsDefault)

	--debug output
	print cast(@importFlrSettings65to70 as nvarchar(512))

	UPDATE [dbo].[Security.RoleAccounts] 
	SET settings = @importFlrSettings65to70         
	WHERE role_group_id NOT IN 
         (
              SELECT ra.role_group_id FROM [dbo].[Security.RoleAccounts] ra 
              WHERE ra.role_id = '5F37A46B-9CE2-40F4-8A62-B45B079257FC' --Portal Administrator
                   OR ra.role_id = 'D19A3D33-CB77-4FFE-94E6-001432483A4E' --Portal User
         )

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 341;  END
END
GO

-- 7.0 has been released

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 341 AND fill_version < 343)
BEGIN

	DECLARE @logged_on_user_id uniqueidentifier 

	DECLARE logged_on_user_cursor CURSOR FOR
	SELECT 
		[id]
	FROM [dbo].[Security.LoggedOnUsers]

	OPEN logged_on_user_cursor
	FETCH NEXT FROM logged_on_user_cursor into @logged_on_user_id
	WHILE @@FETCH_STATUS = 0
	BEGIN

		DELETE FROM [dbo].[Security.LoggedOnUsers] WHERE id = @logged_on_user_id;
		DELETE FROM [dbo].[Security.LoggedOnUserAccounts] WHERE login_id = @logged_on_user_id;
		DELETE FROM [dbo].[Security.LoggedOnUserGroups] WHERE login_id = @logged_on_user_id;
		
		FETCH NEXT FROM logged_on_user_cursor into @logged_on_user_id
	END
	CLOSE logged_on_user_cursor
	DEALLOCATE logged_on_user_cursor	

IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 343;  END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 343 AND fill_version < 346)
BEGIN
	/* ENTERPRISE JOB TYPES */
	DECLARE @statuses_img_folder_id as uniqueidentifier
	DECLARE @ent_job_types_enum_id as uniqueidentifier
	
	SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082',
		   @ent_job_types_enum_id = '6E7CC1EE-6C31-449f-BB98-27A2D6064781'
	
	IF NOT EXISTS (SELECT id FROM [dbo].[Report.Shared.EnumerationValues] WHERE [enumeration_id]=@ent_job_types_enum_id AND [text_value] = 'License key auto update')
	BEGIN
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] @ent_job_types_enum_id, @statuses_img_folder_id, 6, 'License key auto update', null, null
	END	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 346;  END	
END
GO

-- 7.0 patch4 has been released


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 346)
	UPDATE [dbo].[Version] SET fill_version = 391;

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 391)
BEGIN
	
	EXEC [dbo].[MarkColumnsBindingsAsNew_v80]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 392;  END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 392 AND fill_version < 400)
BEGIN
--  Permission types
	DECLARE @perm_exchange_items_restore int 	
	SELECT @perm_exchange_items_restore = 25


	--  Roles
	DECLARE @items_restore_operator_role uniqueidentifier, @admin_role_id uniqueidentifier
	SELECT 
		@items_restore_operator_role = 'F83E4C81-0815-452F-9377-9D573DD9D481',
		@admin_role_id = '5F37A46B-9CE2-40f4-8A62-B45B079257FC'
	
	INSERT INTO [dbo].[Security.Roles]( [id], [number], [name] )
		SELECT @items_restore_operator_role, 5, 'Items Restore Operator'

	-- Permissions
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @items_restore_operator_role, @perm_exchange_items_restore
	
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @admin_role_id, @perm_exchange_items_restore

	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 400; END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 392 AND fill_version < 401)
	UPDATE [dbo].[Version] SET fill_version = 401;
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >=401 AND fill_version < 410)
BEGIN
	
	EXEC [dbo].[Fill_RolePermissions]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 410;  END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 410 AND fill_version < 424)
BEGIN
	UPDATE [dbo].[Report.GridReport.Columns] set is_sortable = '1' where unique_name = 'last_backup_file';
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 424; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 424 AND fill_version < 432)
BEGIN
	
	EXEC [dbo].[Fill_RolePermissions]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 432;  END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 432)
BEGIN
--  Permission types
	DECLARE @perm_sql_items_restore int 	
	SELECT @perm_sql_items_restore = 31;


	--  Roles
	DECLARE @sql_restore_operator_role uniqueidentifier, @admin_role_id uniqueidentifier
	SELECT 
		@sql_restore_operator_role = 'F78A92B8-9F06-4F1E-B522-4F0927CABD0F',
		@admin_role_id = '5F37A46B-9CE2-40f4-8A62-B45B079257FC'
	
	INSERT INTO [dbo].[Security.Roles]( [id], [number], [name] )
		SELECT @sql_restore_operator_role, 6, 'SQL Restore Operator'

	-- Permissions
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @sql_restore_operator_role, @perm_sql_items_restore
	
	INSERT INTO [dbo].[Security.RolePermissions]( [id], [role_id], [permission] )
	SELECT NEWID(), @admin_role_id, @perm_sql_items_restore

	
	DECLARE @items_restore_operator_role uniqueidentifier;
	SELECT @items_restore_operator_role = 'F83E4C81-0815-452F-9377-9D573DD9D481';
	
	UPDATE [dbo].[Security.Roles] SET [name] = 'Exchange Restore operator' WHERE [id] = @items_restore_operator_role;
	
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 433; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 433 AND fill_version < 442)
BEGIN
	UPDATE [dbo].[Report.GridReport.Columns] set display_name = 'Folder Path' where unique_name = 'last_backup_file'
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 442; END
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 442 AND fill_version < 444)
BEGIN
	UPDATE [dbo].[Security.HierarchyScopes] set [hierarchy_root_instance_name] = [hierarchy_root_instance_id] where [hierarchy_root_instance_name ] = '';
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 444; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 444 AND fill_version < 450)
BEGIN
	UPDATE [dbo].[Report.GridReports] set [view_type] = 2 where report_id IN (
		'D6FB5F10-D723-414D-8674-122DDD4D66C1', -- collect sessions
	    '3644428a-d5dd-410d-976c-34c13a76f047', -- vm sessions history
		'0f8fda6d-25d6-4f03-835e-a6ec971be62f',  -- session detail
		'56d6e095-69a1-403f-bf77-422e303fe31a', -- sessions per job
		'E3FB504E-DCBD-4d26-993E-E1A1D62095B1',	-- jobs per server
		'a672891e-c13c-481a-a7ae-c22e54e1d4e2', -- VmInBackups
		'923fa20c-e6f7-4de7-ab69-ba006707af78',	-- Current jobs,
		'67601441-55b6-4372-b2f4-31ff529c42d5', --BSessionsForPeriod
		'8bc0eda7-aad8-4d7c-96fe-2b671ca1eddf', -- SbSessionsPerJob
		'79b78f18-4e61-46a4-be5e-35deaa8ed41b', -- SbSessionDetail,
		'51bd6d3e-1f39-4fa7-9e5c-13c33a14dd1b' -- SbJobsPerServer
	);

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 450; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 450 AND fill_version < 465)
BEGIN
	
	DECLARE @backupsrv_filter_type_id as uniqueidentifier
	DECLARE @grid_repid as uniqueidentifier

	SELECT @backupsrv_filter_type_id = '59835D5B-353D-4e50-8ABA-50BD52ABFD8F'
	SELECT 
			@grid_repid = [dbo].[Report.GridReports].[id]
		FROM [dbo].[Reports]
			INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
		WHERE [dbo].[Reports].[unique_name] = N'vm_in_backups';


	INSERT INTO [dbo].[Report.GridReport.Filters]( [id], [grid_report_id], [filter_type_id], [display_name], [unique_name], [ordinal_number], [width])
	VALUES( NEWID(), @grid_repid, @backupsrv_filter_type_id, 'Backup server', 'vm_backup_srv', 0, 150 )
	
	UPDATE [dbo].[Report.GridReport.Filters] SET [ordinal_number] = 1 WHERE [unique_name] = 'vm_name';

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 465; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 465 AND fill_version < 478)
BEGIN
	
	EXEC [dbo].[Fill_RolePermissions]
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 478;  END	
END
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 478 AND fill_version < 486)
BEGIN
	DECLARE @grid_repid as uniqueidentifier

	SELECT 
			@grid_repid = [dbo].[Report.GridReports].[id] 
	FROM [dbo].[Report.GridReports] WHERE [dbo].[Report.GridReports].[report_id] = '0F8FDA6D-25D6-4f03-835E-A6EC971BE62F'
		

	UPDATE [dbo].[Report.GridReport.Columns] set display_name = 'Object' where unique_name = 'vm_2_vmsessions_href' AND grid_report_id = @grid_repid;
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 486; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 486)
BEGIN
-- add 'is_schedule_enabled' column to jobs report
IF NOT EXISTS (SELECT [id] FROM [Report.GridReport.HiddenColumns] WHERE [unique_name]= N'schedule_enabled')
BEGIN

	DECLARE @grid_repid uniqueidentifier

	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'current_jobs'
	
	
	EXEC [dbo].[usp.GridReport.Config.RegHiddenCol]
		@grid_report_id = @grid_repid,
		@col_unique_name = N'schedule_enabled',
		@datasrc_col_name = N'schedule_enabled',
		@datasrc_col_type = 2
END
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 487; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 487  AND fill_version < 492)
	UPDATE [dbo].[Version] SET fill_version = 492;
GO




-- After v8.0 beta2

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 492  AND fill_version < 574)
	UPDATE [dbo].[Version] SET fill_version = 574;
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 574)
	UPDATE [dbo].[Version] SET fill_version = 575;
GO

-----------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 575)
BEGIN
	IF NOT EXISTS (SELECT [id] FROM [Report.Shared.EnumerationValues] WHERE [text_value]= N'Endpoint')
	BEGIN
		DECLARE @statuses_img_folder_id as uniqueidentifier
		DECLARE @platform_emum_id as uniqueidentifier
	
		SELECT @statuses_img_folder_id = 'FBB0BD0E-9274-4cda-BEFF-653785C89082'
		SELECT @platform_emum_id = '3E1FCBF0-F9C6-49A3-87B6-C0685F8D0182'
		   
												
		-- Register enumeration values
		EXEC [dbo].[usp.Report.Shared.RegisterEnumValue] 
				@enum_id = @platform_emum_id,
				@image_folder_id = @statuses_img_folder_id,					
				@int_value = 6,
				@display_value  = N'Endpoint',
				@small_icon_name = null,
				@large_icon_name = null
	END
	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 576; END	
END
GO



-- 8.Next ----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 576 AND fill_version < 622)
BEGIN	
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Data.Collecting.DeleteDataForNotExistingDbInstances]') AND type in (N'P', N'PC'))
	BEGIN
		exec [dbo].[usp.Data.Collecting.DeleteDataForNotExistingDbInstances]
	END

	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp.Upgrade.v65_to_v70.DeleteTablesAndProc]') AND type in (N'P', N'PC'))
	BEGIN
		exec [dbo].[usp.Upgrade.v65_to_v70.DeleteTablesAndProc]
	END

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 622; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 622 AND fill_version < 639)
	UPDATE [dbo].[Version] SET fill_version = 639;
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 639)
BEGIN
	EXEC [dbo].[MarkColumnsBindingsAsNew_v90]

	IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 640; END
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 640 AND fill_version < 689)
	UPDATE [dbo].[Version] SET fill_version = 689;
GO



IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 689)
BEGIN

-- add 'platform' column to vm in backup report

	DECLARE @grid_repid uniqueidentifier
	
	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'vm_in_backups'
	
	EXEC [dbo].[usp.GridReport.Config.RegHiddenCol]
		@grid_report_id = @grid_repid,
		@col_unique_name = N'platform',
		@datasrc_col_name = N'platform',
		@datasrc_col_type = 8
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 690; END	
END
GO


IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 690)
BEGIN

-- add 'can_restore' column to vm in backup report

	DECLARE @grid_repid uniqueidentifier
	
	SELECT 
		@grid_repid = [dbo].[Report.GridReports].[id]
	FROM [dbo].[Reports]
		INNER JOIN [dbo].[Report.GridReports] ON [dbo].[Reports].[id] = [dbo].[Report.GridReports].[report_id]
	WHERE [dbo].[Reports].[unique_name] = N'vm_in_backups'
	
	EXEC [dbo].[usp.GridReport.Config.RegHiddenCol]
		@grid_report_id = @grid_repid,
		@col_unique_name = N'can_restore',
		@datasrc_col_name = N'can_restore',
		@datasrc_col_type = 2
	
IF @@Error = 0 BEGIN UPDATE [dbo].[Version] SET fill_version = 691; END	
END
GO

IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version >= 691 AND fill_version < 713)
	UPDATE [dbo].[Version] SET fill_version = 713;
GO

--------------------------------------------------------------------
---- IF ANOTHER SCRIPTS WAS UPDATED:
---- 1. UNCOMMENT AND INCREMENT VERSION
---- 2. MAKE SURE THAT THE SCRIPT VERSIONS EQUALS TO THE VERSIONS OF THE CONFIG FILE.

--IF EXISTS (SELECT * FROM [dbo].[Version] WHERE fill_version = 692)
--	UPDATE [dbo].[Version] SET fill_version = 693;
--GO
----------------------------------------------------------------------
----GO