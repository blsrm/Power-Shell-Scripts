SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------------
-- Tape.report_directory_changes
PRINT N'Creating [dbo].[Tape.report_directory_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_directory_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_directory_changes]
GO

	CREATE VIEW [dbo].[Tape.report_directory_changes]
AS

WITH temp_table AS (
	SELECT   
		dir.id,
		dir.name,
		dir.[host_id],
		dir.parent_id,
		ISNULL(dver.creation_time, GETDATE()) as creation_time,
		ISNULL(dver.last_write_time, GETDATE()) as last_write_time,
		(SELECT COUNT(directory_id) FROM [Tape.directory_versions] WHERE directory_id = dir.id) as count_points,
		dver.backup_set_id,
		bset.media_family_id,
		ROW_NUMBER() OVER (PARTITION BY dir.id ORDER BY dir.id DESC) as RN,
		ISNULL(bset.usn, 0) as usn
	FROM [Tape.directories] dir
	LEFT JOIN [Tape.directory_versions] dver ON dver.directory_id = dir.id
	LEFT JOIN [Tape.backup_sets] bset ON bset.id = dver.backup_set_id
	GROUP BY dir.id,dir.name,dir.[host_id],dir.parent_id, creation_time, last_write_time,dver.backup_set_id,bset.media_family_id, usn
	)
SELECT 
	dirs.id,
	ISNULL(dirs.name, '/') name,
	dirs.media_family_id,
	dirs.[host_id],
	dirs.creation_time,
	dirs.last_write_time,
	dirs.backup_set_id,
	dirs.parent_id,
	dirs.count_points,
	dirs.usn
FROM temp_table as dirs
WHERE dirs.RN = 1
	
GO

--------------------------------------------------------------------------------
-- [Tape.report_file_changes]
PRINT N'Creating [dbo].[Tape.report_file_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_file_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_file_changes]
GO

	CREATE VIEW [dbo].[Tape.report_file_changes]
AS

WITH temp_table AS (SELECT  fil.id,
		fil.directory_id,
		fil.name,
		fver.creation_time,
		fver.last_write_time,
		fver.backup_set_id,
		fver.size,
		(SELECT COUNT([file_id]) FROM [Tape.file_versions] WHERE [file_id] = fil.id) as count_points,
		bset.media_family_id,
		ROW_NUMBER() OVER (PARTITION BY fil.id ORDER BY fil.id DESC) as RN,
		bset.usn
 FROM [Tape.file_versions] fver
 INNER JOIN [Tape.backup_sets] bset ON bset.id = fver.backup_set_id
 INNER JOIN [Tape.files] fil ON fil.id = fver.[file_id]
 GROUP BY fil.id,fil.directory_id,fil.name, creation_time, last_write_time, fver.backup_set_id, fver.size, bset.media_family_id, bset.usn)
SELECT files.id,
 files.name,
 files.media_family_id,
 files.creation_time,
 files.last_write_time,
 files.backup_set_id,
 files.directory_id,
 files.size,
 files.count_points,
 files.usn
FROM temp_table as files
WHERE files.RN =1 AND files.count_points > 0

	
GO

--------------------------------------------------------------------------------
-- [Tape.report_job_set_changes]
PRINT N'Creating [dbo].[Tape.report_job_set_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_job_set_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_job_set_changes]
GO

	CREATE VIEW [dbo].[Tape.report_job_set_changes]
AS

SELECT  bsets.id,
		bsets.name,
		bsets.write_time,
		bsets.media_family_id,
		bsets.usn
 FROM [Tape.backup_sets] bsets

	
GO

--------------------------------------------------------------------------------
-- [Tape.report_media_set_changes]
PRINT N'Creating [dbo].[Tape.report_media_set_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_set_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_media_set_changes]
GO

	CREATE VIEW [dbo].[Tape.report_media_set_changes]
AS

WITH temp_table AS (SELECT bsets.media_family_id,
	    bsets.id,
	    bsets.name,
		MAX(bsets.write_time) as write_time,
		tmed.media_pool_id,
		ROW_NUMBER() OVER (PARTITION BY bsets.media_family_id ORDER BY bsets.write_time DESC) as RN,
		MAX(bsets.usn) as usn
 FROM [Tape.backup_sets] bsets 
 INNER JOIN [Tape.tape_mediums] tmed ON tmed.media_family_id = bsets.media_family_id 
 WHERE tmed.cleaner = 0
 GROUP BY bsets.media_family_id, write_time, bsets.id, tmed.media_pool_id, bsets.name)
SELECT media_sets.id,
 media_sets.name,
 media_sets.media_family_id,
 media_sets.write_time,
 media_sets.media_pool_id,
 media_sets.usn
FROM temp_table as media_sets
WHERE media_sets.RN =1

	
GO

--------------------------------------------------------------------------------
-- [Tape.report_server_changes]
PRINT N'Creating [dbo].[Tape.report_server_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_server_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_server_changes]
GO

CREATE VIEW [dbo].[Tape.report_server_changes]
AS
	SELECT 
		DISTINCT(h.id), 
		h.name, 
		(SELECT MAX(usn) FROM [Tape.backup_sets]) usn
	FROM 
		[Tape.hosts] h
		INNER JOIN [Tape.directories] d ON h.id = d.host_id
GO

--------------------------------------------------------------------------------
-- Tape.report_directory_deletes
PRINT N'Creating [dbo].[Tape.report_directory_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_directory_deletes]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.report_directory_deletes]
GO

CREATE PROCEDURE [dbo].[Tape.report_directory_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.directories'
END
GO

--------------------------------------------------------------------------------
-- Tape.report_media_set_deletes
PRINT N'Creating [dbo].[Tape.report_media_set_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_set_deletes]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.report_media_set_deletes]
GO

CREATE PROCEDURE [dbo].[Tape.report_media_set_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.backup_sets'
END
GO

--------------------------------------------------------------------------------
-- Tape.report_file_deletes
PRINT N'Creating [dbo].[Tape.report_file_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_file_deletes]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.report_file_deletes]
GO

CREATE PROCEDURE [dbo].[Tape.report_file_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT uid, usn	FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.files'
END
GO



--------------------------------------------------------------------------------
-- Tape.library_names
PRINT N'Creating [dbo].[Tape.library_names]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.library_names]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.library_names]
GO
CREATE VIEW dbo.[Tape.library_names]
AS
SELECT     
	[Tape.libraries].id, 
	(CASE 
		WHEN [Tape.libraries].name IS NULL OR LTRIM(RTRIM([Tape.libraries].name)) = ''
		THEN [Tape.changers].vendor_id + ' ' + [Tape.changers].product_id + ' ' + [Tape.changers].revision 
		ELSE [Tape.libraries].name 
	END) AS name
FROM
	[Tape.libraries] INNER JOIN
    [Tape.library_devices] ON [Tape.libraries].id = [Tape.library_devices].library_id INNER JOIN
    [Tape.changers] ON [Tape.library_devices].device_id = [Tape.changers].device_id
WHERE     
	[Tape.libraries].type = 0
UNION
SELECT     
	[Tape.libraries].id, 
	(CASE 
		WHEN [Tape.libraries].name IS NULL OR LTRIM(RTRIM([Tape.libraries].name)) = ''
		THEN [Tape.tape_drives].name 
		ELSE [Tape.libraries].name 
	END) AS name
FROM
	[Tape.libraries] INNER JOIN
    [Tape.library_devices] ON [Tape.libraries].id = [Tape.library_devices].library_id INNER JOIN
	[Tape.tape_drives] ON [Tape.library_devices].device_id = [Tape.tape_drives].device_id
WHERE
	[Tape.libraries].type = 1
GO

--------------------------------------------------------------------------------
-- Tape.report_filesysitems
PRINT N'Creating [dbo].[Tape.report_filesysitems]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_filesysitems]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_filesysitems]
GO

CREATE VIEW [dbo].[Tape.report_filesysitems]
AS
SELECT   dir.id,
		 ISNULL(dir.name, '/') name,
		 dir.[host_id],
		 dir.parent_id,
		 dver.last_write_time,
		 dver.creation_time,
		 0 AS size,
		 [dbo].GetDirectoryPointsCount(dir.id) as count_points,
		 0 as [incomplete],
		 0 as [type],
		CASE 
            WHEN bsets.encrypted = 1 AND bsets.crypto_key_id <> '00000000-0000-0000-0000-000000000000'
               THEN 0 
               ELSE bsets.encrypted 
			END AS encrypted,
		ISNULL(bsets.usn, (SELECT MAX(usn) FROM ReplicationInfo)) AS usn
	FROM [Tape.directories] dir
	LEFT JOIN [Tape.directory_versions] dver ON dver.[directory_id] = dir.id
	LEFT JOIN [Tape.backup_sets] bsets ON bsets.backup_id = dver.backup_set_id
	WHERE dver.id in (SELECT MAX(id) FROM [Tape.directory_versions] WHERE directory_id = dir.id) 
	OR (SELECT COUNT(id) FROM [Tape.directory_versions] WHERE directory_id = dir.id) = 0
UNION ALL
SELECT   fil.id,
		 fil.name,
		 '00000000-0000-0000-0000-000000000000' as [host_id],
		 fil.directory_id as parent_id,
		 fver.last_write_time,
		 fver.creation_time,
		 fver.size,
		 [dbo].GetFilePointsCount(fil.id) AS count_points,
		 fver.incomplete,
		 1 as [type],
		 CASE 
            WHEN bsets.encrypted = 1 AND bsets.crypto_key_id <> '00000000-0000-0000-0000-000000000000'
               THEN 0 
               ELSE bsets.encrypted 
			END AS encrypted,
		 ISNULL(bsets.usn, (SELECT MAX(usn) FROM ReplicationInfo)) AS usn
	FROM [Tape.files] fil
	LEFT JOIN [Tape.file_versions] fver ON fver.[file_id] = fil.id AND fver.corrupted = 0
	LEFT JOIN [Tape.backup_sets] bsets ON bsets.backup_id = fver.backup_set_id
	WHERE fver.id in (SELECT MAX(id) FROM [Tape.file_versions] WHERE [file_id] = fil.id)

GO

--------------------------------------------------------------------------------
-- Tape.insert_as_first
PRINT N'Creating [dbo].[Tape.insert_as_first]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.insert_as_first]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[Tape.insert_as_first]
GO
CREATE FUNCTION [dbo].[Tape.insert_as_first] (@x1 XML, @x2 XML)
RETURNS XML
AS
BEGIN
 
      -- insert into null value is impossible
      IF (@x1 is null)
            RETURN null
 
    -- if the value to insert is null or if @x1 contains no element we do nothing
      IF ((@x1.value('count(/*)','int') = 0) OR (@x2 is null))
            RETURN @x1
 
      -- if there is no element to insert we do nothing
      IF (@x2.value('count(/*)','int') = 0)
            RETURN @x1
 
      -- if any one of the two instances is not a valid document (more than one root element)
      -- we do nothing
      IF ((@x1.value('count(/*)','int') > 1) OR (@x2.value('count(/*)','int') > 1))
            RETURN @x1 
 
 
      DECLARE @x XML
      SET @x = CONVERT(XML, (CONVERT(nvarchar(MAX), @x1) + CONVERT(nvarchar(MAX), @x2)))
      SET @x.modify('insert /*[2] as first into /*[1]')
      SET @x.modify('delete /*[2]')
 
      RETURN @x
 
END
GO

--------------------------------------------------------------------------------
-- Tape.get_device_by_serial_number
PRINT N'Creating [dbo].[Tape.get_device_by_serial_number]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_device_by_serial_number]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_device_by_serial_number]
GO
CREATE PROCEDURE [dbo].[Tape.get_device_by_serial_number]
	@serial_number nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.devices] WHERE serial_number = @serial_number
END
GO


--------------------------------------------------------------------------------
-- Tape.get_device
PRINT N'Creating [dbo].[Tape.get_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_device]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_device]
GO
CREATE PROCEDURE [dbo].[Tape.get_device]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.devices] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directory_full_name
PRINT N'Creating [dbo].[Tape.get_directory_full_name]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory_full_name]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory_full_name]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory_full_name]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;

	WITH directory_full_name(i, id, name)
	AS 
	(
		SELECT 0, parent_id, CAST(name AS nvarchar(255))
		FROM [Tape.directories]
		WHERE id = @id
		UNION ALL
		SELECT directory_full_name.i + 1, [Tape.directories].parent_id, [Tape.directories].name
		FROM [Tape.directories]
		INNER JOIN directory_full_name ON directory_full_name.id = [Tape.directories].id
	)
	SELECT name, 1 l, i FROM directory_full_name
--	UNION SELECT h.name, 0, 0 FROM [Tape.hosts] h INNER JOIN [Tape.directories] d ON h.id = d.host_id WHERE d.id = @id
	ORDER BY l ASC, i DESC
	OPTION (MAXRECURSION 32767)
	
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directory_by_host_id_and_name
PRINT N'Creating [dbo].[Tape.get_directory_by_host_id_and_name]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory_by_host_id_and_name]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory_by_host_id_and_name]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory_by_host_id_and_name]
	@host_id uniqueidentifier
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @name IS NULL
		SELECT * FROM [Tape.directories] WHERE [host_id] = @host_id AND parent_id IS NULL AND name IS NULL
	ELSE
		SELECT * FROM [Tape.directories] WHERE [host_id] = @host_id AND parent_id IS NULL AND name = @name COLLATE Latin1_General_BIN
END
GO

--------------------------------------------------------------------------------
-- Tape.get_directory_by_parent_id_and_name
PRINT N'Creating [dbo].[Tape.get_directory_by_parent_id_and_name]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory_by_parent_id_and_name]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory_by_parent_id_and_name]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory_by_parent_id_and_name]
	@parent_id bigint
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.directories] WHERE parent_id = @parent_id AND name = @name COLLATE Latin1_General_BIN
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directory
PRINT N'Creating [dbo].[Tape.get_directory]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.directories] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directories
PRINT N'Creating [dbo].[Tape.get_directories]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directories]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directories]
GO
CREATE PROCEDURE [dbo].[Tape.get_directories]
	@ids xml
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @hdocument int
	EXEC sp_xml_preparedocument @hdocument OUTPUT, @ids

	SELECT * FROM [Tape.directories] WHERE id IN (SELECT * FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id bigint))
	
	EXEC sp_xml_removedocument @hdocument
END
GO


--------------------------------------------------------------------------------
-- Tape.get_host
PRINT N'Creating [dbo].[Tape.get_host]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_host]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_host]
GO
CREATE PROCEDURE [dbo].[Tape.get_host]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.hosts] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_highest_committed_usn
PRINT N'Creating [dbo].[Tape.get_highest_committed_usn]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_highest_committed_usn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_highest_committed_usn]
GO
CREATE PROCEDURE [dbo].[Tape.get_highest_committed_usn]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT usn FROM [ReplicationInfo]
END
GO


--------------------------------------------------------------------------------
-- Tape.report_backup_sets_deletes
PRINT N'Creating [dbo].[Tape.report_backup_sets_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_backup_sets_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_backup_sets_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_backup_sets_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.backup_sets'
END
GO


--------------------------------------------------------------------------------
-- Tape.next_highest_committed_usn
PRINT N'Creating [dbo].[Tape.next_highest_committed_usn]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.next_highest_committed_usn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.next_highest_committed_usn]
GO
CREATE PROCEDURE [dbo].[Tape.next_highest_committed_usn]
	@highest_committed_usn bigint OUT
AS
BEGIN
	SET XACT_ABORT ON;
	BEGIN TRANSACTION
	
	UPDATE [ReplicationInfo] SET usn = usn + 1
	SELECT @highest_committed_usn = usn FROM [ReplicationInfo]
	
	COMMIT TRANSACTION
END
GO


--------------------------------------------------------------------------------
-- Tape.report_backups_deletes
PRINT N'Creating [dbo].[Tape.report_backups_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_backups_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_backups_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_backups_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.jobs'
END
GO


--------------------------------------------------------------------------------
-- Tape.report_media_deletes
PRINT N'Creating [dbo].[Tape.report_media_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_media_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_media_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.tape_mediums'
END
GO


--------------------------------------------------------------------------------
-- Tape.report_media_pool_deletes
PRINT N'Creating [dbo].[Tape.report_media_pool_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_pool_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_media_pool_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_media_pool_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.tape_mediums'
END
GO


--------------------------------------------------------------------------------
-- Tape.report_libraries_deletes
PRINT N'Creating [dbo].[Tape.report_libraries_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_libraries_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_libraries_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_libraries_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.libraries'
END
GO


--------------------------------------------------------------------------------
-- Tape.report_jobs_deletes
PRINT N'Creating [dbo].[Tape.report_jobs_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_jobs_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_jobs_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_jobs_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.jobs'
END
GO


--------------------------------------------------------------------------------
-- Tape.report_media_pools_deletes
PRINT N'Creating [dbo].[Tape.report_media_pools_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_pools_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_media_pools_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_media_pools_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.media_pools'
END
GO


--------------------------------------------------------------------------------
-- Tape.report_sessions_deletes
PRINT N'Creating [dbo].[Tape.report_sessions_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_sessions_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_sessions_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_sessions_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.sessions'
END
GO


--------------------------------------------------------------------------------
-- Tape.report_tape_drives_deletes
PRINT N'Creating [dbo].[Tape.report_tape_drives_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_tape_drives_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_tape_drives_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_tape_drives_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.tape_drives'
END
GO


--------------------------------------------------------------------------------
-- Tape.add_host
PRINT N'Creating [dbo].[Tape.add_host]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_host]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_host]
GO
CREATE PROCEDURE [dbo].[Tape.add_host]
	@name nvarchar(255)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @id AS UNIQUEIDENTIFIER
	SET @id = NEWID()
	
	INSERT INTO [Tape.hosts] (
		id
		,name
		)
	VALUES (
		@id
		,@name
		)
		
	SELECT @id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_directory
PRINT N'Creating [dbo].[Tape.add_directory]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_directory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_directory]
GO
CREATE PROCEDURE [dbo].[Tape.add_directory]
	@host_id uniqueidentifier
	,@parent_id bigint
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [Tape.directories] (
		[host_id]
		,parent_id
		,name
	)
	VALUES (
		@host_id
		,@parent_id
		,@name
	)
		
	SELECT CAST(SCOPE_IDENTITY() AS BIGINT) AS [SCOPE_IDENTITY]
END
GO


--------------------------------------------------------------------------------
-- Tape.add_device
PRINT N'Creating [dbo].[Tape.add_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.add_device]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.add_device]
GO
CREATE PROCEDURE [Tape.add_device]
	@id uniqueidentifier
	,@tape_server_id uniqueidentifier
	,@scsi_port int
	,@scsi_bus int
	,@scsi_target_id int
	,@scsi_logical_unit_id int
	,@type tinyint
	,@name nvarchar(MAX)
	,@serial_number nvarchar(32)
	,@state tinyint
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [Tape.devices] (
		id
		,tape_server_id
		,scsi_port
		,scsi_bus
		,scsi_target_id
		,scsi_logical_unit_id
		,[type]
		,name
		,serial_number
		,[state]
		)
	VALUES (
		@id
		,@tape_server_id
		,@scsi_port
		,@scsi_bus
		,@scsi_target_id
		,@scsi_logical_unit_id
		,@type
		,@name
		,@serial_number
		,@state
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_directories_by_parent_id
PRINT N'Creating [dbo].[Tape.get_all_directories_by_parent_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_directories_by_parent_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id]
	@parent_id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.directories] WHERE parent_id = @parent_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_devices
PRINT N'Creating [dbo].[Tape.get_all_devices]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_devices]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_devices]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_devices]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.devices]
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_device
PRINT N'Creating [dbo].[Tape.delete_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_device]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_device]
GO
CREATE PROCEDURE [dbo].[Tape.delete_device]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.devices] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.unlock_device
PRINT N'Creating [dbo].[Tape.unlock_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.unlock_device]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.unlock_device]
GO
CREATE PROCEDURE [dbo].[Tape.unlock_device]
	@device_id uniqueidentifier 
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.devices] SET lock_id = NULL WHERE id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_all_devices_state
PRINT N'Creating [dbo].[Tape.update_all_devices_state]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_all_devices_state]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_all_devices_state]
GO
CREATE PROCEDURE [dbo].[Tape.update_all_devices_state]
	@state tinyint
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.devices] SET [state] = @state
END
GO


--------------------------------------------------------------------------------
-- Tape.update_device
PRINT N'Creating [dbo].[Tape.update_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_device]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_device]
GO
CREATE PROCEDURE [dbo].[Tape.update_device]
	@id uniqueidentifier
	,@tape_server_id uniqueidentifier
	,@scsi_port int
	,@scsi_bus int
	,@scsi_target_id int
	,@scsi_logical_unit_id int
	,@type tinyint
	,@name nvarchar(MAX)
	,@serial_number nvarchar(32)
	,@state tinyint
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.devices] SET
		tape_server_id = @tape_server_id
		,scsi_port = @scsi_port
		,scsi_bus = @scsi_bus
		,scsi_target_id = @scsi_target_id
		,scsi_logical_unit_id = @scsi_logical_unit_id
		,[type] = @type
		,name = @name
		,serial_number = @serial_number
		,[state] = @state
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_changer
PRINT N'Creating [dbo].[Tape.update_changer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_changer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_changer]
GO
CREATE PROCEDURE [dbo].[Tape.update_changer]
	@device_id uniqueidentifier
	,@name nvarchar(MAX)
	,@vendor_id nvarchar(8)
	,@product_id nvarchar(16)
	,@revision nvarchar(4)
	,@first_drive_number int
	,@drive_count int
	,@first_slot_number int
	,@slot_count int
	,@first_ieport_number int
	,@ieport_count int
	,@first_cleaner_slot_number int
	,@cleaner_slot_count int
	,@magazine_size int
	,@features0 bigint
	,@features1 bigint
	,@move_from_slot tinyint
	,@move_from_ieport tinyint
	,@move_from_drive tinyint
	,@exchange_from_slot tinyint
	,@exchange_from_ieport tinyint
	,@exchange_from_drive tinyint
	,@lock_unlock_capabilities tinyint
	,@is_driver_installed bit
	,@use_scsi bit
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.changers] SET
		vendor_id = @vendor_id
		,name = @name
		,product_id = @product_id
		,revision = @revision
		,first_drive_number = @first_drive_number
		,drive_count = @drive_count
		,first_slot_number = @first_slot_number
		,slot_count = @slot_count
		,first_ieport_number = @first_ieport_number
		,ieport_count = @ieport_count
		,first_cleaner_slot_number = @first_cleaner_slot_number
		,cleaner_slot_count = @cleaner_slot_count
		,magazine_size = @magazine_size
		,features0 = @features0
		,features1 = @features1
		,move_from_slot = @move_from_slot
		,move_from_ieport = @move_from_ieport
		,move_from_drive = @move_from_drive
		,exchange_from_slot = @exchange_from_slot
		,exchange_from_ieport = @exchange_from_ieport
		,exchange_from_drive = @exchange_from_drive
		,lock_unlock_capabilities = @lock_unlock_capabilities
		,is_driver_installed = @is_driver_installed
		,use_scsi = @use_scsi
	WHERE
		device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_changer
PRINT N'Creating [dbo].[Tape.delete_changer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_changer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_changer]
GO
CREATE PROCEDURE [dbo].[Tape.delete_changer]
	@device_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.changers] WHERE device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_files_by_directory_id
PRINT N'Creating [dbo].[Tape.get_all_files_by_directory_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_files_by_directory_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_files_by_directory_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_files_by_directory_id]
	@directory_id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.files] WHERE directory_id = @directory_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_changers
PRINT N'Creating [dbo].[Tape.get_all_changers]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_changers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_changers]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_changers]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.changers]
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_file
PRINT N'Creating [dbo].[Tape.delete_file]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_file]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_file]
GO
CREATE PROCEDURE [dbo].[Tape.delete_file]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.files] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_changer
PRINT N'Creating [dbo].[Tape.add_changer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.add_changer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.add_changer]
GO
CREATE PROCEDURE [dbo].[Tape.add_changer]
	@device_id uniqueidentifier
	,@name nvarchar(MAX)
	,@vendor_id nvarchar(8)
	,@product_id nvarchar(16)
	,@revision nvarchar(4)
	,@first_drive_number int
	,@drive_count int
	,@first_slot_number int
	,@slot_count int
	,@first_ieport_number int
	,@ieport_count int
	,@first_cleaner_slot_number int
	,@cleaner_slot_count int
	,@magazine_size int
	,@features0 bigint
	,@features1 bigint
	,@move_from_slot tinyint
	,@move_from_ieport tinyint
	,@move_from_drive tinyint
	,@exchange_from_slot tinyint
	,@exchange_from_ieport tinyint
	,@exchange_from_drive tinyint
	,@lock_unlock_capabilities tinyint
	,@is_driver_installed bit
	,@use_scsi bit
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [Tape.changers] (
		device_id
		,name
		,vendor_id
		,product_id
		,revision
		,first_drive_number
		,drive_count
		,first_slot_number
		,slot_count
		,first_ieport_number
		,ieport_count
		,first_cleaner_slot_number
		,cleaner_slot_count
		,magazine_size
		,features0
		,features1
		,move_from_slot
		,move_from_ieport
		,move_from_drive
		,exchange_from_slot
		,exchange_from_ieport
		,exchange_from_drive
		,lock_unlock_capabilities
		,is_driver_installed
		,use_scsi
		)
	VALUES (
		@device_id
		,@name
		,@vendor_id
		,@product_id
		,@revision
		,@first_drive_number
		,@drive_count
		,@first_slot_number
		,@slot_count
		,@first_ieport_number
		,@ieport_count
		,@first_cleaner_slot_number
		,@cleaner_slot_count
		,@magazine_size
		,@features0
		,@features1
		,@move_from_slot
		,@move_from_ieport
		,@move_from_drive
		,@exchange_from_slot
		,@exchange_from_ieport
		,@exchange_from_drive
		,@lock_unlock_capabilities
		,@is_driver_installed
		,@use_scsi
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.add_file
PRINT N'Creating [dbo].[Tape.add_file]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_file]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_file]
GO
CREATE PROCEDURE [dbo].[Tape.add_file]
	@directory_id BIGINT
	,@name NVARCHAR(255)
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [Tape.files] (directory_id ,name) VALUES (@directory_id, @name)
		
	SELECT * FROM [Tape.files] WHERE id = CAST(SCOPE_IDENTITY() AS BIGINT)
END
GO


--------------------------------------------------------------------------------
-- Tape.search_files
PRINT N'Creating [dbo].[Tape.search_files]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.search_files]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.search_files]
GO
CREATE PROCEDURE [dbo].[Tape.search_files]
	@pattern nvarchar(800)
	,@parent_ids xml
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @hdocument int
	EXEC sp_xml_preparedocument @hdocument OUTPUT, @parent_ids

	DECLARE @ids_count int	
	SELECT @ids_count = COUNT(*) FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id bigint)
	
	IF @ids_count > 0
		SELECT id FROM [Tape.files] WHERE name LIKE @pattern ESCAPE '\' AND directory_id IN (SELECT id FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id bigint))
	ELSE
		SELECT id FROM [Tape.files] WHERE name LIKE @pattern ESCAPE '\'

	EXEC sp_xml_removedocument @hdocument
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_by_directory_and_name
PRINT N'Creating [dbo].[Tape.get_file_by_directory_and_name]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_by_directory_and_name]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_by_directory_and_name]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_by_directory_and_name]
	@directory_id bigint
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		* 
	FROM 
		[Tape.files]
	WHERE
		directory_id = @directory_id AND
		name = @name COLLATE Latin1_General_BIN
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file
PRINT N'Creating [dbo].[Tape.get_file]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file]
GO
CREATE PROCEDURE [dbo].[Tape.get_file]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.files] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_files
PRINT N'Creating [dbo].[Tape.get_files]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_files]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_files]
GO
CREATE PROCEDURE [dbo].[Tape.get_files]
	@ids xml
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @hdocument int
	EXEC sp_xml_preparedocument @hdocument OUTPUT, @ids
	
	SELECT * FROM [Tape.files] WHERE id IN (SELECT id FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id bigint))

	EXEC sp_xml_removedocument @hdocument
END
GO


--------------------------------------------------------------------------------
-- Tape.get_changer
PRINT N'Creating [dbo].[Tape.get_changer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_changer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_changer]
GO
CREATE PROCEDURE [dbo].[Tape.get_changer]
	@device_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.changers] WHERE device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_libraries
PRINT N'Creating [dbo].[Tape.get_all_libraries]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_libraries]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_libraries]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_libraries]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.libraries]
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_jobs
PRINT N'Creating [dbo].[Tape.get_all_jobs]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_jobs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_jobs]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_jobs]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.jobs] WHERE [Tape.jobs].[Type] in (24, 25, 26, 27, 28, 29, 32, 33, 34, 35, 36, 37) 
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_tape_mediums
PRINT N'Creating [dbo].[Tape.get_all_tape_mediums]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_tape_mediums]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_tape_mediums]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_tape_mediums]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_mediums]
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_tape_drives
PRINT N'Creating [dbo].[Tape.get_all_tape_drives]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_tape_drives]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_tape_drives]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_tape_drives]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_drives]
END
GO


--------------------------------------------------------------------------------
-- Tape.get_library
PRINT N'Creating [dbo].[Tape.get_library]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_library]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_library]
GO
CREATE PROCEDURE [dbo].[Tape.get_library]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.libraries] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_libraries_by_type
PRINT N'Creating [dbo].[Tape.get_libraries_by_type]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_libraries_by_type]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_libraries_by_type]
GO
CREATE PROCEDURE [dbo].[Tape.get_libraries_by_type]
	@type tinyint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.libraries] WHERE [type] = @type
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_mediums_by_media_pool_id
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_media_pool_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_media_pool_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_media_pool_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_media_pool_id]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		* 
	FROM 
		[Tape.tape_mediums] 
	WHERE 
		media_pool_id = @media_pool_id 
	ORDER BY 
		media_family_id, media_sequence_number, barcode
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_medium_to_overwrite
PRINT N'Creating [dbo].[Tape.get_tape_medium_to_overwrite]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium_to_overwrite]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium_to_overwrite]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium_to_overwrite]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT TOP 1 
		*
	FROM 
		[Tape.tape_mediums]
	WHERE 
		media_pool_id = @media_pool_id AND
		location_type IN (0, 1) AND
		is_write_protected = 0 AND
		is_full <> 0
	ORDER BY 
		last_write_time ASC, 
		barcode ASC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_medium_to_append
PRINT N'Creating [dbo].[Tape.get_tape_medium_to_append]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium_to_append]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium_to_append]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium_to_append]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT TOP 1 
		*
	FROM 
		[Tape.tape_mediums]
	WHERE 
		media_pool_id = @media_pool_id AND
		location_type IN (0, 1) AND
		is_write_protected = 0 AND
		is_full = 0
	ORDER BY 
		last_write_time DESC,
		barcode ASC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_medium_by_location
PRINT N'Creating [dbo].[Tape.get_tape_medium_by_location]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium_by_location]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium_by_location]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium_by_location]
	@location_type tinyint
	,@location_library_id uniqueidentifier
	,@location_address int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT
		*
	FROM
		[Tape.tape_mediums]
	WHERE
		location_type = @location_type AND
		location_library_id = @location_library_id AND
		location_address = @location_address
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_medium_by_barcode
PRINT N'Creating [dbo].[Tape.get_tape_medium_by_barcode]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium_by_barcode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium_by_barcode]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium_by_barcode]
	@barcode nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_mediums] WHERE barcode = @barcode
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_medium_by_family_id_and_sequence_number
PRINT N'Creating [dbo].[Tape.get_tape_medium_by_family_id_and_sequence_number]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium_by_family_id_and_sequence_number]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium_by_family_id_and_sequence_number]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium_by_family_id_and_sequence_number]
	@media_family_id int
	,@media_sequence_number int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_mediums] WHERE media_family_id = @media_family_id AND media_sequence_number = @media_sequence_number
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_medium
PRINT N'Creating [dbo].[Tape.get_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_mediums] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_drive
PRINT N'Creating [dbo].[Tape.get_tape_drive]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_drive]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_drive]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_drive]
	@device_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_drives] WHERE device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.lock_tape_medium
PRINT N'Creating [dbo].[Tape.lock_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.lock_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.lock_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.lock_tape_medium]
	@tape_medium_id uniqueidentifier, 
	@lock_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET lock_id = @lock_id, usn = @usn WHERE id = @tape_medium_id AND (lock_id IS NULL OR lock_id = @lock_id)
	
	SELECT @@ROWCOUNT
END
GO


--------------------------------------------------------------------------------
-- Tape.add_library
PRINT N'Creating [dbo].[Tape.add_library]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_library]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_library]
GO
CREATE PROCEDURE [dbo].[Tape.add_library]
	@id uniqueidentifier
	,@tape_server_id uniqueidentifier
	,@type tinyint
	,@enabled bit
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	
	BEGIN TRANSACTION;
	
	INSERT INTO [Tape.libraries] (
		id
		,tape_server_id
		,[type]
		,[enabled]
		)
	VALUES (
		@id
		,@tape_server_id
		,@type
		,@enabled
		)
		
	INSERT INTO 
		[Tape.media_pool_libraries] (media_pool_id, library_id, priority)
	SELECT 
		m.id, @id, 0 
	FROM 
		[Tape.media_pools] m
	WHERE 
		m.type IN (0, 1, 2, 3)

		COMMIT TRANSACTION;
END
GO


--------------------------------------------------------------------------------
-- Tape.add_job
PRINT N'Creating [dbo].[Tape.add_job]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_job]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_job]
GO
CREATE PROCEDURE [dbo].[Tape.add_job]
	@name nvarchar(MAX)
	,@description nvarchar(MAX)
	,@type tinyint
	,@full_mediapool_id uniqueidentifier
	,@incremental_mediapool_id uniqueidentifier
	,@options xml
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @id AS UNIQUEIDENTIFIER
	SET @id = NEWID()
	INSERT INTO [Tape.jobs] (
		id
		,name
		,[description]
		,[type]
		,full_mediapool_id
		,incremental_mediapool_id
		,options
		)
	VALUES (
		@id
		,@name
		,@description
		,@type
		,@full_mediapool_id
		,@incremental_mediapool_id
		,@options
		)
	SELECT @id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_tape_medium
PRINT N'Creating [dbo].[Tape.add_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.add_tape_medium]
	@id uniqueidentifier
	,@barcode nvarchar(MAX)
	,@name nvarchar(MAX)
	,@description nvarchar(MAX)
	,@media_family_id int
	,@media_sequence_number int
	,@media_time datetime
	,@continuation bit
	,@location_type tinyint
	,@location_library_id uniqueidentifier
	,@location_address int
	,@original_slot int
	,@media_pool_id uniqueidentifier
	,@capacity bigint
	,@remaining bigint
	,@block_size int
	,@partition_count int
	,@is_write_protected bit
	,@is_full bit
	,@media_id uniqueidentifier
	,@media_label nvarchar(MAX)
	,@format_logical_address bigint
	,@retirement_reason nvarchar(MAX)
	,@retired bit
	,@cleaner bit
	,@protected bit
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	INSERT INTO [Tape.tape_mediums] (
		id
		,barcode
		,name
		,description
		,media_family_id
		,media_sequence_number
		,media_sequence_number_unique
		,media_time
		,continuation
		,location_type
		,location_library_id
		,location_address
		,original_slot
		,media_pool_id
		,capacity
		,remaining
		,block_size
		,partition_count
		,is_write_protected
		,is_full
		,usn
		,media_id
		,media_label
		,format_logical_address
		,retention_reason
		,retired
		,cleaner
		,protected
		)
	VALUES (
		@id
		,@barcode
		,@name
		,@description
		,@media_family_id
		,@media_sequence_number
		,@media_sequence_number
		,@media_time
		,@continuation
		,@location_type
		,@location_library_id
		,@location_address
		,@original_slot
		,@media_pool_id
		,@capacity
		,@remaining
		,@block_size
		,@partition_count
		,@is_write_protected
		,@is_full
		,@usn
		,@media_id
		,@media_label
		,@format_logical_address
		,@retirement_reason
		,@retired
		,@cleaner
		,@protected
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.add_tape_drive
PRINT N'Creating [dbo].[Tape.add_tape_drive]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_tape_drive]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_tape_drive]
GO
CREATE PROCEDURE [dbo].[Tape.add_tape_drive]
	@device_id uniqueidentifier
	,@address int
	,@name nvarchar(max)
	,@model nvarchar(max)
	,@minimum_block_size int
	,@maximum_block_size int
	,@default_block_size int
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [Tape.tape_drives] (
		device_id
		,[address]
		,[name]
		,[model]
		,minimum_block_size
		,maximum_block_size
		,default_block_size
		)
	VALUES (
		@device_id
		,@address
		,@name
		,@model
		,@minimum_block_size
		,@maximum_block_size
		,@default_block_size
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_job
PRINT N'Creating [dbo].[Tape.delete_job]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_job]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_job]
GO
CREATE PROCEDURE [dbo].[Tape.delete_job]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	
	BEGIN TRANSACTION;
	
	DELETE FROM [Tape.jobs] WHERE id = @id
	DELETE FROM [BJobs] WHERE [id] = @id

	EXEC [Tape.clear_tape_backups]

	COMMIT TRANSACTION
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_tape_medium
PRINT N'Creating [dbo].[Tape.delete_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.delete_tape_medium]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SET XACT_ABORT ON;

	BEGIN TRANSACTION;

	DELETE FROM [Tape.tape_mediums] WHERE id = @id

	DECLARE @usn bigint
	EXEC [dbo].[IncrementUsn] @usn OUTPUT
	EXEC [dbo].[InsertTombStone] 'Tape.tape_mediums', @id, @usn

	COMMIT TRANSACTION;
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_tape_drive
PRINT N'Creating [dbo].[Tape.delete_tape_drive]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_tape_drive]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_tape_drive]
GO
CREATE PROCEDURE [dbo].[Tape.delete_tape_drive]
	@device_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.tape_drives] WHERE device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.unlock_tape_medium
PRINT N'Creating [dbo].[Tape.unlock_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.unlock_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.unlock_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.unlock_tape_medium]
	@tape_medium_id uniqueidentifier 
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET lock_id = NULL, usn = @usn WHERE id = @tape_medium_id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_library
PRINT N'Creating [dbo].[Tape.update_library]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_library]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_library]
GO
CREATE PROCEDURE [dbo].[Tape.update_library]
	@id uniqueidentifier
	,@tape_server_id uniqueidentifier
	,@type tinyint
	,@enabled bit
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.libraries] SET
		tape_server_id = @tape_server_id
		,[type] = @type
		,[enabled] = @enabled
		,[name] = @name
	WHERE 
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_job
PRINT N'Creating [dbo].[Tape.update_job]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_job]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_job]
GO
CREATE PROCEDURE [dbo].[Tape.update_job]
	@id uniqueidentifier
	,@name nvarchar(MAX)
	,@description nvarchar(MAX)
	,@type tinyint
	,@full_mediapool_id uniqueidentifier
	,@incremental_mediapool_id uniqueidentifier
	,@schedule_enabled bit
	,@options xml
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	
	BEGIN TRANSACTION;
	
	UPDATE [Tape.jobs] SET
		name = @name
		,[description] = @description
		,[type] = @type
		,full_mediapool_id = @full_mediapool_id
		,incremental_mediapool_id = @incremental_mediapool_id
		,options= @options
		,schedule_enabled = @schedule_enabled
	WHERE
		id = @id

	UPDATE [BJobs] SET
		name = @name
	WHERE
		id = @id

	COMMIT TRANSACTION;
    
END
GO


--------------------------------------------------------------------------------
-- Tape.get_job
PRINT N'Creating [dbo].[Tape.get_job]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_job]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_job]
GO
CREATE PROCEDURE [dbo].[Tape.get_job]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.jobs] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium
PRINT N'Creating [dbo].[Tape.update_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium]
	@id uniqueidentifier
	,@barcode nvarchar(MAX)
	,@name nvarchar(MAX)
	,@description nvarchar(MAX)
	,@media_family_id int
	,@media_sequence_number int
	,@media_time datetime
	,@continuation bit
	,@location_type tinyint
	,@location_library_id uniqueidentifier
	,@location_address int
	,@original_slot int
	,@media_pool_id uniqueidentifier
	,@capacity bigint
	,@remaining bigint
	,@block_size int
	,@partition_count int
	,@is_write_protected bit
	,@is_full bit
	,@media_id uniqueidentifier
	,@media_label nvarchar(MAX)
	,@format_logical_address bigint
	,@retirement_reason nvarchar(MAX)
	,@retired bit
AS
BEGIN
	SET NOCOUNT ON;
	
	BEGIN TRY
		EXEC [Tape.update_tape_medium_family_id_and_sequence_number] @id = @id, @media_family_id = @media_family_id, @media_sequence_number = @media_sequence_number

		DECLARE @usn bigint
		EXEC [dbo].[IncrementUsn] @usn OUTPUT;

		UPDATE [Tape.tape_mediums] SET
			barcode = @barcode
			,name = @name
			,description = @description
			,media_time = @media_time
			,continuation = @continuation
			,location_type = @location_type
			,location_library_id = @location_library_id
			,location_address = @location_address
			,original_slot = @original_slot
			,media_pool_id = @media_pool_id
			,capacity = @capacity
			,remaining = @remaining
			,block_size = @block_size
			,partition_count = @partition_count
			,is_write_protected = @is_write_protected
			,is_full = @is_full
			,usn = @usn
			,media_id = @media_id
			,media_label = @media_label
			,format_logical_address = @format_logical_address
			,retention_reason = @retirement_reason
			,retired = @retired
		WHERE
			id = @id
	END TRY
	BEGIN CATCH
		DECLARE @error_message NVARCHAR(MAX)
		DECLARE @error_severity INT
		DECLARE @error_state INT

		SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY(), @error_state = ERROR_STATE()

		RAISERROR (@error_message, @error_severity, @error_state)
	END CATCH
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_location
PRINT N'Creating [dbo].[Tape.update_tape_medium_location]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_location]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_location]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_location]
	@id uniqueidentifier
	,@location_type tinyint
	,@location_library_id uniqueidentifier
	,@location_address int
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	
	BEGIN TRANSACTION;
	
	DECLARE @usn bigint
	DECLARE @old_location_type tinyint
	DECLARE @old_location_library_id uniqueidentifier
	DECLARE @old_location_address int

	SELECT @old_location_type = location_type, @old_location_library_id = location_library_id, @old_location_address = location_address FROM [Tape.tape_mediums] WHERE id = @id

	IF @old_location_type = 0
	BEGIN
		exec [dbo].[IncrementUsn] @usn OUTPUT;

		UPDATE 
			[Tape.tape_drives] 
		SET 
			usn = @usn
		FROM 
			[Tape.tape_drives] 
			INNER JOIN [Tape.library_devices] ON [Tape.tape_drives].device_id = [Tape.library_devices].device_id
		WHERE 
			[Tape.tape_drives].address = @old_location_address AND 
			[Tape.library_devices].library_id = @old_location_library_id
	END

	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		location_type = @location_type
		,location_library_id = @location_library_id
		,location_address = @location_address
		,usn = @usn
	WHERE
		id = @id

		COMMIT TRANSACTION;
        
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_original_slot
PRINT N'Creating [dbo].[Tape.update_tape_medium_original_slot]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_original_slot]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_original_slot]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_original_slot]
	@id uniqueidentifier
	,@original_slot int
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;
	
	UPDATE [Tape.tape_mediums] SET
		original_slot = @original_slot
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_barcode
PRINT N'Creating [dbo].[Tape.update_tape_medium_barcode]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_barcode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_barcode]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_barcode]
	@id uniqueidentifier
	,@barcode nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		barcode = @barcode
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_cleaner
PRINT N'Creating [dbo].[Tape.update_tape_medium_cleaner]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_cleaner]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_cleaner]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_cleaner]
	@id uniqueidentifier
	,@cleaner bit
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;
	
	UPDATE [Tape.tape_mediums] SET
		cleaner = @cleaner
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_name
PRINT N'Creating [dbo].[Tape.update_tape_medium_name]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_name]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_name]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_name]
	@id uniqueidentifier
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		name = @name
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_description
PRINT N'Creating [dbo].[Tape.update_tape_medium_description]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_description]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_description]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_description]
	@id uniqueidentifier
	,@description nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		description = @description
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_media_family_id
PRINT N'Creating [dbo].[Tape.update_tape_medium_media_family_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_media_family_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_media_family_id]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_media_family_id]
	@id uniqueidentifier
	,@media_family_id int
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		media_family_id = @media_family_id
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_is_full
PRINT N'Creating [dbo].[Tape.update_tape_medium_is_full]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_is_full]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_is_full]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_is_full]
	@id uniqueidentifier
	,@is_full bit
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;
	
	UPDATE [Tape.tape_mediums] SET
		is_full = @is_full
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_retired
PRINT N'Creating [dbo].[Tape.update_tape_medium_retired]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_retired]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_retired]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_retired]
	@id uniqueidentifier
	,@retirement_reason nvarchar(MAX)
	,@retired bit
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		retention_reason = @retirement_reason
		,retired = @retired
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_media_pool_id
PRINT N'Creating [dbo].[Tape.update_tape_medium_media_pool_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_media_pool_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_media_pool_id]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_media_pool_id]
	@id uniqueidentifier
	,@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		media_pool_id = @media_pool_id
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_media_info
PRINT N'Creating [dbo].[Tape.update_tape_medium_media_info]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_media_info]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_media_info]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_media_info]
	@id uniqueidentifier
	,@media_family_id int
	,@media_sequence_number int
	,@media_time datetime
	,@continuation bit
	,@media_id uniqueidentifier
	,@media_label nvarchar(MAX)
	,@format_logical_address bigint
	,@block_size int
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		EXEC [Tape.update_tape_medium_family_id_and_sequence_number] @id = @id, @media_family_id = @media_family_id, @media_sequence_number = @media_sequence_number

		DECLARE @usn bigint
		EXEC [dbo].[IncrementUsn] @usn OUTPUT;
	
		UPDATE [Tape.tape_mediums] SET
			media_time = @media_time
			,continuation = @continuation
			,media_id = @media_id
			,media_label = @media_label
			,format_logical_address = @format_logical_address
			,block_size = @block_size
			,usn = @usn
		WHERE
			id = @id
	END TRY
	BEGIN CATCH
		DECLARE @error_message NVARCHAR(MAX)
		DECLARE @error_severity INT
		DECLARE @error_state INT

		SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY(), @error_state = ERROR_STATE()

		RAISERROR (@error_message, @error_severity, @error_state)
	END CATCH
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_last_write_time
PRINT N'Creating [dbo].[Tape.update_tape_medium_last_write_time]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_last_write_time]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_last_write_time]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_last_write_time]
	@id uniqueidentifier
	,@last_write_time datetime
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;
	
	UPDATE [Tape.tape_mediums] SET
		last_write_time = @last_write_time
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_remaining
PRINT N'Creating [dbo].[Tape.update_tape_medium_remaining]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_remaining]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_remaining]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_remaining]
	@id uniqueidentifier
	,@remaining bigint
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;
	
	UPDATE [Tape.tape_mediums] SET
		remaining = @remaining
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_info
PRINT N'Creating [dbo].[Tape.update_tape_medium_info]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_info]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_info]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_info]
	@id uniqueidentifier
	,@capacity bigint
	,@remaining bigint
	,@partition_count int
	,@is_write_protected bit
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		capacity = @capacity
		,remaining = @remaining
		,partition_count = @partition_count
		,is_write_protected = @is_write_protected
		,usn = @usn
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_drive
PRINT N'Creating [dbo].[Tape.update_tape_drive]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_drive]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_drive]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_drive]
	@device_id uniqueidentifier
	,@address int
	,@enabled bit
	,@name nvarchar(max)
	,@model nvarchar(max)
	,@minimum_block_size int
	,@maximum_block_size int
	,@default_block_size int
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE [Tape.tape_drives] SET
		[address] = @address
		,[enabled] = @enabled
		,[name] = @name
		,[model] = @model
		,minimum_block_size = @minimum_block_size
		,maximum_block_size = @maximum_block_size
		,default_block_size = @default_block_size
	WHERE
		device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_session_progress
PRINT N'Creating [dbo].[Tape.update_session_progress]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_session_progress]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_session_progress]
GO
CREATE PROCEDURE [dbo].[Tape.update_session_progress]
	@id uniqueidentifier
	,@progress int
	,@total_objects int
	,@processed_objects int
	,@total_size bigint
	,@processed_size bigint
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRANSACTION;

	DECLARE @usn bigint

	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Backup.Model.BackupJobSessions] SET
		total_objects = @total_objects
		,processed_objects = @processed_objects
		,total_size = @total_size
		,total_used_size = @total_size
		,processed_size = @processed_size
		,processed_used_size = @processed_size
		,read_size = @processed_size
		,stored_size = @processed_size
		,usn = @usn
	WHERE
		id = @id

	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Backup.Model.JobSessions] SET
		progress = @progress
		,usn = @usn
	WHERE
		id = @id

		COMMIT TRANSACTION;
END
GO


--------------------------------------------------------------------------------
-- Tape.update_session
PRINT N'Creating [dbo].[Tape.update_session]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_session]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_session]
GO
CREATE PROCEDURE [dbo].[Tape.update_session]
	@id uniqueidentifier
	,@job_id uniqueidentifier
	,@job_name nvarchar(MAX)
	,@job_type int
	,@creation_time datetime
	,@end_time datetime
	,@result int
	,@state int
AS
BEGIN
	SET NOCOUNT ON;
		
	UPDATE [Backup.Model.JobSessions] SET
		job_id = @job_id
		,job_name = @job_name
		,job_type = @job_type
		,creation_time = @creation_time
		,end_time = @end_time
		,result = @result
		,[state] = @state
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_media_pool
PRINT N'Creating [dbo].[Tape.update_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_media_pool]
GO
CREATE PROCEDURE [dbo].[Tape.update_media_pool]
	@id uniqueidentifier
	,@name nvarchar(MAX)
	,@description nvarchar(MAX)
	,@type tinyint
	,@options xml
	,@crypto_key_id uniqueidentifier
	,@vault_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE [Tape.media_pools] SET
		name = @name
		,[description] = @description
		,[type] = @type
		,options = @options
		,crypto_key_id = @crypto_key_id
		,vault_id = @vault_id
	WHERE 
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_backup
PRINT N'Creating [dbo].[Tape.update_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_backup]
GO
CREATE PROCEDURE [dbo].[Tape.update_backup]
	@id uniqueidentifier
	,@job_id uniqueidentifier
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.backups] SET
		job_id = @job_id,
		name = @name
	WHERE
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.unlock_media_pool
PRINT N'Creating [dbo].[Tape.unlock_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.unlock_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.unlock_media_pool]
GO
CREATE PROCEDURE [dbo].[Tape.unlock_media_pool]
	@media_pool_id uniqueidentifier 
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.media_pools] SET lock_id = NULL WHERE id = @media_pool_id
END
GO

--------------------------------------------------------------------------------
-- Tape.unlock_all
PRINT N'Creating [dbo].[Tape.unlock_all]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.unlock_all]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.unlock_all]
GO
CREATE PROCEDURE [dbo].[Tape.unlock_all]
	@lock_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	
	BEGIN TRANSACTION;

	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.devices] SET lock_id = NULL WHERE lock_id = @lock_id
	UPDATE [Tape.media_pools] SET lock_id = NULL WHERE lock_id = @lock_id
	UPDATE [Tape.tape_mediums] SET lock_id = NULL, usn = @usn WHERE lock_id = @lock_id
	UPDATE [Tape.media_families] SET lock_id = NULL WHERE lock_id = @lock_id

	COMMIT TRANSACTION;
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_session
PRINT N'Creating [dbo].[Tape.delete_session]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_session]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_session]
GO
CREATE PROCEDURE [dbo].[Tape.delete_session]
	@id uniqueidentifier	
AS
BEGIN
	SET NOCOUNT ON;
	
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_media_pool
PRINT N'Creating [dbo].[Tape.delete_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_media_pool]
GO
CREATE PROCEDURE [dbo].[Tape.delete_media_pool]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRANSACTION;


	DECLARE @imported_media_pool_id uniqueidentifier

	SELECT @imported_media_pool_id = id 
	FROM [Tape.media_pools] 
	WHERE type = 2
	
	UPDATE [Tape.tape_mediums] 
	SET media_pool_id = @imported_media_pool_id 
	WHERE media_pool_id = @id

	DELETE FROM [Tape.media_pools] 
	WHERE id = @id

	DECLARE @usn bigint
	EXEC [dbo].[IncrementUsn] @usn OUTPUT
	EXEC [dbo].[InsertTombStone] 'Tape.media_pools', @id, @usn

	COMMIT TRANSACTION;
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_library_devices
PRINT N'Creating [dbo].[Tape.delete_library_devices]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_library_devices]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_library_devices]
GO
CREATE PROCEDURE [dbo].[Tape.delete_library_devices]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.library_devices] WHERE library_id = @library_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_changers_by_library_id
PRINT N'Creating [dbo].[Tape.get_all_changers_by_library_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_changers_by_library_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_changers_by_library_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_changers_by_library_id]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		[Tape.changers].* 
	FROM 
		[Tape.changers] 
		INNER JOIN [Tape.library_devices] ON [Tape.changers].device_id = [Tape.library_devices].device_id
	WHERE
		[Tape.library_devices].library_id = @library_id
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_backup
PRINT N'Creating [dbo].[Tape.delete_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_backup]
GO
CREATE PROCEDURE [dbo].[Tape.delete_backup]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.backups] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.cleanup_orphan_locks
PRINT N'Creating [dbo].[Tape.cleanup_orphan_locks]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.cleanup_orphan_locks]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.cleanup_orphan_locks]
GO
CREATE PROCEDURE [dbo].[Tape.cleanup_orphan_locks]
AS
    BEGIN
        SET NOCOUNT ON;
		SET XACT_ABORT ON;
				IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	--insert job session ids
                    SELECT  id
                    INTO    #session_ids
                    FROM    [Backup.Model.JobSessions]
                    WHERE   state <> -1
                            AND [Backup.Model.JobSessions].job_type IN (18, 24,
                                                              25, 26, 27, 28,
                                                              29, 32, 33, 34,
                                                              35, 36, 37 );
	--insert task session ids
                    INSERT  INTO #session_ids
                            SELECT  id
                            FROM    [Backup.Model.BackupTaskSessions]
                            WHERE   session_id IN ( SELECT  id
                                                    FROM    #session_ids );
					
					
					IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL READ COMMITTED ; 
			END;

                    CREATE CLUSTERED INDEX PK_id ON #session_ids (id);
	
                    DECLARE @usn BIGINT;
                    EXEC [dbo].[IncrementUsn] @usn OUTPUT;


					BEGIN TRANSACTION

                    UPDATE  [Tape.devices]
                    SET     lock_id = NULL
                    WHERE   lock_id IS NOT NULL
                            AND lock_id NOT IN ( SELECT id
                                                 FROM   #session_ids );
                    UPDATE  [Tape.media_pools]
                    SET     lock_id = NULL
                    WHERE   lock_id IS NOT NULL
                            AND lock_id NOT IN ( SELECT id
                                                 FROM   #session_ids );
                    UPDATE  [Tape.tape_mediums]
                    SET     lock_id = NULL ,
                            usn = @usn
                    WHERE   lock_id IS NOT NULL
                            AND lock_id NOT IN ( SELECT id
                                                 FROM   #session_ids );
                    UPDATE  [Tape.media_families]
                    SET     lock_id = NULL
                    WHERE   lock_id IS NOT NULL
                            AND lock_id NOT IN ( SELECT id
                                                 FROM   #session_ids );

					COMMIT TRANSACTION

    END;
GO


--------------------------------------------------------------------------------
-- Tape.empty_media_pool
PRINT N'Creating [dbo].[Tape.empty_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.empty_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.empty_media_pool]
GO
	

--------------------------------------------------------------------------------
-- Tape.add_session
PRINT N'Creating [dbo].[Tape.add_session]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_session]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_session]
GO
CREATE PROCEDURE [dbo].[Tape.add_session]
	@job_id uniqueidentifier
	,@job_name nvarchar(MAX)
	,@job_type int
	,@creation_time datetime
	,@end_time datetime
	,@result int
	,@state int
	,@control int
	,@is_full bit
	,@is_active_full bit
	,@transport_type int
	,@job_spec xml
	,@run_manually bit
	,@initiator_sid nvarchar(255)
	,@initiator_name nvarchar(255)
	,@session_algorithm int
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	
	BEGIN TRANSACTION;
	
	DECLARE @id AS UNIQUEIDENTIFIER
	SET @id = NEWID()

	INSERT INTO [Backup.Model.JobSessions] (
		id
		,job_id
		,job_name
		,job_type
		,creation_time
		,end_time
		,result
		,[state]
		,[control]
		,[operation]
		,[job_spec]
		,run_manually
		,[initiator_sid]
		,[initiator_name]
		)
	VALUES (
		@id
		,@job_id
		,@job_name
		,@job_type
		,@creation_time
		,@end_time
		,@result
		,@state
		,@control
		,''
		,@job_spec
		,@run_manually
		,@initiator_sid
		,@initiator_name
		)

	INSERT INTO [Backup.Model.BackupJobSessions] (
		id
		,is_full
		,is_active_full
		,transport_type
		,session_algorithm)
	VALUES (
		@id
		,@is_full
		,@is_active_full
		,@transport_type
		,@session_algorithm)
		
		COMMIT TRANSACTION;

	SELECT @id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_media_pool
PRINT N'Creating [dbo].[Tape.add_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_media_pool]
GO
CREATE PROCEDURE [dbo].[Tape.add_media_pool]
	@name nvarchar(MAX)
	,@description  nvarchar(MAX)
	,@type tinyint
	,@options xml
	,@crypto_key_id uniqueidentifier,
	@vault_id uniqueidentifier	
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @id AS UNIQUEIDENTIFIER
	
	SET @id = NEWID()

	INSERT INTO [Tape.media_pools] (
		id
		,name
		,[description]
		,[type]
		,options
		,crypto_key_id
		,vault_id
	) VALUES (
		@id
		,@name
		,@description
		,@type
		,@options
		,@crypto_key_id
		,@vault_id
	)
		
	SELECT @id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_library_device
PRINT N'Creating [dbo].[Tape.add_library_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_library_device]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_library_device]
GO
CREATE PROCEDURE [dbo].[Tape.add_library_device]
	@library_id uniqueidentifier
	,@device_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [Tape.library_devices] (
		library_id
		,device_id)
	VALUES (
		@library_id
		,@device_id
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.add_backup
PRINT N'Creating [dbo].[Tape.add_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_backup]
GO
CREATE PROCEDURE [dbo].[Tape.add_backup]
	@job_id uniqueidentifier
	,@name nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @id AS UNIQUEIDENTIFIER
	SET @id = NEWID()
	
	INSERT INTO [Tape.backups] (
		id
		,job_id
		,name
		)
	VALUES (
		@id
		,@job_id
		,@name
		)
		
	SELECT @id
END
GO


--------------------------------------------------------------------------------
-- Tape.lock_tape_drive_device
PRINT N'Creating [dbo].[Tape.lock_tape_drive_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.lock_tape_drive_device]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.lock_tape_drive_device]
GO
CREATE PROCEDURE [dbo].[Tape.lock_tape_drive_device]
	@device_ids xml
	,@lock_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	
	BEGIN TRANSACTION;

	DECLARE @temp_lock_id uniqueidentifier
	SET @temp_lock_id = NEWID()
	DECLARE @result uniqueidentifier
	DECLARE @hdocument int
	EXEC sp_xml_preparedocument @hdocument OUTPUT, @device_ids
	DECLARE @tmp TABLE(num int PRIMARY KEY IDENTITY, id uniqueidentifier)
	INSERT INTO @tmp SELECT * FROM OPENXML(@hdocument, N'/ROOT/id', 1)  WITH (id uniqueidentifier)
	UPDATE 
		[Tape.devices] 
	SET 
		lock_id = @temp_lock_id
	WHERE 
		id = 
			(
				SELECT TOP 1	
					t.id
				FROM 
					@tmp t
					INNER JOIN [Tape.devices] WITH (TABLOCKX) ON t.id = [Tape.devices].id 
					INNER JOIN [Tape.tape_drives] ON [Tape.tape_drives].device_id = [Tape.devices].id 
					
				WHERE
					[Tape.devices].lock_id IS NULL AND
					[Tape.tape_drives].[enabled] = 1
			)
	SELECT @result = id FROM [Tape.devices] WHERE lock_id = @temp_lock_id
	UPDATE [Tape.devices] SET lock_id = @lock_id WHERE lock_id = @temp_lock_id

	COMMIT TRANSACTION;
	SELECT @result
END
GO


--------------------------------------------------------------------------------
-- Tape.lock_media_pool
PRINT N'Creating [dbo].[Tape.lock_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.lock_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.lock_media_pool]
GO
CREATE PROCEDURE [dbo].[Tape.lock_media_pool]
	@media_pool_id uniqueidentifier, 
	@lock_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.media_pools] SET lock_id = @lock_id WHERE id = @media_pool_id AND lock_id IS NULL
	
	SELECT @@ROWCOUNT
END
GO




--------------------------------------------------------------------------------
-- Tape.get_media_pool
PRINT N'Creating [dbo].[Tape.get_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_media_pool]
GO
CREATE PROCEDURE [dbo].[Tape.get_media_pool]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.media_pools] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_locking_sessions
PRINT N'Creating [dbo].[Tape.get_locking_sessions]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_locking_sessions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_locking_sessions]
GO
CREATE PROCEDURE [dbo].[Tape.get_locking_sessions]
AS
BEGIN
    SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
    SELECT  lock_id
    INTO    #lock_ids
    FROM    [Tape.devices]
    UNION
    SELECT  lock_id
    FROM    [Tape.media_pools]
    UNION
    SELECT  lock_id
    FROM    [Tape.tape_mediums]
    UNION
    SELECT  lock_id
    FROM    [Tape.media_families];
	
    CREATE CLUSTERED INDEX PK_lock_id ON #lock_ids (lock_id);

    SELECT  s.* ,
            bs.*
    FROM    [Backup.Model.BackupJobSessions] AS s
            INNER JOIN [Backup.Model.JobSessions] AS bs ON s.id = bs.id
            LEFT OUTER JOIN [Backup.Model.BackupTaskSessions] AS ts ON ts.session_id = bs.id
    WHERE   s.id IN ( SELECT    *
                      FROM      #lock_ids )
    UNION ALL
    SELECT  s.* ,
            bs.*
    FROM    [Backup.Model.BackupJobSessions] AS s
            INNER JOIN [Backup.Model.JobSessions] AS bs ON s.id = bs.id
            LEFT OUTER JOIN [Backup.Model.BackupTaskSessions] AS ts ON ts.session_id = bs.id
    WHERE   ts.id IN ( SELECT   *
                       FROM     #lock_ids );
	 
END
GO


--------------------------------------------------------------------------------
-- Tape.get_library_devices
PRINT N'Creating [dbo].[Tape.get_library_devices]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_library_devices]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_library_devices]
GO
CREATE PROCEDURE [dbo].[Tape.get_library_devices]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.library_devices] WHERE library_id = @library_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_library_device_by_device_id
PRINT N'Creating [dbo].[Tape.get_library_device_by_device_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_library_device_by_device_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_library_device_by_device_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_library_device_by_device_id]
	@device_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.library_devices] WHERE device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- Tape.report_backups_changes
PRINT N'Creating [dbo].[Tape.report_backups_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_backups_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_backups_changes]
GO
CREATE VIEW dbo.[Tape.report_backups_changes]
AS
SELECT     id, job_id, name, usn
FROM         dbo.[Tape.backups]
GO


--------------------------------------------------------------------------------
-- Tape.report_sessions_changes
PRINT N'Creating [dbo].[Tape.report_sessions_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_sessions_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_sessions_changes]
GO
CREATE VIEW dbo.[Tape.report_sessions_changes]
AS
SELECT        s.id, (CASE WHEN s.[usn] > bs.[usn] THEN s.[usn] ELSE bs.[usn] END) AS usn, bs.job_name, bs.job_type, bs.state, bs.creation_time AS start_time, bs.end_time, 
                         bs.result, bs.progress, s.total_objects, s.processed_objects, s.total_size, s.processed_size, s.is_full, s.is_active_full, s.transport_type
FROM            dbo.[Backup.Model.BackupJobSessions] AS s INNER JOIN
                         dbo.[Backup.Model.JobSessions] AS bs ON s.id = bs.id
GO


--------------------------------------------------------------------------------
-- Tape.report_media_pools_changes
PRINT N'Creating [dbo].[Tape.report_media_pools_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_pools_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_media_pools_changes]
GO
CREATE VIEW dbo.[Tape.report_media_pools_changes]
AS
SELECT     m.id, (CASE WHEN ISNULL(m.usn, 0) > ISNULL(MAX(tu.usn), 0) THEN ISNULL(m.usn, 0) ELSE ISNULL(MAX(tu.usn), 0) END) AS usn, m.name, m.type, SUM(t.capacity) 
                      AS capacity, SUM(t.remaining) AS remaining, COUNT(t.id) AS tapes
FROM         
	dbo.[Tape.media_pools] AS m 
	LEFT OUTER JOIN dbo.[Tape.tape_mediums] AS t ON m.id = t.media_pool_id 
	CROSS JOIN (SELECT MAX(usn) AS usn FROM dbo.[Tape.tape_mediums]) AS tu
WHERE ISNULL(t.cleaner, 0) = 0
GROUP BY m.id, m.usn, m.name, m.type
GO


--------------------------------------------------------------------------------
-- Tape.report_tape_drives_changes
PRINT N'Creating [dbo].[Tape.report_tape_drives_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_tape_drives_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_tape_drives_changes]
GO
CREATE VIEW [dbo].[Tape.report_tape_drives_changes]
AS
SELECT        td.device_id AS id, ld1.library_id, [dbo].MaxValue2(td.usn,tm.usn) [usn], td.enabled, d1.state, td.name, tm.barcode AS media_barcode, tm.id AS media_id, tm.name AS media_name, ld2.device_id, 
                         CASE WHEN c.first_drive_number IS NULL THEN 'Drive 1 (Drive ID: ' + d1.name + ')' ELSE 'Drive ' + CAST(td.address + 1 AS NVARCHAR) 
                         + ' (Drive ID: ' + d1.name + ')' END AS device, dbo.[Tape.media_families].name AS media_set_name
FROM            dbo.[Tape.media_families] RIGHT OUTER JOIN
                         dbo.[Tape.tape_mediums] AS tm ON dbo.[Tape.media_families].id = tm.media_family_id RIGHT OUTER JOIN
                         dbo.[Tape.devices] AS d2 INNER JOIN
                         dbo.[Tape.library_devices] AS ld2 ON d2.id = ld2.device_id INNER JOIN
                         dbo.[Tape.changers] AS c ON d2.id = c.device_id RIGHT OUTER JOIN
                         dbo.[Tape.tape_drives] AS td INNER JOIN
                         dbo.[Tape.library_devices] AS ld1 ON td.device_id = ld1.device_id INNER JOIN
                         dbo.[Tape.devices] AS d1 ON td.device_id = d1.id AND ld1.device_id = d1.id ON d2.type = 8 AND ld2.library_id = ld1.library_id ON tm.location_type = 0 AND 
                         tm.location_address = td.address AND tm.location_library_id = ld1.library_id
GO


--------------------------------------------------------------------------------
-- Tape.report_tape_drive_changes
PRINT N'Creating [dbo].[Tape.report_tape_drive_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_tape_drive_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_tape_drive_changes]
GO
CREATE VIEW [dbo].[Tape.report_tape_drive_changes]
AS
SELECT        dbo.[Tape.tape_mediums].id, dbo.[Tape.tape_mediums].usn, dbo.[Tape.tape_mediums].name, dbo.[Tape.tape_mediums].barcode, dbo.[Tape.tape_drives].device_id, 
                         dbo.[Tape.media_families].name AS media_set_name
FROM            dbo.[Tape.tape_mediums] INNER JOIN
                         dbo.[Tape.library_devices] ON dbo.[Tape.tape_mediums].location_library_id = dbo.[Tape.library_devices].library_id INNER JOIN
                         dbo.[Tape.tape_drives] ON dbo.[Tape.library_devices].device_id = dbo.[Tape.tape_drives].device_id AND 
                         (dbo.[Tape.tape_mediums].location_address = dbo.[Tape.tape_drives].address OR
                         dbo.[Tape.tape_drives].address IS NULL) LEFT OUTER JOIN
                         dbo.[Tape.media_families] ON dbo.[Tape.tape_mediums].media_family_id = dbo.[Tape.media_families].id
WHERE        (dbo.[Tape.tape_mediums].location_type = 0)
GO


--------------------------------------------------------------------------------
-- Tape.report_jobs_changes
PRINT N'Creating [dbo].[Tape.report_jobs_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_jobs_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_jobs_changes]
GO
CREATE VIEW dbo.[Tape.report_jobs_changes]
AS
SELECT     j.id, (CASE WHEN ISNULL(bs.usn, j.usn) > j.usn THEN ISNULL(bs.usn, j.usn) ELSE j.usn END) AS usn, j.name, ISNULL(bs.state, -1) AS state, 
                      ISNULL(bs.result, -1) AS result, j.type, j.schedule_enabled
FROM         dbo.[Tape.jobs] AS j 
					LEFT OUTER JOIN [Backup.Model.JobSessions] AS bs ON j.id = bs.job_id
WHERE     (bs.id IS NULL OR
                      bs.id =
                          (SELECT     TOP (1) id
                            FROM          dbo.[Backup.Model.JobSessions]
                            WHERE      (job_id = j.id)
                            ORDER BY creation_time DESC)) AND (j.type IN (24, 25, 26, 27, 28, 29, 32, 33, 34, 35, 36, 37))
GO


--------------------------------------------------------------------------------
-- Tape.get_session
PRINT N'Creating [dbo].[Tape.get_session]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_session]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_session]
GO
CREATE PROCEDURE [dbo].[Tape.get_session]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Backup.Model.BackupJobSessions] AS s
	INNER JOIN [Backup.Model.JobSessions] AS bs
	ON s.id = bs.id
	WHERE s.id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_devices_by_library_id
PRINT N'Creating [dbo].[Tape.get_devices_by_library_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_devices_by_library_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_devices_by_library_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_devices_by_library_id]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		[Tape.devices].* 
	FROM 
		[Tape.devices] 
		INNER JOIN [Tape.library_devices] ON [Tape.devices].id = [Tape.library_devices].device_id
	WHERE 
		[Tape.library_devices].library_id = @library_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_session_by_job
PRINT N'Creating [dbo].[Tape.get_last_session_by_job]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_session_by_job]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_session_by_job]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_session_by_job]
	@job_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT TOP 1 *  
	FROM [Backup.Model.BackupJobSessions] AS s
	INNER JOIN [Backup.Model.JobSessions] AS bs ON bs.id = s.id 
	WHERE bs.job_id = @job_id 
	ORDER BY bs.creation_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_sessions
PRINT N'Creating [dbo].[Tape.get_all_sessions]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_sessions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_sessions]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_sessions]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Backup.Model.BackupJobSessions] AS s
	INNER JOIN [Backup.Model.JobSessions] AS bs
	ON s.id = bs.id
	WHERE bs.job_type in (24, 25, 26, 27, 28, 29, 32, 33, 34, 35, 36, 37)
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_media_pools_by_type
PRINT N'Creating [dbo].[Tape.get_all_media_pools_by_type]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_media_pools_by_type]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_media_pools_by_type]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_media_pools_by_type]
	@type tinyint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.media_pools] WHERE [type] = @type
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_media_pools_by_type_and_library_id
PRINT N'Creating [dbo].[Tape.get_all_media_pools_by_type_and_library_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_media_pools_by_type_and_library_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_media_pools_by_type_and_library_id]
GO
	

--------------------------------------------------------------------------------
-- Tape.get_all_media_pools
PRINT N'Creating [dbo].[Tape.get_all_media_pools]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_media_pools]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_media_pools]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_media_pools]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT 
		m.crypto_key_id, 
		m.description, 
		m.id, 
		m.lock_id, 
		m.name, 
		m.options, 
		m.type, 
		m.usn,
		m.vault_id 
	FROM 
		[Tape.media_pools] m 
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_library_devices
PRINT N'Creating [dbo].[Tape.get_all_library_devices]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_library_devices]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_library_devices]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_library_devices]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.library_devices]
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_tape_drives_by_library_id
PRINT N'Creating [dbo].[Tape.get_all_tape_drives_by_library_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_tape_drives_by_library_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_tape_drives_by_library_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_tape_drives_by_library_id]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		[Tape.tape_drives].* 
	FROM 
		[Tape.tape_drives] 
		INNER JOIN [Tape.library_devices] ON [Tape.tape_drives].device_id = [Tape.library_devices].device_id
	WHERE
		[Tape.library_devices].library_id = @library_id
	ORDER BY
		[address] ASC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_by_job_id
PRINT N'Creating [dbo].[Tape.get_backup_by_job_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_by_job_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_by_job_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_by_job_id]
	@job_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.backups] WHERE job_id = @job_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_all
PRINT N'Creating [dbo].[Tape.get_backup_all]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_all]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_all]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_all]
	
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.backups]
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup
PRINT N'Creating [dbo].[Tape.get_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.backups] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_sets_by_backup_id
PRINT N'Creating [dbo].[Tape.get_backup_sets_by_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_sets_by_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_sets_by_backup_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_sets_by_backup_id]
	@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		id, media_family_id, number, name, write_time, usn, backup_id, physical_block_address, pending, crypto_key_id, encrypted, expiration_date, encryption_type, catalog_session, backup_session_id 
	FROM 
		[Tape.backup_sets] 
	WHERE 
		backup_id = @backup_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_set
PRINT N'Creating [dbo].[Tape.get_backup_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_set]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_set]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		id, media_family_id, number, name, write_time, usn, backup_id, physical_block_address, pending, crypto_key_id, encrypted, expiration_date, encryption_type, catalog_session, backup_session_id
	FROM 
		[Tape.backup_sets] 
	WHERE 
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_sets_by_media_family_id
PRINT N'Creating [dbo].[Tape.get_backup_sets_by_media_family_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_sets_by_media_family_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_sets_by_media_family_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_sets_by_media_family_id]
	@media_family_id int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		id, media_family_id, number, name, write_time, usn, backup_id, physical_block_address, pending, crypto_key_id, encrypted, expiration_date, encryption_type, catalog_session, backup_session_id 
	FROM 
		[Tape.backup_sets] 
	WHERE 
		media_family_id = @media_family_id 
	ORDER BY 
		number
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tapes_by_backup_id
PRINT N'Creating [dbo].[Tape.get_tapes_by_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tapes_by_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tapes_by_backup_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tapes_by_backup_id]
	@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * 
	FROM [Tape.tape_mediums] 
	WHERE media_family_id in (SELECT [media_family_id] FROM [Tape.backup_sets] WHERE backup_id = @backup_id) 
	ORDER BY media_time
END
GO


--------------------------------------------------------------------------------
-- Tape.report_media_pool_changes
PRINT N'Creating [dbo].[Tape.report_media_pool_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_pool_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_media_pool_changes]
GO
CREATE VIEW dbo.[Tape.report_media_pool_changes]
AS
SELECT        dbo.[Tape.tape_mediums].id, dbo.[Tape.tape_mediums].usn, dbo.[Tape.tape_mediums].barcode AS name, dbo.[Tape.media_pools].id AS media_pool_id, 
                         dbo.[Tape.library_names].name AS library, dbo.[Tape.tape_mediums].name AS media_set
FROM            dbo.[Tape.tape_mediums] LEFT OUTER JOIN
                         dbo.[Tape.library_names] ON dbo.[Tape.tape_mediums].location_library_id = dbo.[Tape.library_names].id LEFT OUTER JOIN
                         dbo.[Tape.media_pools] ON dbo.[Tape.tape_mediums].media_pool_id = dbo.[Tape.media_pools].id
WHERE dbo.[Tape.tape_mediums].cleaner = 0
GO


--------------------------------------------------------------------------------
-- Tape.report_media_changes
PRINT N'Creating [dbo].[Tape.report_media_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_media_changes]
GO
CREATE VIEW [dbo].[Tape.report_media_changes]
AS
	
    WITH  expiration_date
              AS ( SELECT   MAX(bs.expiration_date) AS expiration_date ,
                            tm.id AS id
                   FROM     dbo.[Tape.media_pools] mp
                            RIGHT OUTER JOIN dbo.[Tape.tape_mediums] tm ON mp.id = tm.media_pool_id
                            LEFT OUTER JOIN [Tape.tape_medium_backup_sets] tmbs ON tmbs.tape_medium_id = tm.id
                            LEFT OUTER JOIN [Tape.backup_sets] bs ON bs.id = tmbs.backup_set_id
                   WHERE    tm.media_pool_id <> '00000000-0000-0000-0000-000000000000'
                            AND tm.cleaner = 0
                   GROUP BY tm.id
                 )
    SELECT  tm.id ,
            dbo.MaxValue4(tm.usn, mv.usn, miv.usn,
                          ( SELECT  MAX([Tape.backup_sets].usn)
                            FROM    [Tape.backup_sets]
                                    INNER JOIN [Tape.tape_medium_backup_sets] ON [Tape.backup_sets].id = [Tape.tape_medium_backup_sets].backup_set_id
                            WHERE   [Tape.tape_medium_backup_sets].tape_medium_id = tm.id
                          )) AS usn ,
            tm.name ,
            tm.barcode ,
            ln.name AS library ,
            mp.name AS media_pool ,
            tm.media_pool_id ,
            ISNULL(tm.media_family_id, -1) AS media_family_id ,
            tm.location_library_id ,
            tm.location_type ,
            tm.location_address + 1 AS location_number ,
            tm.capacity ,
            tm.remaining ,
            tm.retention_reason ,
            tm.description ,
            tm.lock_id ,
            mf.name AS media_set_name ,
            tm.media_sequence_number ,
            mv.name AS vault_name ,
            mv.id AS vault_id ,
            tm.media_time ,
            ISNULL(( SELECT MAX(dbo.IsBackupSetEncrypted(encrypted,
                                                         crypto_key_id))
                     FROM   [Tape.backup_sets]
                            INNER JOIN [Tape.tape_medium_backup_sets] ON [Tape.backup_sets].id = [Tape.tape_medium_backup_sets].backup_set_id
                     WHERE  [Tape.tape_medium_backup_sets].tape_medium_id = tm.id
                   ), 0) AS encrypted ,
            tm.protected ,
            MAX(ex.expiration_date) AS expiration_date ,
            tm.is_write_protected ,
            tm.retired ,
            dev.state AS device_state ,
            COUNT(ch.device_id) AS changers_count ,
            MAX(ch.ieport_count) AS ieport_count ,
            mp.type AS mp_type ,
            [dbo].[Tape.IsMediaUsedByBackup](tm.id) AS used_by_backup
    FROM    dbo.[Tape.media_pools] mp
            RIGHT OUTER JOIN dbo.[Tape.tape_mediums] tm
            LEFT OUTER JOIN dbo.[Tape.media_families] mf ON tm.media_family_id = mf.id ON mp.id = tm.media_pool_id
            LEFT OUTER JOIN dbo.[Tape.library_names] ln ON tm.location_library_id = ln.id
            LEFT OUTER JOIN [Tape.media_in_vaults] miv ON miv.media_id = tm.id
            LEFT OUTER JOIN [Tape.media_vaults] mv ON miv.vault_id = mv.id
            LEFT OUTER JOIN dbo.[Tape.libraries] AS lib ON lib.id = tm.location_library_id
            LEFT OUTER JOIN dbo.[Tape.library_devices] AS ld ON ld.library_id = lib.id
            LEFT OUTER JOIN dbo.[Tape.changers] AS ch ON ld.device_id = ch.device_id
            LEFT OUTER JOIN dbo.[Tape.devices] AS dev ON ld.device_id = dev.id
            LEFT OUTER JOIN expiration_date ex ON ex.id = tm.id
    WHERE   tm.media_pool_id <> '00000000-0000-0000-0000-000000000000'
            AND tm.cleaner = 0
    GROUP BY tm.id ,
            tm.usn ,
            tm.name ,
            tm.barcode ,
            ln.name ,
            mp.name ,
            tm.media_pool_id ,
            tm.media_family_id ,
            tm.location_library_id ,
            tm.location_type ,
            tm.location_address ,
            tm.capacity ,
            tm.remaining ,
            tm.retention_reason ,
            tm.description ,
            tm.lock_id ,
            mf.name ,
            tm.media_sequence_number ,
            mv.name ,
            tm.media_time ,
            tm.protected ,
            tm.is_write_protected ,
            mv.id ,
            mv.usn ,
            miv.usn ,
            tm.retired ,
            dev.state ,
            mp.type;

GO


--------------------------------------------------------------------------------
-- Tape.report_libraries_changes
PRINT N'Creating [dbo].[Tape.report_libraries_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_libraries_changes]') AND type in (N'V'))
	DROP VIEW [dbo].[Tape.report_libraries_changes]
GO
CREATE VIEW [dbo].[Tape.report_libraries_changes]
AS
SELECT      [Tape.libraries].id, 
			[Tape.library_names].name name, 
			[Tape.libraries].usn, 
			[Tape.libraries].type, 
			NULL AS device_id, 
            [Tape.libraries].enabled,
            [Tape.devices].[state],
            [Tape.libraries].tape_server_id,
			NULL device_name,
			[BackupProxies].name AS tape_server_name,
			[Tape.changers].is_driver_installed,
			[Tape.changers].use_scsi,
			(SELECT COUNT(d.device_id) FROM [Tape.libraries] lb
			  LEFT JOIN [Tape.library_devices] ON [Tape.library_devices].library_id = lb.id 
			  LEFT JOIN [Tape.tape_drives] d ON d.device_id = [Tape.library_devices].device_id WHERE lb.id = [Tape.libraries].id GROUP BY lb.id) AS drives_count,
			[Tape.changers].slot_count,
			COUNT([Tape.tape_mediums].id) AS mediums_count
FROM            [Tape.libraries] INNER JOIN
                         [Tape.library_names] ON [Tape.libraries].id = [Tape.library_names].id INNER JOIN
                         [Tape.library_devices] ON [Tape.libraries].id = [Tape.library_devices].library_id INNER JOIN
                         [Tape.changers] ON [Tape.library_devices].device_id = [Tape.changers].device_id INNER JOIN
                         [Tape.devices] ON [Tape.library_devices].device_id = [Tape.devices].id LEFT JOIN
						 [BackupProxies] ON [BackupProxies].id = [Tape.libraries].tape_server_id LEFT JOIN
						 [Tape.tape_mediums] ON [Tape.tape_mediums].location_library_id = [Tape.libraries].id
WHERE        [Tape.libraries].type = 0
GROUP BY [Tape.libraries].id, 
			[Tape.library_names].name,
			[Tape.libraries].usn, 
			[Tape.libraries].type, 
            [Tape.libraries].enabled,
            [Tape.devices].[state],
            [Tape.libraries].tape_server_id,
			[BackupProxies].name,
			[Tape.changers].is_driver_installed,
			[Tape.changers].use_scsi,
			[Tape.changers].slot_count
UNION
SELECT      [Tape.libraries].id, 
			[Tape.library_names].name, 
			[Tape.libraries].usn, 
			[Tape.libraries].type, 
			[Tape.tape_drives].device_id, 
			[Tape.libraries].enabled, 
			[Tape.devices].[state],
            [Tape.libraries].tape_server_id,
			[Tape.devices].name,
			[BackupProxies].name AS tape_server_name,
			0,
			0,
			1,
			0,
			0
FROM            [Tape.libraries] INNER JOIN
                         [Tape.library_names] ON [Tape.libraries].id = [Tape.library_names].id INNER JOIN
                         [Tape.library_devices] ON [Tape.libraries].id = [Tape.library_devices].library_id INNER JOIN
                         [Tape.tape_drives] ON [Tape.library_devices].device_id = [Tape.tape_drives].device_id INNER JOIN
                         [Tape.devices] ON [Tape.library_devices].device_id = [Tape.devices].id LEFT JOIN
						 [BackupProxies] ON [BackupProxies].id = [Tape.libraries].tape_server_id
WHERE        [Tape.libraries].type = 1
GROUP BY [Tape.libraries].id, 
			[Tape.library_names].name,
			[Tape.devices].name,
			[Tape.libraries].usn, 
			[Tape.libraries].type, 
            [Tape.libraries].enabled,
            [Tape.devices].[state],
            [Tape.libraries].tape_server_id,
			[BackupProxies].name,
			[Tape.tape_drives].device_id 
GO


--------------------------------------------------------------------------------
-- Tape.add_backup_set
PRINT N'Creating [dbo].[Tape.add_backup_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.add_backup_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.add_backup_set]
GO
CREATE PROCEDURE [dbo].[Tape.add_backup_set]
	@media_family_id int
	,@number int
	,@write_time datetime
	,@name nvarchar(MAX)
	,@backup_id uniqueidentifier
	,@physical_block_address bigint
	,@pending bit
	,@crypto_key_id uniqueidentifier
	,@encrypted bit
	,@encryption_type tinyint
	,@expiration_date datetime
	,@backup_session_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @id AS UNIQUEIDENTIFIER
	SET @id = NEWID()
	DECLARE @usn bigint
	EXEC [dbo].[IncrementUsn] @usn OUTPUT
	INSERT INTO [Tape.backup_sets] (
		id
		,media_family_id
		,number
		,write_time
		,name
		,backup_id
		,physical_block_address
		,pending
		,crypto_key_id
		,encrypted
		,encryption_type
		,expiration_date
		,usn
		,backup_session_id
	)
	VALUES (
		@id
		,@media_family_id
		,@number
		,@write_time
		,@name
		,@backup_id
		,@physical_block_address
		,@pending
		,@crypto_key_id
		,@encrypted
		,@encryption_type
		,@expiration_date
		,@usn
		,@backup_session_id
	)
	SELECT @id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_backup_set
PRINT N'Creating [dbo].[Tape.update_backup_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.update_backup_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.update_backup_set]
GO
CREATE PROCEDURE [dbo].[Tape.update_backup_set]
	@id uniqueidentifier
	,@media_family_id int
	,@number int
	,@write_time datetime
	,@name nvarchar(MAX)
	,@backup_id uniqueidentifier
	,@physical_block_address bigint
	,@pending bit
	,@crypto_key_id uniqueidentifier
	,@encrypted bit
	,@encryption_type tinyint
	,@catalog_session [varbinary](max)
	,@expiration_date datetime
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @usn bigint
	EXEC [dbo].[IncrementUsn] @usn OUTPUT
	UPDATE 
		[Tape.backup_sets] 
	SET
		media_family_id = @media_family_id
		,number = @number
		,write_time = @write_time
		,name = @name
		,backup_id = @backup_id
		,physical_block_address = @physical_block_address
		,pending = @pending
		,crypto_key_id = @crypto_key_id
		,encrypted = @encrypted
		,encryption_type = @encryption_type
		,catalog_session = @catalog_session
		,expiration_date = @expiration_date
		,usn = @usn
	WHERE
		id = @id	
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_files_by_directory_id_and_backup_set_id
PRINT N'Creating [dbo].[Tape.get_all_files_by_directory_id_and_backup_set_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_files_by_directory_id_and_backup_set_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_files_by_directory_id_and_backup_set_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_files_by_directory_id_and_backup_set_id]
	@directory_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT
		[Tape.files].* 
	FROM 
		[Tape.files] 
		INNER JOIN [Tape.file_versions] ON [Tape.files].id = [Tape.file_versions].[file_id] 
	WHERE 
		ISNULL([Tape.files].directory_id, 0) = COALESCE(@directory_id, [Tape.files].directory_id, 0) AND
		[Tape.file_versions].backup_set_id = @backup_set_id
END
GO

--------------------------------------------------------------------------------
-- Tape.get_all_files_by_directory_id_and_backup_id
PRINT N'Creating [dbo].[Tape.get_all_files_by_directory_id_and_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_files_by_directory_id_and_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_files_by_directory_id_and_backup_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_files_by_directory_id_and_backup_id]
	@directory_id bigint
	,@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT
		[Tape.files].* 
	FROM 
		[Tape.files] 
		INNER JOIN [Tape.file_versions] ON [Tape.files].id = [Tape.file_versions].[file_id] 
		INNER JOIN [Tape.backup_sets] ON [Tape.file_versions].backup_set_id = [Tape.backup_sets].id
	WHERE 
		[Tape.files].directory_id = @directory_id AND
		[Tape.backup_sets].backup_id = @backup_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_files_by_backup_id
PRINT N'Creating [dbo].[Tape.get_all_files_by_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_files_by_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_files_by_backup_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_files_by_backup_id]
	@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT
		[Tape.files].* 
	FROM 
		[Tape.files] 
		INNER JOIN [Tape.file_versions] ON [Tape.files].id = [Tape.file_versions].[file_id] 
		INNER JOIN [Tape.backup_sets] ON [Tape.file_versions].backup_set_id = [Tape.backup_sets].id
	WHERE 
		[Tape.backup_sets].backup_id = @backup_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_directories_by_parent_id_and_tape_medium_id
PRINT N'Creating [dbo].[Tape.get_all_directories_by_parent_id_and_tape_medium_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_directories_by_parent_id_and_tape_medium_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id_and_tape_medium_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id_and_tape_medium_id]
	@parent_id bigint
	,@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT
		d.* 
	FROM 
		[Tape.directories] d
		INNER JOIN [Tape.directory_versions] dv ON d.id = dv.directory_id
		INNER JOIN [Tape.backup_sets] bs ON dv.backup_set_id = bs.id
		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND dv.media_sequence_number = tm.media_sequence_number
	WHERE 
		d.parent_id = @parent_id AND
		tm.id = @tape_medium_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_directories_by_parent_id_and_backup_set_id
PRINT N'Creating [dbo].[Tape.get_all_directories_by_parent_id_and_backup_set_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_directories_by_parent_id_and_backup_set_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id_and_backup_set_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id_and_backup_set_id]
	@parent_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT
		[Tape.directories].* 
	FROM 
		[Tape.directories] 
		INNER JOIN [Tape.directory_versions] ON [Tape.directories].id = [Tape.directory_versions].directory_id
	WHERE 
		[Tape.directories].parent_id = @parent_id AND
		[Tape.directory_versions].backup_set_id = @backup_set_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_directories_by_parent_id_and_backup_id
PRINT N'Creating [dbo].[Tape.get_all_directories_by_parent_id_and_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_directories_by_parent_id_and_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id_and_backup_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_directories_by_parent_id_and_backup_id]
	@parent_id bigint
	,@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT
		[Tape.directories].* 
	FROM 
		[Tape.directories] 
		INNER JOIN [Tape.directory_versions] ON [Tape.directories].id = [Tape.directory_versions].directory_id
		INNER JOIN [Tape.backup_sets] ON [Tape.directory_versions].backup_set_id = [Tape.backup_sets].id
	WHERE 
		[Tape.directories].parent_id = @parent_id AND
		[Tape.backup_sets].backup_id = @backup_id
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_file_version
PRINT N'Creating [dbo].[Tape.delete_file_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_file_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_file_version]
GO
CREATE PROCEDURE [dbo].[Tape.delete_file_version]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	DELETE FROM [Tape.file_versions] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_directory_version
PRINT N'Creating [dbo].[Tape.add_directory_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.add_directory_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.add_directory_version]
GO
CREATE PROCEDURE [dbo].[Tape.add_directory_version]
	@directory_id bigint
	,@backup_set_id uniqueidentifier
	,@creation_time datetime
	,@last_write_time datetime
	,@attributes int
	,@format_logical_address bigint
	,@media_sequence_number int
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [Tape.directory_versions] (
		directory_id
		,backup_set_id
		,creation_time
		,last_write_time
		,attributes
		,format_logical_address
		,media_sequence_number
	)
	VALUES (
		@directory_id
		,@backup_set_id
		,@creation_time
		,@last_write_time
		,@attributes
		,@format_logical_address
		,@media_sequence_number
	)

	SELECT * FROM [Tape.directory_versions] WHERE id = CAST(SCOPE_IDENTITY() AS BIGINT)
END
GO


--------------------------------------------------------------------------------
-- Tape.add_file_version
PRINT N'Creating [dbo].[Tape.add_file_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_file_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_file_version]
GO
CREATE PROCEDURE [dbo].[Tape.add_file_version]
	@file_id bigint
	,@backup_set_id uniqueidentifier
	,@creation_time datetime
	,@last_write_time datetime
	,@size bigint
	,@attributes int
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [Tape.file_versions] (
		[file_id]
		,backup_set_id
		,creation_time
		,last_write_time
		,size
		,attributes
	)
	VALUES (
		@file_id
		,@backup_set_id
		,@creation_time
		,@last_write_time
		,@size
		,@attributes
	)

	SELECT * FROM [Tape.file_versions] WHERE id = CAST(SCOPE_IDENTITY() AS BIGINT)
END
GO


--------------------------------------------------------------------------------
-- Tape.search_directories
PRINT N'Creating [dbo].[Tape.search_directories]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.search_directories]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.search_directories]
GO
CREATE PROCEDURE [dbo].[Tape.search_directories]
	@pattern nvarchar(800)
	,@parent_ids xml
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @hdocument int
	EXEC sp_xml_preparedocument @hdocument OUTPUT, @parent_ids

	DECLARE @ids_count int	
	SELECT @ids_count = COUNT(*) FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id bigint)
	
	IF @ids_count > 0
		SELECT DISTINCT [Tape.directories].id 
		FROM [Tape.directories]
		INNER JOIN [Tape.directory_versions] ON [Tape.directories].id = [Tape.directory_versions].directory_id 
		WHERE name LIKE @pattern ESCAPE '\' AND parent_id IN (SELECT id FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id bigint))
	ELSE
		SELECT DISTINCT [Tape.directories].id 
		FROM [Tape.directories]
		INNER JOIN [Tape.directory_versions] ON [Tape.directories].id = [Tape.directory_versions].directory_id 
		WHERE name LIKE @pattern ESCAPE '\'

	EXEC sp_xml_removedocument @hdocument
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directory_version
PRINT N'Creating [dbo].[Tape.get_directory_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory_version]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory_version]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.directory_versions] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directory_version_by_id_and_backup_set_id
PRINT N'Creating [dbo].[Tape.get_directory_version_by_id_and_backup_set_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory_version_by_id_and_backup_set_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory_version_by_id_and_backup_set_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory_version_by_id_and_backup_set_id]
	@directory_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.directory_versions] WHERE directory_id = @directory_id AND backup_set_id = @backup_set_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_nearest_file_version
PRINT N'Creating [dbo].[Tape.get_nearest_file_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_nearest_file_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_nearest_file_version]
GO
CREATE PROCEDURE [dbo].[Tape.get_nearest_file_version]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;

	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	DECLARE @file_id bigint
	DECLARE @backup_set_id uniqueidentifier

	SELECT @file_id = file_id, @backup_set_id = backup_set_id FROM [Tape.file_versions] WHERE id = @id
	
	SELECT TOP 1
		[Tape.file_versions].*
	FROM
		[Tape.file_versions]
	WHERE 
		[Tape.file_versions].[file_id] = @file_id AND
		[Tape.file_versions].backup_set_id IN (SELECT id FROM [Tape.backup_sets] WHERE write_time <= (SELECT write_time FROM [Tape.backup_sets] WHERE id = @backup_set_id))
	ORDER BY 
		[Tape.file_versions].last_write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_nearest_directory_version
PRINT N'Creating [dbo].[Tape.get_nearest_directory_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_nearest_directory_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_nearest_directory_version]
GO
CREATE PROCEDURE [dbo].[Tape.get_nearest_directory_version]
	@directory_id bigint,
	@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TOP 1
		[Tape.directory_versions].*
	FROM
		[Tape.directory_versions]
	WHERE 
		[Tape.directory_versions].directory_id = @directory_id AND
		[Tape.directory_versions].backup_set_id IN (SELECT id FROM [Tape.backup_sets] WHERE write_time <= (SELECT write_time FROM [Tape.backup_sets] WHERE id = @backup_set_id))
	ORDER BY 
		[Tape.directory_versions].last_write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_sets_by_file_id
PRINT N'Creating [dbo].[Tape.get_backup_sets_by_file_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_sets_by_file_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_sets_by_file_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_sets_by_file_id]
	@file_id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	
	SELECT 
		bs.id, bs.media_family_id, bs.number, bs.name, bs.write_time, bs.usn, bs.backup_id, bs.physical_block_address, bs.pending, bs.crypto_key_id, bs.encrypted, bs.expiration_date, bs.encryption_type, bs.catalog_session, bs.backup_session_id
	FROM 
		[Tape.backup_sets] bs INNER JOIN 
		[Tape.file_versions] ON bs.id = [Tape.file_versions].backup_set_id
	WHERE 
		[Tape.file_versions].[file_id] = @file_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_sets_by_directory_id
PRINT N'Creating [dbo].[Tape.get_backup_sets_by_directory_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_sets_by_directory_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_sets_by_directory_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_sets_by_directory_id]
	@directory_id bigint
AS
BEGIN
	SET NOCOUNT ON;
    
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
    
	WITH subdirectories(id) 
	AS 
	(
		SELECT id
		FROM [Tape.directories]
		WHERE id = @directory_id
		UNION ALL
		SELECT [Tape.directories].id FROM [Tape.directories] INNER JOIN subdirectories ON [Tape.directories].parent_id = subdirectories.id
	)
	
	SELECT DISTINCT 
		bs.id, bs.media_family_id, bs.number, bs.name, bs.write_time, bs.usn, bs.backup_id, bs.physical_block_address, bs.pending, bs.crypto_key_id, bs.encrypted, bs.expiration_date, bs.encryption_type, bs.catalog_session, bs.backup_session_id 
	FROM 
		subdirectories 
		INNER JOIN [Tape.directory_versions] ON subdirectories.id = [Tape.directory_versions].directory_id 
		INNER JOIN [Tape.backup_sets] bs ON [Tape.directory_versions].backup_set_id = bs.id
		OPTION (MAXRECURSION 32767)
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_file_version_by_backup
PRINT N'Creating [dbo].[Tape.get_last_file_version_by_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_file_version_by_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_file_version_by_backup]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_file_version_by_backup]
	@file_id bigint
	,@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	
	SELECT TOP 1 
		[Tape.file_versions].* 
	FROM 
		[Tape.file_versions] 
		INNER JOIN [Tape.backup_sets] ON [Tape.file_versions].backup_set_id = [Tape.backup_sets].id
	WHERE
		[Tape.file_versions].[file_id] = @file_id AND
		[Tape.backup_sets].backup_id = @backup_id
	ORDER BY
		[Tape.backup_sets].write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_file_version
PRINT N'Creating [dbo].[Tape.get_last_file_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_file_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_file_version]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_file_version]
	@file_id bigint
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	
	SELECT TOP 1 * 
	FROM 
		[Tape.file_versions] 
		INNER JOIN [Tape.backup_sets] ON [Tape.file_versions].backup_set_id = [Tape.backup_sets].id
	WHERE
		[Tape.file_versions].[file_id] = @file_id
	ORDER BY
		[Tape.backup_sets].write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_directory_version_by_backup
PRINT N'Creating [dbo].[Tape.get_last_directory_version_by_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_directory_version_by_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_directory_version_by_backup]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_directory_version_by_backup]
	@directory_id bigint
	,@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	
	SELECT TOP 1 
		[Tape.directory_versions].* 
	FROM 
		[Tape.directory_versions] 
		INNER JOIN [Tape.backup_sets] ON [Tape.directory_versions].backup_set_id = [Tape.backup_sets].id
	WHERE
		[Tape.directory_versions].directory_id = @directory_id AND 
		[Tape.backup_sets].backup_id = @backup_id
	ORDER BY
		[Tape.backup_sets].write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_directory_version
PRINT N'Creating [dbo].[Tape.get_last_directory_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_directory_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_directory_version]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_directory_version]
	@directory_id bigint
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	
	SELECT TOP 1 * 
	FROM 
		[Tape.directory_versions] 
		INNER JOIN [Tape.backup_sets] ON [Tape.directory_versions].backup_set_id = [Tape.backup_sets].id
	WHERE
		[Tape.directory_versions].directory_id = @directory_id
	ORDER BY
		[Tape.backup_sets].write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_versions_by_backup_id
PRINT N'Creating [dbo].[Tape.get_file_versions_by_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_versions_by_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_versions_by_backup_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_versions_by_backup_id]
	@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	
	SELECT 
		* 
	FROM 
		[Tape.file_versions] 
	WHERE
		backup_set_id = @backup_set_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_version
PRINT N'Creating [dbo].[Tape.get_file_version]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_version]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_version]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_version]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.file_versions] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_version_by_id_and_backup_set_id
PRINT N'Creating [dbo].[Tape.get_file_version_by_id_and_backup_set_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_version_by_id_and_backup_set_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_version_by_id_and_backup_set_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_version_by_id_and_backup_set_id]
	@file_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		* 
	FROM 
		[Tape.file_versions] 
	WHERE 
		[file_id] = @file_id AND
		backup_set_id = @backup_set_id
END
GO

--------------------------------------------------------------------------------
-- Tape.is_tape_medium_empty
PRINT N'Creating [dbo].[Tape.is_tape_medium_empty]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.is_tape_medium_empty]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.is_tape_medium_empty]
GO
CREATE PROCEDURE [dbo].[Tape.is_tape_medium_empty]
	@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF EXISTS(
		SELECT
			TOP 1 * 
		FROM 
			[Tape.tape_medium_backup_sets]
		WHERE 
			[Tape.tape_medium_backup_sets].tape_medium_id = @tape_medium_id)
		RETURN 0
	ELSE
		RETURN 1
END
GO

--------------------------------------------------------------------------------
-- Tape.get_file_parts_by_tape_medium_id
PRINT N'Creating [dbo].[Tape.get_file_parts_by_tape_medium_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_parts_by_tape_medium_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_parts_by_tape_medium_id]
GO
--CREATE PROCEDURE [dbo].[Tape.get_file_parts_by_tape_medium_id]
--	@tape_medium_id uniqueidentifier
--AS
--BEGIN
--	SET NOCOUNT ON;
	
--	SELECT 
--		* 
--	FROM
--		[Tape.file_parts] fp
--		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id
--		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
--		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
--	WHERE
--		tm.id = @tape_medium_id
--END
--GO

--------------------------------------------------------------------------------
-- Tape.get_file_parts_by_tape_medium_id
PRINT N'Creating [dbo].[Tape.get_file_parts_by_tape_medium_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_parts_by_tape_medium_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_parts_by_tape_medium_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_parts_by_tape_medium_id]
	@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;	
	SELECT 
		* 
	FROM
		[Tape.file_parts] fp
		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
	WHERE
		tm.id = @tape_medium_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_parts_by_backup_set_id
PRINT N'Creating [dbo].[Tape.get_file_parts_by_backup_set_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_parts_by_backup_set_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_parts_by_backup_set_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_parts_by_backup_set_id]
	@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT
		fp.*
	FROM
		[Tape.file_parts] fp
		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id
	WHERE
		fv.backup_set_id = @backup_set_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_parts
PRINT N'Creating [dbo].[Tape.get_file_parts]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_parts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_parts]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_parts]
	@file_version_id bigint 
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;	
	SELECT
		fp.*
	FROM
		[Tape.file_parts] fp
		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id 
	WHERE
		fv.id = @file_version_id
	ORDER BY
		fp.media_sequence_number ASC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_part
PRINT N'Creating [dbo].[Tape.get_file_part]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_part]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_part]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_part]
	@file_version_id bigint
	,@media_sequence_number int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		fp.* 
	FROM
		[Tape.file_parts] fp
		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id
	WHERE
		fv.id = @file_version_id AND
		media_sequence_number = @media_sequence_number
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_files_by_directory_id_and_tape_medium_id
PRINT N'Creating [dbo].[Tape.get_all_files_by_directory_id_and_tape_medium_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_files_by_directory_id_and_tape_medium_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_files_by_directory_id_and_tape_medium_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_files_by_directory_id_and_tape_medium_id]
	@directory_id bigint
	,@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;	
	SELECT DISTINCT
		f.* 
	FROM 
		[Tape.files] f 
		INNER JOIN [Tape.file_versions] fv ON f.id = fv.file_id
		INNER JOIN [Tape.file_parts] fp ON fv.id = fp.file_version_id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
	WHERE 
		f.directory_id = @directory_id AND
		tm.id = @tape_medium_id
END
GO


--------------------------------------------------------------------------------
-- Tape.cleanup_incomplete_oibs
PRINT N'Creating [dbo].[Tape.cleanup_incomplete_oibs]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.cleanup_incomplete_oibs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.cleanup_incomplete_oibs]
GO
CREATE PROCEDURE [dbo].[Tape.cleanup_incomplete_oibs] 
	@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	CREATE TABLE #oibs 
	(
		id uniqueidentifier, 
		link_id uniqueidentifier, 
		parent_id uniqueidentifier
	)

	INSERT INTO #oibs
	SELECT o.id, o.link_id, o.parent_id
	FROM [Tape.tape_mediums] tm
		INNER JOIN [Tape.backup_sets] bs ON tm.media_family_id = bs.media_family_id
		INNER JOIN [Tape.file_parts] fp ON tm.media_sequence_number = fp.media_sequence_number
		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id AND bs.id = fv.backup_set_id
		INNER JOIN [Tape.storages] s ON fv.id = s.file_version_id
		INNER JOIN [Backup.Model.OIBs] o ON s.tape_storage_id = o.storage_id
	WHERE 
		tm.id = @tape_medium_id 

	WHILE @@RowCount > 0
	BEGIN 
		INSERT INTO #oibs
		SELECT id, link_id, parent_id
		FROM [Backup.Model.OIBs]
		WHERE 
			id NOT IN (SELECT id FROM #oibs) AND 
			(
				link_id IN (SELECT id FROM #oibs) OR 
				parent_id IN (SELECT id FROM #oibs) 
--				OR 
--				id IN (SELECT link_id FROM #oibs) OR 
--				id IN (SELECT parent_id FROM #oibs)
			)
	END

	DELETE FROM [Backup.Model.OIBs] WHERE id IN (SELECT id FROM #oibs)

	DECLARE @id uniqueidentifier, @usn bigint
	DECLARE del CURSOR FOR SELECT id FROM #oibs
	OPEN del

	FETCH NEXT FROM del INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] 'Backup.Model.OIBs', @id, @usn

		FETCH NEXT FROM del INTO @id
	END

	CLOSE del
	DEALLOCATE del
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_tape_medium_from_catalogue
PRINT N'Creating [dbo].[Tape.delete_tape_medium_from_catalogue]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_tape_medium_from_catalogue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_tape_medium_from_catalogue]
GO
CREATE PROCEDURE [dbo].[Tape.delete_tape_medium_from_catalogue]
	@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	SET DEADLOCK_PRIORITY HIGH;

	BEGIN TRANSACTION

	DECLARE @id uniqueidentifier
	DECLARE @usn bigint
	DECLARE @media_family_id int
	DECLARE @media_sequence_number int
	DECLARE @batch_size int
	DECLARE @iid bigint

	SELECT TOP(1) @iid = id FROM [Tape.directories] WITH (TABLOCKX)
	SELECT TOP(1) @iid = id FROM [Tape.directory_versions] WITH (TABLOCKX)
	SELECT TOP(1) @iid = id FROM [Tape.files] WITH (TABLOCKX)
	SELECT TOP(1) @iid = id FROM [Tape.file_versions] WITH (TABLOCKX)
	SELECT TOP(1) @iid = id FROM [Tape.file_parts] WITH (TABLOCKX)

	SET @batch_size = 10000
	SELECT @media_family_id = media_family_id, @media_sequence_number = media_sequence_number FROM [Tape.tape_mediums] WHERE id = @tape_medium_id

	-- build file versions table

	SELECT DISTINCT fv.id file_version_id
	INTO #versions
	FROM 
		[Tape.file_versions] fv
		INNER JOIN [Tape.file_parts] fp ON fv.id = fp.file_version_id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
	WHERE bs.media_family_id = @media_family_id AND fp.media_sequence_number = @media_sequence_number

	CREATE CLUSTERED INDEX [file_id_backup_set_id] ON #versions(file_version_id)

	-- mark files as incomplete
	UPDATE [Tape.file_versions] SET [Tape.file_versions].incomplete = 1 
	FROM [Tape.file_versions] INNER JOIN #versions ON [Tape.file_versions].id = #versions.file_version_id

	-- clear directory versions
	DELETE dv
	FROM [Tape.directory_versions] dv 
	INNER JOIN [Tape.backup_sets] bs ON dv.backup_set_id = bs.id
	WHERE bs.media_family_id = @media_family_id AND dv.media_sequence_number = @media_sequence_number

	-- clear oibs
	UPDATE co SET co.link_id = NULL
	FROM 
		[Backup.Model.OIBs] po
		INNER JOIN [Backup.Model.OIBs] co ON po.id = co.link_id
		INNER JOIN [Tape.storages] ts ON po.storage_id = ts.tape_storage_id 
		INNER JOIN #versions p ON ts.file_version_id = p.file_version_id

	SELECT o.id id, o.usn usn
	INTO #oibIds
	FROM
		[Backup.Model.OIBs] o 
		INNER JOIN [Tape.storages] ts ON o.storage_id = ts.tape_storage_id 
		INNER JOIN #versions p ON ts.file_version_id = p.file_version_id

	CREATE CLUSTERED INDEX [id] ON #oibIds (Id)

	EXEC [dbo].[IncrementUsn] @usn OUTPUT
	UPDATE [dbo].[Backup.Model.Backups] SET usn = @usn WHERE id in 
		(SELECT pnts.backup_id FROM [Backup.Model.Points] pnts WHERE pnts.id in 
			(SELECT oibs.point_id FROM [dbo].[Backup.Model.OIBs] oibs WHERE oibs.id in (SELECT id FROM #oibIds)))

	DELETE FROM [Backup.Model.OIBs] WHERE id IN (SELECT id FROM #oibIds)

	DECLARE del CURSOR FOR SELECT id FROM #oibIds
	OPEN del

	FETCH NEXT FROM del INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		BEGIN TRY
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
			EXEC [dbo].[InsertTombStone] 'Backup.Model.OIBs', @id, @usn
		END TRY
		BEGIN CATCH END CATCH
		FETCH NEXT FROM del INTO @id
	END

	CLOSE del
	DEALLOCATE del

	-- clear storages
	SELECT s.id id, s.usn usn
	INTO #storageIds
	FROM 
		[Backup.Model.Storages] s 
		INNER JOIN [Tape.storages] ts ON s.id = ts.tape_storage_id 
		INNER JOIN #versions p ON ts.file_version_id = p.file_version_id

	CREATE CLUSTERED INDEX [id] ON #storageIds (Id)

	SELECT s.storage_key_id id
	INTO #cryptoKeyIds
	FROM [Backup.Model.Storages] s INNER JOIN #storageIds i ON s.id = i.id
	WHERE s.storage_key_id <> '00000000-0000-0000-0000-000000000000'

	INSERT INTO #cryptoKeyIds
	SELECT s.meta_key_id id
	FROM [Backup.Model.Storages] s INNER JOIN #storageIds i ON s.id = i.id
	WHERE s.meta_key_id <> '00000000-0000-0000-0000-000000000000'

	CREATE CLUSTERED INDEX [id] ON #cryptoKeyIds (Id)

	DELETE FROM [Backup.Model.Storages] WHERE id IN (SELECT id FROM #storageIds)
	UPDATE [Backup.Model.Storages] SET link_id = NULL WHERE link_id not in (select id from [Backup.Model.Storages])
	DECLARE del CURSOR FOR SELECT id FROM #storageIds
	OPEN del

	FETCH NEXT FROM del INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		BEGIN TRY
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
			EXEC [dbo].[InsertTombStone] 'Backup.Model.Storages', @id, @usn
		END TRY
		BEGIN CATCH END CATCH
		FETCH NEXT FROM del INTO @id
	END

	CLOSE del
	DEALLOCATE del

	-- clear crypro keys

	DELETE
	FROM [CryptoKeys]
	WHERE 
		EXISTS (SELECT * FROM #cryptoKeyIds WHERE [CryptoKeys].id = #cryptoKeyIds.id) AND
		NOT EXISTS (SELECT * FROM [Backup.Model.Storages] WHERE storage_key_id = [CryptoKeys].id OR meta_key_id = [CryptoKeys].id)

	-- clear points
	UPDATE cp SET cp.link_id = NULL
	FROM 
		[Backup.Model.Points] pp
		INNER JOIN [Backup.Model.Points] cp ON pp.id = cp.link_id
		INNER JOIN [Backup.Model.Backups] b ON pp.backup_id = b.id
	WHERE 
		b.target_type = 4 AND
		pp.id NOT IN 
		(
			SELECT DISTINCT point_id FROM [Backup.Model.OIBs]
		)

	SELECT p.id AS id, p.usn AS usn
	INTO #pointIds
	FROM 
		[Backup.Model.Points] p
		INNER JOIN [Backup.Model.Backups] b ON p.backup_id = b.id
	WHERE 
		b.target_type = 4 AND
		p.id NOT IN 
		(
			SELECT DISTINCT point_id FROM [Backup.Model.OIBs]
		)

	CREATE CLUSTERED INDEX [id] ON #pointIds (Id)

	DELETE FROM [Backup.Model.Points] WHERE id IN (SELECT id FROM #pointIds)

	DECLARE del CURSOR FOR SELECT id FROM #pointIds
	OPEN del

	FETCH NEXT FROM del INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		BEGIN TRY
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
			EXEC [dbo].[InsertTombStone] 'Backup.Model.Points', @id, @usn
		END TRY
		BEGIN CATCH END CATCH
		FETCH NEXT FROM del INTO @id
	END

	CLOSE del
	DEALLOCATE del
	
	-- clear backups
	SELECT id AS id, usn AS usn
	INTO #backupIds
	FROM [Backup.Model.Backups]
	WHERE
		target_type = 4 AND 
		id NOT IN 
		(
			SELECT DISTINCT backup_id FROM [Backup.Model.Points]
			UNION SELECT backup_id FROM [Backup.Model.Storages]
		)

	CREATE CLUSTERED INDEX [id] ON #backupIds (Id)

	DELETE FROM [Backup.Model.Backups] WHERE id IN (SELECT id FROM #backupIds)

	DECLARE del CURSOR FOR SELECT id FROM #backupIds
	OPEN del

	FETCH NEXT FROM del INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		BEGIN TRY
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
			EXEC [dbo].[InsertTombStone] 'Backup.Model.Backups', @id, @usn
		END TRY
		BEGIN CATCH END CATCH
		FETCH NEXT FROM del INTO @id
	END

	CLOSE del
	DEALLOCATE del

	-- clear mapping
	DELETE FROM [Tape.vm_objects]
	WHERE 
		tape_object_id NOT IN 
		(
			SELECT DISTINCT id FROM [Backup.Model.OIBs]
			UNION SELECT id FROM [Backup.Model.Storages]
			UNION SELECT id FROM [Backup.Model.Points]
			UNION SELECT id FROM [Backup.Model.Backups]
		)

	-- clear crypto keys
	DELETE [CryptoKeys] 
	FROM 
		[CryptoKeys] c 
		INNER JOIN [Tape.backup_sets] b ON c.id = b.crypto_key_id 
		INNER JOIN [Tape.tape_medium_backup_sets] t ON t.backup_set_id = b.id
	WHERE 
		t.tape_medium_id = @tape_medium_id AND
		NOT EXISTS (
			SELECT *
			FROM [Tape.tape_medium_backup_sets] 
			WHERE backup_set_id = t.backup_set_id and tape_medium_id <> @tape_medium_id)
	
	-- clear backup sets
	SELECT t.backup_set_id id
	INTO #backupSetIds
	FROM [Tape.tape_medium_backup_sets] t
	WHERE 
		t.tape_medium_id = @tape_medium_id AND
		NOT EXISTS (
			SELECT *
			FROM [Tape.tape_medium_backup_sets] 
			WHERE backup_set_id = t.backup_set_id and tape_medium_id <> @tape_medium_id)

	CREATE CLUSTERED INDEX [id] ON #backupSetIds (id)

	DELETE [Tape.backup_sets] FROM [Tape.backup_sets] bs INNER JOIN #backupSetIds bs2 ON bs.id = bs2.id

	DECLARE del CURSOR FOR SELECT id FROM #backupSetIds
	OPEN del

	FETCH NEXT FROM del INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		BEGIN TRY
			EXEC [dbo].[IncrementUsn] @usn OUTPUT
			EXEC [dbo].[InsertTombStone] 'Tape.backup_sets', @id, @usn
		END TRY
		BEGIN CATCH END CATCH
		FETCH NEXT FROM del INTO @id
	END

	CLOSE del
	DEALLOCATE del
	
	DELETE FROM [Tape.tape_medium_backup_sets] WHERE tape_medium_id = @tape_medium_id

	-- clear tape backups
	EXEC [Tape.clear_tape_backups]

	-- clear encrypted imported backups
	EXEC [Tape.clear_encrypted_imported_backups]

	-- clear orphan file parts
	DELETE fp 
	FROM [Tape.file_parts] fp INNER JOIN #versions p ON fp.file_version_id = p.file_version_id 
	WHERE fp.media_sequence_number = @media_sequence_number

	-- clean orphan file versions
	SELECT id INTO #file_versions 
	FROM [Tape.file_versions] 
	WHERE NOT EXISTS (SELECT * FROM [Tape.file_parts] WHERE [Tape.file_parts].file_version_id = [Tape.file_versions].id)

	CREATE INDEX temp_file_versions ON #file_versions (id)

	DELETE FROM [Tape.file_versions] WHERE id IN (SELECT id FROM #file_versions)

	-- clean orphan files
	SELECT id
	INTO #files
	FROM [Tape.files]
	WHERE NOT EXISTS (SELECT * FROM [Tape.file_versions] WHERE [Tape.file_versions].file_id = [Tape.files].id)

	CREATE INDEX temp_files ON #files (id)

	IF NOT EXISTS (SELECT * FROM [Backup.Model.JobSessions] WHERE job_type = '100' AND STATE = '5')
	BEGIN
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Tape.files]') AND name = N'IX_Tape.files_directory_id_name')
	BEGIN
	DROP INDEX [IX_Tape.files_directory_id_name] ON [Tape.files]
	END
	DELETE FROM [Tape.files] WHERE id IN (SELECT id FROM #files)
	CREATE INDEX [IX_Tape.files_directory_id_name] ON [Tape.files] (directory_id) INCLUDE (name)
	END
	ELSE
	BEGIN
	DELETE FROM [Tape.files] WHERE id IN (SELECT id FROM #files)
	END

	-- clean orphan directories
	WHILE 1=1
	BEGIN
		SELECT id INTO #temp_directories FROM [Tape.directories] 
		WHERE 
			NOT EXISTS (SELECT * FROM [Tape.directories] c WHERE [Tape.directories].id = c.parent_id ) AND
			NOT EXISTS (SELECT * FROM [Tape.directory_versions] v WHERE [Tape.directories].id = v.directory_id) AND
			NOT EXISTS (SELECT * FROM [Tape.files] f WHERE [Tape.directories].id = f.directory_id)

		CREATE INDEX temp_directories ON #temp_directories (id)

		DELETE FROM [Tape.directories] WHERE id IN (SELECT id FROM #temp_directories)

		IF (@@ROWCOUNT = 0) 
			BREAK

		DROP TABLE #temp_directories
	END

	UPDATE [dbo].[Tape.catalog_usn] SET usn = usn + 1

	COMMIT TRANSACTION
END
GO


--------------------------------------------------------------------------------
-- Tape.add_file_part
PRINT N'Creating [dbo].[Tape.add_file_part]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_file_part]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_file_part]
GO
CREATE PROCEDURE [dbo].[Tape.add_file_part]
	@file_version_id bigint
	,@format_logical_address bigint
	,@media_sequence_number int
	,@incompletion tinyint
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRANSACTION;

	INSERT INTO [Tape.file_parts] (
		file_version_id
		,format_logical_address
		,media_sequence_number
		,incompletion
	) VALUES (
		@file_version_id
		,@format_logical_address
		,@media_sequence_number
		,@incompletion
	)

	DECLARE @id bigint

	SET @id = CAST(SCOPE_IDENTITY() AS BIGINT)

	UPDATE [Tape.tape_mediums] SET last_write_time = GETDATE() 
	WHERE 
		id = 
		(
			SELECT tm.id 
			FROM [Tape.file_versions] fv
			INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
			INNER JOIN [Tape.tape_medium_backup_sets] tmbs ON bs.backup_id = tmbs.backup_set_id
			INNER JOIN [Tape.tape_mediums] tm ON tmbs.tape_medium_id = tm.id
			WHERE fv.id = @file_version_id AND tm.media_sequence_number = @media_sequence_number
		)

	COMMIT TRANSACTION;

	SELECT * FROM [Tape.file_parts] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_host_by_name
PRINT N'Creating [dbo].[Tape.get_host_by_name]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_host_by_name]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_host_by_name]
GO
CREATE PROCEDURE [dbo].[Tape.get_host_by_name]
	@name nvarchar(255)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.hosts] WHERE name = @name
END
GO


--------------------------------------------------------------------------------
-- Tape.get_volumes
PRINT N'Creating [dbo].[Tape.get_volumes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_volumes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_volumes]
GO
CREATE PROCEDURE [dbo].[Tape.get_volumes]
	@host_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.directories] WHERE [host_id] = @host_id AND parent_id IS NULL
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_hosts
PRINT N'Creating [dbo].[Tape.get_all_hosts]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_hosts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_hosts]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_hosts]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.hosts]
END
GO

--------------------------------------------------------------------------------
-- Tape.[Tape.get_not_empty_hosts]
PRINT N'Creating [dbo].[Tape.get_not_empty_hosts]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_not_empty_hosts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_not_empty_hosts]
GO
CREATE PROCEDURE [dbo].[Tape.get_not_empty_hosts]
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT DISTINCT(host.id),host.name FROM [Tape.hosts] host
	INNER JOIN [Tape.directories] dir ON dir.[host_id] = host.[id]
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_medium_by_media_id
PRINT N'Creating [dbo].[Tape.get_tape_medium_by_media_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium_by_media_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium_by_media_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium_by_media_id]
	@library_id uniqueidentifier,
	@media_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_mediums] WHERE media_id = @media_id AND location_library_id = @library_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_mediums_by_media_id
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_media_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_media_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_media_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_media_id]
	@media_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.tape_mediums] WHERE media_id = @media_id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_storage
PRINT N'Creating [dbo].[Tape.add_storage]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_storage]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_storage]
GO
CREATE PROCEDURE [dbo].[Tape.add_storage]
	@tape_storage_id uniqueidentifier
	,@file_version_id bigint
	,@media_family_id int
	,@session_number int
	,@format_logical_address bigint
	,@location xml
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [Tape.storages] (
		tape_storage_id
		,file_version_id
		,media_family_id
		,session_number
		,format_logical_address
		,location
		)
	VALUES (
		@tape_storage_id
		,@file_version_id
		,@media_family_id
		,@session_number
		,@format_logical_address
		,@location
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.get_storage
PRINT N'Creating [dbo].[Tape.get_storage]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_storage]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_storage]
GO
CREATE PROCEDURE [dbo].[Tape.get_storage]
	@tape_storage_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.storages] WHERE tape_storage_id = @tape_storage_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_first_tape_medium
PRINT N'Creating [dbo].[Tape.get_first_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_first_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_first_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.get_first_tape_medium]
	@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * 
	FROM [Tape.tape_mediums] 
	WHERE id = 
		(
		SELECT 
			TOP 1 tm.id 
		FROM 
			[Tape.file_versions] fv
			INNER JOIN [Tape.file_parts] fp ON fv.id = fp.file_version_id
			INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
			INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
		WHERE 
			bs.id = @backup_set_id 
		ORDER BY 
			tm.format_logical_address
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.add_vm_object
PRINT N'Creating [dbo].[Tape.add_vm_object]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_vm_object]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_vm_object]
GO
CREATE PROCEDURE [dbo].[Tape.add_vm_object]
	@vm_object_id uniqueidentifier
	,@tape_object_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [Tape.vm_objects] (
		vm_object_id
		,tape_object_id
		)
	VALUES (
		@vm_object_id
		,@tape_object_id
		)
END
GO


--------------------------------------------------------------------------------
-- Tape.get_vm_object_ids
PRINT N'Creating [dbo].[Tape.get_vm_object_ids]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_vm_object_ids]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_vm_object_ids]
GO
CREATE PROCEDURE [dbo].[Tape.get_vm_object_ids]
	@tape_object_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.vm_objects] WHERE tape_object_id = @tape_object_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_object_ids
PRINT N'Creating [dbo].[Tape.get_tape_object_ids]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_object_ids]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_object_ids]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_object_ids]
	@vm_object_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.vm_objects] WHERE vm_object_id = @vm_object_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_part_by_address
PRINT N'Creating [dbo].[Tape.get_file_part_by_address]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_part_by_address]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_part_by_address]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_part_by_address]
	@media_family_id int
	,@backup_set_number int
	,@format_logical_address bigint
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		fp.* 
	FROM 
		[Tape.file_parts] fp
		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id 
	WHERE 
		bs.media_family_id = @media_family_id AND 
		bs.number = @backup_set_number AND
		fp.format_logical_address = @format_logical_address
END
GO


--------------------------------------------------------------------------------
-- Tape.resolve_new_storages
PRINT N'Creating [dbo].[Tape.resolve_new_storages]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.resolve_new_storages]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.resolve_new_storages]
GO
CREATE PROCEDURE [dbo].[Tape.resolve_new_storages]
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE 
		[Tape.storages]
	SET 
		file_version_id = 0
	FROM
		[Tape.storages] s
		INNER JOIN [Tape.backup_sets] bs ON s.media_family_id = bs.media_family_id AND s.session_number = bs.number
		INNER JOIN [Tape.file_parts] fp ON s.format_logical_address = fp.format_logical_address
		INNER JOIN [Tape.file_versions] fv ON fp.file_version_id = fv.id AND bs.id = fv.backup_set_id
	WHERE
		s.file_version_id IS NULL
END
GO


--------------------------------------------------------------------------------
-- Tape.get_tape_mediums_by_media_family_id
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_media_family_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_media_family_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_media_family_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_media_family_id]
	@media_family_id int
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [Tape.tape_mediums] WHERE media_family_id = @media_family_id
END
GO


--------------------------------------------------------------------------------
-- Tape.delete_orphan_vm_objects
PRINT N'Creating [dbo].[Tape.delete_orphan_vm_objects]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_orphan_vm_objects]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_orphan_vm_objects]
GO
CREATE PROCEDURE [dbo].[Tape.delete_orphan_vm_objects]
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRANSACTION; 

	DELETE FROM [Tape.backups]
	WHERE 
	id NOT IN 
	(
		SELECT id FROM [Backup.Model.Backups]
		UNION
		SELECT '437913A2-1D8E-4d74-BB0D-4FDEC6771A6C'
	)

	DELETE FROM [Tape.vm_objects]
	WHERE tape_object_id NOT IN 
	(
		SELECT id FROM [Backup.Model.Backups]
		UNION SELECT id FROM [Backup.Model.Storages]
		UNION SELECT id FROM [Backup.Model.Points]
		UNION SELECT id FROM [Backup.Model.OIBs]
	)

	DELETE [Tape.file_versions]
	FROM 
		[Tape.file_versions] v
	WHERE NOT EXISTS (SELECT * FROM [Tape.storages] s WHERE v.id = s.file_version_id)

	DELETE FROM [Tape.storages]
	WHERE tape_storage_id NOT IN 
	(
		SELECT tape_object_id FROM [Tape.vm_objects]
	)

	COMMIT TRANSACTION;
END
GO


--------------------------------------------------------------------------------
-- Tape.report_directory_changes
PRINT N'Creating [dbo].[Tape.get_last_directory_version_by_id_and_media_family_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_directory_version_by_id_and_media_family_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_directory_version_by_id_and_media_family_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_directory_version_by_id_and_media_family_id]
	@directory_id bigint
	,@media_family_id int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		TOP(1) d.*
	FROM 
		[Tape.directory_versions] AS d
		INNER JOIN [Tape.backup_sets] AS b ON d.backup_set_id = b.id
	WHERE 
		d.directory_id = @directory_id AND 
		b.media_family_id = @media_family_id
	ORDER BY 
		b.write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_file_version_by_id_and_media_family_id
PRINT N'Creating [dbo].[Tape.get_last_file_version_by_id_and_media_family_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_file_version_by_id_and_media_family_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_file_version_by_id_and_media_family_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_file_version_by_id_and_media_family_id]
	@file_id bigint
	,@media_family_id int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		TOP(1) f.*
	FROM 
		[Tape.file_versions] AS f
		INNER JOIN [Tape.backup_sets] AS b ON f.backup_set_id = b.id
	WHERE 
		f.file_id = @file_id AND 
		b.media_family_id = @media_family_id
	ORDER BY 
		b.write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directory_by_host_id_and_path
PRINT N'Creating [dbo].[Tape.get_directory_by_host_id_and_path]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory_by_host_id_and_path]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory_by_host_id_and_path]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory_by_host_id_and_path]
	@host_id uniqueidentifier
	,@root nvarchar(max)
	,@parts xml
	,@add bit
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @id BIGINT
	DECLARE @parent_id BIGINT
	DECLARE @part NVARCHAR(MAX)
	DECLARE @hdocument INT

	IF @root IS NULL
		SELECT @id = id FROM [Tape.directories] WHERE [host_id] = @host_id AND parent_id IS NULL AND name IS NULL
	ELSE
		SELECT @id = id FROM [Tape.directories] WHERE [host_id] = @host_id AND parent_id IS NULL AND name = @root COLLATE Latin1_General_BIN

	IF @id IS NULL
	BEGIN
		INSERT INTO [Tape.directories] ([host_id], parent_id, name) VALUES (@host_id, @parent_id, @root)
		SELECT @id = CAST(SCOPE_IDENTITY() AS BIGINT)
	END

	EXEC sp_xml_preparedocument @hdocument OUTPUT, @parts

	DECLARE part_cursor CURSOR FOR SELECT * FROM OPENXML(@hdocument, N'/ROOT/n', 0) WITH (n NVARCHAR(MAX))
	OPEN part_cursor

	FETCH NEXT FROM part_cursor INTO @part
	WHILE (@@FETCH_STATUS = 0 AND @id IS NOT NULL)
	BEGIN
		SET @parent_id = @id
		SET @id = NULL

		SELECT @id = id FROM [Tape.directories] WHERE parent_id = @parent_id AND name = @part COLLATE Latin1_General_BIN

		if @id IS NULL AND @add <> 0
		BEGIN
			INSERT INTO [Tape.directories] ([host_id], parent_id ,name) VALUES (@host_id, @parent_id, @part)
		
			SELECT @id = CAST(SCOPE_IDENTITY() AS BIGINT)
		END

		FETCH NEXT FROM part_cursor INTO @part
	END

	CLOSE part_cursor
	DEALLOCATE part_cursor

	EXEC sp_xml_removedocument @hdocument

	IF @id IS NOT NULL SELECT * FROM [Tape.directories] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_file_versions_by_file_id
PRINT N'Creating [dbo].[Tape.get_file_versions_by_file_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_file_versions_by_file_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_file_versions_by_file_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_file_versions_by_file_id]
	@file_id bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.file_versions] WHERE file_id = @file_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_directory_versions_by_directory_id
PRINT N'Creating [dbo].[Tape.get_directory_versions_by_directory_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_directory_versions_by_directory_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_directory_versions_by_directory_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_directory_versions_by_directory_id]
	@directory_id bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.directory_versions] WHERE directory_id = @directory_id
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.report_search_filesysitems]
PRINT N'Creating [dbo].[Tape.report_search_filesysitems]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_search_filesysitems]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.report_search_filesysitems]
GO

	CREATE PROCEDURE [dbo].[Tape.report_search_filesysitems]
		@host_id uniqueidentifier,
		@parent_id bigint,
		@like_str varchar(256)
	AS
	BEGIN
		SET NOCOUNT ON;
		IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
		WITH    dirtree (id, parent_id, dirname, level, dirpath) AS 
				(
				SELECT  [id], [parent_id], [name], 1, CAST([name] AS NVARCHAR(1024))
				FROM    [dbo].[Tape.directories]
				WHERE   ((@parent_id IS NOT NULL AND [id] = @parent_id) OR ([parent_id] IS NULL AND @parent_id IS NULL)) AND [host_id] = @host_id
				UNION ALL
				SELECT  child.[id], child.[parent_id], child.[name], level + 1, CAST((dirpath + '/' +child.[name]) AS NVARCHAR(1024)) 
				FROM    [dbo].[Tape.directories] as child
				INNER JOIN dirtree ON child.[parent_id] = dirtree.id
				)
		SELECT f.id,
			 f.name, 
			 fver.creation_time, 
			 fver.last_write_time, 
			 fver.size, d.id as dir_id, 
			 [dbo].GetFilePointsCount(f.id) AS count_points,
			 dirpath, 
			 fver.incomplete,
			 0 as type, 
			 CASE 
				WHEN bsets.encrypted = 1 AND bsets.crypto_key_id <> '00000000-0000-0000-0000-000000000000'
               THEN 0 
               ELSE bsets.encrypted 
			 END AS encrypted
			 FROM dirtree d 
		left join  [dbo].[Tape.files] f on f.directory_id = d.id
		INNER JOIN [Tape.file_versions] fver ON f.id = fver.[file_id] AND fver.last_write_time = (SELECT MAX(last_write_time) FROM [Tape.file_versions] WHERE [file_id] = f.id)
		LEFT JOIN [Tape.backup_sets] bsets ON fver.backup_set_id = bsets.id
		WHERE f.name like @like_str
		GROUP BY f.id, f.name, fver.creation_time, fver.last_write_time, fver.size, 
		d.id, dirpath, bsets.encrypted, bsets.crypto_key_id, fver.incomplete
		OPTION (MAXRECURSION 32767)
	END
	
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.report_search_filesysitems_everywhere]
PRINT N'Creating [dbo].[Tape.report_search_filesysitems_everywhere]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_search_filesysitems_everywhere]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.report_search_filesysitems_everywhere]
GO

	CREATE PROCEDURE [dbo].[Tape.report_search_filesysitems_everywhere]
		@like_str varchar(256)
	AS
	BEGIN
		SET NOCOUNT ON;
		IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

		WITH    dirtree (id, parent_id, dirname, level, dirpath) AS 
				(
				SELECT  d.[id], [parent_id], d.[name], 1, CAST(('file:///' + h.name + '/' + d.name) AS NVARCHAR(1024))
				FROM    [Tape.hosts] h INNER JOIN [Tape.directories] d ON h.id = d.host_id 
				WHERE   [parent_id] IS NULL 
				UNION ALL
				SELECT  child.[id], child.[parent_id], child.[name], level + 1, CAST((dirpath + '/' +child.[name]) AS NVARCHAR(1024)) 
				FROM    [dbo].[Tape.directories] as child
				INNER JOIN dirtree ON child.[parent_id] = dirtree.id
				)
		SELECT f.id, 
			f.name, 
			fver.creation_time, 
			fver.last_write_time, 
			fver.size, d.id as dir_id, 
			[dbo].GetFilePointsCount(f.id) AS count_points,
			dirpath, 0 as type, 
			CASE 
            WHEN bsets.encrypted = 1 AND bsets.crypto_key_id <> '00000000-0000-0000-0000-000000000000'
               THEN 0 
               ELSE bsets.encrypted 
			END AS encrypted
			FROM dirtree d 
		left join  [dbo].[Tape.files] f on f.directory_id = d.id
		INNER JOIN [Tape.file_versions] fver ON f.id = fver.[file_id] AND fver.last_write_time = (SELECT MAX(last_write_time) FROM [Tape.file_versions] WHERE [file_id] = f.id)
		LEFT JOIN [Tape.backup_sets] bsets ON fver.backup_set_id = bsets.id
		WHERE f.name like @like_str
		GROUP BY f.id, f.name, fver.creation_time, fver.last_write_time, fver.size, d.id, dirpath, bsets.encrypted, bsets.crypto_key_id
		OPTION (MAXRECURSION 32767)
	END
	
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.get_nearest_file_versions]
PRINT N'Creating [dbo].[Tape.get_nearest_file_versions]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_nearest_file_versions]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_nearest_file_versions]
GO

CREATE PROCEDURE [dbo].[Tape.get_nearest_file_versions]
	@parent_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	SELECT r.* FROM [Tape.file_versions] r INNER JOIN
	(SELECT 
		fv.file_id, MAX(last_write_time) last_write_time
	FROM 
		[Tape.files] f
		INNER JOIN [Tape.file_versions] fv ON f.id = fv.file_id 
	WHERE 
		f.directory_id = @parent_id AND
		fv.backup_set_id IN (SELECT id FROM [Tape.backup_sets] WHERE write_time <= (SELECT write_time FROM [Tape.backup_sets] WHERE id = @backup_set_id))
	GROUP BY fv.file_id) l ON r.file_id = l.file_id AND r.last_write_time = l.last_write_time
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.get_nearest_directory_versions]
PRINT N'Creating [dbo].[Tape.get_nearest_directory_versions]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_nearest_directory_versions]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_nearest_directory_versions]
GO

CREATE PROCEDURE [dbo].[Tape.get_nearest_directory_versions]
	@parent_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT r.* FROM [Tape.directory_versions] r INNER JOIN
	(SELECT 
		dv.directory_id, MAX(last_write_time) last_write_time
	FROM 
		[Tape.directories] d
		INNER JOIN [Tape.directory_versions] dv ON d.id = dv.directory_id 
	WHERE 
		d.parent_id = @parent_id AND
		dv.backup_set_id IN (SELECT id FROM [Tape.backup_sets] WHERE write_time <= (SELECT write_time FROM [Tape.backup_sets] WHERE id = @backup_set_id))
	GROUP BY dv.directory_id) l ON r.directory_id = l.directory_id AND r.last_write_time = l.last_write_time
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_jobs_by_media_pool_id]
PRINT N'Creating [dbo].[Tape.get_jobs_by_media_pool_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_jobs_by_media_pool_id]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_jobs_by_media_pool_id]
GO

CREATE PROCEDURE [dbo].[Tape.get_jobs_by_media_pool_id]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		[Tape.jobs].* 
	FROM 
		[Tape.jobs] 
	WHERE full_mediapool_id = @media_pool_id OR incremental_mediapool_id = @media_pool_id
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_all_backup_sets_for_directory]
PRINT N'Creating [dbo].[Tape.get_all_backup_sets_for_directory]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_backup_sets_for_directory]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_all_backup_sets_for_directory]
GO

CREATE PROCEDURE [dbo].[Tape.get_all_backup_sets_for_directory]
	@directory_id BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	WITH directories(id)
	AS
	(
		SELECT id
		FROM [Tape.directories]
		WHERE id = @directory_id
		UNION ALL
		SELECT [Tape.directories].id
		FROM [Tape.directories] INNER JOIN directories ON [Tape.directories].parent_id = directories.id
	) 
select *  into #temp_dirs from directories
OPTION (MAXRECURSION 32767)

create index tempdirs on #temp_dirs (id)

select distinct dv.backup_set_id 
into #temp_dir_bs 
from #temp_dirs d 
INNER JOIN [Tape.directory_versions] dv ON d.id = dv.directory_id 


select f.id
into #temp_files 
from #temp_dirs d
INNER JOIN [Tape.files] f ON d.id = f.directory_id

select distinct fv.backup_set_id
into #temp_file_bs
from #temp_files f
INNER JOIN [Tape.file_versions] fv ON f.id = fv.file_id

select distinct
bs.id, bs.media_family_id, bs.number, bs.name, bs.write_time, bs.usn, bs.backup_id, bs.physical_block_address, bs.pending, bs.crypto_key_id, bs.encrypted, bs.expiration_date, bs.encryption_type, bs.catalog_session, bs.backup_session_id 
from #temp_dir_bs dir_bs
inner join [Tape.backup_sets] bs ON bs.id = dir_bs.backup_set_id
union 
select distinct 
bs.id, bs.media_family_id, bs.number, bs.name, bs.write_time, bs.usn, bs.backup_id, bs.physical_block_address, bs.pending, bs.crypto_key_id, bs.encrypted, bs.expiration_date, bs.encryption_type, bs.catalog_session, bs.backup_session_id 
from #temp_file_bs file_bs
iNNER JOIN [Tape.backup_sets] bs ON bs.id = file_bs.backup_set_id

END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.delete_library_device]
PRINT N'Creating [dbo].[Tape.delete_library_device]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_library_device]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.delete_library_device]
GO

CREATE PROCEDURE [dbo].[Tape.delete_library_device]
	@library_id uniqueidentifier
	,@device_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	DELETE FROM [Tape.library_devices] WHERE library_id = @library_id AND device_id = @device_id
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_tape_mediums_by_library_id]
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_library_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_library_id]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_library_id]
GO

CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_library_id]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.tape_mediums] WHERE location_library_id = @library_id
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_tape_mediums_by_vault_id]
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_vault_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_vault_id]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_vault_id]
GO

CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_vault_id]
	@vault_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		*
	FROM
		[dbo].[Tape.tape_mediums] tapes
	INNER JOIN
		[dbo].[Tape.media_in_vaults] miv ON miv.media_id = tapes.id
	WHERE
		miv.vault_id = @vault_id
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_new_tape_mediums_by_library_id]
PRINT N'Creating [dbo].[Tape.get_new_tape_mediums_by_library_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_new_tape_mediums_by_library_id]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_new_tape_mediums_by_library_id]
GO

CREATE PROCEDURE [dbo].[Tape.get_new_tape_mediums_by_library_id]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.tape_mediums] WHERE location_library_id = @library_id AND media_pool_id = '00000000-0000-0000-0000-000000000000'
END
GO

--------------------------------------------------------------------------------
-- Tape.get_tape_mediums_by_backup_set_id
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_backup_set_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_backup_set_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_backup_set_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_backup_set_id]
	@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
	* 
	FROM 
		[Tape.tape_mediums] tm
		INNER JOIN [Tape.tape_medium_backup_sets] tmbs ON tm.id = tmbs.tape_medium_id
	WHERE tmbs.backup_set_id = @backup_set_id
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.add_restore_session]
PRINT N'Creating [dbo].[Tape.add_restore_session]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_restore_session]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.add_restore_session]
GO

CREATE PROCEDURE [dbo].[Tape.add_restore_session]
	@id uniqueidentifier
	,@options nvarchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @usn bigint
	EXEC [dbo].[IncrementUsn] @usn OUTPUT

	INSERT INTO [Backup.Model.RestoreJobSessions] (
		id
		,action
		,usn
		,options
		,reason
		,files_log_xml
		,platform
		,multi_restore_id
		,restore_type
		,oib_id
		,state_xml
		,is_internal
		,oib_display_name
		,oib_creation_time
		)
	VALUES (
		@id
		,0
		,@usn
		,@options
		,''
		,'<Root TotalUsn="0" TotalId="0" />'
		,5
		,'00000000-0000-0000-0000-000000000000'
		,0
		,'00000000-0000-0000-0000-000000000000'
		,'<StateXml/>'
		,0
		,''
		,'1900-01-01'
		)
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.capture_tape_medium]
PRINT N'Creating [dbo].[Tape.capture_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.capture_tape_medium]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.capture_tape_medium]
GO

CREATE PROCEDURE [dbo].[Tape.capture_tape_medium] 
	@source_media_pool_id uniqueidentifier
	,@target_media_pool_id uniqueidentifier
	,@library_id uniqueidentifier
	,@tape_drive_address int
AS
BEGIN
	SET NOCOUNT ON;

	SET XACT_ABORT ON;

	BEGIN TRANSACTION;

	DECLARE @id uniqueidentifier
	SET @id = NEWID()

	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums]
	SET media_pool_id = @target_media_pool_id, lock_id = @id, usn = @usn, media_family_id = NULL, media_sequence_number = NULL, media_sequence_number_unique = NULL
	WHERE id = 
		(
		SELECT TOP 1 id 
		FROM [Tape.tape_mediums] WITH (TABLOCKX) 
		WHERE 
			media_pool_id = @source_media_pool_id AND 
			cleaner = 0 AND 
			location_type IN (0, 1) AND 
			location_library_id = @library_id AND
			protected = 0 AND 
			is_write_protected = 0 AND 
			lock_id IS NULL 
		ORDER BY 
			CASE WHEN location_type = 0 AND location_address = @tape_drive_address THEN 0 ELSE 1 END, 
			CASE WHEN barcode IS NULL THEN 1 ELSE 0 END, 
			barcode
		)

	SELECT @id = id FROM [Tape.tape_mediums] WHERE lock_id = @id
	UPDATE [Tape.tape_mediums] SET lock_id = NULL, usn = @usn WHERE id = @id

	COMMIT TRANSACTION;

	SELECT * FROM [Tape.tape_mediums] WHERE id = @id
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.get_storages_by_oib]
PRINT N'Creating [dbo].[Tape.get_storages_by_oib]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_storages_by_oib]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_storages_by_oib]
GO

CREATE PROCEDURE [dbo].[Tape.get_storages_by_oib]
	@oib_id uniqueidentifier 
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @group_id uniqueidentifier
	DECLARE @num numeric

	SELECT @group_id = group_id, @num = num
	FROM [Backup.Model.Points] 
	WHERE id = (
		SELECT point_id 
		FROM [Backup.Model.OIBs] 
		WHERE id = @oib_id)

	SELECT * 
	FROM [Tape.storages] 
	WHERE tape_storage_id in (
		SELECT DISTINCT storage_id 
		FROM [Backup.Model.Oibs] 
		WHERE point_id in (
			SELECT id 
			FROM [Backup.Model.Points] 
			WHERE group_id = @group_id AND num <= @num))
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_tape_mediums_by_file_version_id]
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_file_version_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_file_version_id]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_file_version_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_file_version_id]
	@file_version_id bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		tm.* 
	FROM 
		[Tape.file_versions] fv
		INNER JOIN [Tape.file_parts] fp ON fv.id = fp.file_version_id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
	WHERE 
		fv.id = @file_version_id
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.get_tape_mediums_by_directory_version_id]
PRINT N'Creating [dbo].[Tape.get_tape_mediums_by_directory_version_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums_by_directory_version_id]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_tape_mediums_by_directory_version_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_mediums_by_directory_version_id]
	@directory_version_id bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		tm.* 
	FROM 
		[Tape.directory_versions] dv
		INNER JOIN [Tape.backup_sets] bs ON dv.backup_set_id = bs.id
		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND dv.media_sequence_number = tm.media_sequence_number
	WHERE 
		dv.id = @directory_version_id
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.get_tape_mediums]
PRINT N'Creating [dbo].[Tape.get_tape_mediums]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_mediums]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_tape_mediums]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_mediums]
	@ids XML
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @hdocument INT
	EXEC sp_xml_preparedocument @hdocument OUTPUT, @ids

	SELECT * FROM [Tape.tape_mediums] WHERE id IN (SELECT * FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id UNIQUEIDENTIFIER))

	EXEC sp_xml_removedocument @hdocument
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.update_backup_set_pending]
PRINT N'Creating [dbo].[Tape.update_backup_set_pending]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_backup_set_pending]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.update_backup_set_pending]
GO
CREATE PROCEDURE [dbo].[Tape.update_backup_set_pending]
	@id uniqueidentifier
	,@pending bit
AS
BEGIN
	SET NOCOUNT ON;

	declare @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT

	UPDATE [dbo].[Tape.backup_sets] SET [pending] = @pending, [usn] = @usn WHERE [id] = @id
END
GO
--------------------------------------------------------------------------------
-- [dbo].[Tape.get_hosts_on_tape_medium]
PRINT N'Creating [dbo].[Tape.get_hosts_on_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_hosts_on_tape_medium]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_hosts_on_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.get_hosts_on_tape_medium]
	@medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	SELECT 
	f.directory_id INTO #temp_files
	FROM
    [Tape.files] f 
	JOIN [Tape.file_versions] fv ON f.id = fv.file_id
	JOIN [Tape.file_parts] fp ON fv.id = fp.file_version_id
	
	JOIN [Tape.backup_sets] fbs ON fv.backup_set_id = fbs.id 
	JOIN [Tape.tape_mediums] ftm ON fbs.media_family_id = ftm.media_family_id AND fp.media_sequence_number = ftm.media_sequence_number and ftm.id = @medium_id
	
	

	SELECT d.host_id INTO #temp_dirs FROM [Tape.directories] d 
	JOIN [Tape.directory_versions] dv ON d.id = dv.directory_id
	
	INNER JOIN [Tape.backup_sets] dbs ON dv.backup_set_id = dbs.id 
	JOIN [Tape.tape_mediums] dtm ON dbs.media_family_id = dtm.media_family_id AND dv.media_sequence_number = dtm.media_sequence_number and dtm.id = @medium_id

	SELECT DISTINCT(h.id), h.name 
	FROM [Tape.hosts] h
	INNER JOIN #temp_dirs d ON h.id = d.host_id

	
	UNION
    
	SELECT DISTINCT(h.id), h.name 
	FROM [Tape.hosts] h
	INNER JOIN [Tape.directories] d ON h.id = d.host_id
	JOIN #temp_files t ON t.directory_id = d.id

END

GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.are_file_system_objects_in_between]
PRINT N'Creating [dbo].[Tape.are_file_system_objects_in_between]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.are_file_system_objects_in_between]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.are_file_system_objects_in_between]
GO
CREATE PROCEDURE [dbo].[Tape.are_file_system_objects_in_between]
	@tape_medium_id uniqueidentifier
	,@backup_set_id uniqueidentifier
	,@min bigint
	,@max bigint
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	DECLARE @count bigint

	SELECT @count = COUNT(*)
	FROM [Tape.directory_versions] dv
	INNER JOIN [Tape.backup_sets] bs ON dv.backup_set_id = bs.id
	INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND dv.media_sequence_number = tm.media_sequence_number
	WHERE 
		tm.id = @tape_medium_id AND
		bs.id = @backup_set_id AND
		dv.format_logical_address > @min AND
		dv.format_logical_address < @max

	IF (@count = 0)
	BEGIN
		SELECT 
			@count = COUNT(*)
		FROM 
			[Tape.file_versions] fv
			INNER JOIn [Tape.file_parts] fp ON fv.id = fp.file_version_id
			INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
			INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
		WHERE 
			tm.id = @tape_medium_id AND
			bs.id = @backup_set_id AND
			fp.format_logical_address > @min AND
			fp.format_logical_address < @max
	END

	SELECT CASE WHEN @count = 0 THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END AS result
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.add_media_family]
PRINT N'Creating [dbo].[Tape.add_media_family]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_media_family]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.add_media_family]
GO
CREATE PROCEDURE [Tape.add_media_family]
	@id int
	,@name nvarchar(MAX)
	,@format_logical_address_size int
	,@lock_id uniqueidentifier
	,@is_closed bit
	,@type_id int
	,@creation_time datetime
	,@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		INSERT INTO [Tape.media_families] (
			id
			,name
			,format_logical_address_size
			,lock_id
			,is_closed
			,type_id
			,creation_time
			,media_pool_id
		)
		VALUES (
			@id
			,@name
			,@format_logical_address_size
			,@lock_id
			,@is_closed
			,@type_id
			,@creation_time
			,@media_pool_id		
		)
	END TRY

	BEGIN CATCH
	
	END CATCH
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.get_media_family]
PRINT N'Creating [dbo].[Tape.get_media_family]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_family]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_media_family]
GO
CREATE PROCEDURE [Tape.get_media_family]
	@id int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.media_families] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_minimum_media_sequence_number]
PRINT N'Creating [dbo].[Tape.get_minimum_media_sequence_number]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_minimum_media_sequence_number]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_minimum_media_sequence_number]
GO
CREATE PROCEDURE [Tape.get_minimum_media_sequence_number]
	@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT MIN(media_sequence_number) media_sequence_number
	FROM 
	(
		SELECT DISTINCT media_sequence_number
		FROM [Tape.directory_versions]
		WHERE backup_set_id = @backup_set_id
		UNION SELECT p.media_sequence_number
		FROM [Tape.file_versions] v INNER JOIN [Tape.file_parts] p ON v.id = p.file_version_id
		WHERE v.backup_set_id = @backup_set_id
	) m
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.get_tape_drive_by_library_id_and_address]
PRINT N'Creating [dbo].[Tape.get_tape_drive_by_library_id_and_address]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_drive_by_library_id_and_address]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_tape_drive_by_library_id_and_address]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_drive_by_library_id_and_address]
	@library_id uniqueidentifier
	,@address int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		[Tape.tape_drives].* 
	FROM 
		[Tape.tape_drives] 
		INNER JOIN [Tape.library_devices] ON [Tape.tape_drives].device_id = [Tape.library_devices].device_id
	WHERE
		[Tape.library_devices].library_id = @library_id AND
		[address] = @address
END
GO


PRINT N'Creating [dbo].[Tape.GetBackupSetsByDirIdIgnoreSubdirs]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.GetBackupSetsByDirIdIgnoreSubdirs]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.GetBackupSetsByDirIdIgnoreSubdirs]
GO

create proc [dbo].[Tape.GetBackupSetsByDirIdIgnoreSubdirs]
	@directory_id bigint
as
begin
	set nocount on;
	select
		id, media_family_id, number, name, write_time, usn, backup_id, physical_block_address, pending, crypto_key_id, encrypted, expiration_date, encryption_type, catalog_session, backup_session_id 
	from [Tape.backup_sets] bs 
	join 
	(
		select distinct dv.backup_set_id 
		from [Tape.directories] d 
		join [Tape.directory_versions] dv 
		on d.id = dv.directory_id
		where d.id = @directory_id  
	) 
	ids on bs.id = ids.backup_set_id
end
go


--------------------------------------------------------------------------------
-- [dbo].[Tape.update_file_part_incomplete]
PRINT N'Creating [dbo].[Tape.update_file_part_incomplete]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_file_part_incomplete]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.update_file_part_incomplete]
GO



-- [dbo].[Tape.GetLibraryState]
PRINT N'Creating [dbo].[Tape.GetLibraryState]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.GetLibraryState]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.GetLibraryState]
GO
create proc [dbo].[Tape.GetLibraryState]
	@lib_id uniqueidentifier
as
begin
	set nocount on;
	
	select top(1) devs.state 
    from [Tape.libraries] libs 
	     join
         [Tape.library_devices] lib_devs on libs.id = lib_devs.library_id 
		 join
         [Tape.devices] devs on lib_devs.device_id = devs.id
    where libs.id = @lib_id
end
go

-- [dbo].[Tape.GetOnlineLibraries]
PRINT N'Creating [dbo].[Tape.GetOnlineLibraries]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.GetOnlineLibraries]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.GetOnlineLibraries]
GO
create proc [dbo].[Tape.GetOnlineLibraries]
as
begin
	set nocount on;
	select 
	     * 
	from 
		 [Tape.libraries] libs
	     join
		 (
			 select distinct libs.id 
		  	 from [Tape.libraries] libs 
			 join [Tape.library_devices] lib_devs on libs.id = lib_devs.library_id 
			 join [Tape.devices] devs on lib_devs.device_id = devs.id
			 where devs.state = 0
		 ) l on libs.id = l.id

end

go

-- [dbo].[Tape.GetOnlineLibraries]
PRINT N'Creating [dbo].[Tape.GetUserMediaPoolsDescriptions]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.GetUserMediaPoolsDescriptions]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.GetUserMediaPoolsDescriptions]
go


--------------------------------------------------------------------------------
-- [dbo].[Tape.remove_tapes_and_library_from_infrastructure]
PRINT N'Creating [dbo].[Tape.remove_tapes_and_library_from_infrastructure]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.remove_tapes_and_library_from_infrastructure]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.remove_tapes_and_library_from_infrastructure]
GO
CREATE PROCEDURE [dbo].[Tape.remove_tapes_and_library_from_infrastructure]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @id uniqueidentifier
	DECLARE @usn bigint

	DECLARE tape_mediums_cursor CURSOR FOR SELECT id FROM [Tape.tape_mediums] WHERE location_library_id = @library_id
	OPEN tape_mediums_cursor

    FETCH NEXT FROM tape_mediums_cursor INTO @id
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC [Tape.delete_tape_medium_from_catalogue] @tape_medium_id = @id

		EXEC [dbo].[IncrementUsn] @usn OUTPUT
		EXEC [dbo].[InsertTombStone] 'Tape.tape_mediums', @id, @usn

        FETCH NEXT FROM tape_mediums_cursor INTO @id
    END
	
	CLOSE tape_mediums_cursor
	DEALLOCATE tape_mediums_cursor

	DELETE FROM [Tape.tape_mediums] WHERE location_library_id = @library_id

	DELETE t FROM [Tape.tape_drives] t INNER JOIN [Tape.library_devices] l ON t.device_id = l.device_id WHERE l.library_id = @library_id
	DELETE c FROM [Tape.changers] c INNER JOIN [Tape.library_devices] l ON c.device_id = l.device_id WHERE l.library_id = @library_id
	DELETE d FROM [Tape.devices] d INNER JOIN [Tape.library_devices] l ON d.id = l.device_id WHERE l.library_id = @library_id
	DELETE FROM [Tape.library_devices] WHERE library_id = @library_id
	DELETE FROM [Tape.libraries] WHERE id = @library_id
END
GO

--------------------------------------------------------------------------------
-- [dbo].[Tape.remove_library_from_infrastructure]
PRINT N'Creating [dbo].[Tape.remove_library_from_infrastructure]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.remove_library_from_infrastructure]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.remove_library_from_infrastructure]
GO
CREATE PROCEDURE [dbo].[Tape.remove_library_from_infrastructure]
	@library_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	DELETE t FROM [Tape.tape_drives] t INNER JOIN [Tape.library_devices] l ON t.device_id = l.device_id WHERE l.library_id = @library_id
	DELETE c FROM [Tape.changers] c INNER JOIN [Tape.library_devices] l ON c.device_id = l.device_id WHERE l.library_id = @library_id
	DELETE d FROM [Tape.devices] d INNER JOIN [Tape.library_devices] l ON d.id = l.device_id WHERE l.library_id = @library_id
	DELETE FROM [Tape.library_devices] WHERE library_id = @library_id
	DELETE FROM [Tape.libraries] WHERE id = @library_id
END
GO

--------------------------------------------------------------------------------
-- Tape.get_oib_ids_by_tape_medium
PRINT N'Creating [dbo].[Tape.get_oib_ids_by_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_oib_ids_by_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_oib_ids_by_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.get_oib_ids_by_tape_medium]
	@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @id uniqueidentifier
	
	-- build file versions table
	SELECT DISTINCT 
		fv.id
	INTO #parts
	FROM 
		[Tape.file_versions] fv
		INNER JOIN [Tape.file_parts] fp ON fv.id = fp.file_version_id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
	WHERE 
		tm.id = @tape_medium_id
	
	CREATE INDEX [file_id_backup_set_id] ON #parts (id)
	
	-- get oibs
	SELECT o.id AS id
	INTO #oibIds
	FROM
		dbo.[Backup.Model.OIBs] o 
		INNER JOIN dbo.[Tape.storages] ts ON o.storage_id = ts.tape_storage_id 
		INNER JOIN #parts p ON ts.file_version_id = p.id

	SELECT * FROM #oibIds

END
GO


--------------------------------------------------------------------------------
-- Tape.get_backup_set_by_tape_medium_id
PRINT N'Creating [dbo].[Tape.get_backup_set_by_tape_medium_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_set_by_tape_medium_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_set_by_tape_medium_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_set_by_tape_medium_id]
	@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		bs.id, bs.media_family_id, bs.number, bs.name, bs.write_time, bs.usn, bs.backup_id, bs.physical_block_address, bs.pending, bs.crypto_key_id, bs.encrypted, bs.expiration_date, bs.encryption_type, bs.catalog_session, bs.backup_session_id 
	FROM
		[Tape.backup_sets] bs
		INNER JOIN [Tape.tape_medium_backup_sets] tb ON bs.id = tb.backup_set_id
	WHERE
		tb.tape_medium_id = @tape_medium_id
END
GO


--------------------------------------------------------------------------------
-- Tape.add_tape_medium_backup_set
PRINT N'Creating [dbo].[Tape.add_tape_medium_backup_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_tape_medium_backup_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_tape_medium_backup_set]
GO
CREATE PROCEDURE [dbo].[Tape.add_tape_medium_backup_set]
	@tape_medium_id uniqueidentifier
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	IF EXISTS(SELECT * FROM [Tape.tape_medium_backup_sets] WHERE @tape_medium_id = tape_medium_id AND @backup_set_id = backup_set_id  )
		RETURN
		
	INSERT INTO [Tape.tape_medium_backup_sets] (
		tape_medium_id
		,backup_set_id
		) 
	VALUES (
		@tape_medium_id
		,@backup_set_id
		)

	SET NOCOUNT ON;
END
GO


--------------------------------------------------------------------------------
-- [Tape.add_media_vault]
PRINT N'Creating [dbo].[Tape.add_media_vault]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_media_vault]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_media_vault]
GO
CREATE PROCEDURE [dbo].[Tape.add_media_vault]
	@id AS UNIQUEIDENTIFIER,
	@name nvarchar(MAX)
	,@protect  bit
	,@description  nvarchar(MAX)

AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [Tape.media_vaults] (
		id
		,name
		,[description]
		,[protect]
	) VALUES (
		@id
		,@name
		,@description
		,@protect
	)
END
GO



--------------------------------------------------------------------------------
-- [Tape.update_media_vault]
PRINT N'Creating [dbo].[Tape.update_media_vault]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_media_vault]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_media_vault]
GO
CREATE PROCEDURE [dbo].[Tape.update_media_vault]
	@id AS UNIQUEIDENTIFIER
	,@name nvarchar(MAX)
	,@protect  bit
	,@description  nvarchar(MAX)

AS
BEGIN
	SET NOCOUNT ON;
	UPDATE [Tape.media_vaults] SET
		[name]			=@name
		,[description]	=@description
		,[protect]		=@protect
	WHERE id = @id
END
GO

--------------------------------------------------------------------------------
-- [Tape.get_media_vault]
PRINT N'Creating [dbo].[Tape.get_media_vault]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_vault]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_media_vault]
GO
CREATE PROCEDURE [dbo].[Tape.get_media_vault]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [Tape.media_vaults] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- [Tape.report_media_vaults_deletes]
PRINT N'Creating [dbo].[Tape.report_media_vaults_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_vaults_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_media_vaults_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_media_vaults_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.media_vaults'
END
GO

--------------------------------------------------------------------------------
-- [Tape.report_media_vault_deletes]
PRINT N'Creating [dbo].[Tape.report_media_vault_deletes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_vault_deletes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.report_media_vault_deletes]
GO
CREATE PROCEDURE [dbo].[Tape.report_media_vault_deletes]
	@row_usn bigint
AS
BEGIN
	SET NOCOUNT ON;
	SELECT uid, usn FROM [TombStones] WHERE usn > @row_usn AND table_name = 'Tape.media_in_vaults'
END
GO


--------------------------------------------------------------------------------
-- [Tape.report_media_vaults_changes]
PRINT N'Creating [dbo].[Tape.report_media_vaults_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_vaults_changes]') AND type in (N'V'))
DROP VIEW [dbo].[Tape.report_media_vaults_changes]
GO
CREATE VIEW [dbo].[Tape.report_media_vaults_changes]
AS
SELECT	mv.[id],
		mv.[name], 
		mv.[description],
		mv.[usn]
FROM [Tape.media_vaults] mv
GO


--------------------------------------------------------------------------------
-- [Tape.report_media_vault_changes]
PRINT N'Creating [dbo].[Tape.report_media_vault_changes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.report_media_vault_changes]') AND type in (N'V'))
DROP VIEW [dbo].[Tape.report_media_vault_changes]
GO
CREATE VIEW [dbo].[Tape.report_media_vault_changes]
AS
SELECT	miv.[id], 
		tm.[id] AS medium_id,
		miv.[vault_id],
		tm.[name],
		tm.library,
		mp.[name] AS [media_pool_name],
		tm.[media_set_name],
		tm.media_time,
		mp.options,
		tm.location_type,
		tm.[description],
		ed.expiration_date,
		tm.protected,
		tm.encrypted,
		tm.is_write_protected,
		tm.retired,
		dbo.MaxValue5(miv.usn, tm.usn, mv.usn, mp.usn, ed.usn) AS [usn]
FROM [Tape.media_in_vaults] miv
INNER JOIN [Tape.media_vaults] mv ON mv.[id] = miv.[vault_id]
INNER JOIN [Tape.report_media_changes] tm ON tm.[id] = miv.[media_id]
INNER JOIN [Tape.media_pools] mp ON mp.[id] = tm.[media_pool_id]
LEFT JOIN
	(
	SELECT tmbs.tape_medium_id, ed.expiration_date, bs.usn 
	FROM [Tape.tape_medium_backup_sets] tmbs 
	INNER JOIN [Tape.backup_sets] bs ON tmbs.backup_set_id = bs.id 
	INNER JOIN 
		(SELECT tmbs.tape_medium_id, MAX(bs.expiration_date) expiration_date
		FROM [Tape.tape_medium_backup_sets] tmbs 
		INNER JOIN [Tape.backup_sets] bs ON tmbs.backup_set_id = bs.id
		GROUP BY tmbs.tape_medium_id) ed ON tmbs.tape_medium_id = ed.tape_medium_id AND bs.expiration_date = ed.expiration_date) ed ON tm.id = ed.tape_medium_id


GO

--------------------------------------------------------------------------------
-- [Tape.get_all_media_vaults]
PRINT N'Creating [dbo].[Tape.get_all_media_vaults]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_media_vaults]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_media_vaults]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_media_vaults]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [Tape.media_vaults] ORDER BY [name] ASC
END
GO

--------------------------------------------------------------------------------
-- [Tape.delete_media_vault]
PRINT N'Creating [dbo].[Tape.delete_media_vault]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_media_vault]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.delete_media_vault]
GO
CREATE PROCEDURE [dbo].[Tape.delete_media_vault]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	DELETE FROM [Tape.media_vaults] WHERE id = @id
	DELETE FROM [Tape.media_in_vaults] WHERE [vault_id] = @id
END
GO

--------------------------------------------------------------------------------
-- [Tape.add_encrypted_imported_backup]
PRINT N'Creating [dbo].[Tape.add_encrypted_imported_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_encrypted_imported_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.add_encrypted_imported_backup]
GO
CREATE PROCEDURE [dbo].[Tape.add_encrypted_imported_backup] 
	@id uniqueidentifier
	,@library_id uniqueidentifier
	,@meta nvarchar(MAX)
	,@original_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [Tape.encrypted_imported_backups] (id, library_id, meta, original_id) VALUES (@id, @library_id, @meta, @original_id)
END
GO

--------------------------------------------------------------------------------
-- [Tape.get_encrypted_imported_backup]
PRINT N'Creating [dbo].[Tape.get_encrypted_imported_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_encrypted_imported_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_encrypted_imported_backup]
GO
CREATE PROCEDURE [dbo].[Tape.get_encrypted_imported_backup] 
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.encrypted_imported_backups] WHERE id = @id
END
GO


--------------------------------------------------------------------------------
-- [Tape.get_encrypted_imported_backup_by_original_id]
PRINT N'Creating [dbo].[Tape.get_encrypted_imported_backup_by_original_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_encrypted_imported_backup_by_original_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_encrypted_imported_backup_by_original_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_encrypted_imported_backup_by_original_id] 
	@original_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.encrypted_imported_backups] WHERE original_id = @original_id
END
GO


--------------------------------------------------------------------------------
-- [Tape.get_all_not_used_media_vaults]
PRINT N'Creating [dbo].[Tape.get_all_not_used_media_vaults]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_not_used_media_vaults]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_not_used_media_vaults]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_not_used_media_vaults]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [dbo].[Tape.media_vaults] vlt WHERE (SELECT COUNT(mp.id) FROM [dbo].[Tape.media_pools] mp WHERE mp.vault_id = vlt.id) = 0 ORDER BY [name] ASC
END
GO

--------------------------------------------------------------------------------
-- [Tape.move_tape_medium_to_vault]
PRINT N'Creating [dbo].[Tape.move_tape_medium_to_vault]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.move_tape_medium_to_vault]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.move_tape_medium_to_vault]
GO
CREATE PROCEDURE [dbo].[Tape.move_tape_medium_to_vault]
	@medium_id uniqueidentifier,
	@vault_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @id uniqueidentifier
	SET @id = NEWID();
	DELETE FROM [Tape.media_in_vaults] WHERE media_id = @medium_id
	INSERT INTO [Tape.media_in_vaults] (id, media_id, vault_id) VALUES(@id, @medium_id, @vault_id)
END
GO

--------------------------------------------------------------------------------
-- [Tape.get_media_vault_by_medium_id]
PRINT N'Creating [dbo].[Tape.get_media_vault_by_medium_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_vault_by_medium_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_media_vault_by_medium_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_media_vault_by_medium_id]
	@medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [Tape.media_vaults] mv
	INNER JOIN [Tape.media_in_vaults] miv ON miv.vault_id = mv.id
	WHERE miv.media_id = @medium_id
END
GO

--------------------------------------------------------------------------------
-- [Tape.get_media_vault_by_medium_id]
PRINT N'Creating [dbo].[Tape.remove_medium_from_vault]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.remove_medium_from_vault]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.remove_medium_from_vault]
GO
CREATE PROCEDURE [dbo].[Tape.remove_medium_from_vault]
	@medium_id uniqueidentifier
AS
BEGIN
	DELETE FROM [Tape.media_in_vaults] WHERE media_id = @medium_id
END
GO

--------------------------------------------------------------------------------
-- [Tape.get_media_vault_by_media_pool_id]
PRINT N'Creating [dbo].[Tape.get_media_vault_by_media_pool_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_vault_by_media_pool_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_media_vault_by_media_pool_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_media_vault_by_media_pool_id]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [Tape.media_vaults] mv
	INNER JOIN [Tape.media_pools] mp ON mp.vault_id = mv.id AND mp.id = @media_pool_id
END
GO


--------------------------------------------------------------------------------
-- [Tape.get_all_backup_sets_by_media_family_id]
PRINT N'Creating [dbo].[Tape.get_all_backup_sets_by_media_family_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_backup_sets_by_media_family_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_backup_sets_by_media_family_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_backup_sets_by_media_family_id] 
	@media_family_id int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		id, media_family_id, number, name, write_time, usn, backup_id, physical_block_address, pending, crypto_key_id, encrypted, expiration_date, encryption_type, catalog_session, backup_session_id 
	FROM 
		[Tape.backup_sets] 
	WHERE 
		media_family_id = @media_family_id
END
GO
 

--------------------------------------------------------------------------------
-- [Tape.get_tape_medium_expiration_date]
PRINT N'Creating [dbo].[Tape.get_tape_medium_expiration_date]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_tape_medium_expiration_date]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_tape_medium_expiration_date]
GO
CREATE PROCEDURE [dbo].[Tape.get_tape_medium_expiration_date] 
	@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		MAX(bs.expiration_date) expiration_date
	FROM 
		[Tape.backup_sets] bs
		INNER JOIN [Tape.tape_medium_backup_sets] tmbs ON  bs.id = tmbs.backup_set_id
	WHERE
		tmbs.tape_medium_id = @tape_medium_id
END
GO
 

--------------------------------------------------------------------------------
-- [Tape.update_tape_medium_expiration_date]
PRINT N'Creating [dbo].[Tape.update_tape_medium_expiration_date]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_expiration_date]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_expiration_date]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_expiration_date] 
	@tape_medium_id uniqueidentifier
	,@expiration_date datetime
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE 
		[Tape.backup_sets] 
	SET 
		expiration_date = @expiration_date
	FROM 
		[Tape.backup_sets] bs
		INNER JOIN [Tape.tape_medium_backup_sets] tmbs ON  bs.id = tmbs.tape_medium_id
	WHERE
		tmbs.tape_medium_id = @tape_medium_id
END
GO

--------------------------------------------------------------------------------
-- Tape.update_tape_medium_protected
PRINT N'Creating [dbo].[Tape.update_tape_medium_protected]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_protected]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_protected]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_protected]
	@id uniqueidentifier
	,@protected bit
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		protected = @protected
		,usn = @usn
	WHERE
		id = @id
END
GO

--------------------------------------------------------------------------------
-- Tape.update_tape_medium_outdated
PRINT N'Creating [dbo].[Tape.update_tape_medium_outdated]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_outdated]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_outdated]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_outdated]
	@id uniqueidentifier
	,@outdated bit
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		outdated = @outdated
		,usn = @usn
	WHERE
		id = @id
END
GO

--------------------------------------------------------------------------------
-- Tape.any_job_exists
PRINT N'Creating [dbo].[Tape.any_job_exists]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.any_job_exists]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.any_job_exists]
GO
CREATE PROCEDURE [dbo].[Tape.any_job_exists]
AS
BEGIN
	SET NOCOUNT ON;
	IF EXISTS(SELECT * FROM [Tape.jobs])
		RETURN 1
	ELSE
		RETURN 0
	
END
GO

--------------------------------------------------------------------------------
-- Tape.set_file_version_corrupted
PRINT N'Creating [dbo].[Tape.set_file_version_corrupted]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.set_file_version_corrupted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.set_file_version_corrupted]
GO
CREATE PROCEDURE [Tape.set_file_version_corrupted]
	@id bigint
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE [Tape.file_versions] SET corrupted = 1 WHERE id = @id
END
GO

--------------------------------------------------------------------------------
-- Tape.get_all_not_corrupted_files_by_directory_id
PRINT N'Creating [dbo].[Tape.get_all_not_corrupted_files_by_directory_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_not_corrupted_files_by_directory_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_not_corrupted_files_by_directory_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_not_corrupted_files_by_directory_id]
	@directory_id bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT f.* 
	FROM [Tape.files] f INNER JOIN [Tape.file_versions] v ON f.id = v.file_id
	WHERE f.directory_id = @directory_id AND v.corrupted = 0
END
GO


--------------------------------------------------------------------------------
-- Tape.get_all_not_corrupted_files_by_directory_id_and_tape_medium_id
PRINT N'Creating [dbo].[Tape.get_all_not_corrupted_files_by_directory_id_and_tape_medium_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_all_not_corrupted_files_by_directory_id_and_tape_medium_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_all_not_corrupted_files_by_directory_id_and_tape_medium_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_all_not_corrupted_files_by_directory_id_and_tape_medium_id]
	@directory_id bigint
	,@tape_medium_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
		IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	SELECT DISTINCT
		f.* 
	FROM 
		[Tape.files] f 
		INNER JOIN [Tape.file_versions] fv ON f.id = fv.file_id
		INNER JOIN [Tape.file_parts] fp ON fv.id = fp.file_version_id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
		INNER JOIN [Tape.tape_mediums] tm ON bs.media_family_id = tm.media_family_id AND fp.media_sequence_number = tm.media_sequence_number
	WHERE 
		f.directory_id = @directory_id AND
		tm.id = @tape_medium_id AND
		fv.corrupted = 0
END
GO

--------------------------------------------------------------------------------
-- Tape.get_backup_sets_by_file_id_not_corrupted
PRINT N'Creating [dbo].[Tape.get_backup_sets_by_file_id_not_corrupted]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_sets_by_file_id_not_corrupted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_sets_by_file_id_not_corrupted]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_sets_by_file_id_not_corrupted]
	@file_id bigint
AS
BEGIN
	SET NOCOUNT ON;
		IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	SELECT 
		bs.id, bs.media_family_id, bs.number, bs.name, bs.write_time, bs.usn, bs.backup_id, bs.physical_block_address, bs.pending, bs.crypto_key_id, bs.encrypted, bs.expiration_date, bs.encryption_type, bs.catalog_session, bs.backup_session_id 
	FROM 
		[Tape.backup_sets] bs INNER JOIN 
		[Tape.file_versions] ON bs.id = [Tape.file_versions].backup_set_id
	WHERE 
		[Tape.file_versions].[file_id] = @file_id AND
		[Tape.file_versions].corrupted = 0 AND
		[Tape.file_versions].incomplete = 0
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_file_version_not_corrupted
PRINT N'Creating [dbo].[Tape.get_last_file_version_not_corrupted]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_file_version_not_corrupted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_file_version_not_corrupted]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_file_version_not_corrupted]
	@file_id bigint
AS
BEGIN
	SET NOCOUNT ON;
		IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

	SELECT TOP 1 * 
	FROM 
		[Tape.file_versions] 
		INNER JOIN [Tape.backup_sets] ON [Tape.file_versions].backup_set_id = [Tape.backup_sets].id
	WHERE
		[Tape.file_versions].[file_id] = @file_id AND
		[Tape.file_versions].corrupted = 0 AND
		[Tape.file_versions].incomplete = 0
	ORDER BY
		[Tape.backup_sets].write_time DESC
END
GO


--------------------------------------------------------------------------------
-- [dbo].[Tape.get_nearest_not_corrupted_file_versions]
PRINT N'Creating [dbo].[Tape.get_nearest_not_corrupted_file_versions]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_nearest_not_corrupted_file_versions]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_nearest_not_corrupted_file_versions]
GO
CREATE PROCEDURE [dbo].[Tape.get_nearest_not_corrupted_file_versions]
	@parent_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT r.* FROM [Tape.file_versions] r INNER JOIN
	(SELECT 
		fv.file_id, MAX(last_write_time) last_write_time
	FROM 
		[Tape.files] f
		INNER JOIN [Tape.file_versions] fv ON f.id = fv.file_id 
	WHERE 
		f.directory_id = @parent_id AND
		fv.corrupted = 0 AND
		fv.backup_set_id IN (SELECT id FROM [Tape.backup_sets] WHERE write_time <= (SELECT write_time FROM [Tape.backup_sets] WHERE id = @backup_set_id))
	GROUP BY fv.file_id) l ON r.file_id = l.file_id AND r.last_write_time = l.last_write_time
END
GO



--------------------------------------------------------------------------------
-- Tape.get_last_file_version_not_corrupted_by_backup
PRINT N'Creating [dbo].[Tape.get_last_file_version_not_corrupted_by_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_file_version_not_corrupted_by_backup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_last_file_version_not_corrupted_by_backup]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_file_version_not_corrupted_by_backup]
	@file_id bigint
	,@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
		IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;
	
	SELECT TOP 1 
		[Tape.file_versions].* 
	FROM 
		[Tape.file_versions] 
		INNER JOIN [Tape.backup_sets] ON [Tape.file_versions].backup_set_id = [Tape.backup_sets].id
	WHERE
		[Tape.file_versions].[file_id] = @file_id AND
		[Tape.file_versions].corrupted = 0 AND
		[Tape.backup_sets].backup_id = @backup_id
	ORDER BY
		[Tape.backup_sets].write_time DESC
END
GO


--------------------------------------------------------------------------------
-- Tape.move_tape_medium_to_free_pool
PRINT N'Creating [dbo].[Tape.move_tape_medium_to_free_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.move_tape_medium_to_free_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.move_tape_medium_to_free_pool]
GO
	
			
--------------------------------------------------------------------------------
-- Tape.update_backup_set_expiration_date_period
PRINT N'Creating [dbo].[Tape.update_backup_set_expiration_date_period]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_backup_set_expiration_date_period]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_backup_set_expiration_date_period]
GO
CREATE PROCEDURE [dbo].[Tape.update_backup_set_expiration_date_period]
	@media_pool_id uniqueidentifier,
	@period nvarchar(MAX),
	@value int
AS
BEGIN
	SET NOCOUNT ON;

	declare @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT
	
	UPDATE
		b
	SET
		b.Usn = @usn,
		b.expiration_date = 
			CASE
				WHEN @period = 'DAY' THEN DATEADD(d, @value, b.write_time)
				WHEN @period = 'WEEK' THEN DATEADD(wk, @value, b.write_time)
				WHEN @period = 'MONTH' THEN DATEADD(m, @value, b.write_time)
			END
	FROM
		[Tape.backup_sets] b 
		INNER JOIN [Tape.tape_medium_backup_sets] tb ON b.id = tb.backup_set_id
		INNER JOIN [Tape.tape_mediums] t ON tb.tape_medium_id = t.id
	WHERE 
		t.media_pool_id = @media_pool_id
END
GO


--------------------------------------------------------------------------------
-- Tape.update_backup_set_expiration_date_value
PRINT N'Creating [dbo].[Tape.update_backup_set_expiration_date_value]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_backup_set_expiration_date_value]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_backup_set_expiration_date_value]
GO
CREATE PROCEDURE [dbo].[Tape.update_backup_set_expiration_date_value]
	@media_pool_id uniqueidentifier,
	@date datetime
AS
BEGIN
	SET NOCOUNT ON;

	declare @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT

	UPDATE
		b
	SET
		b.usn = @usn,
		b.expiration_date = @date
	FROM 
		[Tape.backup_sets] b 
		INNER JOIN [Tape.tape_medium_backup_sets] tb ON b.id = tb.backup_set_id
		INNER JOIN [Tape.tape_mediums] t ON tb.tape_medium_id = t.id
	WHERE 
		t.media_pool_id = @media_pool_id
END
GO


--------------------------------------------------------------------------------
-- Backup.Model.DeleteRotatedDrive
PRINT N'Creating [dbo].[Tape.get_storages_by_backupset]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_storages_by_backupset]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_storages_by_backupset]
GO
CREATE PROCEDURE [dbo].[Tape.get_storages_by_backupset]
	@backup_set_id uniqueidentifier 
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		* 
	FROM 
		[Tape.storages] s
		INNER JOIN [Tape.file_versions] v ON s.file_version_id = v.id
	WHERE 
		v.backup_set_id = ISNULL(@backup_set_id, backup_set_id)
END
GO

--------------------------------------------------------------------------------
-- [Tape.get_media_pools_by_vault_id]
PRINT N'Creating [dbo].[Tape.get_media_pools_by_vault_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_pools_by_vault_id]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_media_pools_by_vault_id]
GO
CREATE PROCEDURE [dbo].[Tape.get_media_pools_by_vault_id]
	@vault_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [Tape.media_pools] WHERE [vault_id] = @vault_id
END
GO



--------------------------------------------------------------------------------
-- [Tape.add_directory_ex]
PRINT N'Creating [dbo].[Tape.add_directory_ex]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_directory_ex]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.add_directory_ex]
GO
CREATE PROCEDURE [dbo].[Tape.add_directory_ex]
	@host_id uniqueIdentifier
	,@root nvarchar(max)
	,@parts xml
	,@backup_set_id uniqueidentifier
	,@creation_time datetime
	,@last_write_time datetime
	,@attributes int
	,@format_logical_address bigint
	,@media_sequence_number int
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	DECLARE @directory_id bigint 
	DECLARE @directory_version_id bigint
	DECLARE @parent_id bigint 

	BEGIN TRANSACTION

	DECLARE @iid bigint

	SELECT TOP(1) @iid = id FROM [Tape.directories] WITH (TABLOCKX)
	SELECT TOP(1) @iid = id FROM [Tape.directory_versions] WITH (TABLOCKX)

	-- find or add directory

	DECLARE @get_directory_result_set table (id bigint, host_id uniqueidentifier, parent_id bigint, name nvarchar(255))

	INSERT INTO @get_directory_result_set EXEC [Tape.get_directory_by_host_id_and_path] @host_id = @host_id, @root = @root, @parts = @parts, @add = 1
	SELECT TOP 1 @directory_id = id, @parent_id = parent_id FROM @get_directory_result_set

	-- find directory version

	SELECT @directory_version_id = id FROM [Tape.directory_versions] WHERE directory_id = @directory_id AND backup_set_id = @backup_set_id

	-- add directory version if required

	IF @directory_version_id IS NULL
	BEGIN 
		DECLARE @add_directory_version_result_set table (directory_id bigint, backup_set_id uniqueidentifier, creation_time datetime, last_write_time datetime, attributes int, format_logical_address bigint, media_sequence_number int, id bigint)

		INSERT INTO @add_directory_version_result_set EXEC [Tape.add_directory_version] @directory_id = @directory_id, @backup_set_id = @backup_set_id, @creation_time = @creation_time, @last_write_time = @last_write_time, @attributes = @attributes, @format_logical_address = @format_logical_address, @media_sequence_number = @media_sequence_number
		SELECT TOP 1 @directory_version_id = id FROM @add_directory_version_result_set
	END

	UPDATE tm SET tm.last_write_time = GETDATE() 
	FROM [Tape.tape_mediums] tm INNER JOIN [Tape.tape_medium_backup_sets] bs ON tm.id = bs.backup_set_id
	WHERE tm.media_sequence_number = @media_sequence_number AND bs.backup_set_id = @backup_set_id

	UPDATE [dbo].[Tape.catalog_usn] SET usn = usn + 1

	COMMIT TRANSACTION

	SELECT @parent_id parent_id, @directory_id directory_id, @directory_version_id directory_version_id
END
GO



--------------------------------------------------------------------------------
-- [Tape.add_file_impl]
PRINT N'Creating [dbo].[Tape.add_file_impl]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_file_impl]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.add_file_impl]
GO
CREATE PROCEDURE [dbo].[Tape.add_file_impl]
	@directory_id bigint
	,@name nvarchar(max)
	,@backup_set_id uniqueidentifier
	,@creation_time datetime
	,@last_write_time datetime
	,@size bigint
	,@attributes int
	,@corrupted bit
	,@format_logical_address bigint
	,@media_sequence_number int
	,@incompletion tinyint
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRANSACTION;

	DECLARE @file_id bigint 
	DECLARE @file_version_id bigint 
	DECLARE @file_part_id bigint 

	-- find file

	DECLARE @get_file_result_set table (id bigint, directory_id bigint, name nvarchar(255))

	INSERT INTO @get_file_result_set EXEC [Tape.get_file_by_directory_and_name] @directory_id = @directory_id, @name = @name
	SELECT TOP 1 @file_id = id FROM @get_file_result_set

	-- add file if not found

	IF @file_id IS NULL
	BEGIN 
		DECLARE @add_file_result_set table (id bigint, directory_id bigint, name nvarchar(255))

		INSERT INTO @add_file_result_set EXEC [Tape.add_file] @directory_id = @directory_id, @name = @name
		SELECT TOP 1 @file_id = id FROM @add_file_result_set
	END

	-- find file version

	SELECT @file_version_id = id FROM [Tape.file_versions] WHERE file_id = @file_id AND backup_set_id = @backup_set_id

	-- add file version if required

	IF @file_version_id IS NULL
	BEGIN 
		DECLARE @add_file_version_result_set table (file_id bigint, backup_set_id uniqueidentifier, creation_time datetime, last_write_time datetime, size bigint, attributes int, corrupted bit, id bigint, incomplete bit)

		INSERT INTO @add_file_version_result_set EXEC [Tape.add_file_version] @file_id = @file_id, @backup_set_id = @backup_set_id, @creation_time = @creation_time, @last_write_time = @last_write_time, @size = @size, @attributes = @attributes
		SELECT TOP 1 @file_version_id = id FROM @add_file_version_result_set
	END

	-- find file part

	SELECT @file_part_id = id FROM [Tape.file_parts] WHERE file_version_id = @file_version_id AND media_sequence_number = @media_sequence_number

	-- add file part if required

	IF @file_part_id IS NULL
	BEGIN 
		DECLARE @add_file_part_result_set table (format_logical_address bigint, media_sequence_number int, id bigint, file_version_id bigint, incompletion tinyint)

		INSERT INTO @add_file_part_result_set EXEC [Tape.add_file_part] @file_version_id = @file_version_id, @format_logical_address = @format_logical_address, @media_sequence_number = @media_sequence_number, @incompletion = @incompletion
		SELECT TOP 1 @file_part_id = id FROM @add_file_part_result_set
	END

	SELECT @directory_id directory_id, @file_id file_id, @file_version_id file_version_id, @file_part_id file_part_id

	COMMIT TRANSACTION;
END
GO

--------------------------------------------------------------------------------
-- [Tape.new_file_impl]
PRINT N'Creating [dbo].[Tape.new_file_impl]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.new_file_impl]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.new_file_impl]
GO
CREATE PROCEDURE [dbo].[Tape.new_file_impl]
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	CREATE CLUSTERED INDEX [temp_ind] ON #temp_tape_files ([name], [directory_id])

	DECLARE @id bigint

	BEGIN TRANSACTION

	SELECT TOP(1) @id = id FROM [Tape.directories] WITH (TABLOCKX)
	SELECT TOP(1) @id = id FROM [Tape.files] WITH (TABLOCKX)
	SELECT TOP(1) @id = id FROM [Tape.file_versions] WITH (TABLOCKX)
	SELECT TOP(1) @id = id FROM [Tape.file_parts] WITH (TABLOCKX)

	INSERT INTO [Tape.files] (directory_id, name)
	SELECT directory_id, name 
	FROM #temp_tape_files a 
	WHERE NOT EXISTS (SELECT id FROM [Tape.files] b WHERE (a.name = b.name AND a.directory_id = b.directory_id ))

	INSERT INTO [Tape.file_versions] ([file_id], [backup_set_id], [creation_time], [last_write_time], [size], [attributes], [corrupted])
	SELECT a.id, b.backup_set_id, b.creation_time, b.last_write_time, b.size, b.attributes, b.corrupted
	FROM 
		#temp_tape_files b JOIN
		[Tape.files] a ON a.name = b.name and a.directory_id = b.directory_id
	WHERE NOT EXISTS (SELECT [file_id] FROM [Tape.file_versions] c WHERE a.id = c.file_id AND c.backup_set_id = b.backup_set_id)

 	INSERT INTO [Tape.file_parts] (file_version_id, format_logical_address, media_sequence_number, incompletion)
	SELECT a.id, c.format_logical_address, c.media_sequence_number, c.incompletion
	FROM 
		[Tape.file_versions] a JOIN 
		[Tape.files] b ON a.file_id = b.id JOIN
		#temp_tape_files c ON b.name = c.name AND b.directory_id = c.directory_id AND a.backup_set_id = c.backup_set_id
	WHERE NOT EXISTS (SELECT id FROM [Tape.file_parts] WHERE file_version_id = a.id AND media_sequence_number = c.media_sequence_number) 

	UPDATE [dbo].[Tape.catalog_usn] SET usn = usn + 1

	COMMIT TRANSACTION
END
GO


--------------------------------------------------------------------------------
-- [Tape.add_file_ex]
PRINT N'Creating [dbo].[Tape.add_file_ex]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_file_ex]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.add_file_ex]
GO



--------------------------------------------------------------------------------
-- [Tape.add_directory_and_file_ex]
PRINT N'Creating [dbo].[Tape.add_directory_and_file_ex]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.add_directory_and_file_ex]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.add_directory_and_file_ex]
GO
CREATE PROCEDURE [dbo].[Tape.add_directory_and_file_ex]
	@host_id uniqueidentifier
	,@root nvarchar(max)
	,@parts xml
	,@name nvarchar(max)
	,@backup_set_id uniqueidentifier
	,@creation_time datetime
	,@last_write_time datetime
	,@size bigint
	,@attributes int
	,@corrupted bit
	,@format_logical_address bigint
	,@media_sequence_number int
	,@incompletion tinyint
AS
BEGIN
	SET NOCOUNT ON;
 
	SET XACT_ABORT ON;
 
	DECLARE @directory_id bigint 

	BEGIN TRAN

	DECLARE @iid bigint

	SELECT TOP(1) @iid = id FROM [Tape.directories] WITH (TABLOCK)
	SELECT TOP(1) @iid = id FROM [Tape.directory_versions] WITH (TABLOCK)
	SELECT TOP(1) @iid = id FROM [Tape.files] WITH (TABLOCK)
	SELECT TOP(1) @iid = id FROM [Tape.file_versions] WITH (TABLOCK)
	SELECT TOP(1) @iid = id FROM [Tape.file_parts] WITH (TABLOCK)

	-- find or add directory

	DECLARE @get_directory_result_set table (id bigint, host_id uniqueidentifier, parent_id bigint, name nvarchar(255))

	INSERT INTO @get_directory_result_set EXEC [Tape.get_directory_by_host_id_and_path] @host_id = @host_id, @root = @root, @parts = @parts, @add = 1
	SELECT TOP 1 @directory_id = id FROM @get_directory_result_set

	-- add file

	EXEC [Tape.add_file_impl] @directory_id = @directory_id, @name = @name, @backup_set_id = @backup_set_id, @creation_time = @creation_time, @last_write_time = @last_write_time, @size = @size, @attributes = @attributes, @corrupted = @corrupted, @format_logical_address = @format_logical_address, @media_sequence_number = @media_sequence_number, @incompletion = @incompletion

	UPDATE [dbo].[Tape.catalog_usn] SET usn = usn + 1

	COMMIT TRANSACTION
	END
GO



--------------------------------------------------------------------------------
-- [Tape.get_last_not_corrupted_file_version_by_backup]
PRINT N'Creating [dbo].[Tape.get_last_not_corrupted_file_version_by_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_not_corrupted_file_version_by_backup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_last_not_corrupted_file_version_by_backup]
GO
CREATE PROCEDURE [Tape.get_last_not_corrupted_file_version_by_backup]
	@directory_id bigint
	,@name nvarchar(MAX)
	,@backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRAN

	DECLARE @id bigint

	SELECT TOP(1) @id = id FROM [Tape.files] WITH (TABLOCKX)
	SELECT TOP(1) @id = id FROM [Tape.file_versions] WITH (TABLOCKX)

	SELECT TOP 1 
		fv.* 
	FROM 
		[Tape.files] f
		INNER JOIN [Tape.file_versions] fv ON f.id = fv.file_id
		INNER JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
	WHERE
		f.directory_id = @directory_id AND
		f.name = @name COLLATE Latin1_General_BIN AND
		fv.corrupted = 0 AND
		bs.backup_id = @backup_id
	ORDER BY
		bs.write_time DESC

	COMMIT
END
GO


--------------------------------------------------------------------------------
-- [Tape.get_media_sequence_numbers]
PRINT N'Creating [dbo].[Tape.get_media_sequence_numbers]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_sequence_numbers]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_media_sequence_numbers]
GO
CREATE PROCEDURE [dbo].[Tape.get_media_sequence_numbers]
	@file_version_ids xml
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @hdocument int

	EXEC sp_xml_preparedocument @hdocument OUTPUT, @file_version_ids

	SELECT DISTINCT fp.media_sequence_number id FROM [Tape.file_parts] fp INNER JOIN OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id bigint) fv ON fp.file_version_id = fv.id

	EXEC sp_xml_removedocument @hdocument
END
GO

--------------------------------------------------------------------------------
-- [Tape.batch_get_last_not_corrupted_file_version_by_backup]
PRINT N'Creating [dbo].[Tape.batch_get_last_not_corrupted_file_version_by_backup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.batch_get_last_not_corrupted_file_version_by_backup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.batch_get_last_not_corrupted_file_version_by_backup]
GO
CREATE PROCEDURE [dbo].[Tape.batch_get_last_not_corrupted_file_version_by_backup]
    @backup_id UNIQUEIDENTIFIER
AS
    BEGIN

		IF @@TRANCOUNT = 0  
			BEGIN; 
				SET TRANSACTION ISOLATION LEVEL SNAPSHOT ; 
			END;

        IF OBJECT_ID('tempdb..#temp_filedirs') IS NOT NULL
            DROP TABLE #temp_filedirs;
		
        SELECT  f.id AS file_id ,
                f.name AS file_name ,
                d.host_id ,
                f.directory_id
        INTO    #temp_filedirs
        FROM    [Tape.files] f
                JOIN [Tape.directories] d ON f.directory_id = d.id; 

	
        CREATE NONCLUSTERED INDEX temp_filename_host_id
        ON [dbo].[#temp_filedirs] ([file_name],[host_id])
        INCLUDE ([directory_id]);

	

        WITH    directories
                  AS ( SELECT   id ,
                                parent_id ,
                                CAST(name AS NVARCHAR(MAX)) AS name ,
                                id AS root_id
                       FROM     [Tape.directories]
                       WHERE    id IN (
                                SELECT  fd.directory_id
                                FROM    #batch_get_last_table t
                                        INNER HASH JOIN #temp_filedirs fd ON fd.host_id = t.host_id
                                                              AND t.name = fd.file_name )
                       UNION ALL
                       SELECT   [Tape.directories].id ,
                                [Tape.directories].parent_id ,
                                name = CAST([Tape.directories].name + '|'
                                + directories.name AS NVARCHAR(MAX)) ,
                                directories.root_id
                       FROM     [Tape.directories]
                                INNER JOIN directories ON [Tape.directories].id = directories.parent_id
								
                     )
					 
            SELECT  t.file_id ,
                    t.record_id
            INTO    #internal_temp_table
            FROM    directories d
                    JOIN ( SELECT   fd.file_id ,
                                    fd.file_name ,
                                    fd.host_id ,
                                    fd.directory_id ,
                                    t.path ,
                                    t.record_id
                           FROM     #batch_get_last_table t
                                    JOIN ( SELECT   f.id AS file_id ,
                                                    f.name AS file_name ,
                                                    d.host_id ,
                                                    f.directory_id
                                           FROM     [Tape.files] f
                                                    JOIN [Tape.directories] d ON f.directory_id = d.id
                                         ) fd ON fd.host_id = t.host_id
                                                 AND t.name = fd.file_name
                         ) t ON d.root_id = t.directory_id
                                AND t.path = d.name
            WHERE   parent_id IS NULL
			OPTION (MAXRECURSION 0)
			;

        CREATE CLUSTERED INDEX Idx1 ON #internal_temp_table(file_id);

        SELECT  *
        FROM    ( SELECT    * ,
                            ROW_NUMBER() OVER ( PARTITION BY file_id ORDER BY backup_set_write_time DESC ) AS rn
                  FROM      ( SELECT    fv.* ,
                                        t.record_id ,
                                        bs.write_time AS backup_set_write_time
                              FROM      [Tape.file_versions] fv
                                        JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
                                        JOIN #internal_temp_table t ON t.file_id = fv.file_id
                              WHERE     fv.corrupted = 0
                                        AND fv.incomplete = 0
                                        AND bs.backup_id = @backup_id
                            ) fv_bs
                ) AS T
        WHERE   rn = 1;
    END;
GO



--------------------------------------------------------------------------------
-- [Tape.delete_partialy_tape_medium_from_catalogue]
PRINT N'Creating [dbo].[Tape.delete_partialy_tape_medium_from_catalogue]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.delete_partialy_tape_medium_from_catalogue]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.delete_partialy_tape_medium_from_catalogue]
GO


--------------------------------------------------------------------------------
-- [Tape.build_file_versions_to_delete_table]
PRINT N'Creating [dbo].[Tape.build_file_versions_to_delete_table]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.build_file_versions_to_delete_table]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.build_file_versions_to_delete_table]
GO


--------------------------------------------------------------------------------
-- [Tape.clear_orphan_file_parts]
PRINT N'Creating [dbo].[Tape.clear_orphan_file_parts]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.clear_orphan_file_parts]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.clear_orphan_file_parts]
GO


--------------------------------------------------------------------------------
-- [Tape.clear_orphan_file_versions]
PRINT N'Creating [dbo].[Tape.clear_orphan_file_versions]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.clear_orphan_file_versions]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.clear_orphan_file_versions]
GO


--------------------------------------------------------------------------------
-- [Tape.clear_orphan_files]
PRINT N'Creating [dbo].[Tape.clear_orphan_files]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.clear_orphan_files]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.clear_orphan_files]
GO


--------------------------------------------------------------------------------
-- [Tape.clear_orphan_directories]
PRINT N'Creating [dbo].[Tape.clear_orphan_directories]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.clear_orphan_directories]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.clear_orphan_directories]
GO


--------------------------------------------------------------------------------
PRINT N'Creating [dbo].[Tape.GetNearestDirectoryAndfileVersionsByParentIdAndBackupSetId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.GetNearestDirectoryAndfileVersionsByParentIdAndBackupSetId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.GetNearestDirectoryAndfileVersionsByParentIdAndBackupSetId]
GO
CREATE PROCEDURE [dbo].[Tape.GetNearestDirectoryAndfileVersionsByParentIdAndBackupSetId]	
	@directory_id bigint
	,@backup_set_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SET XACT_ABORT ON;


  BEGIN TRANSACTION
  DECLARE @id bigint
  SELECT TOP(1) @id = id FROM [Tape.directories] WITH (TABLOCKX)
  SELECT TOP(1) @id = id FROM [Tape.directory_versions] WITH (TABLOCKX)
  SELECT TOP(1) @id = id FROM [Tape.files] WITH (TABLOCKX)
  SELECT TOP(1) @id = id FROM [Tape.file_versions] WITH (TABLOCKX);
  --Enumerate directory and its childs into temp dir
   
 WITH directories
  AS
  (
    SELECT * 
    FROM [Tape.directories]
    WHERE id = @directory_id
    UNION ALL
    SELECT [Tape.directories].*
    FROM [Tape.directories] 
    INNER JOIN directories 
    ON [Tape.directories].parent_id = directories.id 
  )
  SELECT * INTO #directory_ids FROM directories OPTION (MAXRECURSION 32767)

  SELECT id into #matched_backup_sets
    FROM [Tape.backup_sets] 
    WHERE write_time <= 
    (
      SELECT write_time 
      FROM [Tape.backup_sets] 
      WHERE id = @backup_set_id
    );
  --Enumerate top 1 closest directory versions to temp table. 1 as tabletype - means this is directories (for buisness logic) 
  

  

   with sorted_dirs as (
    SELECT 
    dv.*, 
    row_number() OVER
    (
      PARTITION BY directory_id 
      ORDER BY dv.last_write_time DESC, bs.write_time DESC
    ) AS row 
  
  FROM [Tape.directory_versions] dv 
  JOIN #directory_ids dirs ON dirs.id = dv.directory_id
  JOIN [Tape.backup_sets] bs ON dv.backup_set_id = bs.id
  WHERE dv.backup_set_id 
  IN 
  (
    select id from #matched_backup_sets
  )  )

  select * INTO #last_dir_versions_by_dir_ids from sorted_dirs
  where row = '1';

  

   with sorted_files as (SELECT    
    fv.*, f_d.directory_id,
    row_number() OVER
    (
      PARTITION BY fv.file_id 
      ORDER BY fv.last_write_time DESC, bs.write_time DESC
    ) AS Row 
  FROM 
  (
    SELECT f.*
    FROM [Tape.files] f 
    JOIN #directory_ids dirs
    ON f.directory_id = dirs.id
  ) f_d
  JOIN [Tape.file_versions] fv ON fv.file_id = f_d.id 
  JOIN [Tape.backup_sets] bs ON fv.backup_set_id = bs.id
  WHERE 
	fv.corrupted = 0 and 
	fv.incomplete = 0 and 
	fv.backup_set_id IN (select id from #matched_backup_sets) 
  )

  select * INTO #last_file_versions_by_dir_ids from sorted_files
  where row = '1'


  COMMIT  TRANSACTION    
  SELECT *, 1 as tabletype from #last_dir_versions_by_dir_ids 
  SELECT *, 2 as tabletype FROM #last_file_versions_by_dir_ids 
END
go

--------------------------------------------------------------------------------
-- Tape.update_tape_medium_write_protected
PRINT N'Creating [dbo].[Tape.update_tape_medium_write_protected]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_write_protected]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_write_protected]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_write_protected]
	@id uniqueidentifier
	,@write_protected bit
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		is_write_protected = @write_protected
		,usn = @usn
	WHERE
		id = @id
END
GO

--------------------------------------------------------------------------------
-- Tape.clear_tape_medium
PRINT N'Creating [dbo].[Tape.clear_tape_medium]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.clear_tape_medium]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.clear_tape_medium]
GO
CREATE PROCEDURE [dbo].[Tape.clear_tape_medium]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRANSACTION;
	
	DECLARE @usn bigint

	exec [dbo].[IncrementUsn] @usn OUTPUT;

	DECLARE @media_family_id int
	SELECT @media_family_id = media_family_id FROM [Tape.tape_mediums] WHERE id = @id

	UPDATE [Tape.tape_mediums]
	SET 
		media_family_id = NULL, 
		media_sequence_number = NULL,  
		media_sequence_number_unique = NULL,  
		media_time = NULL,
		continuation = 0, 
		is_full = 0, 
		last_write_time = NULL,
		-- media_id = NULL, //Commented by AT - we need media id to be persistent for standalone drives support
		media_label = NULL,
		format_logical_address = 0,
		remaining = capacity,
		retired = 0,
		protected = 0,
		usn = @usn,
		outdated = 0,
		block_size = 0
	WHERE 
		id = @id

		-- close mediaset, if there are no tapes
	UPDATE [Tape.media_families] SET is_closed = 1 
		WHERE @media_family_id IS NOT NULL AND id = @media_family_id and lock_id IS NULL AND
			NOT EXISTS(SELECT * FROM [Tape.tape_mediums] where media_family_id = @media_family_id)

	COMMIT TRANSACTION;
END
GO

--------------------------------------------------------------------------------
-- Tape.move_media_pool
PRINT N'Creating [dbo].[Tape.move_media_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.move_media_pool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.move_media_pool]
GO


--------------------------------------------------------------------------------
-- Tape.set_media_pool_library
PRINT N'Creating [dbo].[Tape.set_media_pool_library]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.set_media_pool_library]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.set_media_pool_library]
GO



--------------------------------------------------------------------------------
-- Tape.get_media_pool_libraries
PRINT N'Creating [dbo].[Tape.get_media_pool_libraries]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_media_pool_libraries]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_media_pool_libraries]
GO
CREATE PROCEDURE [Tape.get_media_pool_libraries]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT library_id FROM [Tape.media_pool_libraries] WHERE media_pool_id = @media_pool_id ORDER BY priority
END
GO



--------------------------------------------------------------------------------
-- Tape.set_media_pool_libraries
PRINT N'Creating [dbo].[Tape.set_media_pool_libraries]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.set_media_pool_libraries]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.set_media_pool_libraries]
GO
CREATE PROCEDURE [Tape.set_media_pool_libraries]
	@media_pool_id uniqueidentifier
	,@libraries_ids xml
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	BEGIN TRANSACTION

	DELETE 
		[Tape.media_pool_libraries]
	WHERE 
		[Tape.media_pool_libraries].media_pool_id = @media_pool_id
	
	DECLARE @hdocument int
	EXEC sp_xml_preparedocument @hdocument OUTPUT, @libraries_ids

	DECLARE @priority int
	SET @priority = 0

	DECLARE @library_id uniqueidentifier

	DECLARE libraries_ids CURSOR FOR SELECT * FROM OPENXML(@hdocument, N'/ROOT/id', 1) WITH (id uniqueidentifier)
	OPEN libraries_ids

	WHILE (1 = 1)
	BEGIN
		FETCH NEXT FROM libraries_ids INTO @library_id
		IF (@@fetch_status <> 0)
			BREAK

		INSERT INTO 
			[Tape.media_pool_libraries] (media_pool_id, library_id, priority) 
		VALUES 
			(@media_pool_id, @library_id, @priority)

		SET @priority = @priority + 1
	END
		
	CLOSE libraries_ids
	DEALLOCATE libraries_ids
	
	EXEC sp_xml_removedocument @hdocument

	COMMIT TRANSACTION
END
GO

--------------------------------------------------------------------------------
-- Tape.lock_media_set
PRINT N'Creating [dbo].[Tape.lock_media_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.lock_media_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.lock_media_set]
GO
CREATE PROCEDURE [dbo].[Tape.lock_media_set]
	@media_set_id int, 
	@lock_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.media_families] SET lock_id = @lock_id WHERE id = @media_set_id AND lock_id IS NULL
	
	SELECT @@ROWCOUNT
END
GO

--------------------------------------------------------------------------------
-- Tape.unlock_media_set
PRINT N'Creating [dbo].[Tape.unlock_media_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.unlock_media_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.unlock_media_set]
GO
CREATE PROCEDURE [dbo].[Tape.unlock_media_set]
	@media_set_id int 
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.media_families] SET lock_id = NULL WHERE id = @media_set_id
END
GO

--------------------------------------------------------------------------------
-- Tape.close_media_set
PRINT N'Creating [dbo].[Tape.close_media_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.close_media_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.close_media_set]
GO
CREATE PROCEDURE [dbo].[Tape.close_media_set]
	@media_set_id int,
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE [Tape.media_families] 
	SET is_closed = 1
	WHERE id = ISNULL(@media_set_id, id) 
	AND media_pool_id = ISNULL(@media_pool_id, media_pool_id)
END
GO


--------------------------------------------------------------------------------
-- Tape.find_last_media_set
PRINT N'Creating [dbo].[Tape.find_last_media_set]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.find_last_media_set]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.find_last_media_set]
GO
CREATE PROCEDURE [dbo].[Tape.find_last_media_set]
	@media_pool_id uniqueidentifier,
	@media_set_type_id int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.media_families]  
	WHERE
	id IN (
		SELECT MAX(id) FROM [Tape.media_families] 
		WHERE media_pool_id = @media_pool_id
		AND type_id = @media_set_type_id
	)
END
GO

--------------------------------------------------------------------------------
-- Tape.get_opened_media_sets
PRINT N'Creating [dbo].[Tape.get_opened_media_sets]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_opened_media_sets]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_opened_media_sets]
GO
CREATE PROCEDURE [dbo].[Tape.get_opened_media_sets]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT * FROM [Tape.media_families]  
	WHERE media_pool_id = @media_pool_id
	AND is_closed = 0
END
GO

--------------------------------------------------------------------------------
-- Tape.update_tape_drive_current_block_size
PRINT N'Creating [dbo].[Tape.update_tape_drive_current_block_size]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_drive_current_block_size]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_drive_current_block_size]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_drive_current_block_size]
	@device_id uniqueidentifier
	,@current_block_size int
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE [Tape.tape_drives] SET current_block_size = @current_block_size WHERE device_id = @device_id
END
GO

--------------------------------------------------------------------------------
-- Tape.update_tape_medium_media_set_type
PRINT N'Creating [dbo].[Tape.update_tape_medium_media_set_type]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_media_set_type]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_media_set_type]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_media_set_type]
	@id uniqueidentifier
	,@media_set_type tinyint
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @usn bigint
	exec [dbo].[IncrementUsn] @usn OUTPUT;

	UPDATE [Tape.tape_mediums] SET
		media_set_type = @media_set_type
		,usn = @usn
	WHERE 
		id = @id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_last_not_failed_overall_tape_gfs_session
PRINT N'Creating [dbo].[Tape.get_last_not_failed_overall_tape_gfs_session]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_last_not_failed_overall_tape_gfs_session]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_last_not_failed_overall_tape_gfs_session]
GO
CREATE PROCEDURE [dbo].[Tape.get_last_not_failed_overall_tape_gfs_session]
	@job_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TOP(1) *
	FROM 
		[Backup.Model.JobSessions]
		INNER JOIN [Backup.Model.BackupJobSessions] ON [Backup.Model.JobSessions].id = [Backup.Model.BackupJobSessions].id
	WHERE 
		job_id = @job_id AND
		job_type = 28 AND		-- EDbJobType.VmTapeBackup
		result IN (0, 1) AND	-- EResult.Success || EResult.Warning
		session_algorithm = 20 AND	-- SessionAlgorithms.TapeGfsOverall
		run_manually = 0
	ORDER BY creation_time DESC
END
GO

--------------------------------------------------------------------------------
-- Tape.lock_opened_media_set_with_specific_free_space
PRINT N'Creating [dbo].[Tape.lock_opened_media_set_with_specific_free_space]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.lock_opened_media_set_with_specific_free_space]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.lock_opened_media_set_with_specific_free_space]
GO
CREATE PROCEDURE [dbo].[Tape.lock_opened_media_set_with_specific_free_space]
	@media_pool_id uniqueidentifier, 
	@lock_id uniqueidentifier,
	@max_free_space_required bit
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON;
	DECLARE @media_set_id int
	
	BEGIN TRAN
		SELECT 
		F.id,
		(SELECT TOP 1 M.id FROM [Tape.tape_mediums] M
					WHERE
						M.location_type IN (0, 1) AND
--						M.is_write_protected = 0 AND
						M.is_full = 0 AND
						M.media_family_id = F.id
					ORDER BY 
						M.last_write_time DESC,
						M.barcode ASC) as last_media_id
		INTO #free_families FROM [Tape.media_families] F WITH(XLOCK)
		WHERE
		F.media_pool_id = @media_pool_id AND
		F.is_closed = 0 AND
		F.lock_id is NULL

		IF (@max_free_space_required = 1) 
			SELECT TOP 1 @media_set_id = F.id FROM #free_families F
			LEFT OUTER JOIN [Tape.tape_mediums] M ON F.last_media_id = M.id		
			ORDER BY M.remaining  DESC
		ELSE--MIN SPACE REST REQUIRED
			SELECT TOP 1 @media_set_id = F.id FROM #free_families F
			LEFT OUTER JOIN [Tape.tape_mediums] M ON F.last_media_id = M.id		
			ORDER BY M.remaining  ASC

								
		UPDATE [Tape.media_families] SET lock_id = @lock_id WHERE id = @media_set_id AND lock_id IS NULL
		
	COMMIT TRAN

	SELECT * FROM [Tape.media_families]  WHERE id = @media_set_id AND lock_id = @lock_id
END
GO


--------------------------------------------------------------------------------
-- Tape.get_duplicate_barcode_online_tapes
PRINT N'Creating [dbo].[Tape.get_duplicate_barcode_online_tapes]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_duplicate_barcode_online_tapes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_duplicate_barcode_online_tapes]
GO
CREATE PROCEDURE [Tape.get_duplicate_barcode_online_tapes]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT barcode INTO #barcodes FROM [Tape.tape_mediums] WHERE ISNULL(barcode, '') <> '' GROUP BY barcode HAVING COUNT(barcode) > 1
	CREATE CLUSTERED INDEX idx ON #barcodes (barcode)

	SELECT t.* FROM #barcodes b INNER JOIN [Tape.tape_mediums] t ON b.barcode = t.barcode WHERE t.location_type IN (0, 1)
END
GO


--------------------------------------------------------------------------------
-- Tape.clear_tape_backups
PRINT N'Creating [dbo].[Tape.clear_tape_backups]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.clear_tape_backups]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.clear_tape_backups]
GO
CREATE PROCEDURE [Tape.clear_tape_backups]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT 
		backup_id 
	INTO 
		#tapeBackupIds 
	FROM 
		[Tape.backup_sets]

	CREATE INDEX [backup_id] ON #tapeBackupIds (backup_id)

	DELETE FROM 
		[Tape.backups] 
	WHERE 
		job_id IS NULL AND 
		id NOT IN (SELECT backup_id FROM #tapeBackupIds) AND 
		id <> '437913A2-1D8E-4D74-BB0D-4FDEC6771A6C'
END
GO


--------------------------------------------------------------------------------
-- Tape.get_jobs_by_repository_id
PRINT N'Creating [dbo].[Tape.get_jobs_by_repository_id]'

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_jobs_by_repository_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_jobs_by_repository_id]
GO

CREATE PROCEDURE [dbo].[Tape.get_jobs_by_repository_id]
		@repositoryId uniqueidentifier
AS
BEGIN

	SELECT TJ.* FROM [Tape.jobs] TJ
	WHERE TJ.id in (
		SELECT LR.job_id  FROM [dbo].[LinkedBackupRepositories] LR WHERE LR.linked_backup_repository_id = @repositoryId)
	   
END	
GO


--------------------------------------------------------------------------------
-- Tape.replace_source_repository_in_job
PRINT N'Creating [dbo].[Tape.replace_source_repository_in_job]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.replace_source_repository_in_job]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.replace_source_repository_in_job]
GO

CREATE PROCEDURE [dbo].[Tape.replace_source_repository_in_job]
		@jobId uniqueidentifier,
		@repositoryIdToDelete uniqueidentifier,
		@repositoryIdToAdd uniqueidentifier
AS
BEGIN
	SET XACT_ABORT ON;

	BEGIN TRAN
		IF (NOT EXISTS(SELECT LR.job_id  FROM [dbo].[LinkedBackupRepositories] LR WHERE LR.linked_backup_repository_id = @repositoryIdToDelete AND job_id = @jobId))
		BEGIN
		    COMMIT TRAN
			RETURN 0;
		END
		DECLARE @last_state int;
		SELECT TOP 1 @last_state = state FROM [dbo].[Backup.Model.JobSessions] 
		WHERE job_id = @jobId
		ORDER BY [creation_time] DESC --SELECT IS REQUIRED TO LOCK RECORD FOR WRITE
		if (@last_state != -1)
		BEGIN
		    COMMIT TRAN
			RETURN 0;
		END
		DELETE FROM [dbo].[LinkedBackupRepositories] WHERE linked_backup_repository_id = @repositoryIdToDelete AND job_id = @jobId
		DECLARE @result int;
		IF EXISTS(SELECT * FROM [dbo].[LinkedBackupRepositories] WHERE linked_backup_repository_id = @repositoryIdToAdd AND job_id = @jobId)
		BEGIN
		    SET @result = 1;
    	END
        ELSE BEGIN
            INSERT INTO [dbo].[LinkedBackupRepositories](job_id, linked_backup_repository_id, usn, creation_time) VALUES(@jobId, @repositoryIdToAdd, 0, GETDATE())
            SET @result = @@ROWCOUNT;
        END
	COMMIT TRAN
	RETURN @result;
END	
GO


--------------------------------------------------------------------------------
-- Tape.update_file_version_incomplete
PRINT N'Creating [dbo].[Tape.update_file_version_incomplete]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_file_version_incomplete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_file_version_incomplete]
GO

CREATE  PROCEDURE [Tape.update_file_version_incomplete]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @file_version_id bigint
	DECLARE @parts int
	DECLARE @tapes int
	DECLARE @incompletes int

	DECLARE c CURSOR FOR SELECT DISTINCT file_version_id FROM [Tape.file_parts] WHERE incompletion <> 0
	OPEN c

	FETCH NEXT FROM c INTO @file_version_id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @parts = COUNT(*), @tapes = MAX(media_sequence_number) - MIN(media_sequence_number) + 1 FROM [Tape.file_parts] WHERE file_version_id = @file_version_id
		SELECT @incompletes = COUNT(*) FROM [Tape.file_parts] WHERE file_version_id = @file_version_id AND incompletion IN (1, 2)

		IF (@parts = @tapes AND @incompletes = 2)
		BEGIN
			UPDATE [Tape.file_versions] SET incomplete = 0 WHERE id = @file_version_id
		END
		ELSE
		BEGIN
			UPDATE [Tape.file_versions] SET incomplete = 1 WHERE id = @file_version_id
		END

		FETCH NEXT FROM c INTO @file_version_id
	END

	CLOSE c
	DEALLOCATE c
END
GO

--------------------------------------------------------------------------------
-- Tape.get_backup_set_backup_meta
PRINT N'Creating [dbo].[Tape.get_backup_set_backup_meta]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.get_backup_set_backup_meta]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.get_backup_set_backup_meta]
GO
CREATE PROCEDURE [dbo].[Tape.get_backup_set_backup_meta]
	@id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT backup_meta FROM [Tape.backup_sets] WHERE id = @id
END
GO

--------------------------------------------------------------------------------
-- Tape.update_backup_set_backup_meta
PRINT N'Creating [dbo].[Tape.update_backup_set_backup_meta]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.update_backup_set_backup_meta]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.update_backup_set_backup_meta]
GO
CREATE PROCEDURE [dbo].[Tape.update_backup_set_backup_meta]
	@id uniqueidentifier
	,@backup_meta [varbinary](max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @usn bigint
	EXEC [dbo].[IncrementUsn] @usn OUTPUT

	UPDATE 
		[Tape.backup_sets] 
	SET
		backup_meta = @backup_meta
		,usn = @usn
	WHERE
		id = @id	
END
GO


--------------------------------------------------------------------------------
-- Tape.get_storages_for_restore
PRINT N'Creating [dbo].[Tape.get_storages_for_restore]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Tape.get_storages_for_restore]') AND type in (N'P', N'PC'))
DROP PROCEDURE [Tape.get_storages_for_restore]
GO
CREATE PROCEDURE [dbo].[Tape.get_storages_for_restore]
	@oib_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	WITH oibs (id, link_id, storage_id, num) 
	AS
	(
		SELECT id, link_id, storage_id, 0 FROM [Backup.Model.OIBs] WHERE id = @oib_id
		UNION ALL
		SELECT p.id, p.link_id, p.storage_id, c.num + 1 FROM [Backup.Model.OIBs] p INNER JOIN oibs c ON p.id = c.link_id 
	)
	SELECT id, storage_id, num INTO #oibs FROM oibs

	DECLARE @storage_id uniqueidentifier
	SELECT TOP(1) @storage_id = storage_id FROM #oibs ORDER BY num DESC;

	WITH storages (id, link_id, file_path)
	AS
	(
		SELECT s.id, s.link_id, s.file_path FROM [Backup.Model.Storages] s WHERE s.id = @storage_id AND RIGHT(s.file_path, 3) = 'vib'
		UNION ALL
		SELECT p.id, p.link_id, p.file_path FROM [Backup.Model.Storages] p INNER JOIN storages c ON p.id = c.link_id WHERE RIGHT(c.file_path, 3) = 'vib'
	)
	SELECT id INTO #storages FROM storages
	UNION
	SELECT #oibs.storage_id FROM #oibs

	CREATE CLUSTERED INDEX id ON #storages(id)

	SELECT s.* FROM [Tape.storages] s INNER JOIN #storages ON s.tape_storage_id = #storages.id
END	
GO

-- Tape.get_max_mediasets_number_in_pool
PRINT N'Creating [dbo].[Tape.get_mediasets_count_in_pool]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_mediasets_count_in_pool]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.get_mediasets_count_in_pool]
GO
CREATE PROCEDURE [dbo].[Tape.get_mediasets_count_in_pool]
	@media_pool_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT COUNT(id) from [Tape.media_families] 
	WHERE media_pool_id = @media_pool_id
END
GO

--------------------------------------------------------------------------------
-- Tape.is_device_exists
PRINT N'Creating [dbo].[Tape.is_device_exists]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.is_device_exists]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.is_device_exists]
GO

	CREATE PROCEDURE [dbo].[Tape.is_device_exists]	
	AS
	BEGIN
		SET NOCOUNT ON;

		IF EXISTS
			(SELECT 
				*
			FROM
				[dbo].[Tape.devices])
			SELECT 1 result
		ELSE
			SELECT 0 result
		
	END
GO


--------------------------------------------------------------------------------
-- Tape.update_backup_set_encrypted_imported_backup_id
PRINT N'Creating [dbo].[Tape.update_backup_set_encrypted_imported_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_backup_set_encrypted_imported_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_backup_set_encrypted_imported_backup_id]
GO
CREATE PROCEDURE [Tape.update_backup_set_encrypted_imported_backup_id]
	@backup_set_id uniqueidentifier
	,@encrypted_imported_backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE
		[Tape.backup_sets]
	SET
		encrypted_imported_backup_id = @encrypted_imported_backup_id
	WHERE
		id = @backup_set_id
END
GO

--------------------------------------------------------------------------------
-- Tape.get_backup_set_by_encrypted_imported_backup_id
PRINT N'Creating [dbo].[Tape.get_backup_set_by_encrypted_imported_backup_id]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.get_backup_set_by_encrypted_imported_backup_id]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.get_backup_set_by_encrypted_imported_backup_id]
GO
CREATE PROCEDURE [Tape.get_backup_set_by_encrypted_imported_backup_id]
	@encrypted_imported_backup_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [Tape.backup_sets] WHERE encrypted_imported_backup_id = @encrypted_imported_backup_id
	END
GO


--------------------------------------------------------------------------------
-- Tape.clear_encrypted_imported_backups
PRINT N'Creating [dbo].[Tape.clear_encrypted_imported_backups]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.clear_encrypted_imported_backups]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.clear_encrypted_imported_backups]
GO
CREATE PROCEDURE [Tape.clear_encrypted_imported_backups]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT encrypted_imported_backup_id id INTO #encryptedImportedBackupIds FROM [Tape.backup_sets]
	CREATE INDEX id ON #encryptedImportedBackupIds (id)

	SELECT id id INTO #encryptedImportedBackupIdsToDelete FROM [Tape.encrypted_imported_backups] WHERE id NOT IN (SELECT id FROM #encryptedImportedBackupIds)
	CREATE INDEX id ON #encryptedImportedBackupIdsToDelete (id)

	DELETE FROM [Backup.Model.EncryptedImportBackups] WHERE id IN (SELECT id FROM #encryptedImportedBackupIdsToDelete)
	DELETE FROM [Tape.encrypted_imported_backups] WHERE id IN (SELECT id FROM #encryptedImportedBackupIdsToDelete)
END
GO


--------------------------------------------------------------------------------
-- [Tape.GetTapeJobsByObjects]
PRINT N'Creating [dbo].[Tape.GetTapeJobsByObjects]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.GetTapeJobsByObjects]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.GetTapeJobsByObjects]
GO
CREATE PROCEDURE [dbo].[Tape.GetTapeJobsByObjects]
AS
BEGIN

select distinct tapeJobs.id as jobId
    from #temp_GetTapeJobsByObjects inputIds
    inner join [dbo].[BObjects] as bobjects on bobjects.id = inputIds.objId
	inner join [dbo].[Backup.Model.OIBs] as oibs on oibs.object_id = bobjects.id
	inner join [dbo].[Tape.storages] as tapeStorages on oibs.storage_id = tapeStorages.tape_storage_id
	inner join [dbo].[Tape.backup_sets] as backupSets on (backupSets.media_family_id = tapeStorages.media_family_id and backupSets.number = tapeStorages.session_number)
	inner join [dbo].[Tape.backups] as backups on backups.id = backupSets.backup_id
	inner join [dbo].[Tape.jobs] as tapeJobs on tapeJobs.id = backups.job_id

END
GO

--------------------------------------------------------------------------------
-- [Tape.GetTapeProxyHostsByJobs]
PRINT N'Creating [dbo].[Tape.GetTapeProxyHostsByJobs]'
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.GetTapeProxyHostsByJobs]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Tape.GetTapeProxyHostsByJobs]
GO
CREATE PROCEDURE [dbo].[Tape.GetTapeProxyHostsByJobs]
AS
BEGIN

select distinct host.id as hostId
    from #temp_GetTapeProxyHostsByJobs inputIds
	inner join [dbo].[Tape.jobs] as tapeJobs on tapeJobs.id = inputIds.jobId
	inner join [dbo].[Tape.media_pool_libraries] mlib on mlib.media_pool_id in (tapeJobs.full_mediapool_id, tapeJobs.incremental_mediapool_id)
	inner join [dbo].[Tape.libraries] lib on lib.id = mlib.library_id
	inner join [dbo].[BackupProxies] proxies on proxies.id = lib.tape_server_id
	inner join [dbo].[Hosts] host on host.id = proxies.host_id

END
GO


--------------------------------------------------------------------------------
-- Tape.update_tape_medium_family_id_and_sequence_number
PRINT N'Creating [dbo].[Tape.update_tape_medium_family_id_and_sequence_number]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Tape.update_tape_medium_family_id_and_sequence_number]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Tape.update_tape_medium_family_id_and_sequence_number]
GO
CREATE PROCEDURE [dbo].[Tape.update_tape_medium_family_id_and_sequence_number]
	@id uniqueidentifier
	,@media_family_id int
	,@media_sequence_number int
AS
BEGIN
	SET NOCOUNT ON;

	SET XACT_ABORT ON;

	BEGIN TRANSACTION

	IF EXISTS(
		SELECT *
		FROM [Tape.tape_mediums] 
		WITH (TABLOCKX, HOLDLOCK)
		WHERE
			id <> @id AND
			media_family_id IS NOT NULL AND 
			media_sequence_number IS NOT NULL AND
			media_family_id = @media_family_id AND 
			media_sequence_number = @media_sequence_number)
	BEGIN
		DECLARE @error_message NVARCHAR(MAX)
		SET @error_message = 'Duplicate tapes with the same family id (' + CAST(@media_family_id AS NVARCHAR(MAX)) + ') and sequence number (' + CAST(@media_sequence_number AS NVARCHAR(MAX)) + ')'

		ROLLBACK TRANSACTION
		RAISERROR(@error_message, 18, 1)
		RETURN
	END

	UPDATE [Tape.tape_mediums] SET
		media_family_id = @media_family_id
		,media_sequence_number = @media_sequence_number
		,media_sequence_number_unique = @media_sequence_number
	WHERE
		id = @id

	COMMIT TRANSACTION
END
GO
