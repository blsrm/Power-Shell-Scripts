SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Hosts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Hosts](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Hosts_id]  DEFAULT (newid()),
    [type] [int] NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [ip] [nvarchar](50) NULL,
    [parent_id] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Hosts] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [IX_Hosts] UNIQUE NONCLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Folders]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Folders](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Folders_id]  DEFAULT (newid()),
    [parent_id] [uniqueidentifier] NULL,
    [name] [nvarchar](255) NULL,
 CONSTRAINT [PK_Folders] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Version]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Version]([current_version] int) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Folder_Host]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Folder_Host](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Folder_Host_id]  DEFAULT (newid()),
    [folder_id] [uniqueidentifier] NOT NULL,
    [host_id] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Folder_Host] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ObjectsInJobs]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ObjectsInJobs](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_ObjectsInJobs_id]  DEFAULT (newid()),
    [job_id] [uniqueidentifier] NOT NULL,
    [object_id] [uniqueidentifier] NULL,
    [folder_id] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ObjectsInJobs] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Soap_creds]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Soap_creds](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Soap_creds_id]  DEFAULT (newid()),
    [host_id] [uniqueidentifier] NOT NULL,
    [port] [int] NOT NULL,
    [user] [nvarchar](255) NOT NULL,
    [password] [nvarchar](512) NULL,
    [savepassword] [bit] NOT NULL,
    [useproxy] [bit] NOT NULL,
    [proxyip] [nvarchar](50) NULL,
    [proxyport] [int] NULL,
 CONSTRAINT [PK_Soap_creds] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BJobs]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BJobs](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_BJobs_id]  DEFAULT (newid()),
    [type] [int] NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [target_host_id] [uniqueidentifier] NOT NULL,
    [target_dir] [nvarchar](1000) NOT NULL,
    [target_file] [nvarchar](255) NULL,
    [options] [xml] NULL,
    [schedule] [xml] NULL,
    [is_deleted] [bit] NOT NULL DEFAULT ((0)),
    [latest_result] [int] NOT NULL DEFAULT ((-1)),
 CONSTRAINT [PK_BJobs] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BObjects]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BObjects](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_BObjects_ID]  DEFAULT (newid()),
    [type] [int] NOT NULL,
    [host_id] [uniqueidentifier] NOT NULL,
    [object_name] [nvarchar](255) NULL,
    [object_id] [nvarchar](400) NOT NULL,
    [viobject_type] [nvarchar](50) NULL,
 CONSTRAINT [PK_BObjects] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BObjects]') AND name = N'IX_BObjects')
CREATE UNIQUE NONCLUSTERED INDEX [IX_BObjects] ON [dbo].[BObjects] 
(
    [host_id] ASC,
    [object_id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backups]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Backups](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Backups_ID]  DEFAULT (newid()),
    [creation_time] [datetime] NOT NULL,
    [is_rollback] [bit] NOT NULL,
    [host_id] [uniqueidentifier] NOT NULL,
    [linked_rollback] [uniqueidentifier] NULL,
    [job_name] [nvarchar](255) NOT NULL,
    [job_id] [uniqueidentifier] NULL,
    [job_type] [int] NOT NULL DEFAULT ((0)),
    [is_retry] [bit] NOT NULL DEFAULT ((0)),
 CONSTRAINT [PK_Backups] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[onBackupDelete]'))
EXEC dbo.sp_executesql @statement = N'
    CREATE TRIGGER [dbo].[onBackupDelete]
       ON  [dbo].[Backups] 
       instead of delete
    AS 
    BEGIN
        declare @bk uniqueidentifier
        select @bk = id from deleted
        print ''id of record = '' + cast (@bk as nvarchar(256))
        print ''deleting''
        update BSessionInfo set backup_id = null where backup_id = @bk
        delete from ObjectsInBackups where backup_id = @bk
        delete from Backups where id = @bk
    END
    ' 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Ssh_creds]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Ssh_creds](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Ssh_creds_id]  DEFAULT (newid()),
    [host_id] [uniqueidentifier] NOT NULL,
    [user] [nvarchar](255) NOT NULL,
    [password] [nvarchar](512) NULL,
    [savepassword] [bit] NOT NULL,
    [elevatetoroot] [bit] NOT NULL,
    [rootpassword] [nvarchar](512) NULL,
    [port] [int] NOT NULL,
    [startftport] [int] NOT NULL,
    [endftport] [int] NOT NULL,
    [buffersize] [int] NOT NULL,
    [isftserver] [bit] NOT NULL,
    [timeout] [int] NOT NULL,
 CONSTRAINT [PK_Ssh_creds] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BSessions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BSessions](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_BSessions_id]  DEFAULT (newid()),
    [creation_time] [datetime] NOT NULL,
    [job_id] [uniqueidentifier] NULL,
    [job_name] [nvarchar](255) NOT NULL,
    [overall_status] [int] NOT NULL CONSTRAINT [DF_BSessions_overall_status]  DEFAULT ((-1)),
    [progress] [int] NOT NULL DEFAULT ((0)),
    [description] [text] NULL DEFAULT (NULL),
    [job_type] [int] NOT NULL DEFAULT ((0)),
    [is_retry] [bit] NOT NULL DEFAULT ((0)),
 CONSTRAINT [PK_BSessions] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[onSessionDelete]'))
EXEC dbo.sp_executesql @statement = N'
    create trigger [dbo].[onSessionDelete] ON  [dbo].[BSessions] instead of delete
    AS 
    BEGIN
        declare @s uniqueidentifier
        select @s = id from deleted
        delete from BSessionInfo where session_id = @s
        delete from BSessions where id = @s
    END    
    ' 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ObjectsInBackups]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ObjectsInBackups](
    [id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_ObjectsInBackups_id]  DEFAULT (newid()),
    [object_id] [uniqueidentifier] NOT NULL,
    [backup_id] [uniqueidentifier] NOT NULL,
    [filename] [nvarchar](1000) NULL,
    [is_corrupted] [bit] NOT NULL DEFAULT ((0)),
    [is_running] [bit] NOT NULL DEFAULT ((0)),
    [next_id] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ObjectsInBackups_1] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BSessionInfo]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BSessionInfo](
    [id] [uniqueidentifier] NOT NULL,
    [session_id] [uniqueidentifier] NOT NULL,
    [creation_time] [datetime] NOT NULL,
    [object_name] [nvarchar](255) NOT NULL,
    [status] [int] NOT NULL CONSTRAINT [DF_BSessionInfo_status]  DEFAULT ((-1)),
    [reason] [ntext] NULL,
    [backup_id] [uniqueidentifier] NULL,
    [object_id] [uniqueidentifier] NULL,
 CONSTRAINT [PK_BSessionInfo] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LicensedHosts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LicensedHosts](
    [id] [uniqueidentifier] NOT NULL,
    [uuid] [nvarchar](255) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [cpu] [int] NOT NULL,
 CONSTRAINT [PK_LicensedHosts] PRIMARY KEY CLUSTERED 
(
    [id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
if not exists (select * from sys.sysobjects where id = OBJECT_ID(N'[dbo].[TrackChange]'))
begin
    exec sp_executesql @statement = N'
    CREATE PROCEDURE [dbo].[TrackChange] 
	    -- Add the parameters for the stored procedure here
	    @table_name nvarchar(50),
	    @row_id uniqueidentifier,
	    @change_type int
    AS
    BEGIN
	    SET NOCOUNT ON;
	    declare @lastId int
    END
    '
end
GO
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[i_BSessions]'))
begin
	declare @tables table (prefix nvarchar(255), owner nvarchar(255), tname nvarchar(255), ttype nvarchar(255), rem nvarchar(255))
	insert into @tables exec sp_tables null, 'dbo'

	declare @cur_tables cursor
	set @cur_tables = cursor local for select tname from @tables
	open @cur_tables

	declare @tname nvarchar(255)
	fetch next from @cur_tables into @tname
	while @@fetch_status = 0
	begin
		if not (@tname = 'Version' OR 
					@tname = 'sysdiagrams' OR 
					@tname = 'Track_changes' OR
					@tname = 'log')
		begin
			declare @text nvarchar(1024)
			declare @script nvarchar (1024)
			select @text = N'
			create trigger !!## on [dbo].[##] for ^^ 
			as
			begin
				declare @id uniqueidentifier
				select @id = id from $$
				if not @id is null
					exec dbo.TrackChange ''##'', @id, %%
			end
			'
			IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[i_' + @tname + ']'))
			begin
				select @script = replace (@text, '##', @tname)
				select @script = replace (@script, '!!', 'i_')
				select @script = replace (@script, '^^', 'insert')
				select @script = replace (@script, '$$', 'inserted')
				select @script = replace (@script, '%%', '0')
				print @script

				EXEC dbo.sp_executesql @statement = @script
				print 'Trigger after insert added ' + @tname
			end
	                
			IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[u_' + @tname + ']'))
			begin
				select @script = replace (@text, '##', @tname)
				select @script = replace (@script, '!!', 'u_')
				select @script = replace (@script, '^^', 'update')
				select @script = replace (@script, '$$', 'inserted')
				select @script = replace (@script, '%%', '1')
				print @script

				EXEC dbo.sp_executesql @statement = @script
				print 'Trigger after update added ' + @tname
			end
	        
			IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[d_' + @tname + ']'))
			begin
				select @script = replace (@text, '##', @tname)
				select @script = replace (@script, '!!', 'd_')
				select @script = replace (@script, '^^', 'delete')
				select @script = replace (@script, '$$', 'deleted')
				select @script = replace (@script, '%%', '2')
				print @script

				EXEC dbo.sp_executesql @statement = @script
				print 'Trigger after delete added ' + @tname
			end
		end
		fetch next from @cur_tables into @tname
	end
end
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Folders_Folders]') AND parent_object_id = OBJECT_ID(N'[dbo].[Folders]'))
ALTER TABLE [dbo].[Folders]  WITH CHECK ADD  CONSTRAINT [FK_Folders_Folders] FOREIGN KEY([parent_id])
REFERENCES [dbo].[Folders] ([id])
GO
ALTER TABLE [dbo].[Folders] CHECK CONSTRAINT [FK_Folders_Folders]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Folder_Host_Folders]') AND parent_object_id = OBJECT_ID(N'[dbo].[Folder_Host]'))
ALTER TABLE [dbo].[Folder_Host]  WITH CHECK ADD  CONSTRAINT [FK_Folder_Host_Folders] FOREIGN KEY([folder_id])
REFERENCES [dbo].[Folders] ([id])
GO
ALTER TABLE [dbo].[Folder_Host] CHECK CONSTRAINT [FK_Folder_Host_Folders]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Folder_Host_Hosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[Folder_Host]'))
ALTER TABLE [dbo].[Folder_Host]  WITH CHECK ADD  CONSTRAINT [FK_Folder_Host_Hosts] FOREIGN KEY([host_id])
REFERENCES [dbo].[Hosts] ([id])
GO
ALTER TABLE [dbo].[Folder_Host] CHECK CONSTRAINT [FK_Folder_Host_Hosts]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ObjectsInJobs_BJobs]') AND parent_object_id = OBJECT_ID(N'[dbo].[ObjectsInJobs]'))
ALTER TABLE [dbo].[ObjectsInJobs]  WITH CHECK ADD  CONSTRAINT [FK_ObjectsInJobs_BJobs] FOREIGN KEY([job_id])
REFERENCES [dbo].[BJobs] ([id])
GO
ALTER TABLE [dbo].[ObjectsInJobs] CHECK CONSTRAINT [FK_ObjectsInJobs_BJobs]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ObjectsInJobs_BObjects]') AND parent_object_id = OBJECT_ID(N'[dbo].[ObjectsInJobs]'))
ALTER TABLE [dbo].[ObjectsInJobs]  WITH CHECK ADD  CONSTRAINT [FK_ObjectsInJobs_BObjects] FOREIGN KEY([object_id])
REFERENCES [dbo].[BObjects] ([id])
GO
ALTER TABLE [dbo].[ObjectsInJobs] CHECK CONSTRAINT [FK_ObjectsInJobs_BObjects]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ObjectsInJobs_Folders]') AND parent_object_id = OBJECT_ID(N'[dbo].[ObjectsInJobs]'))
ALTER TABLE [dbo].[ObjectsInJobs]  WITH CHECK ADD  CONSTRAINT [FK_ObjectsInJobs_Folders] FOREIGN KEY([folder_id])
REFERENCES [dbo].[Folders] ([id])
GO
ALTER TABLE [dbo].[ObjectsInJobs] CHECK CONSTRAINT [FK_ObjectsInJobs_Folders]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Soap_creds_Hosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[Soap_creds]'))
ALTER TABLE [dbo].[Soap_creds]  WITH CHECK ADD  CONSTRAINT [FK_Soap_creds_Hosts] FOREIGN KEY([host_id])
REFERENCES [dbo].[Hosts] ([id])
GO
ALTER TABLE [dbo].[Soap_creds] CHECK CONSTRAINT [FK_Soap_creds_Hosts]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BJobs_Hosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[BJobs]'))
ALTER TABLE [dbo].[BJobs]  WITH CHECK ADD  CONSTRAINT [FK_BJobs_Hosts] FOREIGN KEY([target_host_id])
REFERENCES [dbo].[Hosts] ([id])
GO
ALTER TABLE [dbo].[BJobs] CHECK CONSTRAINT [FK_BJobs_Hosts]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BObjects_Hosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[BObjects]'))
ALTER TABLE [dbo].[BObjects]  WITH CHECK ADD  CONSTRAINT [FK_BObjects_Hosts] FOREIGN KEY([host_id])
REFERENCES [dbo].[Hosts] ([id])
GO
ALTER TABLE [dbo].[BObjects] CHECK CONSTRAINT [FK_BObjects_Hosts]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Backups_Backups]') AND parent_object_id = OBJECT_ID(N'[dbo].[Backups]'))
ALTER TABLE [dbo].[Backups]  WITH CHECK ADD  CONSTRAINT [FK_Backups_Backups] FOREIGN KEY([linked_rollback])
REFERENCES [dbo].[Backups] ([id])
GO
ALTER TABLE [dbo].[Backups] CHECK CONSTRAINT [FK_Backups_Backups]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Backups_BJobs]') AND parent_object_id = OBJECT_ID(N'[dbo].[Backups]'))
ALTER TABLE [dbo].[Backups]  WITH CHECK ADD  CONSTRAINT [FK_Backups_BJobs] FOREIGN KEY([job_id])
REFERENCES [dbo].[BJobs] ([id])
GO
ALTER TABLE [dbo].[Backups] CHECK CONSTRAINT [FK_Backups_BJobs]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Backups_Hosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[Backups]'))
ALTER TABLE [dbo].[Backups]  WITH CHECK ADD  CONSTRAINT [FK_Backups_Hosts] FOREIGN KEY([host_id])
REFERENCES [dbo].[Hosts] ([id])
GO
ALTER TABLE [dbo].[Backups] CHECK CONSTRAINT [FK_Backups_Hosts]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Ssh_creds_Hosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[Ssh_creds]'))
ALTER TABLE [dbo].[Ssh_creds]  WITH CHECK ADD  CONSTRAINT [FK_Ssh_creds_Hosts] FOREIGN KEY([host_id])
REFERENCES [dbo].[Hosts] ([id])
GO
ALTER TABLE [dbo].[Ssh_creds] CHECK CONSTRAINT [FK_Ssh_creds_Hosts]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BSessions_BJobs]') AND parent_object_id = OBJECT_ID(N'[dbo].[BSessions]'))
ALTER TABLE [dbo].[BSessions]  WITH CHECK ADD  CONSTRAINT [FK_BSessions_BJobs] FOREIGN KEY([job_id])
REFERENCES [dbo].[BJobs] ([id])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[BSessions] CHECK CONSTRAINT [FK_BSessions_BJobs]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ObjectsInBackups_Backups]') AND parent_object_id = OBJECT_ID(N'[dbo].[ObjectsInBackups]'))
ALTER TABLE [dbo].[ObjectsInBackups]  WITH CHECK ADD  CONSTRAINT [FK_ObjectsInBackups_Backups] FOREIGN KEY([backup_id])
REFERENCES [dbo].[Backups] ([id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ObjectsInBackups] CHECK CONSTRAINT [FK_ObjectsInBackups_Backups]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ObjectsInBackups_BObjects]') AND parent_object_id = OBJECT_ID(N'[dbo].[ObjectsInBackups]'))
ALTER TABLE [dbo].[ObjectsInBackups]  WITH CHECK ADD  CONSTRAINT [FK_ObjectsInBackups_BObjects] FOREIGN KEY([object_id])
REFERENCES [dbo].[BObjects] ([id])
GO
ALTER TABLE [dbo].[ObjectsInBackups] CHECK CONSTRAINT [FK_ObjectsInBackups_BObjects]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BSessionInfo_BSessions]') AND parent_object_id = OBJECT_ID(N'[dbo].[BSessionInfo]'))
ALTER TABLE [dbo].[BSessionInfo]  WITH CHECK ADD  CONSTRAINT [FK_BSessionInfo_BSessions] FOREIGN KEY([session_id])
REFERENCES [dbo].[BSessions] ([id])
GO
ALTER TABLE [dbo].[BSessionInfo] CHECK CONSTRAINT [FK_BSessionInfo_BSessions]
GO
ALTER TABLE [dbo].[BSessionInfo]  WITH CHECK ADD  CONSTRAINT [FK_BSessionInfo_Backups] FOREIGN KEY([backup_id]) REFERENCES [dbo].[Backups] ([id])
GO
ALTER TABLE [dbo].[BSessionInfo]  WITH CHECK ADD  CONSTRAINT [FK_BSessionInfo_BObjects] FOREIGN KEY([object_id]) REFERENCES [dbo].[BObjects] ([id])
GO
ALTER TABLE [dbo].[ObjectsInBackups]  WITH CHECK ADD  CONSTRAINT [FK_ObjectsInBackups_ObjectsInBackups] FOREIGN KEY([next_id]) REFERENCES [dbo].[ObjectsInBackups] ([id])
GO
ALTER TABLE [dbo].[Hosts]  WITH CHECK ADD  CONSTRAINT [FK_Hosts_Hosts] FOREIGN KEY([parent_id]) REFERENCES [dbo].[Hosts] ([id])
GO
if not exists (select * from [dbo].[Version])
BEGIN
	INSERT INTO [dbo].[Folders] ([id], [parent_id], [name]) VALUES ('4cebeb16-a4bb-4b9b-8cbb-67bbb8c59f0e','4cebeb16-a4bb-4b9b-8cbb-67bbb8c59f0e','Servers')
	INSERT INTO [dbo].[Folders] ([id], [parent_id], [name]) VALUES ('6938fc8c-7450-4c9e-8760-baf3b8dbb0cc','6938fc8c-7450-4c9e-8760-baf3b8dbb0cc','Backup')
	INSERT INTO [dbo].[Folders] ([id], [parent_id], [name]) VALUES ('aacdcffb-a706-4327-8884-8506e46275fc','6938fc8c-7450-4c9e-8760-baf3b8dbb0cc','Logs')
	INSERT INTO [dbo].[Folders] ([id], [parent_id], [name]) VALUES ('f52dcf05-839e-4f37-a269-9180e96d9b04','6938fc8c-7450-4c9e-8760-baf3b8dbb0cc','Replicas')
	INSERT INTO [dbo].[Folders] ([id], [parent_id], [name]) VALUES ('e5487d36-e764-48e6-9fab-b9ba692d924f','6938fc8c-7450-4c9e-8760-baf3b8dbb0cc','Backups')
	INSERT INTO [dbo].[Folders] ([id], [parent_id], [name]) VALUES ('ed083ca0-a8f5-49d1-bcf3-ca5d4abc1951','6938fc8c-7450-4c9e-8760-baf3b8dbb0cc','Jobs')
	INSERT INTO [dbo].[Hosts]   ([id] ,[type] ,[name],[ip]) VALUES ('6745a759-2205-4cd2-b172-8ec8f7e60ef8',3,'This server',NULL)
	INSERT INTO [dbo].[Version] ([current_version]) VALUES (12)
END
GO