﻿

--------------------------------------------------------------------------------
-- MaxValue
PRINT N'Creating [dbo].[MaxValue]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MaxValue]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[MaxValue]
GO

	CREATE FUNCTION [dbo].[MaxValue]
		(@x1 bigint, @x2 bigint)
	RETURNS bigint
	AS
	BEGIN
		  IF (@x1 > @x2 )
				RETURN @x1;
		  IF (@x1 < @x2 )
				RETURN @x2;
		  RETURN @x1;
	END

GO


--------------------------------------------------------------------------------
-- MaxValue3
PRINT N'Creating [dbo].[MaxValue3]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MaxValue3]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[MaxValue3]
GO

	CREATE FUNCTION [dbo].[MaxValue3]
		(@x1 bigint, @x2 bigint, @x3 bigint)
	RETURNS bigint
	AS
	BEGIN
		DECLARE @result bigint
		SELECT @result = 0
		IF (@x1 > @result)
			SELECT @result = @x1;
		IF (@x2 > @result)
			SELECT @result = @x2;
		IF (@x3 > @result)
			SELECT @result = @x3;
		RETURN @result;
	END

GO

--------------------------------------------------------------------------------
-- MaxValue4
PRINT N'Creating [dbo].[MaxValue4]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MaxValue4]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[MaxValue4]
GO

	CREATE FUNCTION [dbo].[MaxValue4]
		(@x1 bigint, @x2 bigint, @x3 bigint, @x4 bigint)
	RETURNS bigint
	AS
	BEGIN
		DECLARE @result bigint
		SELECT @result = 0
		IF (@x1 > @result)
			SELECT @result = @x1;
		IF (@x2 > @result)
			SELECT @result = @x2;
		IF (@x3 > @result)
			SELECT @result = @x3;
		IF (@x4 > @result)
			SELECT @result = @x4;
		RETURN @result;
	END

GO


--------------------------------------------------------------------------------
-- MaxValue5
PRINT N'Creating [dbo].[MaxValue5]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MaxValue5]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[MaxValue5]
GO

	CREATE FUNCTION [dbo].[MaxValue5]
		(@x1 bigint, @x2 bigint, @x3 bigint, @x4 bigint, @x5 bigint)
	RETURNS bigint
	AS
	BEGIN
		DECLARE @result bigint
		SELECT @result = 0
		IF (@x1 > @result)
			SELECT @result = @x1;
		IF (@x2 > @result)
			SELECT @result = @x2;
		IF (@x3 > @result)
			SELECT @result = @x3;
		IF (@x4 > @result)
			SELECT @result = @x4;
		IF (@x5 > @result)
			SELECT @result = @x5;		
		RETURN @result;
	END

GO

--------------------------------------------------------------------------------
-- MaxValue6
PRINT N'Creating [dbo].[MaxValue6]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MaxValue6]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[MaxValue6]
GO

CREATE FUNCTION [dbo].[MaxValue6] (
	 @val1 bigint
	,@val2 bigint
	,@val3 bigint
	,@val4 bigint
	,@val5 bigint
	,@val6 bigint
	)
RETURNS bigint
AS
BEGIN
		DECLARE @result bigint
		SELECT @result = 0
		IF (@val1 > @result)
			SELECT @result = @val1;
		IF (@val2 > @result)
			SELECT @result = @val2;
		IF (@val3 > @result)
			SELECT @result = @val3;
		IF (@val4 > @result)
			SELECT @result = @val4;
		IF (@val5 > @result)
			SELECT @result = @val5;
		IF (@val6 > @result)
			SELECT @result = @val6;
		RETURN @result;
END
GO


--------------------------------------------------------------------------------
-- MinValue
PRINT N'Creating [dbo].[MinValue]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MinValue]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[MinValue]
GO

	CREATE FUNCTION [dbo].[MinValue]
		(@x1 int, @x2 int)
	RETURNS int
	AS
	BEGIN
		  IF (@x1 > @x2 )
				RETURN @x2;
		  IF (@x1 < @x2 )
				RETURN @x1;
		  RETURN @x1;
	END

GO

--------------------------------------------------------------------------------
-- Split
PRINT N'Creating [dbo].[Split]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Split]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[Split]
GO

	CREATE FUNCTION [dbo].[Split]
		(@text nvarchar(max), @delimiter char(1) = ' ')
	RETURNS @Strings TABLE(position int IDENTITY PRIMARY KEY, value int)
	AS 
	BEGIN
		DECLARE @INDEX int    
		SET @INDEX = -1
		WHILE (LEN(@text) > 0)
		BEGIN        
			SET @INDEX = CHARINDEX(@delimiter , @text)        
			IF (@INDEX = 0) AND (LEN(@text) > 0)
			BEGIN   
				INSERT INTO @Strings VALUES (@text)   
				BREAK
			END        
			IF (@INDEX > 1)
			BEGIN   
				INSERT INTO @Strings VALUES (LEFT(@text, @INDEX - 1))   
				SET @text = RIGHT(@text, (LEN(@text) - @INDEX))
			END
			ELSE   
				SET @text = RIGHT(@text, (LEN(@text) - @INDEX))
		END
		RETURN
	END

GO


--------------------------------------------------------------------------------
-- ParseIdList
PRINT N'Creating [dbo].[ParseIdList]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ParseIdList]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[ParseIdList]
GO

CREATE FUNCTION [dbo].[ParseIdList](@xmlTable xml)
	RETURNS @xml TABLE ([id] uniqueidentifier)
	AS	
	BEGIN
		WITH pXml AS 
		(
		SELECT dataset.rowset.value('id[1]', 'uniqueidentifier') as id
			FROM @xmlTable.nodes('/dataset/row') as dataset(rowset)
		)
		INSERT @xml SELECT * FROM pXml
			RETURN
	END
GO


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MaxValue7]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[MaxValue7]
GO
CREATE FUNCTION [dbo].[MaxValue7] (
	 @val1 bigint
	,@val2 bigint
	,@val3 bigint
	,@val4 bigint
	,@val5 bigint
	,@val6 bigint
	,@val7 bigint
	)
RETURNS bigint
AS
BEGIN
		DECLARE @result bigint
		SELECT @result = 0
		IF (@val1 > @result)
			SELECT @result = @val1;
		IF (@val2 > @result)
			SELECT @result = @val2;
		IF (@val3 > @result)
			SELECT @result = @val3;
		IF (@val4 > @result)
			SELECT @result = @val4;
		IF (@val5 > @result)
			SELECT @result = @val5;
		IF (@val6 > @result)
			SELECT @result = @val6;
		IF (@val7 > @result)
			SELECT @result = @val7;
		RETURN @result;
END
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MaxValue2]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[MaxValue2]
GO
CREATE FUNCTION [dbo].[MaxValue2]
		(@x1 bigint, @x2 bigint)
	RETURNS bigint
	AS
	BEGIN
		DECLARE @result bigint
		SELECT @result = 0
		IF (@x1 > @result)
			SELECT @result = @x1;
		IF (@x2 > @result)
			SELECT @result = @x2;
		RETURN @result;
	END
GO

-- [dbo].[FindIndexColumnsByIndexAndTableName] --

PRINT N'Creating [dbo].[FindForeignKeysByTableAndIndexName]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindForeignKeysByTableAndIndexName]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[FindForeignKeysByTableAndIndexName] 
GO

CREATE FUNCTION [dbo].[FindForeignKeysByTableAndIndexName]
(
	@table_name nvarchar(128),
	@index_name nvarchar(128)
)
RETURNS
	@table TABLE
	(	
		fk_name nvarchar(128),
		fk_table_name nvarchar(128),
		column_name nvarchar(128),
		referenced_table_name nvarchar(128),
		referenced_column_name nvarchar(128),
		column_id nvarchar(128)
	)
AS
	BEGIN

	WITH foreign_keys AS (
		SELECT  
			obj.name AS FK_NAME,
			tab1.name AS [table],
			col1.name AS [column],
			tab2.name AS [referenced_table],
			col2.name AS [referenced_column], 
			fkc.constraint_column_id as column_id
		FROM sys.foreign_key_columns fkc
		INNER JOIN sys.objects obj
			ON obj.object_id = fkc.constraint_object_id
		INNER JOIN sys.tables tab1
			ON tab1.object_id = fkc.parent_object_id
		INNER JOIN sys.schemas sch
			ON tab1.schema_id = sch.schema_id
		INNER JOIN sys.columns col1
			ON col1.column_id = parent_column_id AND col1.object_id = tab1.object_id
		INNER JOIN sys.tables tab2
			ON tab2.object_id = fkc.referenced_object_id
		INNER JOIN sys.columns col2
			ON col2.column_id = referenced_column_id AND col2.object_id = tab2.object_id)
			INSERT @table(FK_name, fk_table_name, column_name, referenced_table_name, referenced_column_name, column_id)
	
		SELECT * FROM foreign_keys WHERE referenced_table = @table_name
		and referenced_column in (SELECT * FROM [FindIndexColumnsByIndexAndTableName](@table_name, @index_name))

	RETURN
END

GO

-- [dbo].[FindIndexColumnsByIndexAndTableName] --

PRINT N'Creating [dbo].[FindIndexColumnsByIndexAndTableName]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindIndexColumnsByIndexAndTableName]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[FindIndexColumnsByIndexAndTableName] 
GO


CREATE FUNCTION [dbo].[FindIndexColumnsByIndexAndTableName]
(
	@table_name nvarchar(128),
	@index_name nvarchar(128)
)
RETURNS
	@table TABLE
	(
		column_name nvarchar(128)
	)
AS
BEGIN

	INSERT @table(column_name)

	SELECT col.name as column_name
 
		FROM 
			 sys.indexes ind 
		INNER JOIN 
			 sys.index_columns ic ON  ind.object_id = ic.object_id and ind.index_id = ic.index_id 
		INNER JOIN 
			 sys.columns col ON ic.object_id = col.object_id and ic.column_id = col.column_id 
		INNER JOIN 
			 sys.tables t ON ind.object_id = t.object_id 
		WHERE 
			 t.name =  @table_name
			 AND ind.name = @index_name
		ORDER BY 
			 t.name, ind.name, ind.index_id, ic.index_column_id 

	RETURN
END

GO

-- [dbo].[FindPrimaryKeyByTable] --

PRINT N'Creating [dbo].[FindPrimaryKeyByTable]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindPrimaryKeyByTable]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[FindPrimaryKeyByTable] 
GO

CREATE FUNCTION [dbo].[FindPrimaryKeyByTable]
(
	@table_name nvarchar(128)
	
)
RETURNS
	@table TABLE
	(	
		PK_name nvarchar(128)
	)
AS

BEGIN

	
	WITH primary_keys AS
		(SELECT  i.name AS indexName,
				OBJECT_NAME(ic.OBJECT_ID) AS tableName,
				COL_NAME(ic.OBJECT_ID,ic.column_id) AS columnName
		FROM    sys.indexes AS i INNER JOIN 
				sys.index_columns AS ic ON  i.OBJECT_ID = ic.OBJECT_ID
										AND i.index_id = ic.index_id
		WHERE   i.is_primary_key = 1)

		INSERT INTO @table

		SELECT DISTINCT indexName FROM primary_keys WHERE tablename = @table_name;

		RETURN
END

GO


-- [dbo].[GetSortedIndexColumns] --

PRINT N'Creating [dbo].[GetSortedIndexColumns]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSortedIndexColumns]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[GetSortedIndexColumns] 
GO



CREATE FUNCTION [dbo].[GetSortedIndexColumns]
(
	@table_name nvarchar(128)	
)
RETURNS
	@table TABLE
	(
		table_name nvarchar(128),
		index_name nvarchar(128),
		column_name nvarchar(128),
		index_type nvarchar(128),
		is_primary_key int,
		index_number int,
		column_number int
	)
AS
	BEGIN
	WITH index_columns AS 
		(SELECT
			sys.objects.name as table_name,
			sys.indexes.name as index_name,
			sys.columns.name as column_name,
			sys.indexes.type_desc,
			sys.indexes.is_primary_key,
			DENSE_RANK() over (order by sys.indexes.name) as index_number,
			ROW_NUMBER() over (partition by sys.indexes.name order by sys.indexes.name) as column_number
		FROM
			sys.objects
		INNER JOIN
			sys.indexes
		ON
			sys.objects.object_id = sys.indexes.object_id
		INNER JOIN
			sys.index_columns
		ON
			sys.index_columns.object_id = sys.indexes.object_id AND sys.index_columns.index_id = sys.indexes.index_id
		INNER JOIN
			sys.columns
		ON
			sys.columns.object_id = sys.index_columns.object_id AND sys.columns.column_id = sys.index_columns.column_id
		WHERE
			sys.objects.type_desc = N'USER_TABLE' and sys.objects.name = @table_name)
		INSERT @table(table_name, index_name, column_name, index_type, is_primary_key, index_number, column_number)
			SELECT * FROM index_columns
	RETURN
END


GO


-- [dbo].[SplitString] --

PRINT N'Creating [dbo].[SplitString]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SplitString]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[SplitString] 
GO


	CREATE FUNCTION [dbo].[SplitString]
		(@text nvarchar(max), @delimiter char(1) = ' ')
	RETURNS @Strings TABLE(position int IDENTITY PRIMARY KEY, value varchar(200))
	AS 
	BEGIN
		DECLARE @INDEX int    
		SET @INDEX = -1
		WHILE (LEN(@text) > 0)
		BEGIN        
			SET @INDEX = CHARINDEX(@delimiter , @text)        
			IF (@INDEX = 0) AND (LEN(@text) > 0)
			BEGIN   
				INSERT INTO @Strings VALUES (@text)   
				BREAK
			END        
			IF (@INDEX > 1)
			BEGIN   
				INSERT INTO @Strings VALUES (LEFT(@text, @INDEX - 1))   
				SET @text = RIGHT(@text, (LEN(@text) - @INDEX))
			END
			ELSE   
				SET @text = RIGHT(@text, (LEN(@text) - @INDEX))
		END
		RETURN
	END

GO


-- [dbo].[CheckIfIndexExistsByColumnNames] --

PRINT N'Creating [dbo].[CheckIfIndexExistsByColumnNames]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CheckIfIndexExistsByColumnNames]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[CheckIfIndexExistsByColumnNames] 
GO


CREATE FUNCTION [dbo].[CheckIfIndexExistsByColumnNames]
(
	@table_name nvarchar(128),
	@column_names nvarchar(128),
	@index_type nvarchar(128)	
)
RETURNS
	int
AS
BEGIN

	DECLARE @i INT;
	SET @i = 0;
	DECLARE @index_exists INT;
	SET @index_exists = 0;

	WHILE (@i < 256)
		BEGIN
		IF NOT EXISTS
			(SELECT position, value, @index_type as index_type FROM dbo.SplitString(@column_names, ',')
			EXCEPT
			SELECT column_number, column_name, index_type FROM [GetSortedIndexColumns](@table_name) WHERE index_number = @i)
			BEGIN
			SET @index_exists = '1'
			BREAK
			END
		ELSE 
		SET @i = @i + 1;
		CONTINUE
	END
		RETURN @index_exists
END

GO


-- [dbo].[CheckIfIndexExistsByIndexName] --

PRINT N'Creating [dbo].[CheckIfIndexExistsByIndexName]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CheckIfIndexExistsByIndexName]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[CheckIfIndexExistsByIndexName]
GO


CREATE FUNCTION [dbo].[CheckIfIndexExistsByIndexName]
(
	@table_name nvarchar(128),
	@index_name nvarchar(128),
	@index_type nvarchar(128)	
)
RETURNS
	int
AS
BEGIN
	declare @table_name_bracketed nvarchar(128)

	SET @table_name_bracketed = '[' + @table_name + ']'
	DECLARE @clustered_index_name varchar(100)
	SET @clustered_index_name = (SELECT name FROM sys.indexes WHERE object_id = OBJECT_ID(@table_name_bracketed) AND TYPE = 1);

	declare @column_names varchar(100);
	set @column_names = '';
	SELECT @column_names = @column_names + column_name + ',' from [FindIndexColumnsByIndexAndTableName](@table_name, @clustered_index_name)
	SELECT @column_names = SUBSTRING(@column_names, 1, LEN(@column_names)-1)



	DECLARE @index_exists INT;
	SET @index_exists = (select [dbo].[CheckIfIndexExistsByColumnNames](@table_name, @column_names, @index_type) as a);

	RETURN @index_exists
END

GO


-- [dbo].[ConvertToUnderscoredString] --

PRINT N'Creating [dbo].[ConvertToUnderscoredString]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ConvertToUnderscoredString]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[ConvertToUnderscoredString]
GO

CREATE FUNCTION [dbo].[ConvertToUnderscoredString]
(
	@column_names nvarchar(128)
)
RETURNS varchar(128)
	
AS

BEGIN

	DECLARE @column_names_underscored varchar(128);
	SET @column_names_underscored = ''
	SELECT @column_names_underscored = @column_names_underscored + value + '_' FROM dbo.splitstring(@column_names, ',')
	SELECT @column_names_underscored = SUBSTRING(@column_names_underscored, 1, LEN(@column_names_underscored)-1)

	RETURN 	@column_names_underscored
	
END

GO


-- [dbo].[FindPrimaryKeyColumnsByTable] --

PRINT N'Creating [dbo].[FindPrimaryKeyColumnsByTable]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindPrimaryKeyColumnsByTable]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[FindPrimaryKeyColumnsByTable]
GO


CREATE FUNCTION [dbo].[FindPrimaryKeyColumnsByTable]
(
	@table_name nvarchar(128)
)
RETURNS
	@table TABLE
	(	
		columns nvarchar(128)
	)
AS
	BEGIN
	WITH primary_keys AS 
		(SELECT  i.name AS indexName,
				OBJECT_NAME(ic.OBJECT_ID) AS tableName,
				COL_NAME(ic.OBJECT_ID,ic.column_id) AS columnName
		FROM    sys.indexes AS i INNER JOIN 
				sys.index_columns AS ic ON  i.OBJECT_ID = ic.OBJECT_ID
										AND i.index_id = ic.index_id
		WHERE   i.is_primary_key = 1)
		INSERT INTO @table
		SELECT columnName FROM primary_keys where tablename = @table_name;
		
	RETURN
END

GO


-- [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames] --

PRINT N'Creating [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames]
GO

CREATE FUNCTION [dbo].[CheckIfIdenticalNonClusteredIndexExistsByColumnNames]
(
	@table_name nvarchar(128),
	@column_names nvarchar(128)
	
)
RETURNS
	int
AS
BEGIN
DECLARE @i INT;
SET @i = 0;
DECLARE @index_exists INT;
SET @index_exists = 0;
WHILE (@i < 256)
	BEGIN
	IF NOT EXISTS
		((SELECT position, value FROM dbo.SplitString(@column_names, ',')
		EXCEPT
		SELECT column_number, column_name FROM [GetSortedIndexColumns](@table_name) WHERE index_number = @i and index_type = 'NonClustered')
			UNION ALL
		(SELECT column_number, column_name FROM [GetSortedIndexColumns](@table_name) WHERE index_number = @i and index_type = 'NonClustered'
		EXCEPT
		SELECT position, value FROM dbo.SplitString(@column_names, ',')))
		BEGIN
		SET @index_exists = '1'
		BREAK
		END
	ELSE 
	SET @i = @i + 1;
	CONTINUE
END
	RETURN @index_exists
END

GO


-- [dbo].[GetNonClusteredIndexNamesByColumnNames] --

PRINT N'Creating [dbo].[GetNonClusteredIndexNamesByColumnNames]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNonClusteredIndexNamesByColumnNames]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[GetNonClusteredIndexNamesByColumnNames]
GO


CREATE FUNCTION [dbo].[GetNonClusteredIndexNamesByColumnNames]
(
	@table_name nvarchar(128),
	@column_names nvarchar(128)
	
)

RETURNS
	@table TABLE
	(	
		index_name varchar(128)
	)

AS
BEGIN
DECLARE @i INT;
SET @i = 0;
DECLARE @index_exists INT;
SET @index_exists = 0;


WHILE (@i < 256)

	
	BEGIN
	INSERT INTO @table SELECT index_name from [GetSortedIndexColumns](@table_name) WHERE index_number = @i AND is_primary_key = 0 
	AND NOT EXISTS
		((SELECT position, value FROM dbo.SplitString(@column_names, ',')
		EXCEPT
		SELECT column_number, column_name FROM [GetSortedIndexColumns](@table_name) WHERE index_number = @i and index_type = 'NonClustered')
			UNION ALL
		(SELECT column_number, column_name FROM [GetSortedIndexColumns](@table_name) WHERE index_number = @i and index_type = 'NonClustered'
		EXCEPT
		SELECT position, value FROM dbo.SplitString(@column_names, ',')));
	 
	SET @i = @i + 1;
	END

RETURN;
END

GO


-- [dbo].[CheckIfIndexWithTheSameNameExists] --

PRINT N'Creating [dbo].[CheckIfIndexWithTheSameNameExists]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CheckIfIndexWithTheSameNameExists]') AND type in (N'FN'))
	DROP FUNCTION [dbo].[CheckIfIndexWithTheSameNameExists]
GO


CREATE FUNCTION [dbo].[CheckIfIndexWithTheSameNameExists]
(
	@table_name varchar(128),
	@column_names varchar(128),
	@index_type varchar(128),
	@include_columns varchar(128) = null
)
RETURNS
	int
AS
BEGIN
DECLARE @index_name varchar(128);
DECLARE @index_exists int;
SET @index_exists = 0;
DECLARE @table_name_bracketed VARCHAR(128);
SET @table_name_bracketed = '[' + @table_name + ']'
DECLARE @column_names_underscored varchar(128);
SELECT @column_names_underscored = (SELECT [dbo].[ConvertToUnderscoredString](@column_names));
IF (@index_type = 'Clustered')
BEGIN
SET @index_name = 'PK_' + @table_name + '_' + @column_names_underscored
IF EXISTS (SELECT * FROM sys.indexes WHERE name = @index_name AND object_id = OBJECT_ID(@table_name_bracketed) and type = '1')
BEGIN
SET @index_exists = 1;
END
ELSE
SET @index_name = 'CI_' + @table_name + '_' + @column_names_underscored;
IF EXISTS (SELECT * FROM sys.indexes WHERE name = @index_name AND object_id = OBJECT_ID(@table_name_bracketed) and type = '1')
BEGIN
SET @index_exists = 1;
END
END
IF (@index_type = 'Nonclustered' and @include_columns IS NULL)
BEGIN
SET @index_name = 'IX_' + @table_name + '_' + @column_names_underscored
IF EXISTS (SELECT * FROM sys.indexes WHERE name = @index_name AND object_id = OBJECT_ID(@table_name_bracketed) and type = '2')
BEGIN
SET @index_exists = 1;
END
END
IF (@index_type = 'Nonclustered' and @include_columns IS NOT NULL)
BEGIN
SELECT @column_names_underscored = @column_names_underscored + '_' + (SELECT [dbo].[ConvertToUnderscoredString](@include_columns));
SET @index_name = 'IX_' + @table_name + '_' + @column_names_underscored
IF EXISTS (SELECT * FROM sys.indexes WHERE name = @index_name AND object_id = OBJECT_ID(@table_name_bracketed) and type = '2')
BEGIN
SET @index_exists = 1;
END
END
	RETURN @index_exists;
END

GO

	-- [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames] --
PRINT N'Creating [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames]') AND type in (N'TF'))
	DROP FUNCTION [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames]
GO

CREATE FUNCTION [dbo].[GetMatchingNonClusteredPrimaryKeyNameByColumnNames]
(
	@table_name nvarchar(128),
	@column_names nvarchar(128)
)
RETURNS
	@table TABLE
	(	
		index_name varchar(128)
	)
AS
BEGIN
DECLARE @i INT;
SET @i = 0;
DECLARE @index_exists INT;
SET @index_exists = 0;
WHILE (@i < 256)
	BEGIN
	INSERT INTO @table SELECT index_name from [GetSortedIndexColumns](@table_name) WHERE index_number = @i AND is_primary_key = 1 
	AND NOT EXISTS
		((SELECT position, value FROM dbo.SplitString(@column_names, ',')
		EXCEPT
		SELECT column_number, column_name FROM [GetSortedIndexColumns](@table_name) WHERE index_number = @i and index_type = 'NonClustered')
			UNION ALL
		(SELECT column_number, column_name FROM [GetSortedIndexColumns](@table_name) WHERE index_number = @i and index_type = 'NonClustered'
		EXCEPT
		SELECT position, value FROM dbo.SplitString(@column_names, ',')));
	SET @i = @i + 1;
	END
RETURN;
END
GO

