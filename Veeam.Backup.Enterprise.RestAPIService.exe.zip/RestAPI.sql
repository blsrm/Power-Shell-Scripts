--******************************************************************--
--* REST STORED PROCEDURES
--******************************************************************--
----------------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.Reports.Summary.GetOverviewFrame]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Rest.Reports.Summary.GetOverviewFrame]
GO
CREATE PROCEDURE [dbo].[Rest.Reports.Summary.GetOverviewFrame]
AS
BEGIN
	SET NOCOUNT ON;
		CREATE TABLE #LatestSessions
	(	[id] uniqueidentifier,
		[job_id] uniqueidentifier,
		[state] int	
	)
	INSERT INTO #LatestSessions
	SELECT q.[id], q.[job_id], q.[state]
	FROM
		(SELECT 
			session.[id], session.[job_id], session.[state],
			ROW_NUMBER() OVER (PARTITION BY session.job_id ORDER BY session.[creation_time] DESC) as rn
		FROM 			
			[dbo].[C.Backup.Model.JobSessions] session
			INNER JOIN [dbo].[C.BJobs] jobs ON session.[job_id] = jobs.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON jobs.[db_instance_id] = bservers.[current_db_id]
		WHERE jobs.[type] IN (0,1)) as q --backup, replica
	WHERE q.rn = 1

	SELECT
		(SELECT count(id) FROM [dbo].[Repl.Topology.BackupDbInstances]) as backup_servers,
		(SELECT count(repo.id) FROM [dbo].[C.BackupRepositories] repo
			INNER JOIN [dbo].[Repl.Topology.BackupDbInstances] db ON repo.[db_instance_id] = db.[id]) as repositories,
		(SELECT count(proxy.id) FROM [dbo].[C.BackupProxies] proxy
			INNER JOIN [dbo].[Repl.Topology.BackupDbInstances] db ON proxy.[db_instance_id] = db.[id]) as proxies,
		(SELECT count(id) FROM #LatestSessions sessions WHERE sessions.[state] IN (3, 5)) as running_jobs, --starting, running
		(SELECT count(jobs.id) FROM [dbo].[C.BJobs] jobs
			INNER JOIN [dbo].[Repl.Topology.BackupDbInstances] db ON jobs.[db_instance_id] = db.[id]
		 WHERE 
			jobs.[schedule_enabled] = 1 AND 
			ISNULL(jobs.options.value('(/*/RunManually)[1]', 'bit'), 1) = 0 AND 
			jobs.[type] IN (0,1)
		) as scheduled_jobs,
		(SELECT count(task_sessions.id) FROM #LatestSessions latest_sessions
			INNER JOIN [dbo].[C.Backup.Model.BackupTaskSessions] task_sessions ON latest_sessions.[id] = task_sessions.[session_id]
			WHERE task_sessions.[status] = 0) as vms_success, -- success
		(SELECT count(task_sessions.id) FROM #LatestSessions latest_sessions
			INNER JOIN [dbo].[C.Backup.Model.BackupTaskSessions] task_sessions ON latest_sessions.[id] = task_sessions.[session_id]
			WHERE task_sessions.[status] = 3) as vms_warning, -- warning
		(SELECT count(task_sessions.id) FROM #LatestSessions latest_sessions
			INNER JOIN [dbo].[C.Backup.Model.BackupTaskSessions] task_sessions ON latest_sessions.[id] = task_sessions.[session_id]
			WHERE task_sessions.[status] = 2) as vms_error -- error
	DROP TABLE #LatestSessions

END  
GO



-----------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.Reports.LatestOibsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.Reports.LatestOibsView]
GO
	CREATE VIEW [dbo].[Rest.Reports.LatestOibsView]
	AS
		SELECT q.id, q.creation_time, q.backup_id, q.object_id
		FROM
	    (
	    SELECT 
			oibs.id,
			oibs.creation_time,
			oibs.object_id,
			--oibs.vmname,
			pnts.backup_id,
			ROW_NUMBER() OVER (PARTITION BY pnts.backup_id, oibs.object_id ORDER BY pnts.num DESC, oibs.[creation_time] DESC) rn
		 FROM 
			[dbo].[C.Backup.Model.OIBs] oibs 
			INNER JOIN [dbo].[C.Backup.Model.Points] pnts ON pnts.id = oibs.point_id
			INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON pnts.backup_id = backups.id
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON backups.[db_instance_id] = bservers.[current_db_id]
		 WHERE 
			backups.job_target_type IN (0,1) AND
			oibs.is_corrupted = 0
		) q
		WHERE 
			q.rn = 1

GO


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.Rest.Reports.BackupInfoForPeriod]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [dbo].[fn.Rest.Reports.BackupInfoForPeriod]
GO
	CREATE FUNCTION [dbo].[fn.Rest.Reports.BackupInfoForPeriod]
	(
		@days int
	)
	RETURNS 
		@Result TABLE 
		(
			[id] uniqueidentifier,
			[job_name] nvarchar(256),
			[is_replica] bit,
			[full_storages_size] bigint,
			[incremental_storages_size] bigint
		)
	AS
	BEGIN
	
		DECLARE @utc_time_current datetime, @utc_time_from datetime
		SET @utc_time_current = GETUTCDATE()
		SET @utc_time_from = DATEADD(day, -@days, @utc_time_current)

		INSERT INTO @Result 
		SELECT
			b.[id],
			b.[job_name],
			CONVERT(BIT, CASE WHEN b.[job_target_type] = 1 THEN 1 ELSE 0 END) as is_replica,
			ISNULL(CASE 
				WHEN b.[job_target_type] = 0 THEN sss.[full_storages_size]
				ELSE 0
			END, 0) as full_storages_size,
			ISNULL(CASE 
				WHEN b.[job_target_type] = 0 THEN sss.[incremental_storages_size]
				ELSE 0
			END, 0) as incremental_storages_size
			--,sss.[total_storages_size]
		FROM
			[dbo].[C.Backup.Model.Backups] b			
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON b.[db_instance_id] = bservers.[current_db_id]
			INNER JOIN (
				SELECT
					ss.[backup_id],
					SUM((1 - ss.[is_incremental]) * ss.[ssize]) AS full_storages_size,
					SUM(ss.[is_incremental] * ss.[ssize]) AS incremental_storages_size
					--SUM(ss.[ssize]) AS total_storages_size					
				FROM
					(
						SELECT
							s.[backup_id],
							ISNULL(s.stats.value('(/stats/CBackupStats/BackupSize)[1]', 'bigint'), 0) as ssize,
							CASE WHEN PATINDEX('%.vbk', s.file_path) > 0 THEN 0 ELSE 1 END AS is_incremental							
						FROM
							[dbo].[C.Backup.Model.Storages] s
							INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON s.[db_instance_id] = bservers.[current_db_id]
						WHERE
							s.[creation_time] > @utc_time_from
					) ss
				GROUP BY [backup_id]
			) sss ON sss.[backup_id] = b.[id]
		WHERE
			b.job_target_type IN (0,1)
			
	RETURN
	END
GO



IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.Reports.Summary.GetVmsOverviewFrame]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Rest.Reports.Summary.GetVmsOverviewFrame]
GO
CREATE PROCEDURE [dbo].[Rest.Reports.Summary.GetVmsOverviewFrame]
	@days int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @utc_time_current datetime, @utc_time_from datetime
	SET @utc_time_current = GETUTCDATE()
	SET @utc_time_from = DATEADD(day, -@days, @utc_time_current)
	CREATE TABLE #VmRestorePoints
	(
		[vm_obj_id] uniqueidentifier,
		[oib_id] uniqueidentifier,
		[oib_creation_time] datetime,
		[storage_id] uniqueidentifier,
		[job_target_type] int,
		[backup_id] uniqueidentifier,
		[oib_type] int,
		[oib_approx_size] bigint,
		is_corrupted bit
	)
	INSERT INTO #VmRestorePoints
	SELECT 
		oibs.[object_id] as vm_obj_id, 
		oibs.[id] as oib_id,
		oibs.[creation_time] as oib_creation_time,
		oibs.[storage_id] as storage_id,
		backups.[job_target_type] as job_target_type,
		backups.[id] as backup_id,
		oibs.[type] as oib_type,
		oibs.[approx_size] as oib_approx_size,
		oibs.[is_corrupted]
	FROM 
		[dbo].[C.Backup.Model.OIBs] oibs
		INNER JOIN [dbo].[C.Backup.Model.Points] points ON oibs.[point_id] = points.[id]
		INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON points.[backup_id] = backups.[id]
		INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON backups.[db_instance_id] = bservers.[current_db_id]
	WHERE 
		--oibs.[is_corrupted] = 0 AND 
		oibs.[creation_time] > @utc_time_from AND
		backups.[job_target_type] IN (0, 1)


	DECLARE @expected_backedup_vms int
	DECLARE @expected_replicated_vms int
	DECLARE @total_last_oibs int
	SELECT @expected_backedup_vms = ISNULL(COUNT(vm_obj_id), 0)
	FROM 
		(SELECT DISTINCT vms.[vm_obj_id] FROM #VmRestorePoints vms WHERE vms.[job_target_type] = 0) as q	
	SELECT @expected_replicated_vms = ISNULL(COUNT(vm_obj_id), 0)
	FROM 
		( SELECT DISTINCT vms.[vm_obj_id] FROM #VmRestorePoints vms WHERE vms.[job_target_type] = 1) as q

	SELECT @total_last_oibs = ISNULL(COUNT(vms.vm_obj_id), 0)
	FROM #VmRestorePoints vms
		INNER JOIN [dbo].[Rest.Reports.LatestOibsView] last_oibs ON vms.[oib_id] = last_oibs.[id]	
	SELECT 
		(
			SELECT ISNULL(COUNT(vm_obj_id), 0)
			FROM 
				(SELECT DISTINCT vms.[vm_obj_id] FROM #VmRestorePoints vms WHERE vms.[is_corrupted] = 0 AND vms.[job_target_type] = 0) as q	
		)as backedup_vms,
		(
			SELECT ISNULL(COUNT(vm_obj_id), 0)
			FROM 
				(SELECT DISTINCT vms.[vm_obj_id] FROM #VmRestorePoints vms WHERE vms.[is_corrupted] = 0 AND vms.[job_target_type] = 1) as q
		) as replicated_vms,
		(
			SELECT ISNULL(COUNT(*), 0)
			FROM
			(SELECT DISTINCT vms.[vm_obj_id] FROM #VmRestorePoints vms WHERE vms.[is_corrupted] = 0) as q
		) as protected_vms,
		(
			SELECT ISNULL(SUM(backups.[full_storages_size]), 0) FROM [dbo].[fn.Rest.Reports.BackupInfoForPeriod](@days) backups
			WHERE backups.[is_replica] = 0
		) as full_backup_points_size,
		(			
			SELECT ISNULL(SUM(backups.[incremental_storages_size]), 0) FROM [dbo].[fn.Rest.Reports.BackupInfoForPeriod](@days) backups
			WHERE backups.[is_replica] = 0
		) as incr_backup_points_size,
		(
			SELECT ISNULL(SUM(stg.[full_size]), 0) FROM #VmRestorePoints vms
			INNER JOIN [dbo].[C.Backup.Model.Storages] stg ON vms.[storage_id] = stg.[id]
			WHERE 
				vms.[is_corrupted] = 0 AND
				job_target_type = 1 AND -- replica
				vms.[oib_type] IN (0,1,4) --full, rollback, snapshot
		) as replica_restore_points_size,
		(
			SELECT ISNULL(COUNT(*), 0) FROM #VmRestorePoints vms WHERE vms.[is_corrupted] = 0
		) as restore_points,
		(
			SELECT ISNULL(SUM(q.[oib_approx_size]), 0)
			FROM 
			(
				SELECT 
					vms.[oib_approx_size],
					ROW_NUMBER() OVER (PARTITION BY vms.vm_obj_id ORDER BY vms.[oib_creation_time] DESC) as rn
				FROM #VmRestorePoints vms
				WHERE vms.[is_corrupted] = 0
			) as q
			WHERE q.rn = 1
		) as source_vms_size,
		(
			SELECT 
				CASE @expected_backedup_vms + @expected_replicated_vms
					WHEN 0 THEN 0
					ELSE @total_last_oibs / (CAST(@expected_backedup_vms + @expected_replicated_vms as real))
				END
		) as success_backup_ratio
	DROP TABLE #VmRestorePoints
END
GO





IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.Reports.Summary.GetJobStatsFrame]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Rest.Reports.Summary.GetJobStatsFrame]
GO
CREATE PROCEDURE [dbo].[Rest.Reports.Summary.GetJobStatsFrame]
	@days int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @utc_time_current datetime, @utc_time_from datetime
	SET @utc_time_current = GETUTCDATE()
	SET @utc_time_from = DATEADD(day, -@days, @utc_time_current)
	CREATE TABLE #LatestSessions
	(	[id] uniqueidentifier,
		[job_id] uniqueidentifier,
		[state] int	
	)
	INSERT INTO #LatestSessions
	SELECT q.[id], q.[job_id], q.[state]
	FROM
		(SELECT 
			session.[id], session.[job_id], session.[state],
			ROW_NUMBER() OVER (PARTITION BY session.job_id ORDER BY session.[creation_time] DESC) as rn
		FROM 
			[dbo].[C.Backup.Model.JobSessions] session
			INNER JOIN [dbo].[C.BJobs] jobs ON session.[job_id] = jobs.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON jobs.[db_instance_id] = bservers.[current_db_id]
		WHERE 
			jobs.[type] IN (0,1) AND --backup, replica
			session.[creation_time] > @utc_time_from
		) as q
	WHERE q.rn = 1
	
	DECLARE @max_backup_job_duration_mins int
	DECLARE @max_duration_backup_job_name nvarchar(1024)
	DECLARE @max_replica_job_duration_mins int
	DECLARE @max_duration_replica_job_name nvarchar(1024)
	


	SELECT TOP(1)
		@max_backup_job_duration_mins = q.duration,
		@max_duration_backup_job_name = q.job_name
	FROM
		(SELECT
					MAX(
						DATEDIFF(mi, sessions.[creation_time], 
						CASE 
							WHEN sessions.[end_time] < sessions.[creation_time] THEN @utc_time_current
							ELSE sessions.[end_time]
						END
						)
					) as duration,
					sessions.[job_name] as job_name
		FROM 
			[dbo].[Repl.Topology.BackupDbInstances] db
			INNER JOIN [dbo].[view.Backup.BackupJobSessions] sessions ON db.[id] = sessions.[db_instance_id]
		WHERE 
			sessions.[job_type] = 0 AND --backup
			sessions.[creation_time] > @utc_time_from
		GROUP BY sessions.[job_name]) as q
	ORDER BY q.duration DESC
	

	SELECT TOP(1)
		@max_replica_job_duration_mins = q.duration,
		@max_duration_replica_job_name = q.job_name
	FROM
		(SELECT
					MAX(
						DATEDIFF(mi, sessions.[creation_time], 
						CASE 
							WHEN sessions.[end_time] < sessions.[creation_time] THEN @utc_time_current
							ELSE sessions.[end_time]
						END
						)
					) as duration,
					sessions.[job_name] as job_name
		FROM 
			[dbo].[Repl.Topology.BackupDbInstances] db
			INNER JOIN [dbo].[view.Backup.BackupJobSessions] sessions ON db.[id] = sessions.[db_instance_id]
		WHERE 
			sessions.[job_type] = 1 AND --replica
			sessions.[creation_time] > @utc_time_from
		GROUP BY sessions.[job_name]) as q
	ORDER BY q.duration DESC

	
	SELECT 
		(
			SELECT COUNT(id) FROM #LatestSessions sessions WHERE sessions.[state] IN (3, 5)--starting, running
		) as running_jobs, 
		(
			SELECT COUNT(jobs.id) 
			FROM [dbo].[C.BJobs] jobs 
				INNER JOIN [dbo].[Repl.Topology.BackupDbInstances] db ON jobs.[db_instance_id] = db.[id]
			WHERE 
				jobs.[schedule_enabled] = 1 AND 
				ISNULL(jobs.options.value('(/*/RunManually)[1]', 'bit'), 1) = 0 AND
				jobs.[type] = 0
		) as backup_scheduled_jobs,
		(
			SELECT COUNT(jobs.id) 
			FROM [dbo].[C.BJobs] jobs 
				INNER JOIN [dbo].[Repl.Topology.BackupDbInstances] db ON jobs.[db_instance_id] = db.[id]
			WHERE 
				jobs.[schedule_enabled] = 1 AND 
				ISNULL(jobs.options.value('(/*/RunManually)[1]', 'bit'), 1) = 0 AND
				jobs.[type] = 1
		) as replica_scheduled_jobs,
		(
			SELECT COUNT(jobs.[id]) 
			FROM [dbo].[Repl.Topology.BackupServers]
				INNER JOIN [dbo].[C.BJobs] jobs ON [dbo].[Repl.Topology.BackupServers].[current_db_id] = jobs.[db_instance_id]
				INNER JOIN [dbo].[view.Backup.BackupJobSessions] ON jobs.[id] = [dbo].[view.Backup.BackupJobSessions].[job_id]
			WHERE 
				jobs.[type] IN (0,1) AND
				[dbo].[view.Backup.BackupJobSessions].[end_time] > @utc_time_from
		) as total_job_runs,
		(
			SELECT COUNT(jobs.[id]) 
			FROM [dbo].[Repl.Topology.BackupServers]
				INNER JOIN [dbo].[C.BJobs] jobs ON [dbo].[Repl.Topology.BackupServers].[current_db_id] = jobs.[db_instance_id]
				INNER JOIN [dbo].[view.Backup.BackupJobSessions] ON jobs.[id] = [dbo].[view.Backup.BackupJobSessions].[job_id]
			WHERE
				jobs.[type] IN (0,1) AND
				[dbo].[view.Backup.BackupJobSessions].[result] = 0 AND 
				[dbo].[view.Backup.BackupJobSessions].[end_time] > @utc_time_from
		) as job_successes,
		(
			SELECT COUNT(jobs.[id]) 
			FROM [dbo].[Repl.Topology.BackupServers]
				INNER JOIN [dbo].[C.BJobs] jobs ON [dbo].[Repl.Topology.BackupServers].[current_db_id] = jobs.[db_instance_id]
				INNER JOIN [dbo].[view.Backup.BackupJobSessions] ON jobs.[id] = [dbo].[view.Backup.BackupJobSessions].[job_id]
			WHERE
				jobs.[type] IN (0,1) AND
				[dbo].[view.Backup.BackupJobSessions].[result] = 1 AND 
				[dbo].[view.Backup.BackupJobSessions].[end_time] > @utc_time_from
		) as job_warnings,
		(
			SELECT COUNT(jobs.[id]) 
			FROM [dbo].[Repl.Topology.BackupServers]
				INNER JOIN [dbo].[C.BJobs] jobs ON [dbo].[Repl.Topology.BackupServers].[current_db_id] = jobs.[db_instance_id]
				INNER JOIN [dbo].[view.Backup.BackupJobSessions] ON jobs.[id] = [dbo].[view.Backup.BackupJobSessions].[job_id]
			WHERE
				jobs.[type] IN (0,1) AND
				[dbo].[view.Backup.BackupJobSessions].[result] = 2 AND 
				[dbo].[view.Backup.BackupJobSessions].[end_time] > @utc_time_from
		) as job_errors,
		ISNULL(@max_backup_job_duration_mins, 0) as max_backup_job_duration,
		ISNULL(@max_duration_backup_job_name, N'') as max_duration_backup_job_name,
		ISNULL(@max_replica_job_duration_mins, 0) as max_replica_job_duration,
		ISNULL(@max_duration_replica_job_name, N'') as max_duration_replica_job_name				
END  
GO




IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.Reports.Summary.GetProcessedVmsFrame]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Rest.Reports.Summary.GetProcessedVmsFrame]
GO
CREATE PROCEDURE [dbo].[Rest.Reports.Summary.GetProcessedVmsFrame]
	@days int
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @utc_time_current datetime, @utc_time_from datetime
	SET @utc_time_current = GETUTCDATE()
	SET @utc_time_from = DATEADD(day, -@days, @utc_time_current)
	
	CREATE TABLE #SuccessVmRestorePoints
	(
		[vm_obj_id] uniqueidentifier,
		[oib_id] uniqueidentifier,
		[oib_creation_time] datetime,
		[job_target_type] int,
		[backup_id] uniqueidentifier,
		[oib_type] int,
		[oib_approx_size] bigint,
		[is_corrupted] bit
	)

	INSERT INTO #SuccessVmRestorePoints
	SELECT 
		oibs.[object_id] as vm_obj_id, 
		oibs.[id] as oib_id,
		oibs.[creation_time] as oib_creation_time,
		backups.[job_target_type] as job_target_type,
		backups.[id] as backup_id,
		oibs.[type] as oib_type,
		oibs.[approx_size] as oib_approx_size,
		oibs.[is_corrupted]		
	FROM 
		[dbo].[Repl.Topology.BackupDbInstances] db
		INNER JOIN [dbo].[C.Backup.Model.OIBs] oibs ON db.[id] = oibs.[db_instance_id]		
		INNER JOIN [dbo].[C.Backup.Model.Points] points ON oibs.[point_id] = points.[id]
		INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON points.[backup_id] = backups.[id]
	WHERE 
		oibs.[is_corrupted] = 0 AND 
		oibs.[creation_time] > @utc_time_from AND
		backups.[job_target_type] IN (0, 1)

	SELECT 
		vms.[oib_id] as id, 
		vms.[oib_creation_time] as creation_time, 
		vms.[job_target_type] as job_target_type,
		DATEDIFF(dd, vms.[oib_creation_time], @utc_time_current) as days_in_depth
	FROM #SuccessVmRestorePoints vms	
	ORDER BY vms.[oib_creation_time] DESC
	
END  
GO




IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.Reports.Summary.GetRepositoriesFrame]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Rest.Reports.Summary.GetRepositoriesFrame]
GO
CREATE PROCEDURE [dbo].[Rest.Reports.Summary.GetRepositoriesFrame]	
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		repo.[name],
		repo.[total_space],
		repo.[free_space],
		repo.[total_space] - repo.[free_space] as used_space
	FROM [dbo].[C.BackupRepositories] repo
		INNER JOIN [dbo].[Repl.Topology.BackupDbInstances] db ON repo.[db_instance_id] = db.[id]
	WHERE 
		repo.[type] != 8 -- NetApp Storage fake repo
	END  
GO



IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.GetJobItems]') AND type in (N'P'))
DROP PROCEDURE [dbo].[Rest.GetJobItems]
GO
CREATE PROCEDURE [dbo].[Rest.GetJobItems]
	@job_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
		SELECT
		    [dbo].[C.ObjectsInJobs].[id] AS [oij_id],
		    [dbo].[C.ObjectsInJobs].[job_id] AS [oij_job_id],
		    [dbo].[C.ObjectsInJobs].[folder_id] AS [oij_folder_id],
		    [dbo].[C.ObjectsInJobs].[vss_options] AS [oij_vss_options],
		    [dbo].[C.ObjectsInJobs].[location] AS [oij_location],
		    [dbo].[C.ObjectsInJobs].[type] AS [oij_type],
            [dbo].[C.BObjects].[platform],
		    [dbo].[C.BObjects].[id],
		    [dbo].[C.BObjects].[type],
		    [dbo].[C.BObjects].[host_id],
		    [dbo].[C.BObjects].[object_name],
		    [dbo].[C.BObjects].[object_id],
		    [dbo].[C.BObjects].[viobject_type],
		    [dbo].[C.BObjects].[guest_os],
		    [dbo].[C.BObjects].[path],		                    
		    [dbo].[C.BObjects].[uuid],
            [dbo].[C.BObjects].[display_name]
	    FROM
		    [dbo].[C.ObjectsInJobs],
		    [dbo].[C.BObjects]
	    WHERE
		    [dbo].[C.ObjectsInJobs].[object_id] = [dbo].[C.BObjects].[id] AND
		    [dbo].[C.ObjectsInJobs].[db_instance_id] = [dbo].[C.BObjects].[db_instance_id] AND
		    [dbo].[C.ObjectsInJobs].[job_id] = @job_id
END
GO


--******************************************************************--
--* REST API VIEWS
--******************************************************************--
----------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.RootHostsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.RootHostsView]
GO
	CREATE VIEW [dbo].[Rest.RootHostsView] 
	AS
		SELECT 
			h.*,			
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name
		FROM [dbo].[C.Hosts] h 
		INNER JOIN [dbo].[Repl.Topology.BackupDbInstances] db ON h.[db_instance_id] = db.[id]		
		INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON h.[db_instance_id] = bservers.[current_db_id]
		WHERE 	
			bservers.[major_version] >= 7 
			AND [dbo].[fn.IsRootVisibleHost](h.[id]) = 'True'
			AND ( ( 
				  h.[type] in (0, 6, 7, 8, 9, 14)
			      AND	h.[parent_id] = '00000000-0000-0000-0000-000000000000'
			     ) OR h.[type] = 1 )
GO


--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.JobsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.JobsView]
GO
	CREATE VIEW [dbo].[Rest.JobsView]
	AS
		SELECT 
			jobs.[id] as id
			,jobs.[type] as type
			,jobs.[name] as name
			,jobs.[description] as description
			,~ISNULL(jobs.options.value('(/*/RunManually)[1]', 'bit'), 1) as is_schedule_configured
			,jobs.[schedule] as schedule_options
			,jobs.[platform] as platform
			,jobs.[schedule_enabled] as is_schedule_enabled
			,jobs.[next_run_time] as next_run
			
			,jobs.[target_host_id]
			,jobs.[target_dir]
			,jobs.[target_file]
			,jobs.[options]			
			,jobs.[is_deleted]
			,jobs.[latest_result]
			,jobs.[vss_options]
			,jobs.[vcb_host_id]
			,jobs.[target_type]
			,jobs.[parent_schedule_id]			
			--,[job_source_type]
			--,[included_size]
			--,[excluded_size]			
			--,[source_proxy_host_id]
			--,[target_proxy_host_id]
			--,[repository_id]
			--,[initialsync_repository_id]			
			,bservers.[id] as parent_bserver_id
			,bservers.[ip_or_dns_name] as parent_bserver_name
			,jobs.[pwd_key_id]
		FROM 
			[dbo].[C.BJobs] jobs 
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON jobs.[db_instance_id] = bservers.[current_db_id]
		WHERE 
			bservers.[major_version] >= 7 AND
			jobs.[type] IN (0,1) -- backup, replica, copy
GO


--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.FailoverPlansView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.FailoverPlansView]
GO
	CREATE VIEW [dbo].[Rest.FailoverPlansView]
	AS
		SELECT 
			jobs.[id] as id
			,jobs.[type] as type
			,jobs.[name] as name
			,jobs.[description] as description
			,~ISNULL(jobs.options.value('(/*/RunManually)[1]', 'bit'), 1) as is_schedule_configured
			,jobs.[schedule] as schedule_options
			,jobs.[platform] as platform
			,jobs.[schedule_enabled] as is_schedule_enabled
			,jobs.[next_run_time] as next_run
			,jobs.[options]			
			,jobs.[is_deleted]
			,jobs.[latest_result]
			,jobs.[vss_options]
			,jobs.[vcb_host_id]
			,jobs.[target_type]
			,jobs.[parent_schedule_id]					
			,bservers.[id] as parent_bserver_id
			,bservers.[ip_or_dns_name] as parent_bserver_name
			,jobs.[pwd_key_id]
		FROM 
			[dbo].[C.BJobs] jobs 
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON jobs.[db_instance_id] = bservers.[current_db_id]
		WHERE 
			bservers.[major_version] >= 7 AND
			jobs.[type] = 202 -- failover plan
GO



--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn.GetRepositoryUniqueIdByIdOrEmptyId]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn.GetRepositoryUniqueIdByIdOrEmptyId]
GO
CREATE FUNCTION [dbo].[fn.GetRepositoryUniqueIdByIdOrEmptyId]
(
	@db_instance_id uniqueidentifier,
	@repo_id_or_null uniqueidentifier
)
RETURNS uniqueidentifier
AS
BEGIN
	
	declare @repo_unqiue_id uniqueidentifier
	
	SELECT @repo_unqiue_id = repo.unique_id FROM [dbo].[C.BackupRepositories] repo 
	WHERE repo.[db_instance_id] = @db_instance_id AND 
	repo.id = 
		CASE
		 WHEN @repo_id_or_null = '00000000-0000-0000-0000-000000000000' THEN '88788F9E-D8F5-4eb4-BC4F-9B3F5403BCEC'
		 ELSE @repo_id_or_null
		END
	
	RETURN @repo_unqiue_id
END
GO


--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.BackupsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.BackupsView]
GO
	CREATE VIEW [dbo].[Rest.BackupsView] 
	AS
		SELECT
			q.[id],
			q.[name],
			q.[job_id],
			q.[job_name],
			q.[platform],
			q.[backupserver_id],
			q.[backupinstance_id],
			q.[backupserver_name],
			repo.[unique_id] as repository_id,
			repo.[name] as repository_name			
		FROM 
		(
		SELECT 
			backups.[id] as id,
			backups.[job_name] as name,
			backups.[job_id] as job_id,			
			backups.[platform],
			backups.[job_name] as job_name,			
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name,
			[dbo].[fn.GetRepositoryUniqueIdByIdOrEmptyId](backups.[db_instance_id], backups.[repository_id]) repo_unique_id
		FROM 
			[dbo].[C.Backup.Model.Backups] backups			
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON backups.[db_instance_id] = bservers.[current_db_id]
		WHERE 
			backups.[job_target_type] = 0
		) q
		INNER JOIN [dbo].[C.BackupRepositories] repo ON q.repo_unique_id = repo.[unique_id]
		--WHERE bservers.[major_version] >= 7
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.ReplicasView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.ReplicasView]
GO
	CREATE VIEW [dbo].[Rest.ReplicasView] 
	AS
		SELECT
			q.[id],
			q.[name],
			q.[job_id],
			q.[job_name],
			q.[platform],
			q.[backupserver_id],
			q.[backupinstance_id],
			q.[backupserver_name],
			repo.[unique_id] as repository_id,
			repo.[name] as repository_name			
		FROM 
		(
		SELECT 
			backups.[id] as id,
			backups.[job_name] as name,
			backups.[job_id] as job_id,	
			backups.[platform],
			backups.[job_name] as job_name,			
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name,
			[dbo].[fn.GetRepositoryUniqueIdByIdOrEmptyId](backups.[db_instance_id], backups.[repository_id]) repo_unique_id
		FROM 
			[dbo].[C.Backup.Model.Backups] backups			
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON backups.[db_instance_id] = bservers.[current_db_id]
		WHERE 
			backups.[job_target_type] = 1 AND
			backups.[target_type] != 100
		) q
		INNER JOIN [dbo].[C.BackupRepositories] repo ON q.repo_unique_id = repo.[unique_id]
		--WHERE bservers.[major_version] >= 7
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.RestorePointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.RestorePointsView]
GO
	CREATE VIEW [dbo].[Rest.RestorePointsView] 
	AS
		SELECT 
			points.[id] as id,
			CAST(points.[creation_time] as nvarchar(256)) as name,
			points.[creation_time] as point_creation_time,
			backups.[id] as backup_id,			
			backups.[job_name] as backup_name,
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name
		FROM 
			[dbo].[C.Backup.Model.Points] points
			INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON points.[backup_id] = backups.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON backups.[db_instance_id] = bservers.[current_db_id]
		WHERE 
			backups.[job_target_type] = 0
			AND bservers.[major_version] >= 7
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.VmRestorePointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.VmRestorePointsView]
GO
	CREATE VIEW [dbo].[Rest.VmRestorePointsView]
	AS
		SELECT 
			oibs.[id],
			oibs.[object_id],
			oibs.[vmname] + '@' + CONVERT(nvarchar(50), oibs.creation_time, 120) as name,
			oibs.[vmname] as vm_real_name,
			oibs.[display_name] as vm_display_name,
			oibs.[creation_time] as creation_time,
			oibs.[type] as type,
			oibs.[alg] as algorithm,
			oibs.[has_index] as has_index,
			oibs.[original_oib_id] as original_oib_id,
			oibs.[parent_id] as parent_id,
			oibs.[aux_data] as aux_data,
			oibsforparents.[display_name] as parent_name,
			bobjects.[viobject_type] as object_type_str,
			points.[id] as point_id,
			CAST(points.[creation_time] as nvarchar(256)) as point_name,
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name,
			backups.[id] as backup_id,			
			backups.[job_name] as backup_name,
			bobjects.[object_id] as obj_ref,
			bobjects.[host_id],
			bobjects.[type] as object_type,
			host.[type] as object_host_type
		FROM 
			[dbo].[C.Backup.Model.OIBs] oibs
			INNER JOIN [dbo].[C.Backup.Model.Points] points ON oibs.[point_id] = points.[id]
			INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON points.[backup_id] = backups.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON points.[db_instance_id] = bservers.[current_db_id]
			INNER JOIN [dbo].[C.BObjects] bobjects ON oibs.[object_id] = bobjects.[id]
			LEFT JOIN [dbo].[C.Backup.Model.OIBs] oibsforparents ON oibsforparents.[id] = oibs.[parent_id]
			INNER JOIN [dbo].[C.Hosts] host ON bobjects.[host_id] = host.[id]
		WHERE 
			backups.[job_target_type] = 0 AND
			bservers.[major_version] >= 7 AND 
			oibs.is_corrupted = 0 AND
			bobjects.[viobject_type] = N'VirtualMachine'
			OR bobjects.[viobject_type] = N'Vm' --hv VM
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.VAppRestorePointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.VAppRestorePointsView]
GO
	CREATE VIEW [dbo].[Rest.VAppRestorePointsView]
	AS
		SELECT 
			oibs.[id],
			oibs.[object_id],
			oibs.[vmname] + '@' + CONVERT(nvarchar(50), oibs.creation_time, 120) as name,
			oibs.[vmname] as vapp_real_name,
			oibs.[display_name] as vapp_display_name,
			oibs.[creation_time] as creation_time,
			oibs.[type] as type,
			oibs.[alg] as algorithm,
			oibs.[has_index] as has_index,
			oibs.[original_oib_id] as original_oib_id,
			bobjects.[viobject_type] as object_type_str,
			points.[id] as point_id,
			CAST(points.[creation_time] as nvarchar(256)) as point_name,
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name,
			backups.[id] as backup_id,			
			backups.[job_name] as backup_name,
			bobjects.[object_id] as obj_ref,
			bobjects.[type] as object_type,	
			bobjects.[host_id],		
			host.[type] as object_host_type
		FROM 
			[dbo].[C.Backup.Model.OIBs] oibs
			INNER JOIN [dbo].[C.Backup.Model.Points] points ON oibs.[point_id] = points.[id]
			INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON points.[backup_id] = backups.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON points.[db_instance_id] = bservers.[current_db_id]
			INNER JOIN [dbo].[C.BObjects] bobjects ON oibs.[object_id] = bobjects.[id]			
			INNER JOIN [dbo].[C.Hosts] host ON bobjects.[host_id] = host.[id]
		WHERE 
			backups.[job_target_type] = 0 AND
			bservers.[major_version] >= 7 AND 
			oibs.is_corrupted = 0 AND
			bobjects.[viobject_type] = N'Vapp'
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.VmReplicaPointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.VmReplicaPointsView]
GO
	CREATE VIEW [dbo].[Rest.VmReplicaPointsView]
	AS
		SELECT 
			oibs.[id],
			oibs.[object_id],
			oibs.[vmname] + '@' + CONVERT(nvarchar(50), oibs.creation_time, 120) as name,
			oibs.[vmname] as vm_real_name,
			oibs.[display_name] as vm_display_name,
			oibs.[creation_time] as creation_time,
			oibs.[type] as type,
			oibs.[alg] as algorithm,
			oibs.[has_index] as has_index,
			oibs.[original_oib_id] as original_oib_id,
			backups.[id] as backup_id,			
			backups.[job_name] as backup_name,		
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name
		FROM 
			[dbo].[C.Backup.Model.OIBs] oibs
			INNER JOIN [dbo].[C.Backup.Model.Points] points ON oibs.[point_id] = points.[id]
			INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON points.[backup_id] = backups.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON points.[db_instance_id] = bservers.[current_db_id]
		WHERE 
			backups.[job_target_type] = 1 AND
			bservers.[major_version] >= 7 AND 
			oibs.is_corrupted = 0 AND
			backups.[target_type] = 2
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.RepositoriesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.RepositoriesView]
GO
	CREATE VIEW [dbo].[Rest.RepositoriesView]
	AS
		SELECT
			r.unique_id as id,
			r.name as name,
			r.total_space,
			r.free_space,			
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name	
		FROM
			[dbo].[C.BackupRepositories] r 			
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON r.[db_instance_id] = bservers.[current_db_id]
		WHERE bservers.[major_version] >= 7 AND
			r.id not in (select dependant_repo_id from [C.Backup.ExtRepo.ExtRepos])
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.BackupJobSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.BackupJobSessionsView]
GO
	CREATE VIEW [dbo].[Rest.BackupJobSessionsView]
	AS
		SELECT 
			js.id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS name,
			js.job_type,
			js.job_id,
			js.job_name,
			js.creation_time,
			js.end_time,
			js.state,
			js.result,
			bjs.is_retry,
			bjs.cur_point_id,
			CAST(pt.[creation_time] as nvarchar(256)) as cur_point_name,
			js.reason as failure_message,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			js.progress
		FROM 
			[dbo].[C.Backup.Model.BackupJobSessions] bjs
			INNER JOIN [dbo].[C.Backup.Model.JobSessions] js ON bjs.id = js.id
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON bjs.db_instance_id = bs.current_db_id
			LEFT JOIN [dbo].[C.Backup.Model.Points] pt ON pt.id = bjs.cur_point_id
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 0
			
GO
--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.ReplicaJobSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.ReplicaJobSessionsView]
GO
	CREATE VIEW [dbo].[Rest.ReplicaJobSessionsView]
	AS
		SELECT 
			js.id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS name,
			js.job_type,
			js.job_id,
			js.job_name,
			js.progress,
			js.creation_time,
			js.end_time,
			js.state,
			js.result,
			bjs.is_retry,
			js.reason as failure_message,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name
		FROM 
			[dbo].[C.Backup.Model.BackupJobSessions] bjs
			INNER JOIN [dbo].[C.Backup.Model.JobSessions] js ON bjs.id = js.id
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON bjs.db_instance_id = bs.current_db_id
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 1

GO
------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.TaskSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.TaskSessionsView]
GO
	CREATE VIEW [dbo].[Rest.TaskSessionsView]
	AS
		SELECT 
			ts.id,
			ts.session_id as jobsession_id,
			ts.object_name + '@' + CONVERT(nvarchar(50), ts.creation_time, 120) AS name,
			ts.creation_time,
			ts.end_time,
			ts.status,
			ts.object_name as vm_display_name,
			CAST(ts.reason as nvarchar(max)) as reason,
			ts.total_size,
			js.job_id as job_id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS job_session_name,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			oib.[id] as oib_id,
			oib.[vmname] + '@' + CONVERT(nvarchar(50), oib.creation_time, 120) as oib_name,
			js.job_name
		FROM 
			[dbo].[C.Backup.Model.BackupTaskSessions] ts
			JOIN [dbo].[C.Backup.Model.JobSessions] js ON ts.session_id = js.id
			JOIN [dbo].[Repl.Topology.BackupServers] bs ON js.db_instance_id = bs.current_db_id 
			LEFT JOIN [C.Backup.Model.BackupJobSessions] bjs ON js.id = bjs.id
			LEFT JOIN [dbo].[C.Backup.Model.Points] p ON p.id = bjs.cur_point_id		
			LEFT JOIN [dbo].[C.Backup.Model.OIBs] oib ON oib.point_id = p.id AND ts.[object_id] = oib.[object_id] AND oib.is_corrupted = 0
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 0
GO
------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.ReplicaTaskSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.ReplicaTaskSessionsView]
GO
	CREATE VIEW [dbo].[Rest.ReplicaTaskSessionsView]
	AS
		SELECT 
			ts.id,
			ts.session_id as jobsession_id,
			ts.object_name + '@' + CONVERT(nvarchar(50), ts.creation_time, 120) AS name,
			ts.creation_time,
			ts.end_time,
			ts.status,
			ts.object_name as vm_display_name,
			CAST(ts.reason as nvarchar(max)) as reason,
			ts.total_size,
			js.job_id as job_id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS job_session_name,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			oib.[id] as oib_id,
			oib.[vmname] + '@' + CONVERT(nvarchar(50), oib.creation_time, 120) as oib_name,
			js.job_name
		FROM 
			[dbo].[C.Backup.Model.BackupTaskSessions] ts
			JOIN [dbo].[C.Backup.Model.JobSessions] js ON ts.session_id = js.id
			JOIN [dbo].[Repl.Topology.BackupServers] bs ON js.db_instance_id = bs.current_db_id 
			LEFT JOIN [dbo].[C.Backup.Model.Backups] b ON b.job_id = js.job_id
			LEFT JOIN [dbo].[C.Backup.Model.Points] p ON p.backup_id = b.id
			LEFT JOIN [dbo].[C.Backup.Model.OIBs] oib ON oib.point_id = p.id AND ts.[object_id] = oib.[object_id]
			AND oib.creation_time >= js.creation_time AND oib.creation_time < js.end_time AND oib.is_corrupted = 0
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 1
GO
--------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.BackupServersView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.BackupServersView]
GO
	CREATE VIEW [dbo].[Rest.BackupServersView]
	AS
		SELECT 
			bs.id,
			bs.display_name AS name,
			bs.ip_or_dns_name,
			bs.description,
			bs.current_db_id,
			bs.port,
			bs.version,
			name_in_catalog  
		FROM 
			[dbo].[Repl.Topology.BackupServers] bs
			LEFT OUTER JOIN [Repl.Topology.BackupServerCreds] bsc ON  bs.id = bsc.backup_server
		WHERE bs.[major_version] >= 7
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.UserVmRestorePointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.UserVmRestorePointsView]
GO
	CREATE VIEW [dbo].[Rest.UserVmRestorePointsView]
	AS
		SELECT 
			vrp.*,
			t.sid as userSid
		FROM [dbo].[Rest.VmRestorePointsView] vrp
		JOIN 
		(
			SELECT DISTINCT lu.sid_string as sid, bo.id 
			FROM [dbo].[C.BObjects] bo 
			JOIN [dbo].[Security.VmsRecursiveInclusion] vri on vri.vm_key_hash = bo.unique_key_hash
			JOIN [dbo].[Security.HierarchyScopes] hs on hs.hierarchy_object_keyhash = vri.container_key_hash
			JOIN [dbo].[Security.RoleAccounts] ra on ra.role_group_id = hs.role_account_group_id
			JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
			JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
		) as t on t.id = vrp.object_id		
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.UserVAppRestorePointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.UserVAppRestorePointsView]
GO
	CREATE VIEW [dbo].[Rest.UserVAppRestorePointsView]
	AS
		SELECT 
			vrp.*,
			t.sid as userSid
		FROM [dbo].[Rest.VAppRestorePointsView] vrp
		JOIN 
		(
			SELECT DISTINCT lu.sid_string as sid, bo.id 
			FROM [dbo].[C.BObjects] bo 
			JOIN [dbo].[Security.VmsRecursiveInclusion] vri on vri.vm_key_hash = bo.unique_key_hash
			JOIN [dbo].[Security.HierarchyScopes] hs on hs.hierarchy_object_keyhash = vri.container_key_hash
			JOIN [dbo].[Security.RoleAccounts] ra on ra.role_group_id = hs.role_account_group_id
			JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
			JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
		) as t on t.id = vrp.object_id		
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.UserVmReplicaPointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.UserVmReplicaPointsView]
GO
	CREATE VIEW [dbo].[Rest.UserVmReplicaPointsView]
	AS
		SELECT 
			vrp.*,
			t.sid as userSid
		FROM [dbo].[Rest.VmReplicaPointsView] vrp
		JOIN 
		(
			SELECT DISTINCT lu.sid_string as sid, bo.id 
			FROM [dbo].[C.BObjects] bo 
			JOIN [dbo].[Security.VmsRecursiveInclusion] vri on vri.vm_key_hash = bo.unique_key_hash
			JOIN [dbo].[Security.HierarchyScopes] hs on hs.hierarchy_object_keyhash = vri.container_key_hash
			JOIN [dbo].[Security.RoleAccounts] ra on ra.role_group_id = hs.role_account_group_id
			JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
			JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
		) as t on t.id = vrp.object_id		
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.ObjectsInJobView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.ObjectsInJobView]
GO
	CREATE VIEW [dbo].[Rest.ObjectsInJobView]
	AS
		SELECT 
			objsInJob.[id] AS id,
		    objsInJob.[vss_options] AS oij_vss_options,
		    objsInJob.[type] AS oij_type,
			objsInJob.[order_no] AS oij_order_no,
		    objs.[type] as obj_type,
		    objs.[object_name] as obj_name,
		    objs.[object_id] as obj_ref,
		    objs.[viobject_type] as obj_type_str,
            objs.[display_name]as obj_display_name,
			objs.[platform]as obj_platform,	
			objs.[host_id] as obj_host_id,
			jobs.[id] as job_id,
			jobs.[name] as job_name,
			bservers.[id] as bserver_id,
			bservers.[ip_or_dns_name] as bserver_name

	    FROM [dbo].[C.ObjectsInJobs] objsInJob 
			INNER JOIN [dbo].[C.BJobs] jobs ON objsInJob.[job_id] = jobs.[id]
			INNER JOIN [dbo].[C.BObjects] objs ON objsInJob.[object_id] = objs.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON objsInJob.[db_instance_id] = bservers.[current_db_id]		
		WHERE bservers.[major_version] >= 7
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.FailoveredVmsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.FailoveredVmsView]
GO
	CREATE VIEW [dbo].[Rest.FailoveredVmsView]
	AS
		SELECT 
			objsInJob.[id] AS id,
		    objsInJob.[vss_options] AS fvm_vss_options,
			objsInJob.[order_no] AS fvm_order_no,
		    objs.[object_name] as fvm_name,
		    objs.[object_id] as fvm_ref,
            objs.[display_name]as fvm_display_name,	
			objs.[host_id] as fvm_host_id,
			objs.[platform]as obj_platform,	
			objs.[type] as obj_type,
			objs.[viobject_type] as obj_type_str,
			jobs.[id] as job_id,
			jobs.[name] as job_name,
			bservers.[id] as bserver_id,
			bservers.[ip_or_dns_name] as bserver_name
	    FROM [dbo].[C.ObjectsInJobs] objsInJob 
			INNER JOIN [dbo].[C.BJobs] jobs ON objsInJob.[job_id] = jobs.[id]
			INNER JOIN [dbo].[C.BObjects] objs ON objsInJob.[object_id] = objs.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON objsInJob.[db_instance_id] = bservers.[current_db_id]		
		WHERE bservers.[major_version] >= 7 AND jobs.[type] = 202 -- failover plan
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.AccountRolesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.AccountRolesView]
GO
	CREATE VIEW [dbo].[Rest.AccountRolesView]
	AS
		SELECT 
			ra.[id] AS id,
			ra.[role_id] AS role_id,
			roles.[name] AS role_name,
			ra.[account_id] AS account_id,
			acc.[name] AS account_name,
			ra.[settings] as settings
	    FROM [dbo].[Security.RoleAccounts] ra
			INNER JOIN [dbo].[Security.Roles] roles ON ra.[role_id] = roles.[id]
			INNER JOIN [dbo].[Security.Accounts] acc ON ra.[account_id] = acc.[id]	
GO


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.AccountScopesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.AccountScopesView]
GO
CREATE VIEW [dbo].[Rest.AccountScopesView]
	AS
	SELECT DISTINCT 
		s.id, 
		ra.account_id,
		s.role_account_group_id, 
		s.scope_state, 
		s.scope_name, 
		s.hierarchy_root_instance_id, 
		s.hierarchy_object_ref, 
		s.hierarchy_object_type,
		s.platform
		
	FROM [dbo].[Security.HierarchyScopes] s
	JOIN [dbo].[Security.RoleAccounts] ra ON (ra.role_group_id = s.role_account_group_id)
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[Rest.AccountsView]'))
DROP VIEW [dbo].[Rest.AccountsView]
GO

CREATE VIEW [dbo].[Rest.AccountsView]
	AS
		SELECT DISTINCT
			acc.*,
			ra.security_scope_enabled as security_scope_enabled 
			FROM [dbo].[Security.RoleAccounts] ra
			INNER JOIN [dbo].[Security.Accounts] acc ON acc.id = ra.account_id
GO


--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.RestoreJobSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.RestoreJobSessionsView]
GO
	CREATE VIEW [dbo].[Rest.RestoreJobSessionsView]
	AS
		SELECT 
			js.id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS name,
			js.job_type,
			js.creation_time,
			js.end_time,
			js.state,
			rjs.oib_display_name as vm_display_name,
			js.result,
			js.progress,
			js.reason as failure_message,
			-- bjs.is_retry,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			rjs.restored_obj_id as restored_obj_id,
			rjs.oib_id,
			CASE 
				WHEN bo.[viobject_type] = N'Vapp' THEN 1
				WHEN bo.[viobject_type] = N'VirtualMachine' OR bo.[viobject_type] = N'Vm' THEN 0
				ELSE -1
			END as restore_oib_type,
			oibs.[vmname] + '@' + CONVERT(nvarchar(50), oibs.creation_time, 120) as oib_name
		FROM 
			[dbo].[C.Backup.Model.RestoreJobSessions] rjs
			INNER JOIN [dbo].[C.Backup.Model.JobSessions] js ON rjs.id = js.id
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON rjs.db_instance_id = bs.current_db_id
			LEFT  JOIN [dbo].[C.Backup.Model.OIBs] oibs ON rjs.oib_id = oibs.id
			INNER JOIN [dbo].[C.BObjects] bo ON oibs.object_id = bo.id
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type IN (4, 5, 6, 7, 10, 11, 13, 25, 29, 41, 42, 48)
GO


--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.UserRestorePointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.UserRestorePointsView]
GO
	CREATE VIEW [dbo].[Rest.UserRestorePointsView]
	AS
	
		SELECT DISTINCT
			pt.*,
			t.sid as userSid
		FROM [dbo].[Rest.RestorePointsView] pt
		JOIN [dbo].[C.Backup.Model.OIBs] vmpt ON pt.[id] = vmpt.[point_id]
		JOIN 
		(
			SELECT DISTINCT lu.sid_string as sid, bo.id 
			FROM [dbo].[C.BObjects] bo 
			JOIN [dbo].[Security.VmsRecursiveInclusion] vri on vri.vm_key_hash = bo.unique_key_hash
			JOIN [dbo].[Security.HierarchyScopes] hs on hs.hierarchy_object_keyhash = vri.container_key_hash
			JOIN [dbo].[Security.RoleAccounts] ra on ra.role_group_id = hs.role_account_group_id
			JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
			JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
		) as t on t.id = vmpt.object_id	
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.UserRestoreJobSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.UserRestoreJobSessionsView]
GO
	CREATE VIEW [dbo].[Rest.UserRestoreJobSessionsView]
	AS
		SELECT 
			js.id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS name,
			js.job_type,
			js.creation_time,
			js.end_time,
			js.state,
			rjs.oib_display_name as vm_display_name,
			js.result,
			js.progress,
			js.reason as failure_message,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			t.sid as userSid,
			rjs.oib_id,
			CASE 
				WHEN bobjects.[viobject_type] = N'Vapp' THEN 1
				WHEN bobjects.[viobject_type] = N'VirtualMachine' OR bobjects.[viobject_type] = N'Vm' THEN 0
				ELSE -1
			END as restore_oib_type,
			vmpt.[vmname] + '@' + CONVERT(nvarchar(50), vmpt.creation_time, 120) as oib_name
		FROM 
			[dbo].[C.Backup.Model.RestoreJobSessions] rjs
			INNER JOIN [dbo].[C.Backup.Model.JobSessions] js ON rjs.id = js.id
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON rjs.db_instance_id = bs.current_db_id
			INNER JOIN [dbo].[C.Backup.Model.OIBs] vmpt ON rjs.oib_id = vmpt.[id]
			INNER JOIN [dbo].[C.BObjects] bobjects ON vmpt.object_id = bobjects.id
			INNER JOIN 
			(
				SELECT DISTINCT lu.sid_string as sid, bo.id 
				FROM [dbo].[C.BObjects] bo 
				JOIN [dbo].[Security.VmsRecursiveInclusion] vri on vri.vm_key_hash = bo.unique_key_hash
				JOIN [dbo].[Security.HierarchyScopes] hs on hs.hierarchy_object_keyhash = vri.container_key_hash
				JOIN [dbo].[Security.RoleAccounts] ra on ra.role_group_id = hs.role_account_group_id
				JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
				JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
			) as t on t.id = vmpt.object_id	
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type IN (4, 5, 6, 10, 11, 13, 25, 29, 41, 42, 48)
GO

------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.UserTaskSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.UserTaskSessionsView]
GO
	CREATE VIEW [dbo].[Rest.UserTaskSessionsView]
	AS
		SELECT 
			ts.id,
			ts.object_name + '@' + CONVERT(nvarchar(50), ts.creation_time, 120) AS name,
			ts.creation_time,
			ts.end_time,
			ts.status,
			ts.object_name as vm_display_name,
			CAST(ts.reason as nvarchar(max)) as reason,
			ts.total_size,
			js.job_id as job_id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS job_session_name,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			t.sid as userSid,
			js.job_name
		FROM 
			[dbo].[C.Backup.Model.BackupTaskSessions] ts
			JOIN [dbo].[C.Backup.Model.JobSessions] js ON ts.session_id = js.id
			JOIN [dbo].[Repl.Topology.BackupServers] bs ON js.db_instance_id = bs.current_db_id 
			INNER JOIN 
			(
				SELECT DISTINCT lu.sid_string as sid, bo.id 
				FROM [dbo].[C.BObjects] bo 
				JOIN [dbo].[Security.VmsRecursiveInclusion] vri on vri.vm_key_hash = bo.unique_key_hash
				JOIN [dbo].[Security.HierarchyScopes] hs on hs.hierarchy_object_keyhash = vri.container_key_hash
				JOIN [dbo].[Security.RoleAccounts] ra on ra.role_group_id = hs.role_account_group_id
				JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
				JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
			) as t on t.id = ts.object_id
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 0
GO

------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.UserReplicaTaskSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.UserReplicaTaskSessionsView]
GO
	CREATE VIEW [dbo].[Rest.UserReplicaTaskSessionsView]
	AS
		SELECT 
			ts.id,
			ts.object_name + '@' + CONVERT(nvarchar(50), ts.creation_time, 120) AS name,
			ts.creation_time,
			ts.end_time,
			ts.status,
			ts.object_name as vm_display_name,
			CAST(ts.reason as nvarchar(max)) as reason,
			ts.total_size,
			js.job_id as job_id,
			js.job_name + '@' + CONVERT(nvarchar(50), js.creation_time, 120) AS job_session_name,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			t.sid as userSid,
			js.job_name
		FROM 
			[dbo].[C.Backup.Model.BackupTaskSessions] ts
			JOIN [dbo].[C.Backup.Model.JobSessions] js ON ts.session_id = js.id
			JOIN [dbo].[Repl.Topology.BackupServers] bs ON js.db_instance_id = bs.current_db_id 
			INNER JOIN 
			(
				SELECT DISTINCT lu.sid_string as sid, bo.id 
				FROM [dbo].[C.BObjects] bo 
				JOIN [dbo].[Security.VmsRecursiveInclusion] vri on vri.vm_key_hash = bo.unique_key_hash
				JOIN [dbo].[Security.HierarchyScopes] hs on hs.hierarchy_object_keyhash = vri.container_key_hash
				JOIN [dbo].[Security.RoleAccounts] ra on ra.role_group_id = hs.role_account_group_id
				JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
				JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
			) as t on t.id = ts.object_id
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 1
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.LastBackupJobSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.LastBackupJobSessionsView]
GO
	CREATE VIEW [dbo].[Rest.LastBackupJobSessionsView]
	AS
		SELECT *
		FROM
		(
			SELECT 
				bjs.*,
				ROW_NUMBER() OVER(PARTITION BY job_id ORDER BY end_time DESC) AS number
			FROM [dbo].[Rest.BackupJobSessionsView] bjs
		) t
		WHERE t.number = 1
GO

PRINT N'Creating [dbo].[Rest.WanAcceleratorsView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.WanAcceleratorsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.WanAcceleratorsView]	
GO
	CREATE VIEW [dbo].[Rest.WanAcceleratorsView]
	AS
		SELECT
			wa.[id],
			wa.[name],
			wa.[description],
			wa.[host_id],
			hc.[is_up_to_date] as is_up_to_date,
			hc.[version],
			case 
				when hc.options.exist('/options') = 1
				then hc.options.value('(/options/WanAcceleratorClientOptions/MaxCacheSize)[1]', 'int')
				else hc.options.value('(/WanAcceleratorClientOptions/MaxCacheSize)[1]', 'int')
			end maxCacheSize,
			case 
				when hc.options.exist('/options') = 1
				then hc.options.value('(/options/WanAcceleratorClientOptions/SizeUnit)[1]', 'nvarchar(10)')
				else hc.options.value('(/WanAcceleratorClientOptions/SizeUnit)[1]', 'nvarchar(10)')
			end sizeUnit,
			case 
				when hc.options.exist('/options') = 1
				then hc.options.value('(/options/WanAcceleratorClientOptions/TrafficPort)[1]', 'int')
				else hc.options.value('(/WanAcceleratorClientOptions/TrafficPort)[1]', 'int')
			end trafficPort,			
			case 
				when hc.options.exist('/options') = 1
				then hc.options.value('(/options/WanAcceleratorClientOptions/CachePath)[1]', 'nvarchar(max)')
				else hc.options.value('(/WanAcceleratorClientOptions/CachePath)[1]', 'nvarchar(max)')
			end cachePath,		
			case 
				when hc.options.exist('/options') = 1
				then hc.options.value('(/options/WanAcceleratorClientOptions/DownloadStreamCount)[1]', 'int') 
				else hc.options.value('(/WanAcceleratorClientOptions/DownloadStreamCount)[1]', 'int') 
			end connectionsCount,		
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name	
		FROM [dbo].[C.WanAccelerators] wa
		JOIN [dbo].[C.Hosts] h ON wa.[host_id] = h.[id]
		JOIN [dbo].[C.HostComponents] hc ON hc.[physical_host_id] = h.[physical_host_id]
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON wa.[db_instance_id] = bservers.[current_db_id]
		WHERE hc.[type] = 5 AND bservers.[major_version] >= 7
GO

PRINT N'Creating [dbo].[Rest.CloudGatesView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudGatesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudGatesView]	
GO
	CREATE VIEW [dbo].[Rest.CloudGatesView]
	AS
		select
			cg.id, 
			cg.name, 
			cg.description, 
			cg.creds_id, 
			 
			case 
				when cg.options.exist('/options') = 1
				then cg.options.value('(/options/CloudGateClientOptions/ExternalIP)[1]', 'nvarchar(20)')
				else cg.options.value('(/CloudGateClientOptions/ExternalIP)[1]', 'nvarchar(20)')
			end external_ip,
			case 
				when cg.options.exist('/options') = 1
				then cg.options.value('(/options/CloudGateClientOptions/ExternPort)[1]', 'int')
				else cg.options.value('(/CloudGateClientOptions/ExternPort)[1]', 'int')
			end external_port,
			case 
				when cg.options.exist('/options') = 1
				then cg.options.value('(/options/CloudGateClientOptions/NetworkMode)[1]', 'int')
				else cg.options.value('(/CloudGateClientOptions/NetworkMode)[1]', 'int')
			end network_mode,
			case 
				when cg.options.exist('/options') = 1
				then cg.options.value('(/options/CloudGateClientOptions/NATPort)[1]', 'int')
				else cg.options.value('(/CloudGateClientOptions/NATPort)[1]', 'int')
			end nat_port,
			case 
				when cg.options.exist('/options') = 1
				then cg.options.value('(/options/CloudGateClientOptions/MgmtPort)[1]', 'int')
				else cg.options.value('(/CloudGateClientOptions/MgmtPort)[1]', 'int')
			end internal_port,		

			~cg.disabled as enabled,
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name	
		from [C.Backup.Model.CloudGates] cg
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON cg.[db_instance_id] = bservers.[current_db_id]

GO

--------------------------------------------------------------------------------
PRINT N'Creating [dbo].[Rest.TenantLastActiveView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.TenantLastActiveView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.TenantLastActiveView]
GO

	CREATE VIEW [dbo].[Rest.TenantLastActiveView]
	AS
	SELECT DISTINCT ten_sess.tenant_id,
			 job_sess.id,
			 job_sess.end_time,
			 job_sess.state,
			 job_sess.result,
			 csess.session_type						 
	FROM 
	(
		(SELECT trq.tenant_id as tenant_id, soc.session_id as session_id FROM [C.TenantsResourcesQuota] trq
			RIGHT JOIN [dbo].[C.Backup.Model.CloudSessionsOnQuotas] soc on soc.quota_id=trq.id)
		UNION
		(SELECT tviq.tenantId as tenant_id, sovic.session_id as session_id FROM [C.Backup.Model.ViHardwareQuotas] tviq
			RIGHT JOIN [dbo].[C.Backup.Model.CloudSessionsOnViHardwareQuotas] sovic on sovic.quota_id=tviq.id)
		UNION
		(SELECT thvq.tenantId as tenant_id, sohvc.session_id as session_id FROM [C.Backup.Model.HvHardwareQuotas] thvq
			RIGHT JOIN [dbo].[C.Backup.Model.CloudSessionsOnHvHardwareQuotas] sohvc on sohvc.quota_id=thvq.id)
	) ten_sess
		LEFT JOIN [C.Backup.Model.JobSessions] job_sess ON job_sess.id = ten_sess.session_id 
			LEFT JOIN [C.Backup.Model.CloudSessions] csess ON csess.id = job_sess.id
				LEFT JOIN	(
								SELECT viq.tenantId, Count(*) as num FROM [C.Replicas] r 
									JOIN [C.Backup.Model.ViCloudTenantBackups] vicb ON r.backup_id = vicb.backup_id
										JOIN [C.Backup.Model.ViHardwareQuotas] viq ON vicb.quota_id = viq.id
								Where r.state = 2
								GROUP BY viq.tenantId
							) frepl ON frepl.tenantId = ten_sess.tenant_id

	WHERE job_sess.creation_time IN (SELECT MAX(creation_time) 
									FROM [C.Backup.Model.JobSessions] js 
										LEFT JOIN [C.Backup.Model.CloudSessions] cs ON cs.id = js.id
										WHERE cs.session_type <> 3 
											AND 
											(
											 exists (SELECT * FROM  [dbo].[C.Backup.Model.CloudSessionsOnQuotas] 
													WHERE session_id  = cs.id)
													OR
											 exists (SELECT * FROM  [dbo].[C.Backup.Model.CloudSessionsOnViHardwareQuotas] 
													WHERE session_id  = cs.id)
													OR
											 exists (SELECT * FROM  [dbo].[C.Backup.Model.CloudSessionsOnHvHardwareQuotas] 
													WHERE session_id  = cs.id)
											)
										GROUP BY cs.tenant_id
									)

GO

PRINT N'Creating [dbo].[Rest.CloudTenantsView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudTenantsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudTenantsView]	
GO
	CREATE VIEW [dbo].[Rest.CloudTenantsView]
	AS
		select
			ct.id, 
			ct.name, 
			ct.description, 
			ct.expire_time,  
			ct.throttling_speed_limit,
			ct.throttling_speed_unit,
			ct.is_throttling_enabled,
			ct.max_concurent_tasks,
			~ct.disabled as enabled,			
			--ISNULL((SELECT end_time FROM [dbo].[view.Cloud.LastActiveView] lav  where lav.tenant_id = ct.id),DATEADD(dd, -1, GETDATE())) as last_active, 
			--ISNULL((SELECT result FROM [dbo].[view.Cloud.LastActiveView] lav  where lav.tenant_id = ct.id),-1) as last_result,
			ISNULL(lav.end_time,DATEADD(dd, -1, GETDATE())) as last_active, 
			ISNULL(lav.result,-1) as last_result,
			vm_count = 
			ISNULL((
				SELECT COUNT(DISTINCT cvms.vm_id) FROM [C.Backup.Model.CloudVmsOnQuotas] cvms 
				LEFT JOIN [C.TenantsResourcesQuota] trq on cvms.resource_quota_id = trq.id 
				where trq.[tenant_id] = ct.[id]),0),
			replica_count = 
				(select count(vib.[object_id]) from [dbo].[C.Backup.Model.ViCloudQuotaObjects] vib 
					inner join [dbo].[C.Backup.Model.ViHardwareQuotas] viq on viq.id = vib.quota_id 
					inner join [dbo].[C.Backup.Model.CloudLicensedObjects] clo ON clo.[object_id] = vib.[object_id]
					where viq.tenantId = ct.[id])
				+ (select count(hib.[object_id]) from [dbo].[C.Backup.Model.HvCloudQuotaObjects] hib 
					inner join [dbo].[C.Backup.Model.HvHardwareQuotas] hiq on hiq.id = hib.quota_id 
					inner join [dbo].[C.Backup.Model.CloudLicensedObjects] clo ON clo.[object_id] = hib.[object_id]
					where hiq.tenantId = ct.[id]),
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name,
			(SELECT COUNT(ips.ip_address) FROM [C.Backup.Model.CloudPublicIp] as ips where ct.id = ips.tenant_id) as public_ip_count
		from [C.Tenants] ct
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON ct.[db_instance_id] = bservers.[current_db_id]
		LEFT JOIN [dbo].[Rest.TenantLastActiveView] lav on  ct.[id] = lav.[tenant_id]
GO


PRINT N'Creating [dbo].[Rest.CloudTenantResourcesView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudTenantResourcesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudTenantResourcesView]	
GO
	CREATE VIEW [dbo].[Rest.CloudTenantResourcesView]
	AS
		select
			tr.id, 
			tr.friendly_name as name,
			tr.tenant_id, 
			tr.folder,
			ct.name as tenant_name, 
			parent_repos.[unique_id] as repository_id, 
			tr.wan_id,  
			tr.quota_mb,
			tr.used_quota_mb,
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name	
		from [C.TenantsResourcesQuota] tr
		JOIN [C.Tenants] ct ON ct.[id] = tr.[tenant_id]
		JOIN [dbo].[C.BackupRepositories] parent_repos ON parent_repos.[id] = tr.repository_id AND parent_repos.[db_instance_id] = tr.[db_instance_id]
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON tr.[db_instance_id] = bservers.[current_db_id]

GO

PRINT N'Creating [dbo].[Rest.ManagedServersView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.ManagedServersView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.ManagedServersView]	
GO
	CREATE VIEW [dbo].[Rest.ManagedServersView]
	AS
		SELECT 
			 h.[id]
			,h.[type]
			,h.[name]
			,h.[ip]
			,h.[parent_id]
			,h.[info]
			,h.[description]
			,h.[protocol]
			,h.[reference]
			,h.[api_version]
			,h.[db_instance_id]
			,h.[win_creds]
			,h.[physical_host_id]
			,h.[host_instance_id]
			,bs.[id] [bs_id]
			,bs.[display_name] [bs_name]
		FROM 
			[dbo].[C.Hosts] h,
			[dbo].[Repl.Topology.BackupServers] bs
		WHERE 
			[dbo].[fn.IsRootVisibleHost](h.[id]) = 1 and
			h.[db_instance_id] = bs.[current_db_id] and
			bs.[major_version] >= 7 

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[fn.Rest.FailoverPlan.GetAccessible]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn.Rest.FailoverPlan.GetAccessible]
GO
CREATE FUNCTION [dbo].[fn.Rest.FailoverPlan.GetAccessible] 
(
	@userSid nvarchar(max)
)
RETURNS
@t_resultTable TABLE(
			row_num BIGINT,
			id UNIQUEIDENTIFIER,
			name NVARCHAR(255),
			db_instance_id UNIQUEIDENTIFIER,
			[description] NVARCHAR(1024),
			[platform] INT,
			[options] XML,			
		    [is_deleted] BIT,
		    [latest_result] INT,
		    [vss_options] XML,
		    [vcb_host_id] UNIQUEIDENTIFIER,
		    [target_type] INT,
		    parent_bserver_id UNIQUEIDENTIFIER,
		    parent_bserver_name NVARCHAR(255),
		    [pwd_key_id] UNIQUEIDENTIFIER
		)
AS
BEGIN
	DECLARE
		@t_notAllowed TABLE(jobId UNIQUEIDENTIFIER);

	DECLARE
		@t_userRoles TABLE (id UNIQUEIDENTIFIER);
	DECLARE
		@v_binSid	varbinary(max),
		@v_restoreVmRole uniqueidentifier,
		@v_adminRole uniqueidentifier;
	SET @v_restoreVmRole = 'C11C0C38-BA8B-49c7-BF70-FC2058FFF1E2';
	SET @v_adminRole     = '5F37A46B-9CE2-40F4-8A62-B45B079257FC';
	SET @v_binSid = (
		SELECT TOP 1
			lu.sid_binary
		FROM
			[dbo].[Security.LoggedOnUsers] lu
		WHERE
			lu.sid_string = @userSid
		)
	INSERT INTO
		@t_userRoles
	SELECT DISTINCT 
		r.[id] as role_id
	FROM [dbo].[Security.Roles] r 
		JOIN [dbo].[Security.RoleAccounts] ra ON ra.[role_id] = r.[id] 
		JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
		JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
	WHERE
		lu.sid_binary = @v_binSid

	IF EXISTS (SELECT id FROM @t_userRoles WHERE id in (@v_restoreVmRole, @v_adminRole))
	BEGIN
		INSERT INTO
			@t_notAllowed ( jobId ) 	
		SELECT
			jobs.id
		FROM [C.BJobs] jobs
		JOIN [C.ObjectsInJobs] AS oijs ON oijs.job_id = jobs.id
		LEFT JOIN 
		(
			SELECT
				id
			FROM
				[dbo].[fn.Backup.GetRoleAccessibleObjects](@v_binSid, @v_restoreVmRole)
		) as t on t.id = oijs.[object_id]
		WHERE 
			jobs.[type] = 202 AND
			t.id IS NULL
		GROUP BY jobs.id
		INSERT INTO 
			@t_resultTable
		SELECT 
			 ROW_NUMBER() OVER (ORDER BY jobs.id)
			,jobs.id
			,jobs.name
			,jobs.db_instance_id
			,jobs.[description] 
			,jobs.[platform] 
			,jobs.[options]			
			,jobs.[is_deleted]
			,jobs.[latest_result]
			,jobs.[vss_options]
			,jobs.[vcb_host_id]
			,jobs.[target_type]				
			,bservers.[id] 
			,bservers.[ip_or_dns_name] 
			,jobs.[pwd_key_id]
		FROM [C.BJobs] jobs
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON jobs.[db_instance_id] = bservers.[current_db_id]
		LEFT JOIN [dbo].[C.Backup.Model.CloudFailoverPlan] cloudfp ON jobs.id = cloudfp.job_id
		WHERE 
			jobs.type = 202 AND
			jobs.id NOT IN ( SELECT jobId FROM @t_notAllowed ) AND
			bservers.[major_version] >= 7 AND
			cloudfp.job_id IS NULL
		ORDER BY jobs.name	
	END
	RETURN;
END
GO	

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[fn.Rest.CloudFailoverPlan.GetAccessible]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn.Rest.CloudFailoverPlan.GetAccessible]
GO
CREATE FUNCTION [dbo].[fn.Rest.CloudFailoverPlan.GetAccessible] 
(
	@userSid nvarchar(max)
)
RETURNS
@t_resultTable TABLE(
			row_num BIGINT,
			id UNIQUEIDENTIFIER,
			name NVARCHAR(255),
			tenant_id UNIQUEIDENTIFIER,
			tenant_name NVARCHAR(255),
			db_instance_id UNIQUEIDENTIFIER,
			[description] NVARCHAR(1024),
			[platform] INT,
			[options] XML,			
		    [is_deleted] BIT,
		    [latest_result] INT,
		    [vss_options] XML,
		    [vcb_host_id] UNIQUEIDENTIFIER,
		    [target_type] INT,
		    parent_bserver_id UNIQUEIDENTIFIER,
		    parent_bserver_name NVARCHAR(255),
		    [pwd_key_id] UNIQUEIDENTIFIER
		)
AS
BEGIN
	DECLARE
		@t_notAllowed TABLE(jobId UNIQUEIDENTIFIER);

	DECLARE
		@t_userRoles TABLE (id UNIQUEIDENTIFIER);
	DECLARE
		@v_binSid	varbinary(max),
		@v_restoreVmRole uniqueidentifier,
		@v_adminRole uniqueidentifier;
	SET @v_restoreVmRole = 'C11C0C38-BA8B-49c7-BF70-FC2058FFF1E2';
	SET @v_adminRole     = '5F37A46B-9CE2-40F4-8A62-B45B079257FC';
	SET @v_binSid = (
		SELECT TOP 1
			lu.sid_binary
		FROM
			[dbo].[Security.LoggedOnUsers] lu
		WHERE
			lu.sid_string = @userSid
		)
	INSERT INTO
		@t_userRoles
	SELECT DISTINCT 
		r.[id] as role_id
	FROM [dbo].[Security.Roles] r 
		JOIN [dbo].[Security.RoleAccounts] ra ON ra.[role_id] = r.[id] 
		JOIN [dbo].[Security.LoggedOnUserAccounts] lua ON (lua.account_id = ra.account_id)		
		JOIN [dbo].[Security.LoggedOnUsers] lu ON (lu.id = lua.login_id)
	WHERE
		lu.sid_binary = @v_binSid

	IF EXISTS (SELECT id FROM @t_userRoles WHERE id in (@v_restoreVmRole, @v_adminRole))
	BEGIN
		INSERT INTO
			@t_notAllowed ( jobId ) 	
		SELECT
			jobs.id
		FROM [C.BJobs] jobs
		JOIN [C.ObjectsInJobs] AS oijs ON oijs.job_id = jobs.id
		LEFT JOIN 
		(
			SELECT
				id
			FROM
				[dbo].[fn.Backup.GetRoleAccessibleObjects](@v_binSid, @v_restoreVmRole)
		) as t on t.id = oijs.[object_id]
		WHERE 
			jobs.[type] = 202 AND
			t.id IS NULL
		GROUP BY jobs.id
		INSERT INTO 
			@t_resultTable
		SELECT 
			 ROW_NUMBER() OVER (ORDER BY jobs.id)
			,jobs.id
			,jobs.name
			,cloudfp.tenant_id
			,ten.name
			,jobs.db_instance_id
			,jobs.[description] 
			,jobs.[platform] 
			,jobs.[options]			
			,jobs.[is_deleted]
			,jobs.[latest_result]
			,jobs.[vss_options]
			,jobs.[vcb_host_id]
			,jobs.[target_type]				
			,bservers.[id] 
			,bservers.[ip_or_dns_name] 
			,jobs.[pwd_key_id]
		FROM [C.BJobs] jobs
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON jobs.[db_instance_id] = bservers.[current_db_id]
		LEFT JOIN [dbo].[C.Backup.Model.CloudFailoverPlan] cloudfp ON jobs.id = cloudfp.job_id
		LEFT JOIN [dbo].[C.Tenants] ten ON cloudfp.tenant_id = ten.id
		WHERE 
			jobs.type = 202 AND
			jobs.id NOT IN ( SELECT jobId FROM @t_notAllowed ) AND
			bservers.[major_version] >= 7 AND
			cloudfp.job_id IS NOT NULL
		ORDER BY jobs.name	
	END
	RETURN;
END
GO	

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudFailoveredVmsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudFailoveredVmsView]
GO
	CREATE VIEW [dbo].[Rest.CloudFailoveredVmsView]
	AS
		SELECT 
			objsInJob.[id] AS id,
		    objsInJob.[vss_options] AS fvm_vss_options,
			objsInJob.[order_no] AS fvm_order_no,
		    objs.[object_name] as fvm_name,
		    objs.[object_id] as fvm_ref,
            objs.[display_name]as fvm_display_name,	
			objs.[host_id] as fvm_host_id,
			objs.[platform]as obj_platform,	
			objs.[type] as obj_type,
			objs.[viobject_type] as obj_type_str,
			jobs.[id] as job_id,
			jobs.[name] as job_name,
			cloudfp.[tenant_id] as tenant_id,
			ten.[name] as tenant_name,
			bservers.[id] as bserver_id,
			bservers.[ip_or_dns_name] as bserver_name
	    FROM [dbo].[C.ObjectsInJobs] objsInJob 
			INNER JOIN [dbo].[C.BJobs] jobs ON objsInJob.[job_id] = jobs.[id]
			INNER JOIN [dbo].[C.BObjects] objs ON objsInJob.[object_id] = objs.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON objsInJob.[db_instance_id] = bservers.[current_db_id]	
			LEFT JOIN [dbo].[C.Backup.Model.CloudFailoverPlan] cloudfp ON jobs.id = cloudfp.job_id	
			LEFT JOIN [dbo].[C.Tenants] ten ON cloudfp.tenant_id = ten.id
		WHERE bservers.[major_version] >= 7 AND
			  jobs.[type] = 202 AND -- failover plan
			  cloudfp.job_id IS NOT NULL
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudVmReplicaPointsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudVmReplicaPointsView]
GO
	CREATE VIEW [dbo].[Rest.CloudVmReplicaPointsView]
	AS
		SELECT 
			oibs.[id],
			oibs.[object_id],
			oibs.[vmname] + '@' + CONVERT(nvarchar(50), oibs.creation_time, 120) as name,
			oibs.[vmname] as vm_real_name,
			oibs.[display_name] as vm_display_name,
			oibs.[creation_time] as creation_time,
			oibs.[type] as type,
			oibs.[alg] as algorithm,
			oibs.[has_index] as has_index,
			oibs.[original_oib_id] as original_oib_id,
			repl.[state],
			hrdwQuotas.[tenantId] as tenant_id,
			backups.[id] as backup_id,			
			backups.[job_name] as backup_name,		
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name
		FROM 
			[dbo].[C.Backup.Model.OIBs] oibs
			INNER JOIN [dbo].[C.Backup.Model.Points] points ON oibs.[point_id] = points.[id]
			INNER JOIN [dbo].[C.Backup.Model.Backups] backups ON points.[backup_id] = backups.[id]
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON points.[db_instance_id] = bservers.[current_db_id]
			LEFT JOIN [dbo].[view.Cloud.TenantBackups] tenBackups ON backups.[id] = tenBackups.[backup_id]
			LEFT JOIN [dbo].[view.Cloud.HardwareQuotas] hrdwQuotas On tenBackups.[quota_id] = hrdwQuotas.[id]
			INNER JOIN [dbo].[C.Replicas] repl ON oibs.[object_id] = repl.[object_id]
		WHERE 
			backups.[job_target_type] = 1 AND
			bservers.[major_version] >= 7 AND 
			oibs.is_corrupted = 0 AND
			backups.[target_type] = 100
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudReplicasView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudReplicasView]
GO
	CREATE VIEW [dbo].[Rest.CloudReplicasView] 
	AS
		SELECT
			q.[id],
			q.[name],
			q.[job_id],
			q.[job_name],
			q.[platform],
			q.[tenant_id],
			q.[backupserver_id],
			q.[backupinstance_id],
			q.[backupserver_name],
			repo.[unique_id] as repository_id,
			repo.[name] as repository_name			
		FROM 
		(
		SELECT 
			backups.[id] as id,
			backups.[job_name] as name,
			backups.[job_id] as job_id,	
			backups.[platform],
			backups.[job_name] as job_name,			
			hrdwQuotas.[tenantId] as tenant_id,
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name,
			[dbo].[fn.GetRepositoryUniqueIdByIdOrEmptyId](backups.[db_instance_id], backups.[repository_id]) repo_unique_id
		FROM 
			[dbo].[C.Backup.Model.Backups] backups			
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON backups.[db_instance_id] = bservers.[current_db_id]
			LEFT JOIN [dbo].[view.Cloud.TenantBackups] tenBackups ON backups.[id] = tenBackups.[backup_id]
			LEFT JOIN [dbo].[view.Cloud.HardwareQuotas] hrdwQuotas On tenBackups.[quota_id] = hrdwQuotas.[id]
		WHERE 
			backups.[job_target_type] = 1 AND
			backups.[target_type] = 100
		) q
		INNER JOIN [dbo].[C.BackupRepositories] repo ON q.repo_unique_id = repo.[unique_id]
		--WHERE bservers.[major_version] >= 7
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudFailoverPlansView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudFailoverPlansView]
GO
	CREATE VIEW [dbo].[Rest.CloudFailoverPlansView]
	AS
		SELECT 
			cloudfp.[job_id] as id,			
			ten.[id] as	tenant_id,
			ten.[name] as tenant_name,
			ten.[password] as tenant_password,
			bservers.[id] as backupserver_id,
			bservers.[current_db_id] as backupinstance_id,
			bservers.[ip_or_dns_name] as backupserver_name
	FROM [C.BJobs] jobs
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON jobs.[db_instance_id] = bservers.[current_db_id]
		LEFT JOIN [dbo].[C.Backup.Model.CloudFailoverPlan] cloudfp ON jobs.id = cloudfp.job_id
		LEFT JOIN [dbo].[C.Tenants] ten ON cloudfp.tenant_id = ten.id
	WHERE 
		cloudfp.[job_id] IS NOT NULL
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudPublicIpAddressesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudPublicIpAddressesView]
GO
	CREATE VIEW [dbo].[Rest.CloudPublicIpAddressesView]
	AS 
		SELECT 
		ips.id as id,
		ips.ip_address as name,
		ips.ip_address as ip_address,
		ips.tenant_id as tenant_id,
		ten.name as tenant_name,
		bservers.id as parent_bserver_id,
		bservers.ip_or_dns_name as parent_bserver_name
		FROM [dbo].[C.Backup.Model.CloudPublicIp] ips
			LEFT JOIN [dbo].[C.Tenants] ten ON ips.tenant_id = ten.id
			JOIN [dbo].[Repl.Topology.BackupServers] bservers ON ips.[db_instance_id] = bservers.[current_db_id]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudHardwarePlansView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudHardwarePlansView]
GO
	CREATE VIEW [dbo].[Rest.CloudHardwarePlansView]
	AS 
		SELECT 
		plans.id as id,
		plans.friendlyName as name,
		plans.[description] as [description],
		plans.[processorUsageLimitMhz] as processor_usage_limit_mhz,
		plans.memoryUsageLimitMb as memory_usage_limit_mb,
		plans.[platform_type] as hardware_plan_type,
		viplan.id as vi_hardware_plan_id,
		viplan.hypervisorHostId as vi_hypervisor_host_id,
		viplan.parentType as vi_parent_type,
		viplan.parentReference as vi_parent_ref,
		viplan.parentName as vi_parent_name,	 		
		hvplan.id as hv_hardware_plan_id,
		hvplan.hypervisorHostId as hv_hypervisor_host_id,
		hvplan.hypervisorHostId as hv_hypervisor_host_ref,
		bservers.id as parent_bserver_id,
		bservers.ip_or_dns_name as parent_bserver_name
		 FROM [dbo].[view.Cloud.HardwarePlans] plans
		 JOIN [dbo].[Repl.Topology.BackupServers] bservers ON plans.[db_instance_id] = bservers.[current_db_id]
			LEFT JOIN [C.Backup.Model.ViHardwarePlans] viplan ON plans.id = viplan.id
			LEFT JOIN [C.Backup.Model.HvHardwarePlans] hvplan ON plans.id = hvplan.id
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.ViCloudHardwarePlansStoragesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.ViCloudHardwarePlansStoragesView]
GO
	CREATE VIEW [dbo].[Rest.ViCloudHardwarePlansStoragesView]
	AS 
		SELECT 
		stores.id as id,
		stores.hardwarePlanId as vi_hardware_plan_id,
		stores.friendlyName as friendly_name,	
		stores.reference as	datastore_ref_raw,
		stores.rootPath as datastore_root_path,
		stores.quotaGb as quota_gb,
		stores.viType as vi_type
		FROM [dbo].[C.Backup.Model.ViHardwarePlanDatastores] stores
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.HvCloudHardwarePlansStoragesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.HvCloudHardwarePlansStoragesView]
GO
	CREATE VIEW [dbo].[Rest.HvCloudHardwarePlansStoragesView]
	AS 
		SELECT 
			volms.id as id,
			volms.hardwarePlanId as hv_hardware_plan_id,
			volms.friendlyName as friendly_name,	
			volms.volumePath as	volume_path,		
			volms.quotaGb as quota_gb	
		FROM [dbo].[C.Backup.Model.HvHardwarePlanVolumes] volms
GO

--IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudTenantComputeResourcesView]') AND type in (N'V'))
--	DROP VIEW [dbo].[Rest.CloudTenantComputeResourcesView]
--GO
--	CREATE VIEW [dbo].[Rest.CloudTenantComputeResourcesView]
--	AS 
--		SELECT 
--			quotas.id as id,
--			quotas.hardwarePlanId as hardware_plan_id,
--			quotas.tenantId as tenant_id,
--			ten.name as tenant_name,
--			quotas.wan_id as wan_accelerator_id,		
--			quotas.expireDate as expire_time,
--			quotas.is_enabled as enabled,
--			quotas.platform_type,
--			viquotas.folderReference,
--			viquotas.resourcePoolReference			
--		FROM [dbo].[view.Cloud.HardwareQuotas] quotas
--			JOIN [C.Tenants] ten ON quotas.tenantId = ten.id
--			LEFT JOIN [dbo].[C.Backup.Model.ViHardwareQuotas] viquotas ON quotas.id = viquotas.id
--GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.ViCloudHardwarePlansNetworks]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.ViCloudHardwarePlansNetworks]
GO
	CREATE VIEW [dbo].[Rest.ViCloudHardwarePlansNetworks]
	AS 
		SELECT 
			plans.hardwarePlanId as hardwarePlanId,
			plans.countWithInternet as countWithInternet,
			plans.countWithoutInternet as countWithoutInternet
		FROM [dbo].[C.Backup.Model.ViHardwarePlanNetworks] plans		
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.HvCloudHardwarePlansNetworks]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.HvCloudHardwarePlansNetworks]
GO
	CREATE VIEW [dbo].[Rest.HvCloudHardwarePlansNetworks]
	AS 
		SELECT 
			plans.hardwarePlanId as hardwarePlanId,
			plans.countWithInternet as countWithInternet,
			plans.countWithoutInternet as countWithoutInternet
		FROM [dbo].[C.Backup.Model.HvHardwarePlanNetworks] plans		
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.HostNetwork]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.HostNetwork]
GO
	CREATE VIEW [dbo].[Rest.HostNetwork]
	AS 
	SELECT
	   hn.[id]
      ,hn.[host_id]
      ,hn.[inet_vlans_left_bound]
      ,hn.[inet_vlans_right_bound]
      ,hn.[non_inet_vlans_left_bound]
      ,hn.[non_inet_vlans_right_bound]
      ,hn.[vi_cluster_ref]
      ,hn.[vi_cluster_name]
      ,hn.[vswitch_name] as name
      ,hn.[vswitch_type]
      ,hn.[vswitch_id]
	  ,hosts.[type] as host_type
	  ,hosts.[reference] as host_ref 
      ,bservers.id as parent_bserver_id
	  ,bservers.ip_or_dns_name as parent_bserver_name
	FROM [dbo].[C.HostNetwork] hn	
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON hn.[db_instance_id] = bservers.[current_db_id]
		JOIN [dbo].[C.Hosts] hosts ON hn.[host_id] = hosts.[id]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudAppliances]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudAppliances]
GO
	CREATE VIEW [dbo].[Rest.CloudAppliances]
	AS 
	SELECT
		appl.id,
		appl.tenant_id,
		appl.connhost_id,		
		appl.pod_id,
		appl.network_spec,
		appl.live_info,
		bservers.id as parent_bserver_id,
		bservers.ip_or_dns_name as parent_bserver_name
	FROM [dbo].[C.Backup.Model.CloudAppliances] appl	
		JOIN [dbo].[Repl.Topology.BackupServers] bservers ON appl.[db_instance_id] = bservers.[current_db_id]		
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudTenantComputeResourcesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudTenantComputeResourcesView]
GO
	CREATE VIEW [dbo].[Rest.CloudTenantComputeResourcesView]
	AS 
		SELECT 
			quotas.id as id,
			quotas.hardwarePlanId as hardware_plan_id,
			quotas.tenantId as tenant_id,
			ten.name as tenant_name,
			quotas.wan_id as wan_accelerator_id,		
			quotas.expireDate as expire_time,
			quotas.is_enabled as enabled,
			quotas.platform_type,
			viquotas.folderReference,
			viquotas.resourcePoolReference,				
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name,
			ISNULL((SELECT network_spec FROM [dbo].[Rest.CloudAppliances] appl 
				JOIN [view.Cloud.HardwarePlans] plans ON quotas.hardwarePlanId = plans.id
				WHERE appl.connhost_id = plans.hypervisorHostId AND quotas.tenantId = appl.tenant_id ),NULL)
			as network_spec
			FROM [dbo].[view.Cloud.HardwareQuotas] quotas
			JOIN [C.Tenants] ten ON quotas.tenantId = ten.id			
			LEFT JOIN [dbo].[C.Backup.Model.ViHardwareQuotas] viquotas ON quotas.id = viquotas.id		
			JOIN [dbo].[Repl.Topology.BackupServers] bservers ON ten.[db_instance_id] = bservers.[current_db_id]
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.NonSobrRepositoriesView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.NonSobrRepositoriesView]
GO
	CREATE VIEW [dbo].[Rest.NonSobrRepositoriesView]
	AS
		SELECT
			r.unique_id as id,			
			bservers.[id] as parent_bserver_id,
			bservers.[ip_or_dns_name] as parent_bserver_name	
		FROM
			[dbo].[C.BackupRepositories] r 			
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bservers ON r.[db_instance_id] = bservers.[current_db_id]
		WHERE bservers.[major_version] >= 7 AND
			r.id not in (select meta_repo_id from [C.Backup.ExtRepo.ExtRepos])
			AND r.id not in (select dependant_repo_id from [C.Backup.ExtRepo.ExtRepos])
			
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudFailoverSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudFailoverSessionsView]
GO
	CREATE VIEW [dbo].[Rest.CloudFailoverSessionsView]
	AS
		SELECT 
			js.id,
			js.job_name as name,
			js.job_type,
			js.creation_time,
			js.end_time,
			js.state,			
			js.result,
			js.progress,
			js.reason as failure_message,			
			rjs.multi_restore_id,
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name			
		FROM 
			[dbo].[C.Backup.Model.RestoreJobSessions] rjs
			INNER JOIN [dbo].[C.Backup.Model.JobSessions] js ON rjs.id = js.id
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON rjs.db_instance_id = bs.current_db_id					
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 202
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudFailoverTaskSessionsView]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudFailoverTaskSessionsView]
GO
	CREATE VIEW [dbo].[Rest.CloudFailoverTaskSessionsView]
	AS
		SELECT 				
			js.job_type,
			js.creation_time,
			js.end_time,
			js.state,
			rjs.oib_display_name as vm_display_name,
			js.result,
			js.progress,
			js.reason as failure_message,			
			bs.id AS backupserver_id,
			bs.ip_or_dns_name AS backupserver_name,
			rjs.restored_obj_id as restored_obj_id,
			rjs.oib_id,
			rjs.multi_restore_id,				
			oibs.[vmname] + '@' + CONVERT(nvarchar(50), oibs.creation_time, 120) as oib_name			
		FROM 
			[dbo].[C.Backup.Model.RestoreJobSessions] rjs
			INNER JOIN [dbo].[C.Backup.Model.JobSessions] js ON rjs.id = js.id
			INNER JOIN [dbo].[Repl.Topology.BackupServers] bs ON rjs.db_instance_id = bs.current_db_id
			INNER JOIN [dbo].[C.Backup.Model.OIBs] oibs ON rjs.oib_id = oibs.id			
		WHERE 
			bs.[major_version] >= 7 AND
			js.job_type = 204
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudHardwareQuotaCpuMemoryUsage]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudHardwareQuotaCpuMemoryUsage]
GO
	CREATE VIEW [dbo].[Rest.CloudHardwareQuotaCpuMemoryUsage]
	AS
SELECT	trp.id as hrdwQuotaId,		
		SUM(ISNULL(replc.cpuCount,0) ) as cpuCount,
		SUM(ISNULL(replc.memoryMb,0) ) as memoryMb 
	FROM   [C.Tenants] t
		JOIN [view.Cloud.HardwareQuotas] trp ON t.id = trp.tenantId
		LEFT JOIN [view.Cloud.HardwarePlans] vihp ON trp.hardwarePlanId = vihp.id	 
		LEFT JOIN [view.Cloud.HardwarePlanStorages] vihd ON vihd.[hardwarePlanId] = vihp.id
		LEFT JOIN [view.Cloud.QuotaStorages] vihqd ON vihqd.hardwareQuotaId = trp.id
                            AND vihqd.[hardwarePlanStorageId] = vihd.id
		LEFT JOIN [view.Cloud.QuotaStoragesUsages] vihqdu ON vihqdu.[quotaStorageId] = vihqd.id
		LEFT JOIN [C.ReplicaConfigurations] replc ON replc.id = vihqdu.replicaId
	GROUP BY 
	trp.id
GO

--------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rest.CloudHardwareStorageUsage]') AND type in (N'V'))
	DROP VIEW [dbo].[Rest.CloudHardwareStorageUsage]
GO
	CREATE VIEW [dbo].[Rest.CloudHardwareStorageUsage]
	AS
SELECT	
		vihp.id as hrdwPlanStorageId,
		vihd.friendlyName as StorageName,
		vihd.quotaGb as StorageLimitGb,
		trp.id as hrdwQuotaId,	
		(CAST(SUM(ISNULL(vihqdu.usageBytes,0)) AS FLOAT) / (1024*1024*1024) ) as StorageUsageGb
	FROM   [C.Tenants] t
		JOIN [view.Cloud.HardwareQuotas] trp ON t.id = trp.tenantId
		JOIN [view.Cloud.HardwarePlans] vihp ON trp.hardwarePlanId = vihp.id	 
		JOIN [view.Cloud.HardwarePlanStorages] vihd ON vihd.[hardwarePlanId] = vihp.id
		LEFT JOIN [view.Cloud.QuotaStorages] vihqd ON vihqd.hardwareQuotaId = trp.id
                            AND vihqd.[hardwarePlanStorageId] = vihd.id
		LEFT JOIN [view.Cloud.QuotaStoragesUsages] vihqdu ON vihqdu.[quotaStorageId] = vihqd.id
		LEFT JOIN [C.ReplicaConfigurations] replc ON replc.id = vihqdu.replicaId
	GROUP BY 
	vihp.id,
	vihd.friendlyName,
	vihd.quotaGb,
	trp.id
GO

