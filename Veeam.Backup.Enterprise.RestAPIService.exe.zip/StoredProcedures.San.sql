PRINT N'Creating [dbo].[GetHp3PARVmsByNamePart]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHp3PARVmsByNamePart]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHp3PARVmsByNamePart]
GO

CREATE PROCEDURE [dbo].[GetHp3PARVmsByNamePart]
	@name_part nvarchar(max),
	@server_id uniqueidentifier,
	@volume_id uniqueidentifier,
	@plugin_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SELECT 
		vms.*, volumes.name as volume_name, hosts.name as mgmt_group_name
	FROM
	(
		SELECT 
			*
		FROM
		(
			SELECT 
				snapshotVmsView.*
				,RANK() OVER (PARTITION BY snapshotVmsView.obj_id ORDER BY snapshotVmsView.creation_time DESC) rank_creation_time
			FROM 
				[dbo].[ReportSnapshotVmsView] snapshotVmsView
			WHERE 
				snapshotVmsView.vm_name like @name_part
		) snapshotVmsWithRank
		WHERE 
			snapshotVmsWithRank.rank_creation_time = 1
	) vms	
	join [dbo].[Backup.Model.SanSnapshots] snapshots
		join [dbo].[Backup.Model.SanVolumes] volumes 
				join [dbo].[Hosts] hosts
					join [dbo].[Backup.Model.SanHostsPlugins] plugins
					on hosts.id = plugins.host_id 
			on volumes.host_id = hosts.id
		on volumes.id = snapshots.volume_id
	on vms.snapshot_id = snapshots.id  
	WHERE 
		hosts.id = ISNULL (@server_id, hosts.id) AND
		volumes.id = ISNULL (@volume_id, volumes.id) AND
		plugins.plugin_id = ISNULL (@plugin_id, plugins.plugin_id) 
END
GO

PRINT N'Creating [dbo].[AddHp3ParAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHp3ParAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHp3ParAdapter]
GO
	CREATE PROCEDURE [dbo].[AddHp3ParAdapter]
		@row_id uniqueidentifier,
		@row_server_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_iscsi_iqn nvarchar(255)
	AS
	BEGIN		
		INSERT INTO [dbo].[Backup.Model.Hp3ParAdapters]
				([id], [server_id], [ip] ,[iscsi_iqn])
		 VALUES
			(@row_id, @row_server_id, @row_ip, @row_iscsi_iqn)
	END
GO

PRINT N'Creating [dbo].[UpdateHp3ParAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHp3ParAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHp3ParAdapter]
GO
	CREATE PROCEDURE [dbo].[UpdateHp3ParAdapter]
		@row_id uniqueidentifier,
		@row_server_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_iscsi_iqn nvarchar(255)
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.Hp3ParAdapters] SET
				   [server_id] = @row_server_id,
				   [ip] = @row_ip,
				   [iscsi_iqn] = @row_iscsi_iqn
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetHp3ParAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHp3ParAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHp3ParAdapter]
GO
	CREATE PROCEDURE [dbo].[GetHp3ParAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.Hp3ParAdapters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetHp3ParAdaptersInServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHp3ParAdaptersInServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHp3ParAdaptersInServer]
GO
	CREATE PROCEDURE [dbo].[GetHp3ParAdaptersInServer]
		@row_server_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.Hp3ParAdapters]
		WHERE server_id = @row_server_id
	END
GO

PRINT N'Creating [dbo].[DeleteHp3ParAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteHp3ParAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteHp3ParAdapter]
GO
	CREATE PROCEDURE [dbo].[DeleteHp3ParAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		
		DELETE [dbo].[Backup.Model.Hp3ParAdapters] 
		WHERE id = @row_id
	END
GO

PRINT N'Creating [dbo].[AddHPSanCluster]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHPSanCluster]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHPSanCluster]
GO
	CREATE PROCEDURE [dbo].[AddHPSanCluster]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_space_total bigint,
		@row_space_free bigint
	AS
	BEGIN
		declare @update_usn bigint
		exec [dbo].[IncrementUsn] @update_usn OUTPUT
		INSERT INTO [dbo].[Backup.Model.HPSanClusters]
				([id]
				,[name]
				,[host_id]
				,[usn]
				,[space_total]
				,[space_free])
		 VALUES
				(@row_id,
				@row_name,
				@row_host_id,
				@update_usn,
				@row_space_total,
				@row_space_free)
	END
GO

PRINT N'Creating [dbo].[UpdateHPSanCluster]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHPSanCluster]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHPSanCluster]
GO
	CREATE PROCEDURE [dbo].[UpdateHPSanCluster]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_space_total bigint,
		@row_space_free bigint
	AS
	BEGIN
		declare @update_usn bigint
		exec [dbo].[IncrementUsn] @update_usn OUTPUT
		UPDATE [dbo].[Backup.Model.HPSanClusters] SET
				[name] = @row_name,
				[host_id] = @row_host_id,
				[usn] = @update_usn,
				[space_total] = @row_space_total,
				[space_free] = @row_space_free
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetHPSanCluster]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHPSanCluster]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHPSanCluster]
GO

	CREATE PROCEDURE [dbo].[GetHPSanCluster]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanClusters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetAllHPSanClusters]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllHPSanClusters]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetAllHPSanClusters]
GO
	CREATE PROCEDURE [dbo].[GetAllHPSanClusters]
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanClusters]
	END
GO

PRINT N'Creating [dbo].[GetHPSanClustersInGroup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHPSanClustersInGroup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHPSanClustersInGroup]
GO
	CREATE PROCEDURE [dbo].[GetHPSanClustersInGroup]
		@row_group_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanClusters]
		WHERE host_id = @row_group_id
	END
GO

PRINT N'Creating [dbo].[GetHPSanClusterByNameInGroup]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHPSanClusterByNameInGroup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].GetHPSanClusterByNameInGroup
GO
	CREATE PROCEDURE [dbo].GetHPSanClusterByNameInGroup
		@row_name nvarchar(255),
		@row_group_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanClusters]
		WHERE [name] = @row_name AND [host_id] = @row_group_id
	END
GO

PRINT N'Creating [dbo].[ReportSanClusterView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportSanClusterView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportSanClusterView]
GO

CREATE VIEW [dbo].[ReportSanClusterView]
AS
	SELECT
		cl.id,
		cl.name,
		cl.[host_id],
		hs.name as [host_name],
		(select count(vl.id) from [dbo].[Backup.Model.SanVolumes] vl where vl.parent_id = cl.id) as volumes_count,
		cl.space_total,
		cl.space_free,
		cl.usn
	FROM 
		[dbo].[Backup.Model.HPSanClusters] cl
		inner join [dbo].[Hosts] hs ON hs.id = cl.[host_id]
GO

PRINT N'Creating [dbo].[ReportHpP4kVolumeView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportHpP4kVolumeView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportHpP4kVolumeView]
GO
CREATE VIEW [dbo].[ReportHpP4kVolumeView]
AS
SELECT
		vl.id,
		vl.name,
		vl.parent_id as cluster_id,
		vl.internal_id,
		cl.name as cluster_name,
		(select count(sn.id) from [dbo].[Backup.Model.SanSnapshots] sn where sn.volume_id = vl.id AND sn.is_removed = 0) as snapshots_count,
		vl.size as reported_size,
		vl.consumed_space,
		vl.is_thin_provision,
		vl.saved_space,
		vl.host_id,
		(select top(1) sn.creation_time from [dbo].[Backup.Model.SanSnapshots] sn where sn.volume_id = vl.id AND sn.is_removed = 0 order by sn.creation_time desc) as last_snapshot_creation_time,
		vl.usn
	FROM 
		[dbo].[Backup.Model.SanVolumes] vl
		inner join [dbo].[Backup.Model.HPSanClusters] cl ON cl.id = vl.parent_id
GO

PRINT N'Creating [dbo].[ReportSanClusterDeleteView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportSanClusterDeleteView]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[ReportSanClusterDeleteView]
GO
	CREATE PROCEDURE [dbo].[ReportSanClusterDeleteView]
		@row_usn bigint
	AS
	BEGIN
		SET NOCOUNT ON;
		SELECT uid, usn FROM TombStones WHERE table_name= 'Backup.Model.HPSanClusters' AND usn > @row_usn
	END
GO

PRINT N'Creating [dbo].[ReportSanStorageVmsView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportSanStorageVmsView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportSanStorageVmsView]
GO
	CREATE VIEW [dbo].[ReportSanStorageVmsView]
	AS
	SELECT DISTINCT
		 oibs.[object_id] as id,
		 oibs.vmname,
		 hst.id as [host_id],
		 hst.name as [host_name],
		 sclu.id as cluster_id,
		 svol.id as volume_id,
		 svol.name as volume_name,
		 (SELECT COUNT(id) FROM [dbo].[Backup.Model.SanSnapshots] ssnp WHERE svol.id = ssnp.volume_id) as snapshot_count,
		 max(oibs.usn) as usn
		FROM [dbo].[Backup.Model.OIBs] oibs
			inner join [dbo].[Backup.Model.Points] pnts ON oibs.point_id = pnts.id
			inner join [dbo].[Backup.Model.Backups] bcks ON pnts.backup_id = bcks.id
			inner join [dbo].[Backup.Model.SanVolumeBackups] vlbk ON bcks.id = vlbk.backup_id
			inner join [dbo].[Backup.Model.SanVolumes] svol ON vlbk.volume_id = svol.id
			inner join [dbo].[Backup.Model.HPSanClusters] sclu ON svol.parent_id = sclu.id
			inner join [dbo].[Hosts] hst ON sclu.[host_id] = hst.id
	group by 
		 oibs.[object_id],
		 oibs.vmname,
		 hst.id,
		 hst.name,
		 sclu.id,
		 svol.id,
		 svol.name
GO

PRINT N'Creating [dbo].[Backup.Model.DeleteHPSanCluster]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup.Model.DeleteHPSanCluster]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[Backup.Model.DeleteHPSanCluster]
GO
	CREATE PROCEDURE [dbo].[Backup.Model.DeleteHPSanCluster]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		declare @usn bigint
		exec [dbo].[IncrementUsn] @usn OUTPUT

		DELETE [dbo].[Backup.Model.HPSanClusters] WHERE id = @id
		
		exec [dbo].[InsertTombStone] 'Backup.Model.HPSanClusters', @id, @usn
	END
GO

PRINT N'Creating [dbo].[GetHpSanVmsByNamePart]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHpSanVmsByNamePart]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHpSanVmsByNamePart]
GO

CREATE PROCEDURE [dbo].[GetHpSanVmsByNamePart]
	@name_part nvarchar(max),
	@mgmt_group_id uniqueidentifier,
	@cluster_id uniqueidentifier,
	@volume_id uniqueidentifier,
	@plugin_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		vms.*, volumes.name as volume_name, hosts.name as mgmt_group_name
	FROM
	(
		SELECT 
			*
		FROM
		(
			SELECT 
				snapshotVmsView.*
				,RANK() OVER (PARTITION BY snapshotVmsView.obj_id ORDER BY snapshotVmsView.creation_time DESC) rank_creation_time
			FROM 
				[dbo].[ReportSnapshotVmsView] snapshotVmsView
			WHERE 
				snapshotVmsView.vm_name like @name_part
		) snapshotVmsWithRank
		WHERE 
			snapshotVmsWithRank.rank_creation_time = 1
	) vms
	join [dbo].[Backup.Model.SanSnapshots] snapshots
		join [dbo].[Backup.Model.SanVolumes] volumes
			join [dbo].[Backup.Model.HPSanClusters] clusters
				join [dbo].[Hosts] hosts
					join [dbo].[Backup.Model.SanHostsPlugins] plugins
					on hosts.id = plugins.host_id
				on clusters.host_id = hosts.id
			on volumes.parent_id= clusters.id
		on volumes.id = snapshots.volume_id
	on vms.snapshot_id = snapshots.id
	WHERE 
		hosts.id = ISNULL (@mgmt_group_id, hosts.id) AND
		clusters.id = ISNULL (@cluster_id, clusters.id) AND
		volumes.id = ISNULL (@volume_id, volumes.id) AND
		plugins.plugin_id = ISNULL (@plugin_id, plugins.plugin_id)
END
GO

PRINT N'Creating [dbo].[AddHPSanStorageSystem]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHPSanStorageSystem]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHPSanStorageSystem]
GO
	CREATE PROCEDURE [dbo].[AddHPSanStorageSystem]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_cluster_id uniqueidentifier
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.HPSanStorageSystems]
				([id]
				,[name]
				,[cluster_id]
				)
		 VALUES
				(@row_id,
				@row_name,
				@row_cluster_id
				)
	END
GO

PRINT N'Creating [dbo].[UpdateHPSanStorageSystem]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHPSanStorageSystem]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHPSanStorageSystem]
GO
	CREATE PROCEDURE [dbo].[UpdateHPSanStorageSystem]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_cluster_id uniqueidentifier
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.HPSanStorageSystems] SET
				[name] = @row_name,
				[cluster_id] = @row_cluster_id
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetHPSanStorageSystem]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHPSanStorageSystem]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHPSanStorageSystem]
GO
	CREATE PROCEDURE [dbo].[GetHPSanStorageSystem]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanStorageSystems]
			WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetHPSanStorageSystemsInCluster]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHPSanStorageSystemsInCluster]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHPSanStorageSystemsInCluster]
GO
	CREATE PROCEDURE [dbo].[GetHPSanStorageSystemsInCluster]
		@row_cluster_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanStorageSystems]
		WHERE cluster_id = @row_cluster_id
	END
GO

PRINT N'Creating [dbo].[GetHPSanStorageSystemByNameInCluster]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHPSanStorageSystemByNameInCluster]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].GetHPSanStorageSystemByNameInCluster
GO
	CREATE PROCEDURE [dbo].GetHPSanStorageSystemByNameInCluster
		@row_name nvarchar(255),
		@row_cluster_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanStorageSystems]
		WHERE [name] = @row_name AND [cluster_id] = @row_cluster_id
	END
GO

PRINT N'Creating [dbo].[DeleteHPSanStorageSystem]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteHPSanStorageSystem]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteHPSanStorageSystem]
GO
	CREATE PROCEDURE [dbo].[DeleteHPSanStorageSystem]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.HPSanStorageSystems] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[AddHPSanStorageSystemNic]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddHPSanStorageSystemNic]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddHPSanStorageSystemNic]
GO
	CREATE PROCEDURE [dbo].[AddHPSanStorageSystemNic]
		@row_id uniqueidentifier,
		@row_name [nvarchar](255),
		@row_storage_id [uniqueidentifier],
		@row_ip [nvarchar](255),
		@row_netmask [nvarchar](255)
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.HPSanStorageSystemNics]
				([id]
				,[name]
				,[storage_system_id]
				,[ip]
				,[netmask])
		 VALUES
				(@row_id,
				@row_name,
				@row_storage_id,
				@row_ip,
				@row_netmask
				)
	END
GO

PRINT N'Creating [dbo].[UpdateHPSanStorageSystemNic]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateHPSanStorageSystemNic]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateHPSanStorageSystemNic]
GO
	CREATE PROCEDURE [dbo].[UpdateHPSanStorageSystemNic]
		@row_id uniqueidentifier,
		@row_name [nvarchar](255),
		@row_storage_id [uniqueidentifier],
		@row_ip [nvarchar](255),
		@row_netmask [nvarchar](255)
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.HPSanStorageSystemNics] SET
				[name] = @row_name,
				[storage_system_id] = @row_storage_id,
				[ip] = @row_ip,
				[netmask] = @row_netmask
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetHPSanStorageSystemNics]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetHPSanStorageSystemNics]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetHPSanStorageSystemNics]
GO
	CREATE PROCEDURE [dbo].[GetHPSanStorageSystemNics]
		@row_storage_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.HPSanStorageSystemNics]
				WHERE [storage_system_id] = @row_storage_id
	END
GO

PRINT N'Creating [dbo].[DeleteHPSanStorageSystemNic]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteHPSanStorageSystemNic]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteHPSanStorageSystemNic]
GO
	CREATE PROCEDURE [dbo].[DeleteHPSanStorageSystemNic]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.HPSanStorageSystemNics] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[ReportNaVolumeView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportNaVolumeView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportNaVolumeView]
GO
CREATE VIEW [dbo].[ReportNaVolumeView]
AS
SELECT 
		vl.id,
		vl.name,
		vl.parent_id,
		vl.internal_id,
		(select count(sn.id) from [dbo].[Backup.Model.SanSnapshots] sn where sn.volume_id = vl.id AND sn.is_removed = 0 ) as snapshots_count,
		vl.size as reported_size,
		vl.consumed_space as used_space,
		vl.is_thin_provision,
		vl.aux_data,
		vl.host_id,
		(select top(1) sn.creation_time from [dbo].[Backup.Model.SanSnapshots] sn where sn.volume_id = vl.id AND sn.is_removed = 0 order by sn.creation_time desc) as last_snapshot_creation_time,
		vl.usn
	FROM 
		[dbo].[Backup.Model.SanVolumes] vl
GO

PRINT N'Creating [dbo].[AddNetAppvFiler]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddNetAppvFiler]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddNetAppvFiler]
GO
	CREATE PROCEDURE [dbo].[AddNetAppvFiler]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_uuid nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_iscsi_iqn nvarchar(255),
		@row_fc_wwnn nvarchar(255)
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.NetAppVFilers]
				([id], [name], [uuid], [host_id], [iscsi_iqn], [fc_wwnn])
		 VALUES
				(@row_id, @row_name, @row_uuid, @row_host_id, @row_iscsi_iqn, @row_fc_wwnn)
	END
GO

PRINT N'Creating [dbo].[UpdateNetAppvFiler]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateNetAppvFiler]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateNetAppvFiler]
GO
	CREATE PROCEDURE [dbo].[UpdateNetAppvFiler]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_uuid nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_iscsi_iqn nvarchar(255),
		@row_fc_wwnn nvarchar(255)
	AS
	BEGIN		
		UPDATE [dbo].[Backup.Model.NetAppVFilers] SET
				[name] = @row_name,
				[uuid] = @row_uuid,
				[host_id] = @row_host_id,
				[iscsi_iqn] = @row_iscsi_iqn,
				[fc_wwnn] = @row_fc_wwnn
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvFiler]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvFiler]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvFiler]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvFiler]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVFilers]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvFilersInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvFilersInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvFilersInHost]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvFilersInHost]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVFilers]
		WHERE host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvFilerByNameInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvFilerByNameInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvFilerByNameInHost]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvFilerByNameInHost]
		@row_name nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVFilers]
		WHERE [name] = @row_name AND [host_id] = @row_host_id
	END
GO

PRINT N'Creating [dbo].[DeleteNetAppvFiler]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteNetAppvFiler]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteNetAppvFiler]
GO
	CREATE PROCEDURE [dbo].[DeleteNetAppvFiler]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.NetAppVFilers] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[AddNetAppvFilerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddNetAppvFilerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddNetAppvFilerAdapter]
GO
	CREATE PROCEDURE [dbo].[AddNetAppvFilerAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_vfiler_id uniqueidentifier,
		@row_adapter_type int,
		@row_speed_mode int
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.NetAppVFilerAdapters]
				([id], [ip], [vfiler_id], [adapter_type], [speed_mode])
		 VALUES
				(@row_id, @row_ip, @row_vfiler_id, @row_adapter_type, @row_speed_mode)
	END
GO

PRINT N'Creating [dbo].[UpdateNetAppvFilerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateNetAppvFilerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateNetAppvFilerAdapter]
GO
	CREATE PROCEDURE [dbo].[UpdateNetAppvFilerAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_vfiler_id uniqueidentifier,
		@row_adapter_type int,
		@row_speed_mode int
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.NetAppVFilerAdapters] SET
				[ip] = @row_ip,
				[vfiler_id] = @row_vfiler_id,
				[adapter_type] = @row_adapter_type,
				[speed_mode] = @row_speed_mode
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvFilerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvFilerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvFilerAdapter]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvFilerAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVFilerAdapters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppAdapterInvFilers]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppAdapterInvFilers]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppAdapterInvFilers]
GO
	CREATE PROCEDURE [dbo].[GetNetAppAdapterInvFilers]
		@row_vfiler_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVFilerAdapters]
		WHERE vfiler_id = @row_vfiler_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppAdapterInvFilerByType]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppAdapterInvFilerByType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppAdapterInvFilerByType]
GO
	CREATE PROCEDURE [dbo].[GetNetAppAdapterInvFilerByType]
		@row_vfiler_id uniqueidentifier,
		@row_adapter_type int
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVFilerAdapters]
		WHERE vfiler_id = @row_vfiler_id AND adapter_type = @row_adapter_type
	END
GO

PRINT N'Creating [dbo].[DeleteNetAppvFilerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteNetAppvFilerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteNetAppvFilerAdapter]
GO
	CREATE PROCEDURE [dbo].[DeleteNetAppvFilerAdapter]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.NetAppVFilerAdapters] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[AddNetAppvServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddNetAppvServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddNetAppvServer]
GO
	CREATE PROCEDURE [dbo].[AddNetAppvServer]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_uuid nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_iscsi_iqn nvarchar(255),
		@row_fc_wwnn nvarchar(255)
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.NetAppVServers]
				([id], [name], [uuid], [host_id], [iscsi_iqn], [fc_wwnn])
		 VALUES
				(@row_id, @row_name, @row_uuid, @row_host_id, @row_iscsi_iqn, @row_fc_wwnn)
	END
GO

PRINT N'Creating [dbo].[UpdateNetAppvServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateNetAppvServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateNetAppvServer]
GO
	CREATE PROCEDURE [dbo].[UpdateNetAppvServer]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_uuid nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_iscsi_iqn nvarchar(255),
		@row_fc_wwnn nvarchar(255)
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.NetAppVServers] SET
				[name] = @row_name,
				[uuid] = @row_uuid,
				[host_id] = @row_host_id,
				[iscsi_iqn] = @row_iscsi_iqn,
				[fc_wwnn] = @row_fc_wwnn
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvServer]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvServer]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVServers]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvServersInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvServersInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvServersInHost]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvServersInHost]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVServers]
		WHERE host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvServerByNameInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvServerByNameInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvServerByNameInHost]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvServerByNameInHost]
		@row_name nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVServers]
		WHERE [name] = @row_name AND [host_id] = @row_host_id
	END
GO

PRINT N'Creating [dbo].[DeleteNetAppvServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteNetAppvServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteNetAppvServer]
GO
	CREATE PROCEDURE [dbo].[DeleteNetAppvServer]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.NetAppVServers] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[ReportNaServerView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportNaServerView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportNaServerView]
GO

CREATE VIEW [dbo].[ReportNaServerView]
AS
SELECT 
		[dbo].[Hosts].[id],
		[dbo].[Hosts].[name],
		[dbo].[Hosts].[description],
		[dbo].[Hosts].[type],
		[dbo].[Hosts].[options],
		[dbo].[Hosts].[parent_id],
		[dbo].[Hosts].[usn],
		plugins.plugin_id
	FROM 
		[dbo].[Hosts] LEFT JOIN [Backup.Model.SanHostsPlugins] plugins ON [dbo].[Hosts].id = plugins.host_id
GO

PRINT N'Creating [dbo].[ReportNaServerDeleteView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportNaServerDeleteView]') AND type in (N'P'))
	DROP PROCEDURE [dbo].[ReportNaServerDeleteView]
GO
	CREATE PROCEDURE [dbo].[ReportNaServerDeleteView]
		@row_usn bigint
	AS
	BEGIN
		SET NOCOUNT ON;

		SELECT uid, usn FROM TombStones WHERE table_name= 'Hosts' AND usn > @row_usn
	END
GO

PRINT N'Creating [dbo].[ReportNaVFilerView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportNaVFilerView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportNaVFilerView]
GO

CREATE VIEW [dbo].[ReportNaVFilerView]
AS
	SELECT
		vFilers.[id],
		vFilers.[name],
		vFilers.[host_id],
		vFilers.[usn]
	FROM
		[dbo].[Backup.Model.NetAppVFilers] vFilers
GO

PRINT N'Creating [dbo].[ReportNaVFilerDeleteView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportNaVFilerDeleteView]') AND type in (N'P'))
	DROP PROCEDURE [dbo].[ReportNaVFilerDeleteView]
GO
	CREATE PROCEDURE [dbo].[ReportNaVFilerDeleteView]
		@row_usn bigint
	AS
	BEGIN
		SET NOCOUNT ON;
		SELECT uid, usn FROM TombStones WHERE table_name = '[dbo].[Backup.Model.NetAppVFilers]' AND usn > @row_usn
	END
GO

PRINT N'Creating [dbo].[ReportNaVServerView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportNaVServerView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportNaVServerView]
GO

CREATE VIEW [dbo].[ReportNaVServerView]
AS
	SELECT
		vServers.[id],
		vServers.[name],
		vServers.[host_id],
		vServers.[usn]
	FROM 
		[dbo].[Backup.Model.NetAppVServers] vServers
GO

PRINT N'Creating [dbo].[ReportNaVFilerDeleteView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportNaVServerDeleteView]') AND type in (N'P'))
	DROP PROCEDURE [dbo].[ReportNaVServerDeleteView]
GO
	CREATE PROCEDURE [dbo].[ReportNaVServerDeleteView]
		@row_usn bigint
	AS
	BEGIN
		SET NOCOUNT ON;
		SELECT uid, usn FROM TombStones WHERE table_name = '[dbo].[Backup.Model.NetAppVServers]' AND usn > @row_usn
	END
GO

PRINT N'Creating [dbo].[GetNaVmsByNamePart]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNaVmsByNamePart]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNaVmsByNamePart]
GO

CREATE PROCEDURE [dbo].[GetNaVmsByNamePart]
	@name_part nvarchar(max),
	@volume_id uniqueidentifier,
	@plugin_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		vms.*, volumes.name as volume_name, hosts.name as server_name
	FROM
	(
		SELECT
			*
		FROM
		(
			SELECT
				snapshotVmsView.*
				,RANK() OVER (PARTITION BY snapshotVmsView.obj_id ORDER BY snapshotVmsView.creation_time DESC) rank_creation_time
			FROM
				[dbo].[ReportSnapshotVmsView] snapshotVmsView
			WHERE
				snapshotVmsView.vm_name like @name_part
		) snapshotVmsWithRank
		WHERE 
			snapshotVmsWithRank.rank_creation_time = 1
	) vms
	join [dbo].[Backup.Model.SanSnapshots] snapshots
		join [dbo].[Backup.Model.SanVolumes] volumes
			join [dbo].[Hosts] hosts
				join [dbo].[Backup.Model.SanHostsPlugins] plugins
				on hosts.id = plugins.host_id 
			on volumes.host_id= hosts.id
		on volumes.id = snapshots.volume_id
	on vms.snapshot_id = snapshots.id
	WHERE 
		volumes.id = ISNULL (@volume_id, volumes.id) AND
		plugins.plugin_id = ISNULL (@plugin_id, plugins.plugin_id)
END
GO

PRINT N'Creating [dbo].[GetNaVmsOnClusterByNamePart]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNaVmsOnClusterByNamePart]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNaVmsOnClusterByNamePart]
GO

CREATE PROCEDURE [dbo].[GetNaVmsOnClusterByNamePart]
	@name_part nvarchar(max),
	@cluster_id uniqueidentifier,
	@vServer_id uniqueidentifier,
	@volume_id uniqueidentifier,
	@plugin_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		vms.*, volumes.name as volume_name, hosts.name as server_name
	FROM
	(
		SELECT 
			*
		FROM
		(
			SELECT
				snapshotVmsView.*
				,RANK() OVER (PARTITION BY snapshotVmsView.obj_id ORDER BY snapshotVmsView.creation_time DESC) rank_creation_time
			FROM
				[dbo].[ReportSnapshotVmsView] snapshotVmsView
			WHERE
				snapshotVmsView.vm_name like @name_part
		) snapshotVmsWithRank
		WHERE
			snapshotVmsWithRank.rank_creation_time = 1
	) vms
	join [dbo].[Backup.Model.SanSnapshots] snapshots
		join [dbo].[Backup.Model.SanVolumes] volumes
			join [dbo].[Backup.Model.NetAppVServers] vServers
				join [dbo].[Hosts] hosts
					join [dbo].[Backup.Model.SanHostsPlugins] plugins
					on hosts.id = plugins.host_id
				on vServers.host_id = hosts.id
			on volumes.parent_id= vServers.id
		on volumes.id = snapshots.volume_id
	on vms.snapshot_id = snapshots.id
	WHERE 
		hosts.id = ISNULL (@cluster_id, hosts.id) AND
		vServers.id = ISNULL (@vServer_id, vServers.id) AND
		volumes.id = ISNULL (@volume_id, volumes.id) AND
		plugins.plugin_id = ISNULL (@plugin_id, plugins.plugin_id)
END
GO

PRINT N'Creating [dbo].[GetNaVmsOnHostByNamePart]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNaVmsOnHostByNamePart]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNaVmsOnHostByNamePart]
GO

CREATE PROCEDURE [dbo].[GetNaVmsOnHostByNamePart]
	@name_part nvarchar(max),
	@host_id uniqueidentifier,
	@vFiler_id uniqueidentifier,
	@volume_id uniqueidentifier,
	@plugin_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		vms.*, volumes.name as volume_name, hosts.name as server_name
	FROM
	(
		SELECT 
			*
		FROM
		(
			SELECT 
				snapshotVmsView.*
				,RANK() OVER (PARTITION BY snapshotVmsView.obj_id ORDER BY snapshotVmsView.creation_time DESC) rank_creation_time
			FROM
				[dbo].[ReportSnapshotVmsView] snapshotVmsView
			WHERE 
				snapshotVmsView.vm_name like @name_part
		) snapshotVmsWithRank
		WHERE
			snapshotVmsWithRank.rank_creation_time = 1
	) vms
	join [dbo].[Backup.Model.SanSnapshots] snapshots
		join [dbo].[Backup.Model.SanVolumes] volumes
			join [dbo].[Backup.Model.NetAppVFilers] vFilers
				join [dbo].[Hosts] hosts
					join [dbo].[Backup.Model.SanHostsPlugins] plugins
					on hosts.id = plugins.host_id
				on vFilers.host_id = hosts.id
			on volumes.parent_id= vFilers.id
		on volumes.id = snapshots.volume_id
	on vms.snapshot_id = snapshots.id
	WHERE
		hosts.id = ISNULL (@host_id, hosts.id) AND
		vFilers.id = ISNULL (@vFiler_id, vFilers.id) AND
		volumes.id = ISNULL (@volume_id, volumes.id) AND
		plugins.plugin_id = ISNULL (@plugin_id, plugins.plugin_id)
END
GO

PRINT N'Creating [dbo].[AddNetAppvServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddNetAppvServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddNetAppvServerAdapter]
GO
	CREATE PROCEDURE [dbo].[AddNetAppvServerAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_vserver_id uniqueidentifier,
		@row_adapter_type int,
		@row_speed_mode int
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.NetAppVServerAdapters]
				([id], [ip], [vserver_id], [adapter_type], [speed_mode])
		 VALUES
				(@row_id, @row_ip, @row_vserver_id, @row_adapter_type, @row_speed_mode)
	END
GO

PRINT N'Creating [dbo].[UpdateNetAppvServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateNetAppvServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateNetAppvServerAdapter]
GO
	CREATE PROCEDURE [dbo].[UpdateNetAppvServerAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_vserver_id uniqueidentifier,
		@row_adapter_type int,
		@row_speed_mode int
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.NetAppVServerAdapters] SET
				[ip] = @row_ip,
				[vserver_id] = @row_vserver_id,
				[adapter_type] = @row_adapter_type,
				[speed_mode] = @row_speed_mode
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppvServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppvServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppvServerAdapter]
GO
	CREATE PROCEDURE [dbo].[GetNetAppvServerAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVServerAdapters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppAdapterInvServers]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppAdapterInvServers]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppAdapterInvServers]
GO
	CREATE PROCEDURE [dbo].[GetNetAppAdapterInvServers]
		@row_vserver_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVServerAdapters]
		WHERE vserver_id = @row_vserver_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppAdapterInvServerByType]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppAdapterInvServerByType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppAdapterInvServerByType]
GO
	CREATE PROCEDURE [dbo].[GetNetAppAdapterInvServerByType]
		@row_vserver_id uniqueidentifier,
		@row_adapter_type int
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVServerAdapters]
		WHERE vserver_id = @row_vserver_id AND adapter_type = @row_adapter_type
	END
GO

PRINT N'Creating [dbo].[DeleteNetAppvServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteNetAppvServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteNetAppvServerAdapter]
GO
	CREATE PROCEDURE [dbo].[DeleteNetAppvServerAdapter]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.NetAppVServerAdapters] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[AddNetAppVeeamSnapshot]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddNetAppVeeamSnapshot]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddNetAppVeeamSnapshot]
GO
	CREATE PROCEDURE [dbo].[AddNetAppVeeamSnapshot]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_volume_name nvarchar(255),
		@row_volume_id uniqueidentifier,
		@row_creation_time datetime
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.NetAppVeeamSnapshots]
				([id], [name], [volume_name], [volume_id], [creation_time])
		 VALUES
				(@row_id, @row_name, @row_volume_name, @row_volume_id, @row_creation_time)
	END
GO

PRINT N'Creating [dbo].[DeleteNetAppVeeamSnapshot]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteNetAppVeeamSnapshot]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteNetAppVeeamSnapshot]
GO
	CREATE PROCEDURE [dbo].[DeleteNetAppVeeamSnapshot]
		@row_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.NetAppVeeamSnapshots] WHERE id = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppVeeamSnapshotAll]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppVeeamSnapshotAll]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppVeeamSnapshotAll]
GO
	CREATE PROCEDURE [dbo].[GetNetAppVeeamSnapshotAll]
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVeeamSnapshots]
	END
GO

PRINT N'Creating [dbo].[GetNetAppVeeamSnapshotByVolumeId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppVeeamSnapshotByVolumeId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppVeeamSnapshotByVolumeId]
GO
	CREATE PROCEDURE [dbo].[GetNetAppVeeamSnapshotByVolumeId]
		@row_volume_id nvarchar(255)
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppVeeamSnapshots] WHERE [volume_id] = @row_volume_id
	END
GO

PRINT N'Creating [dbo].[ReportVnxDataMoverView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportVnxDataMoverView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportVnxDataMoverView]
GO

CREATE VIEW [dbo].[ReportVnxDataMoverView]
AS
	SELECT 
		dataMovers.[id],
		dataMovers.[name],
		dataMovers.[host_id],
		dataMovers.[usn]
	FROM 
		[dbo].[Backup.Model.VnxDataMovers] dataMovers
GO

PRINT N'Creating [dbo].[ReportVnxDataMoverDeleteView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportVnxDataMoverDeleteView]') AND type in (N'P'))
	DROP PROCEDURE [dbo].[ReportVnxDataMoverDeleteView]
GO
	CREATE PROCEDURE [dbo].[ReportVnxDataMoverDeleteView]
		@row_usn bigint
	AS
	BEGIN
		SET NOCOUNT ON;
		SELECT uid, usn FROM TombStones WHERE table_name = '[dbo].[Backup.Model.VnxDataMovers]' AND usn > @row_usn
	END
GO

PRINT N'Creating [dbo].[ReportVnxDataMoverView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportVnxDataMoverView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportVnxDataMoverView]
GO

CREATE VIEW [dbo].[ReportVnxDataMoverView]
AS
	SELECT
		dataMovers.[id],
		dataMovers.[name],
		dataMovers.[host_id],
		dataMovers.[usn]
	FROM 
		[dbo].[Backup.Model.VnxDataMovers] dataMovers
GO

PRINT N'Creating [dbo].[ReportVnxDataMoverDeleteView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportVnxDataMoverDeleteView]') AND type in (N'P'))
	DROP PROCEDURE [dbo].[ReportVnxDataMoverDeleteView]
GO
	CREATE PROCEDURE [dbo].[ReportVnxDataMoverDeleteView]
		@row_usn bigint
	AS
	BEGIN
		SET NOCOUNT ON;
		SELECT uid, usn FROM TombStones WHERE table_name = '[dbo].[Backup.Model.VnxDataMovers]' AND usn > @row_usn
	END
GO

PRINT N'Creating [dbo].[GetVnxVmsOnHostByNamePart]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxVmsOnHostByNamePart]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxVmsOnHostByNamePart]
GO

CREATE PROCEDURE [dbo].[GetVnxVmsOnHostByNamePart]
	@name_part nvarchar(max),
	@host_id uniqueidentifier,
	@volume_id uniqueidentifier,
	@plugin_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		vms.*, volumes.name as volume_name, hosts.name as server_name
	FROM
	(
		SELECT
			*
		FROM
		(
			SELECT
				snapshotVmsView.*
				,RANK() OVER (PARTITION BY snapshotVmsView.obj_id ORDER BY snapshotVmsView.creation_time DESC) rank_creation_time
			FROM
				[dbo].[ReportSnapshotVmsView] snapshotVmsView
			WHERE
				snapshotVmsView.vm_name like @name_part
		) snapshotVmsWithRank
		WHERE 
			snapshotVmsWithRank.rank_creation_time = 1
	) vms
	join [dbo].[Backup.Model.SanSnapshots] snapshots
		join [dbo].[Backup.Model.SanVolumes] volumes
				join [dbo].[Hosts] hosts
					join [dbo].[Backup.Model.SanHostsPlugins] plugins
					on hosts.id = plugins.host_id 
			on volumes.host_id= hosts.id
		on volumes.id = snapshots.volume_id
	on vms.snapshot_id = snapshots.id
	WHERE
		hosts.id = ISNULL (@host_id, hosts.id) AND
		volumes.id = ISNULL (@volume_id, volumes.id) AND
		plugins.plugin_id = ISNULL (@plugin_id, plugins.plugin_id)
END
GO

PRINT N'Creating [dbo].[GetVnxVmsOnDataMoverByNamePart]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxVmsOnDataMoverByNamePart]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxVmsOnDataMoverByNamePart]
GO

CREATE PROCEDURE [dbo].[GetVnxVmsOnDataMoverByNamePart]
	@name_part nvarchar(max),
	@host_id uniqueidentifier,
	@data_mover_id uniqueidentifier,
	@volume_id uniqueidentifier,
	@plugin_id uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		vms.*, volumes.name as volume_name, hosts.name as server_name
	FROM
	(
		SELECT
			*
		FROM
		(
			SELECT
				snapshotVmsView.*
				,RANK() OVER (PARTITION BY snapshotVmsView.obj_id ORDER BY snapshotVmsView.creation_time DESC) rank_creation_time
			FROM
				[dbo].[ReportSnapshotVmsView] snapshotVmsView
			WHERE
				snapshotVmsView.vm_name like @name_part
		) snapshotVmsWithRank
		WHERE
			snapshotVmsWithRank.rank_creation_time = 1
	) vms
	join [dbo].[Backup.Model.SanSnapshots] snapshots
		join [dbo].[Backup.Model.SanVolumes] volumes
			join [dbo].[Backup.Model.VnxDataMovers] data_mover
				join [dbo].[Hosts] hosts
					join [dbo].[Backup.Model.SanHostsPlugins] plugins
					on hosts.id = plugins.host_id
				on data_mover.host_id = hosts.id
			on volumes.parent_id= data_mover.id
		on volumes.id = snapshots.volume_id
	on vms.snapshot_id = snapshots.id
	WHERE
		hosts.id = ISNULL (@host_id, hosts.id) AND
		data_mover.id = ISNULL (@data_mover_id, data_mover.id) AND
		volumes.id = ISNULL (@volume_id, volumes.id) AND
		plugins.plugin_id = ISNULL (@plugin_id, plugins.plugin_id)
END
GO

PRINT N'Creating [dbo].[AddVnxDataMover]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddVnxDataMover]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddVnxDataMover]
GO
	CREATE PROCEDURE [dbo].[AddVnxDataMover]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_internal_id nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.VnxDataMovers]
				([id], [name], [internal_id], [host_id])
		 VALUES
				(@row_id, @row_name, @row_internal_id, @row_host_id)
	END
GO

PRINT N'Creating [dbo].[UpdateVnxDataMover]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateVnxDataMover]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateVnxDataMover]
GO
	CREATE PROCEDURE [dbo].[UpdateVnxDataMover]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_internal_id nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.VnxDataMovers] SET
				[name] = @row_name,
				[internal_id] = @row_internal_id,
				[host_id] = @row_host_id
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVnxDataMover]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxDataMover]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxDataMover]
GO
	CREATE PROCEDURE [dbo].[GetVnxDataMover]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VnxDataMovers]
		WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetAllVnxDataMovers]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllVnxDataMovers]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetAllVnxDataMovers]
GO
	CREATE PROCEDURE [dbo].[GetAllVnxDataMovers]
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VnxDataMovers]
	END
GO

PRINT N'Creating [dbo].[GetVnxDataMoversInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxDataMoversInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxDataMoversInHost]
GO
	CREATE PROCEDURE [dbo].[GetVnxDataMoversInHost]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VnxDataMovers]
		WHERE host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[GetVnxDataMoverByNameInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxDataMoverByNameInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxDataMoverByNameInHost]
GO
	CREATE PROCEDURE [dbo].[GetVnxDataMoverByNameInHost]
		@row_name nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VnxDataMovers]
		WHERE [name] = @row_name AND [host_id] = @row_host_id
	END
GO

PRINT N'Creating [dbo].[GetVnxDataMoverByFsNameInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxDataMoverByFsNameInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxDataMoverByFsNameInHost]
GO
	CREATE PROCEDURE [dbo].[GetVnxDataMoverByFsNameInHost]
		@row_fs_name nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT _dataMovers.*
		FROM [dbo].[Backup.Model.VnxDataMovers] as _dataMovers
			join [dbo].[Backup.Model.SanVolumes] as _sanVolumes on _sanVolumes.parent_id = _dataMovers.id
		WHERE _sanVolumes.name = @row_fs_name 
			AND _dataMovers.host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[DeleteVnxDataMover]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteVnxDataMover]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteVnxDataMover]
GO
	CREATE PROCEDURE [dbo].[DeleteVnxDataMover]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;

		DELETE [dbo].[Backup.Model.VnxDataMovers] 
		WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[AddVnxAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddVnxAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddVnxAdapter]
GO
	CREATE PROCEDURE [dbo].[AddVnxAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_data_mover_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.VnxAdapters]
				([id], [ip], [data_mover_id], [type], [speed_mode])
		 VALUES
				(@row_id, @row_ip, @row_data_mover_id, @row_type, @row_speed_mode)
	END
GO

PRINT N'Creating [dbo].[UpdateVnxAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateVnxAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateVnxAdapter]
GO
	CREATE PROCEDURE [dbo].[UpdateVnxAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_data_mover_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.VnxAdapters] SET
				[ip] = @row_ip,
				[data_mover_id] = @row_data_mover_id,
				[type] = @row_type,
				[speed_mode] = @row_speed_mode
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVnxAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxAdapter]
GO
	CREATE PROCEDURE [dbo].[GetVnxAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VnxAdapters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVnxAdaptersInDM]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxAdaptersInDM]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxAdaptersInDM]
GO
	CREATE PROCEDURE [dbo].[GetVnxAdaptersInDM]
		@row_data_mover_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VnxAdapters]
		WHERE data_mover_id = @row_data_mover_id
	END
GO

PRINT N'Creating [dbo].[GetVnxAdaptersInDmByType]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxAdaptersInDmByType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxAdaptersInDmByType]
GO
	CREATE PROCEDURE [dbo].[GetVnxAdaptersInDmByType]
		@row_data_mover_id uniqueidentifier,
		@row_type int
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VnxAdapters]
		WHERE data_mover_id = @row_data_mover_id AND type = @row_type
	END
GO

PRINT N'Creating [dbo].[DeleteVnxAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteVnxAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteVnxAdapter]
GO
	CREATE PROCEDURE [dbo].[DeleteVnxAdapter]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.VnxAdapters] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[GetVnxAdaptersInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVnxAdaptersInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVnxAdaptersInHost]
GO
	CREATE PROCEDURE [dbo].[GetVnxAdaptersInHost]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT _adapters.*
		FROM [dbo].[Backup.Model.VnxAdapters] as _adapters
			join [dbo].[Backup.Model.VnxDataMovers] as _dataMovers on _adapters.data_mover_id = _dataMovers.id
		WHERE 
			_dataMovers.host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[AddVNXeNasServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddVNXeNasServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddVNXeNasServer]
GO
	CREATE PROCEDURE [dbo].[AddVNXeNasServer]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_internal_id nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.VNXeNasServers]
				([id], [name], [internal_id], [host_id])
		 VALUES
				(@row_id, @row_name, @row_internal_id, @row_host_id)
	END
GO

PRINT N'Creating [dbo].[UpdateVNXeNasServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateVNXeNasServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateVNXeNasServer]
GO
	CREATE PROCEDURE [dbo].[UpdateVNXeNasServer]
		@row_id uniqueidentifier,
		@row_name nvarchar(255),
		@row_internal_id nvarchar(255),
		@row_host_id uniqueidentifier
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.VNXeNasServers] SET
				[name] = @row_name,
				[internal_id] = @row_internal_id,
				[host_id] = @row_host_id
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVNXeNasServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeNasServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeNasServer]
GO
	CREATE PROCEDURE [dbo].[GetVNXeNasServer]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeNasServers]
		WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetAllVNXeNasServers]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetAllVNXeNasServers]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetAllVNXeNasServers]
GO
	CREATE PROCEDURE [dbo].[GetAllVNXeNasServers]
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeNasServers]
	END
GO

PRINT N'Creating [dbo].[GetVNXeNasServersInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeNasServersInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeNasServersInHost]
GO
	CREATE PROCEDURE [dbo].[GetVNXeNasServersInHost]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeNasServers]
		WHERE host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[DeleteVNXeNasServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteVNXeNasServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteVNXeNasServer]
GO
	CREATE PROCEDURE [dbo].[DeleteVNXeNasServer]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.VNXeNasServers] 
		WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[AddVNXeNasServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddVNXeNasServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddVNXeNasServerAdapter]
GO
	CREATE PROCEDURE [dbo].[AddVNXeNasServerAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_nas_server_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.VNXeNasServerAdapters]
				([id], [ip], [nas_server_id], [type], [speed_mode])
		 VALUES
				(@row_id, @row_ip, @row_nas_server_id, @row_type, @row_speed_mode)
	END
GO

PRINT N'Creating [dbo].[UpdateVNXeNasServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateVNXeNasServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateVNXeNasServerAdapter]
GO
	CREATE PROCEDURE [dbo].[UpdateVNXeNasServerAdapter]
		@row_id uniqueidentifier,
		@row_ip nvarchar(255),
		@row_nas_server_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.VNXeNasServerAdapters] SET
				[ip] = @row_ip,
				[nas_server_id] = @row_nas_server_id,
				[type] = @row_type,
				[speed_mode] = @row_speed_mode
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVNXeNasServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeNasServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeNasServerAdapter]
GO
	CREATE PROCEDURE [dbo].[GetVNXeNasServerAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeNasServerAdapters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVNXeNasServerAdaptersInNasServer]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeNasServerAdaptersInNasServer]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeNasServerAdaptersInNasServer]
GO
	CREATE PROCEDURE [dbo].[GetVNXeNasServerAdaptersInNasServer]
		@row_nas_server_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeNasServerAdapters]
		WHERE nas_server_id = @row_nas_server_id
	END
GO

PRINT N'Creating [dbo].[GetVNXeNasServerAdaptersInNasServerByType]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeNasServerAdaptersInNasServerByType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeNasServerAdaptersInNasServerByType]
GO
	CREATE PROCEDURE [dbo].[GetVNXeNasServerAdaptersInNasServerByType]
		@row_nas_server_id uniqueidentifier,
		@row_type int
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeNasServerAdapters]
		WHERE nas_server_id = @row_nas_server_id AND type = @row_type
	END
GO

PRINT N'Creating [dbo].[DeleteVNXeNasServerAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteVNXeNasServerAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteVNXeNasServerAdapter]
GO
	CREATE PROCEDURE [dbo].[DeleteVNXeNasServerAdapter]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.VNXeNasServerAdapters] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[AddVNXeBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddVNXeBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddVNXeBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[AddVNXeBlockAdapter]
		@row_id uniqueidentifier,
		@row_iqn_or_wwn nvarchar(255),
		@row_ip nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.VNXeBlockAdapters]
				([id], [iqn_or_wwn], [ip], [host_id], [type], [speed_mode])
		 VALUES
				(@row_id, @row_iqn_or_wwn, @row_ip, @row_host_id, @row_type, @row_speed_mode)
	END
GO

PRINT N'Creating [dbo].[UpdateVNXeBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateVNXeBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateVNXeBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[UpdateVNXeBlockAdapter]
		@row_id uniqueidentifier,
		@row_iqn_or_wwn nvarchar(255),
		@row_ip nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.VNXeBlockAdapters] SET
				[iqn_or_wwn] = @row_iqn_or_wwn,
				[ip] = @row_ip,
				[host_id] = @row_host_id,
				[type] = @row_type,
				[speed_mode] = @row_speed_mode
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVNXeBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[GetVNXeBlockAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeBlockAdapters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVNXeBlockAdaptersInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeBlockAdaptersInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeBlockAdaptersInHost]
GO
	CREATE PROCEDURE [dbo].[GetVNXeBlockAdaptersInHost]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeBlockAdapters]
		WHERE host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[GetVNXeBlockAdaptersInHostByType]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXeBlockAdaptersInHostByType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXeBlockAdaptersInHostByType]
GO
	CREATE PROCEDURE [dbo].[GetVNXeBlockAdaptersInHostByType]
		@row_host_id uniqueidentifier,
		@row_type int
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXeBlockAdapters]
		WHERE host_id = @row_host_id AND type = @row_type
	END
GO

PRINT N'Creating [dbo].[DeleteVNXeBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteVNXeBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteVNXeBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[DeleteVNXeBlockAdapter]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.VNXeBlockAdapters] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[ReportVnxServerView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportVnxServerView]') AND type in (N'V'))
	DROP VIEW [dbo].[ReportVnxServerView]
GO

CREATE VIEW [dbo].[ReportVnxServerView]
AS
SELECT
		[dbo].[Hosts].[id],
		[dbo].[Hosts].[name],
		[dbo].[Hosts].[description],
		[dbo].[Hosts].[type],
		[dbo].[Hosts].[options],
		[dbo].[Hosts].[parent_id],
		[dbo].[Hosts].[usn],
		plugins.plugin_id
	FROM 
		[dbo].[Hosts] LEFT JOIN [Backup.Model.SanHostsPlugins] plugins ON [dbo].[Hosts].id = plugins.host_id
GO

PRINT N'Creating [dbo].[ReportVnxServerDeleteView]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportVnxServerDeleteView]') AND type in (N'P'))
	DROP PROCEDURE [dbo].[ReportVnxServerDeleteView]
GO
	CREATE PROCEDURE [dbo].[ReportVnxServerDeleteView]
		@row_usn bigint
	AS
	BEGIN
		SET NOCOUNT ON;
		SELECT uid, usn FROM TombStones WHERE table_name= 'Hosts' AND usn > @row_usn
	END
GO

PRINT N'Creating [dbo].[AddVNXBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddVNXBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[AddVNXBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[AddVNXBlockAdapter]
		@row_id uniqueidentifier,
		@row_iqn_or_wwn nvarchar(255),
		@row_ip nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.VNXBlockAdapters]
				([id], [iqn_or_wwn], [ip], [host_id], [type], [speed_mode])
		 VALUES
				(@row_id, @row_iqn_or_wwn, @row_ip, @row_host_id, @row_type, @row_speed_mode)
	END
GO

PRINT N'Creating [dbo].[UpdateVNXBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateVNXBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[UpdateVNXBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[UpdateVNXBlockAdapter]
		@row_id uniqueidentifier,
		@row_iqn_or_wwn nvarchar(255),
		@row_ip nvarchar(255),
		@row_host_id uniqueidentifier,
		@row_type int,
		@row_speed_mode int
	AS
	BEGIN
		UPDATE [dbo].[Backup.Model.VNXBlockAdapters] SET
				[iqn_or_wwn] = @row_iqn_or_wwn,
				[ip] = @row_ip,
				[host_id] = @row_host_id,
				[type] = @row_type,
				[speed_mode] = @row_speed_mode
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVNXBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[GetVNXBlockAdapter]
		@row_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXBlockAdapters]
				WHERE [id] = @row_id
	END
GO

PRINT N'Creating [dbo].[GetVNXBlockAdaptersInHost]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXBlockAdaptersInHost]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXBlockAdaptersInHost]
GO
	CREATE PROCEDURE [dbo].[GetVNXBlockAdaptersInHost]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXBlockAdapters]
		WHERE host_id = @row_host_id
	END
GO

PRINT N'Creating [dbo].[GetVNXBlockAdaptersInHostByType]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetVNXBlockAdaptersInHostByType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetVNXBlockAdaptersInHostByType]
GO
	CREATE PROCEDURE [dbo].[GetVNXBlockAdaptersInHostByType]
		@row_host_id uniqueidentifier,
		@row_type int
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.VNXBlockAdapters]
		WHERE host_id = @row_host_id AND type = @row_type
	END
GO

PRINT N'Creating [dbo].[DeleteVNXBlockAdapter]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteVNXBlockAdapter]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteVNXBlockAdapter]
GO
	CREATE PROCEDURE [dbo].[DeleteVNXBlockAdapter]
		@id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.VNXBlockAdapters] WHERE id = @id
	END
GO

PRINT N'Creating [dbo].[CreateNetAppSnapshotJobInfo]'

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CreateNetAppSnapshotJobInfo]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CreateNetAppSnapshotJobInfo]
GO
	CREATE PROCEDURE [dbo].[CreateNetAppSnapshotJobInfo]
		@row_id uniqueidentifier,
		@row_snapshot_name nvarchar(255),
		@row_snapshot_uuid nvarchar(255),
		@row_snapshot_logical_uuid nvarchar(255),
        @row_volume_name nvarchar(255),
		@row_volume_uuid nvarchar(255),
		@row_host_id uniqueidentifier,
        @row_job_id uniqueidentifier,
		@row_type int
	AS
	BEGIN
		INSERT INTO [dbo].[Backup.Model.NetAppSnapshotJobInfos]
				([id], [snapshot_name], [snapshot_uuid], [snapshot_logical_uuid], [volume_name], [volume_uuid], [host_id], [job_id], [type])
		 VALUES
				(@row_id, @row_snapshot_name, @row_snapshot_uuid, @row_snapshot_logical_uuid, @row_volume_name, @row_volume_uuid, @row_host_id, @row_job_id, @row_type)
	END
GO


PRINT N'Creating [dbo].[DeleteNetAppSnapshotJobInfo]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeleteNetAppSnapshotJobInfo]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[DeleteNetAppSnapshotJobInfo]
GO
	CREATE PROCEDURE [dbo].[DeleteNetAppSnapshotJobInfo]
		@row_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		DELETE [dbo].[Backup.Model.NetAppSnapshotJobInfos] WHERE id = @row_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppSnapshotJobInfoAll]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppSnapshotJobInfoAll]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppSnapshotJobInfoAll]
GO
	CREATE PROCEDURE [dbo].[GetNetAppSnapshotJobInfoAll]
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppSnapshotJobInfos]
	END
GO

PRINT N'Creating [dbo].[GetNetAppSnapshotJobInfoByJobId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppSnapshotJobInfoByJobId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppSnapshotJobInfoByJobId]
GO
	CREATE PROCEDURE [dbo].[GetNetAppSnapshotJobInfoByJobId]
		@row_job_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppSnapshotJobInfos] WHERE [job_id] = @row_job_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppSnapshotJobInfoByHostId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppSnapshotJobInfoByHostId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppSnapshotJobInfoByHostId]
GO
	CREATE PROCEDURE [dbo].[GetNetAppSnapshotJobInfoByHostId]
		@row_host_id uniqueidentifier
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppSnapshotJobInfos] WHERE [host_id] = @row_host_id
	END
GO

PRINT N'Creating [dbo].[GetNetAppSnapshotJobInfoByVolumeUuid]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppSnapshotJobInfoByVolumeUuid]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppSnapshotJobInfoByVolumeUuid]
GO
	CREATE PROCEDURE [dbo].[GetNetAppSnapshotJobInfoByVolumeUuid]
		@row_volume_uuid nvarchar(255)
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppSnapshotJobInfos] WHERE [volume_uuid] = @row_volume_uuid 
	END
GO     

PRINT N'Creating [dbo].[GetNetAppVolumeSnapshotJobInfos]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetNetAppVolumeSnapshotJobInfos]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[GetNetAppVolumeSnapshotJobInfos]
GO
	CREATE PROCEDURE [dbo].[GetNetAppVolumeSnapshotJobInfos]
		@row_job_id uniqueidentifier,
		@row_host_id uniqueidentifier,
		@row_volume_uuid nvarchar(255),
		@row_type int
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppSnapshotJobInfos] WHERE 
			[job_id] = @row_job_id AND 
			[host_id] = @row_host_id AND 
			[volume_uuid]  = @row_volume_uuid AND 
			[type] = @row_type
	END
GO  

PRINT N'Creating [dbo].[FindNetAppSnapshotJobInfo]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindNetAppSnapshotJobInfo]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindNetAppSnapshotJobInfo]
GO
	CREATE PROCEDURE [dbo].[FindNetAppSnapshotJobInfo]		
		@row_host_id uniqueidentifier,
		@row_volume_uuid nvarchar(255),
		@row_snapshot_uuid nvarchar(255)
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppSnapshotJobInfos] WHERE 			
			[host_id] = @row_host_id AND 
			[volume_uuid]  = @row_volume_uuid AND 
			[snapshot_uuid]  = @row_snapshot_uuid
	END
GO

PRINT N'Creating [dbo].[FindNetAppSnapshotJobInfoByLogicalUuid]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindNetAppSnapshotJobInfoByLogicalUuid]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[FindNetAppSnapshotJobInfoByLogicalUuid]
GO
	CREATE PROCEDURE [dbo].[FindNetAppSnapshotJobInfoByLogicalUuid]		
		@row_host_id uniqueidentifier,
		@row_volume_uuid nvarchar(255),
		@row_snapshot_logical_uuid nvarchar(255)
	AS
	BEGIN
		SELECT * FROM [dbo].[Backup.Model.NetAppSnapshotJobInfos] WHERE 			
			[host_id] = @row_host_id AND 
			[volume_uuid]  = @row_volume_uuid AND 
			[snapshot_logical_uuid]  = @row_snapshot_logical_uuid
	END
GO

PRINT N'Creating [dbo].[IsSanHostExistsByPluginId]'
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IsSanHostExistsByPluginId]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[IsSanHostExistsByPluginId]
GO
	CREATE PROCEDURE [dbo].[IsSanHostExistsByPluginId]
		@plugin_id uniqueidentifier
	AS
	BEGIN
		SET NOCOUNT ON;
		IF EXISTS (SELECT * FROM [dbo].[Backup.Model.SanHostsPlugins] WHERE [plugin_id] = @plugin_id)
			SELECT 1 result
		ELSE
			SELECT 0 result
	END
GO